"""Estilo visual de Lumati: la paleta de la interfaz en un solo lugar, paneles
blancos tipo estación espacial ("blanco de médico"), casillas, íconos dibujados
por código y un sistema de partículas muy simple.

Este archivo SOLO dibuja: no tiene reglas del juego ni valores de balance.
main.py lo usa para que el inventario, las barras, la barra de herramientas y
los avisos se vean del mismo estilo. Todo el arte de aquí es propio (rectángulos
y polígonos de pygame); no usa imágenes de otros juegos.

Para cambiar el aspecto de toda la interfaz basta con cambiar los colores de la
sección "Paleta".
"""

import math
import random

import pygame

# --------------------------------------------------------------------------
# Paleta (única para toda la interfaz)
# --------------------------------------------------------------------------
# Estilo espacial "blanco de médico": blancos y grises claros, limpio como el
# interior de una estación, con un acento frío (cian) discreto. El texto es gris
# casi negro para que se lea bien sobre el blanco.
CONTORNO = (58, 70, 86)             # línea exterior de paneles y casillas (gris pizarra)
MARCO = (196, 206, 217)             # marco de los paneles (gris claro azulado)
BISEL = (208, 215, 224)             # sombra interior del panel y separadores
PANEL = (243, 245, 247)             # fondo de los paneles (blanco clínico)
PANEL_LUZ = (255, 255, 255)         # brillo del borde de arriba y de la izquierda
CASILLA = (229, 233, 238)           # casilla vacía (gris muy claro)
CASILLA_SOMBRA = (198, 206, 216)    # borde interior de la casilla
CASILLA_ACTIVA = (222, 239, 248)    # casilla elegida (cian muy pálido)
ACENTO = (62, 150, 190)             # acento frío: franja de los paneles y borde de lo elegido
TINTA = (30, 38, 50)                # texto sobre blanco
TINTA_SUAVE = (98, 110, 126)        # texto secundario
CREMA = (255, 255, 255)             # texto claro sobre fondos oscuros
FALTA = (186, 62, 44)               # "te falta este recurso" (no es el rojo de las luces)
OK = TINTA                          # palomita de "alcanza" (forma, no color)
FONDO_BARRA = (64, 74, 88)          # fondo de las barras vitales (oscuro: los colores resaltan)
SOMBRA = (0, 0, 0, 70)              # sombra suave bajo paneles, máquinas y astronauta
# Nombres de la paleta anterior (madera), por si algo todavía los usa.
MADERA_OSCURA = MARCO
MADERA = BISEL

POLVO = [(214, 214, 220), (188, 188, 194), (160, 160, 166)]         # polvo lunar
POLVO_MARTE = [(236, 176, 132), (216, 150, 108), (150, 84, 56)]     # polvo marciano
CHISPA = [(255, 255, 255), (170, 222, 245)]                          # al construir o recoger
RACHA_POLVO = (244, 206, 166)                                        # rachas de la tormenta de polvo

BORDE_PANEL = 4                     # grosor total del marco de un panel, en píxeles


# --------------------------------------------------------------------------
# Paneles y casillas
# --------------------------------------------------------------------------
_sombras = {}                       # (ancho, alto) -> superficie de sombra ya hecha


def sombra(pantalla, rect, desplazar=(3, 4), radio=6):
    """Sombra suave (un rectángulo negro translúcido) debajo de `rect`."""
    clave = (rect.width, rect.height, radio)
    imagen = _sombras.get(clave)
    if imagen is None:
        imagen = pygame.Surface(rect.size, pygame.SRCALPHA)
        pygame.draw.rect(imagen, SOMBRA, imagen.get_rect(), border_radius=radio)
        if len(_sombras) > 200:     # los avisos cambian de tamaño: que la caché no crezca sin fin
            _sombras.clear()
        _sombras[clave] = imagen
    pantalla.blit(imagen, (rect.x + desplazar[0], rect.y + desplazar[1]))


def panel(pantalla, rect, con_sombra=True, borde=None):
    """Panel blanco: contorno oscuro, marco gris claro, fondo blanco, un brillo
    arriba a la izquierda y una franja fina del acento frío arriba. `borde`
    cambia el color del marco (avisos de tormenta)."""
    rect = pygame.Rect(rect)
    if con_sombra:
        sombra(pantalla, rect)
    pygame.draw.rect(pantalla, CONTORNO, rect, border_radius=6)
    pygame.draw.rect(pantalla, borde or MARCO, rect.inflate(-2, -2), border_radius=5)
    dentro = rect.inflate(-2 * BORDE_PANEL, -2 * BORDE_PANEL)
    pygame.draw.rect(pantalla, PANEL, dentro, border_radius=3)
    # Bisel: una línea clara arriba y a la izquierda, una gris abajo y a la derecha.
    pygame.draw.line(pantalla, PANEL_LUZ, dentro.topleft, (dentro.right - 1, dentro.top))
    pygame.draw.line(pantalla, PANEL_LUZ, dentro.topleft, (dentro.left, dentro.bottom - 1))
    pygame.draw.line(pantalla, BISEL, (dentro.left, dentro.bottom - 1), (dentro.right - 1, dentro.bottom - 1))
    pygame.draw.line(pantalla, BISEL, (dentro.right - 1, dentro.top), (dentro.right - 1, dentro.bottom - 1))
    if dentro.width > 40 and dentro.height > 20:     # franja del acento (como una luz de estación)
        pygame.draw.line(pantalla, ACENTO, (dentro.left + 6, dentro.top + 1), (dentro.right - 7, dentro.top + 1), 2)
    return dentro


def casilla(pantalla, rect, activa=False, mouse=False):
    """Casilla de inventario u objeto: hundida, gris muy claro. La elegida lleva
    borde grueso del acento frío; la que está bajo el mouse, borde gris."""
    rect = pygame.Rect(rect)
    pygame.draw.rect(pantalla, CONTORNO, rect, border_radius=4)
    dentro = rect.inflate(-4, -4)
    pygame.draw.rect(pantalla, CASILLA_ACTIVA if activa else CASILLA, dentro, border_radius=2)
    # Hundida: sombra arriba y a la izquierda.
    pygame.draw.line(pantalla, CASILLA_SOMBRA, dentro.topleft, (dentro.right - 1, dentro.top), 2)
    pygame.draw.line(pantalla, CASILLA_SOMBRA, dentro.topleft, (dentro.left, dentro.bottom - 1), 2)
    if activa:
        pygame.draw.rect(pantalla, ACENTO, rect.inflate(-2, -2), 3, border_radius=4)
        pygame.draw.rect(pantalla, CONTORNO, rect.inflate(4, 4), 2, border_radius=6)
    elif mouse:
        pygame.draw.rect(pantalla, TINTA_SUAVE, rect.inflate(-2, -2), 2, border_radius=4)
    return dentro


def separador(pantalla, x0, x1, y):
    """Línea horizontal entre dos partes de un panel."""
    pygame.draw.line(pantalla, BISEL, (x0, y), (x1, y))
    pygame.draw.line(pantalla, PANEL_LUZ, (x0, y + 1), (x1, y + 1))


def barra(pantalla, rect, fraccion, color, borde=CONTORNO):
    """Barra de progreso con fondo oscuro, relleno de color y un brillo arriba."""
    rect = pygame.Rect(rect)
    pygame.draw.rect(pantalla, FONDO_BARRA, rect, border_radius=3)
    ancho = int((rect.width - 4) * max(0.0, min(1.0, fraccion)))
    if ancho > 0:
        relleno = pygame.Rect(rect.x + 2, rect.y + 2, ancho, rect.height - 4)
        pygame.draw.rect(pantalla, color, relleno, border_radius=2)
        claro = tuple(min(255, int(c * 1.2) + 12) for c in color)
        pygame.draw.line(pantalla, claro, (relleno.x + 1, relleno.y), (relleno.right - 2, relleno.y))
    pygame.draw.rect(pantalla, borde, rect, 2, border_radius=3)


def mezclar(a, b, t):
    """Color entre a y b (t de 0 a 1). Sirve para pulsos suaves, sin parpadeo."""
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def pulso(periodo=1.6):
    """Número que sube y baja despacio entre 0 y 1 (un ciclo cada `periodo`
    segundos). Reemplaza a los parpadeos bruscos: menos de 1 destello por segundo."""
    return (math.sin(pygame.time.get_ticks() / 1000.0 * 2 * math.pi / periodo) + 1) / 2


# --------------------------------------------------------------------------
# Íconos dibujados por código (pixel art propio)
# --------------------------------------------------------------------------
def _de_mapa(filas, colores, escala):
    """Imagen a partir de un dibujo hecho con letras: cada letra es un color de
    `colores` y el punto es transparente. Se agranda `escala` veces sin suavizar."""
    alto, ancho = len(filas), len(filas[0])
    imagen = pygame.Surface((ancho, alto), pygame.SRCALPHA)
    for y, fila in enumerate(filas):
        for x, letra in enumerate(fila):
            if letra != ".":
                imagen.set_at((x, y), colores[letra])
    return pygame.transform.scale(imagen, (ancho * escala, alto * escala))


def _tonos(color):
    """(oscuro, base, claro) de un color, para sombrear un ícono."""
    oscuro = tuple(int(c * 0.6) for c in color)
    claro = tuple(min(255, int(c * 1.18) + 14) for c in color)
    return oscuro, color, claro


# Íconos de las 4 barras vitales (8x8). o = contorno, b = color de la barra, c = brillo.
_MAPAS_BARRA = {
    "oxigeno": ["..oooo..",       # burbuja de aire
                ".obbbbo.",
                "obcbbbbo",
                "obcbbbbo",
                "obbbbbbo",
                "obbbbbbo",
                ".obbbbo.",
                "..oooo.."],
    "energia": ["...ooo..",       # rayo
                "..obbo..",
                ".obbo...",
                "obbbboo.",
                ".oobbbo.",
                "..obbo..",
                ".obbo...",
                ".ooo...."],
    "comida": ["......oo",        # hoja
               "...ooobo",
               "..obbbbo",
               ".obbcbo.",
               ".obcbbo.",
               ".obbbo..",
               "obooo...",
               "oo......"],
    "dosis": ["...oo...",         # destello de radiación (rayos saliendo de un centro)
              ".o.bb.o.",
              "..obbo..",
              "obbccbbo",
              "obbccbbo",
              "..obbo..",
              ".o.bb.o.",
              "...oo..."],
}


def icono_barra(nombre, color, escala=2):
    """Ícono de una barra vital, con el color de esa barra. Así cada barra se
    reconoce por su dibujo y no solo por el color."""
    _, base, claro = _tonos(color)
    return _de_mapa(_MAPAS_BARRA[nombre], {"o": CONTORNO, "b": base, "c": claro}, escala)


# Íconos de los recursos (12x12). o contorno, s sombra, b base, c claro.
_MAPAS_RECURSO = {
    "regolito": ["............",      # montoncito de polvo y piedras
                 "............",
                 ".....oo.....",
                 "....occo....",
                 "...ocbbso...",
                 "..ocbbbbso..",
                 ".ocbbbcbbso.",
                 ".obbbsbbbbso",
                 "obbcbbbbsbso",
                 "obbbbbsbbbso",
                 ".oooooooooo.",
                 "............"],
    "hielo": ["............",         # cubo de hielo
              "..oooooooo..",
              ".occccccccoo",
              "occccccccobo",
              "oooooooooobo",
              "obbbbbbbbobo",
              "obcbbbbbbobo",
              "obcbbbbbbobo",
              "obbbbbbbbobo",
              "obbbbbbbsoo.",
              "oooooooooo..",
              "............"],
    "hierro": ["............",        # mena angulosa
               "....oooo....",
               "...occbboo..",
               "..ocbbbbbso.",
               ".ocbbsbbbbso",
               ".obbbbbcbbso",
               "obbcbbbbbsso",
               "obbbbsbbbso.",
               ".osbbbbbsso.",
               "..oosssoo...",
               "....ooo.....",
               "............"],
    "metal": ["............",         # lingote
              "............",
              "...ooooooo..",
              "..occccccco.",
              ".occccccccso",
              ".ooooooooosso",
              "obbbbbbbbosso",
              "obbcbbbbbosso",
              "obbbbbbbboso.",
              "ooooooooooo..",
              "............",
              "............"],
    "cristal": ["............",       # gema
                ".....oo.....",
                "....occo....",
                "...occbso...",
                "..occbbsso..",
                ".occbbbbsso.",
                ".obbbbbbsso.",
                "..obbbbsso..",
                "...obbsso...",
                "....obso....",
                ".....oo.....",
                "............"],
    "agua": ["............",          # gota
             ".....oo.....",
             "....obbo....",
             "....obbo....",
             "...obbbbo...",
             "..obcbbbbo..",
             ".obcbbbbbso.",
             ".obcbbbbbso.",
             ".obbbbbbsso.",
             "..obbbssoo..",
             "...oooooo...",
             "............"],
}
# El lingote se dibujó con filas de 13: se recorta a 12 para que todas midan igual.
_MAPAS_RECURSO = {n: [fila[:12] for fila in filas] for n, filas in _MAPAS_RECURSO.items()}


def icono_recurso(nombre, color, escala=3):
    """Ícono de un recurso del inventario, sombreado a partir de su color."""
    oscuro, base, claro = _tonos(color)
    return _de_mapa(_MAPAS_RECURSO[nombre], {"o": CONTORNO, "s": oscuro, "b": base, "c": claro}, escala)


# Equipo con el que empieza el astronauta (12x12). m = mango, g = metal, c = brillo, a = agua.
_MAPAS_EQUIPO = {
    "pico": ["............",
             "..ooooooo...",
             ".ogggggggo..",
             "ogcoooooggo.",
             "oo...omo.ogo",
             ".....omo..oo",
             "....omo.....",
             "...omo......",
             "..omo.......",
             ".omo........",
             "omo.........",
             "oo.........."],
    "regadera": ["............",
                 "............",
                 "oo....ooo...",
                 "oao..o...o..",
                 ".oaoooooooo.",
                 "..ogggggggo.",
                 "..ogcgggggo.",
                 "..ogcgggggo.",
                 "..ogggggggo.",
                 "..ogggggggo.",
                 "...ooooooo..",
                 "............"],
    "taladro": ["............",
                ".oooooooooo.",
                ".oggggggggo.",
                ".ogcggggogo.",
                ".oggggggggo.",
                ".oooooooooo.",
                "...oggggo...",
                "...ogcggo...",
                "....oggo....",
                "....oggo....",
                ".....oo.....",
                "............"],
}


def icono_equipo(nombre, escala=3):
    """Ícono del pico, la regadera o el taladro básico."""
    colores = {"o": CONTORNO, "m": (150, 96, 52), "g": (150, 162, 176),
               "c": (214, 224, 234), "a": (120, 200, 235)}
    return _de_mapa(_MAPAS_EQUIPO[nombre], colores, escala)


def vineta(tam, color, grosor=0.28):
    """Imagen del tamaño de la ventana, transparente en el centro y de `color`
    hacia los bordes. Se hace una sola vez, en chico, y se agranda suavizada."""
    ancho, alto = tam[0] // 10, tam[1] // 10
    chica = pygame.Surface((ancho, alto), pygame.SRCALPHA)
    for y in range(alto):
        for x in range(ancho):
            # 0 en el centro, 1 en el borde (lo que esté más cerca de una orilla manda)
            dx = abs(x - (ancho - 1) / 2) / ((ancho - 1) / 2)
            dy = abs(y - (alto - 1) / 2) / ((alto - 1) / 2)
            borde = max(dx, dy)
            fuerza = max(0.0, (borde - (1 - grosor)) / grosor)
            chica.set_at((x, y), (*color, int(255 * fuerza * fuerza)))
    return pygame.transform.smoothscale(chica, tam)


# --------------------------------------------------------------------------
# Partículas
# --------------------------------------------------------------------------
class Particulas:
    """Cuadritos de color que salen, se frenan, se achican y desaparecen: polvo
    al caminar, un soplo al construir, chispas al recoger. Son solo adorno: no
    cambian nada del juego. Guardan coordenadas del MUNDO; quien las dibuja
    decide dónde caen en pantalla (así funcionan con el mapa que da la vuelta).
    Hay un máximo para que nunca pesen."""

    MAXIMO = 160

    def __init__(self, semilla=11):
        self._azar = random.Random(semilla)
        self.lista = []             # [x, y, vx, vy, vida, vida_total, color, tamaño]

    def emitir(self, x, y, colores, cantidad=6, velocidad=45.0, vida=0.5, tam=6, subir=0.0):
        """Suelta `cantidad` partículas en (x, y) del mundo, en todas direcciones.
        `subir` les da un empujón hacia arriba (chispas que flotan)."""
        azar = self._azar
        for _ in range(cantidad):
            if len(self.lista) >= self.MAXIMO:
                return
            angulo = azar.uniform(0, 2 * math.pi)
            rapidez = azar.uniform(0.3, 1.0) * velocidad
            duracion = azar.uniform(0.6, 1.0) * vida
            self.lista.append([x + azar.uniform(-4, 4), y + azar.uniform(-3, 3),
                               math.cos(angulo) * rapidez, math.sin(angulo) * rapidez * 0.6 - subir,
                               duracion, duracion, azar.choice(colores), tam])

    def actualizar(self, dt):
        vivas = []
        freno = max(0.0, 1.0 - 4.0 * dt)        # se frenan pronto (poca gravedad, mucho polvo)
        for p in self.lista:
            p[4] -= dt
            if p[4] <= 0:
                continue
            p[0] += p[2] * dt
            p[1] += p[3] * dt
            p[2] *= freno
            p[3] *= freno
            vivas.append(p)
        self.lista = vivas

    def dibujar(self, pantalla, a_pantalla):
        """a_pantalla(x, y) convierte del mundo a la pantalla."""
        for x, y, _, _, vida, total, color, tam in self.lista:
            lado = max(2, int(tam * (0.35 + 0.65 * vida / total)))
            px, py = a_pantalla(x, y)
            pygame.draw.rect(pantalla, color, (px - lado // 2, py - lado // 2, lado, lado))

    def vaciar(self):
        self.lista = []
