"""Taladros y recursos del terreno. Lógica pura: no usa pygame, así que se
puede probar sin abrir una ventana.

Todos los valores de balance están aquí arriba para ajustarlos fácil
(dificultad fácil por defecto).
"""

import random

# --------------------------------------------------------------------------
# Balance
# --------------------------------------------------------------------------
RECURSOS = ("regolito", "hielo", "hierro", "metal", "cristal", "agua")   # el agua sale del purificador
RECURSO_BASE = "regolito"       # lo que hay bajo un cuadro de suelo normal

ALMACEN_MAX = 3                 # unidades que guarda un taladro antes de parar
NIVEL_MAX = 3
TIEMPO_POR_UNIDAD = {1: 8.0, 2: 5.0, 3: 3.0}    # segundos por unidad, según nivel

# Nivel mínimo para extraer cada recurso (el nivel 3 incluye todo lo anterior).
# El cristal raro es ingrediente de mejoras: nunca da oxígeno, agua ni energía.
NIVEL_REQUERIDO = {"regolito": 1, "hielo": 1, "hierro": 2, "metal": 3, "cristal": 3}

# Botín de los taladros: el mapa ya no muestra vetas; cada unidad que saca un
# taladro sale al azar de esta tabla (recurso: peso) según su nivel. Mejorar el
# taladro abre los recursos valiosos. BALANCE: cambia los pesos para ajustar.
BOTIN = {
    1: {"regolito": 45, "hielo": 30, "hierro": 25},
    2: {"regolito": 35, "hielo": 25, "hierro": 25, "metal": 15},
    3: {"regolito": 25, "hielo": 25, "hierro": 20, "metal": 18, "cristal": 12},
}

# Costo de subir AL nivel indicado.
COSTO_MEJORA = {
    2: {"regolito": 5, "hierro": 3},
    3: {"hierro": 5, "metal": 3},
}

# Lo que el jugador puede llevar encima (guía: máximo 3 cubos de hielo en las manos).
LIMITE_INVENTARIO = {"hielo": 3}

# Mochila de casillas: CASILLAS lugares y hasta PILA_MAX unidades del mismo
# recurso en cada uno (BALANCE: sube PILA_MAX si se llena demasiado pronto).
CASILLAS = 21
PILA_MAX = 10

# TEMPORAL: recursos que el pico recoge a mano, 1 por clic. Hace falta porque
# subir a nivel 2 cuesta hierro y subir a nivel 3 cuesta metal valioso, y
# ningún taladro de nivel bajo puede extraerlos. Quitar o cambiar cuando se
# decida cómo se consigue el primer hierro.
A_MANO = {"hierro": 1, "metal": 1}

# Fracción de cuadros libres que tienen cada veta. El hielo debería ir solo en
# cráteres con sombra, pero el piso aún no marca dónde están los cráteres: por
# ahora se reparten al azar.
DENSIDAD_VETAS = {"hielo": 0.04, "hierro": 0.04, "metal": 0.02, "cristal": 0.015}

# Estados de un taladro
PRODUCIENDO = "produciendo"
LLENO = "lleno"
SIN_ENERGIA = "sin_energia"
NECESITA_NIVEL = "necesita_nivel"
SIN_ENTRADA = "sin_entrada"     # máquina de la cadena del agua sin su ingrediente
SIN_TANQUE = "sin_tanque"       # electrolizador sin un tanque pegado
TANQUE_LLENO = "tanque_lleno"   # electrolizador con el tanque pegado ya lleno

# --------------------------------------------------------------------------
# Cadena del agua y gases (balance)
# --------------------------------------------------------------------------
# hielo -> purificador -> agua -> electrolizador -> oxígeno + hidrógeno (al tanque)
# agua -> invernadero -> comida
PURIFICADOR = "purificador"
ELECTROLIZADOR = "electrolizador"
INVERNADERO = "invernadero"
TANQUE = "tanque"
BLOQUE = "bloque"               # bloque de regolito (blindaje contra radiación)

# tipo -> (lo que se le mete, lo que sale, segundos por unidad)
RECETAS = {
    PURIFICADOR: ("hielo", "agua", 6.0),
    ELECTROLIZADOR: ("agua", "oxigeno", 8.0),     # cada unidad manda además 1 de hidrógeno al tanque
    INVERNADERO: ("agua", "comida", 20.0),
}
# Lo que siembra cada invernadero, en este orden (el primero tomate, luego lechuga...).
CULTIVOS = ("tomate", "lechuga", "zanahoria", "nopal")   # el nopal gasta poca agua (guiño mexicano)
ENTRADA_MAX = 3                 # unidades de ingrediente que caben dentro de una máquina
SALIDA_MAX = 3                  # unidades listas para recoger antes de que pare
TANQUE_MAX = 6                  # unidades de hidrógeno de un tanque lleno (lo que pide la nave)
OXIGENO_POR_UNIDAD = 25.0       # cuánto sube la barra de oxígeno cada unidad recogida
COMIDA_POR_UNIDAD = 30.0        # cuánto sube la barra de comida cada unidad recogida

# Costo de construir (dificultad fácil: al quitar algo se devuelve todo).
COSTO_CONSTRUIR = {
    BLOQUE: {"regolito": 2},
    PURIFICADOR: {"regolito": 2, "hierro": 2},
    ELECTROLIZADOR: {"hierro": 3, "metal": 1},
    TANQUE: {"hierro": 3},
    INVERNADERO: {"regolito": 4, "hierro": 2},
}


# --------------------------------------------------------------------------
# Recursos del terreno (capa bajo el mapa)
# --------------------------------------------------------------------------
def generar_recursos(filas, columnas, es_libre, semilla, fijos=None):
    """Matriz recursos[fila][columna] con el recurso que hay bajo cada cuadro.

    es_libre(f, c) dice si en ese cuadro puede haber una veta (por ejemplo,
    que no sea una roca). fijos = {(f, c): recurso} pone vetas en lugares
    exactos, para que haya de todo cerca del inicio. Misma semilla = mismo
    terreno en cada partida.
    """
    azar = random.Random(semilla)
    recursos = [[RECURSO_BASE] * columnas for _ in range(filas)]
    for f in range(filas):
        for c in range(columnas):
            tirada = azar.random()          # siempre se gasta, así el resto no cambia
            if not es_libre(f, c):
                continue
            acumulado = 0.0
            for nombre, densidad in DENSIDAD_VETAS.items():
                acumulado += densidad
                if tirada < acumulado:
                    recursos[f][c] = nombre
                    break
    for (f, c), nombre in (fijos or {}).items():
        recursos[f % filas][c % columnas] = nombre
    return recursos


# --------------------------------------------------------------------------
# Inventario
# --------------------------------------------------------------------------
def casillas_ocupadas(inventario, sin=None):
    """Cuántas casillas gastan las cantidades del inventario (una casilla por
    cada PILA_MAX unidades de un mismo recurso, redondeando hacia arriba).
    `sin` = un recurso que no se cuenta."""
    return sum(-(-n // PILA_MAX) for r, n in inventario.items() if r != sin and n > 0)


def casillas(inventario):
    """Lista de CASILLAS elementos: (recurso, cantidad) o None si está vacía.
    Se calcula de las cantidades (que son el único dato guardado): los recursos
    van en el orden de RECURSOS y cada uno llena casillas de PILA_MAX en PILA_MAX.
    Nunca devuelve más de CASILLAS, aunque un test deje más cosas dentro."""
    lista = []
    for recurso in RECURSOS:
        n = inventario.get(recurso, 0)
        while n > 0:
            lista.append((recurso, min(n, PILA_MAX)))
            n -= PILA_MAX
    return (lista + [None] * CASILLAS)[:CASILLAS]


def espacio(inventario, recurso):
    """Cuántas unidades más de ese recurso caben: lo que dejan libre las
    casillas y, para el hielo, además el máximo de las manos. Nunca negativo."""
    libres = CASILLAS - casillas_ocupadas(inventario, sin=recurso)
    cabe = max(0, libres * PILA_MAX - inventario.get(recurso, 0))
    limite = LIMITE_INVENTARIO.get(recurso)
    if limite is not None:
        cabe = min(cabe, max(0, limite - inventario.get(recurso, 0)))
    return cabe


def faltante(inventario, costo):
    """{recurso: cantidad que falta} para pagar el costo; vacío si alcanza."""
    return {r: n - inventario.get(r, 0)
            for r, n in costo.items() if inventario.get(r, 0) < n}


# --------------------------------------------------------------------------
# Taladro
# --------------------------------------------------------------------------
class Taladro:
    """Un taladro saca recursos del subsuelo: cada unidad sale al azar del
    BOTIN de su nivel. Su almacén guarda hasta ALMACEN_MAX unidades (pueden ser
    de recursos distintos). El hielo guardado NO se sublima."""

    def __init__(self, azar=None):
        self.nivel = 1
        self.almacen = []           # recursos guardados, en el orden en que salieron
        self.progreso = 0.0         # segundos acumulados de la unidad en curso
        self._azar = azar or random.Random()
        self.extra = {}             # pesos extra del botín (ronda 20: en un cráter de Marte, más hielo)

    @property
    def cantidad(self):
        return len(self.almacen)

    @property
    def tiempo_unidad(self):
        return TIEMPO_POR_UNIDAD[self.nivel]

    @property
    def botin(self):
        """Recursos que puede sacar con su nivel actual."""
        return list(BOTIN[self.nivel])

    def estado(self, con_energia):
        """PRODUCIENDO, LLENO o SIN_ENERGIA."""
        if self.cantidad >= ALMACEN_MAX:
            return LLENO
        if not con_energia:
            return SIN_ENERGIA
        return PRODUCIENDO

    def _sortear(self):
        tabla = BOTIN[self.nivel]
        if self.extra:              # sin extra la tabla es la misma de siempre
            tabla = dict(tabla)
            for recurso, peso in self.extra.items():
                tabla[recurso] = tabla.get(recurso, 0) + peso
        return self._azar.choices(list(tabla), weights=list(tabla.values()))[0]

    def actualizar(self, dt, con_energia):
        """Avanza dt segundos. Solo suma tiempo si está PRODUCIENDO. Devuelve
        el estado."""
        estado = self.estado(con_energia)
        if estado != PRODUCIENDO:
            return estado
        self.progreso += dt
        while self.progreso >= self.tiempo_unidad and self.cantidad < ALMACEN_MAX:
            self.progreso -= self.tiempo_unidad
            self.almacen.append(self._sortear())
        if self.cantidad >= ALMACEN_MAX:
            self.progreso = 0.0     # lleno: se detiene sin guardar tiempo
        return self.estado(con_energia)

    def retirar(self, guardar):
        """Entrega el almacén unidad por unidad: guardar(recurso) la guarda y
        devuelve True, o False si ya no cabe (esa unidad se queda en el taladro).
        Devuelve {recurso: cantidad entregada}."""
        sacado, queda = {}, []
        for recurso in self.almacen:
            if guardar(recurso):
                sacado[recurso] = sacado.get(recurso, 0) + 1
            else:
                queda.append(recurso)
        self.almacen = queda
        return sacado

    @property
    def costo_mejora(self):
        """Costo de subir al siguiente nivel, o None si ya es el máximo."""
        return COSTO_MEJORA.get(self.nivel + 1)

    def mejorar(self):
        """Sube un nivel (el cobro del inventario lo hace quien llama)."""
        if self.nivel < NIVEL_MAX:
            self.nivel += 1


# --------------------------------------------------------------------------
# Máquinas de la cadena del agua
# --------------------------------------------------------------------------
class Tanque:
    """Tanque de hidrógeno: lo llena un electrolizador pegado a él. No usa
    energía. Tiene 4 estados de llenado para el dibujo (0 vacío ... 3 lleno)."""

    tipo = TANQUE

    def __init__(self):
        self.hidrogeno = 0

    @property
    def lleno(self):
        return self.hidrogeno >= TANQUE_MAX

    @property
    def estado_llenado(self):
        """0 vacío, 1 menos de la mitad, 2 de la mitad para arriba, 3 lleno."""
        if self.hidrogeno <= 0:
            return 0
        if self.lleno:
            return 3
        return 1 if self.hidrogeno < TANQUE_MAX / 2 else 2

    @property
    def vacia(self):
        return self.hidrogeno == 0


class Maquina:
    """Purificador, electrolizador o invernadero. El jugador le mete el
    ingrediente (entrada) y recoge lo que produce (salida). Con energía, cada
    RECETAS[tipo][2] segundos convierte 1 de entrada en 1 de salida. El
    electrolizador además manda 1 de hidrógeno al tanque que tenga pegado; sin
    tanque, o con el tanque lleno, se detiene."""

    def __init__(self, tipo, cultivo=None):
        if tipo not in RECETAS:
            raise ValueError(f"máquina desconocida: '{tipo}'")
        self.tipo = tipo
        if tipo == INVERNADERO and cultivo is None:
            cultivo = CULTIVOS[0]
        self.cultivo = cultivo      # solo el invernadero: "tomate", "lechuga" o "zanahoria"
        self.entrada = 0
        self.salida = 0
        self.progreso = 0.0
        self.producidas = 0         # total de unidades hechas (para la comparación del final)

    @property
    def recurso_entrada(self):
        return RECETAS[self.tipo][0]

    @property
    def recurso_salida(self):
        return RECETAS[self.tipo][1]

    @property
    def tiempo_unidad(self):
        return RECETAS[self.tipo][2]

    @property
    def vacia(self):
        return self.entrada == 0 and self.salida == 0

    def estado(self, con_energia, tanque=None):
        """LLENO, SIN_TANQUE, TANQUE_LLENO, SIN_ENERGIA, SIN_ENTRADA o
        PRODUCIENDO (en ese orden de prioridad)."""
        # SIMPLIFICACIÓN: el electrolizador no se detiene por tener el oxígeno lleno
        # (lo que no cabe se libera); si se detuviera, con la barra de oxígeno
        # llena nunca se podría juntar el hidrógeno para la nave.
        if self.salida >= SALIDA_MAX and self.tipo != ELECTROLIZADOR:
            return LLENO
        if self.tipo == ELECTROLIZADOR:
            if tanque is None:
                return SIN_TANQUE
            if tanque.lleno:
                return TANQUE_LLENO
        if not con_energia:
            return SIN_ENERGIA
        if self.entrada <= 0:
            return SIN_ENTRADA
        return PRODUCIENDO

    def actualizar(self, dt, con_energia, tanque=None):
        """Avanza dt segundos y devuelve el estado. Un dt grande da lo mismo que
        muchos pasos chicos: se termina unidad por unidad. Si la máquina se
        detiene, la unidad a medias se pierde (vuelve a empezar de 0)."""
        estado = self.estado(con_energia, tanque)
        while estado == PRODUCIENDO and dt > 0:
            falta = self.tiempo_unidad - self.progreso
            if dt < falta:
                self.progreso += dt
                return estado
            dt -= falta
            self.progreso = 0.0
            self.entrada -= 1
            self.salida = min(SALIDA_MAX, self.salida + 1)
            self.producidas += 1
            if self.tipo == ELECTROLIZADOR:
                tanque.hidrogeno += 1
            estado = self.estado(con_energia, tanque)
        if estado != PRODUCIENDO:
            self.progreso = 0.0
        return estado

    def depositar(self, cantidad):
        """Mete hasta `cantidad` de ingrediente y devuelve cuántas entraron."""
        entran = max(0, min(cantidad, ENTRADA_MAX - self.entrada))
        self.entrada += entran
        return entran

    def retirar(self, maximo):
        """Saca hasta `maximo` unidades de lo producido y devuelve cuántas."""
        sacadas = max(0, int(min(self.salida, maximo)))
        self.salida -= sacadas
        return sacadas
