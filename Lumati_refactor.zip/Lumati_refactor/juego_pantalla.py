"""Pantalla completa (ronda 29).

El juego siempre dibuja a su tamaño interno (ANCHO x ALTO, 960x640). La ventana
se crea con pygame.SCALED: SDL agranda esa imagen a la pantalla manteniendo la
proporción (con barras negras si sobra espacio) y con píxeles nítidos (sin
suavizado). SDL también convierte el mouse: pygame.mouse.get_pos() y evento.pos
siguen dando coordenadas del juego (0..959, 0..639), así que los clics en
tarjetas, mapa, inventario y slots no cambian.

Teclas: Cmd+F o Ctrl+Cmd+F (Mac) en cualquier momento; F con el menú
principal o la pausa abiertos. También hay un botón en el menú principal y la
opción "Pantalla completa: sí/no" en la pausa. Para arrancar ya en pantalla
completa: python main.py --completa (se puede combinar con marte).

Si el sistema no deja cambiar, el juego no truena: avisa y sigue como estaba.
"""

import os

import pygame

from textos import t
from config import ALTO, ANCHO

# Píxeles nítidos al agrandar (vecino más cercano). Se pone antes de crear la ventana.
os.environ.setdefault("SDL_RENDER_SCALE_QUALITY", "0")

# Argumentos de main.py que arrancan en pantalla completa.
ARGUMENTOS = ("--completa", "completa", "--pantalla-completa", "pantalla_completa", "--fullscreen", "fullscreen")


def crear_ventana(completa=False):
    """Crea la ventana del juego (ANCHO x ALTO, escalada por SDL). Si SCALED no se
    puede en este sistema, una ventana normal como antes."""
    banderas = pygame.SCALED | (pygame.FULLSCREEN if completa else 0)
    try:
        return pygame.display.set_mode((ANCHO, ALTO), banderas)
    except pygame.error:
        return pygame.display.set_mode((ANCHO, ALTO))


def esta_completa():
    """True si la ventana está en pantalla completa ahora."""
    try:
        return bool(pygame.display.is_fullscreen())
    except (pygame.error, AttributeError):
        return False


class PantallaMixin:
    """Alternar ventana / pantalla completa sin tronar."""

    def tecla_pantalla(self, tecla):
        """True (y alterna) si la tecla es de pantalla completa: F con Cmd
        (Cmd+F o Ctrl+Cmd+F en Mac). La F sola se ve en los menús (tecla_opciones)."""
        mods = pygame.key.get_mods()
        if tecla == pygame.K_f and mods & pygame.KMOD_META:   # F11 quitado en la ronda 36
            self.alternar_pantalla_completa()
            return True
        return False

    def alternar_pantalla_completa(self, quiere=None):
        """Pasa a pantalla completa o vuelve a ventana. Primero con
        toggle_fullscreen (lo recomendado con SCALED); si no funciona, vuelve a
        crear la ventana con la bandera; si tampoco, avisa y se queda como estaba.
        Devuelve True si quedó como se pidió."""
        if quiere is None:
            quiere = not esta_completa()
        if esta_completa() != quiere:
            try:
                pygame.display.toggle_fullscreen()
            except pygame.error:
                pass
        if esta_completa() != quiere:                        # plan B: volver a crear la ventana
            try:
                self.pantalla = crear_ventana(quiere)
            except pygame.error:
                try:                                         # algo salió mal: ventana normal otra vez
                    self.pantalla = crear_ventana(False)
                except pygame.error:
                    pass
        superficie = pygame.display.get_surface()
        if superficie is not None:
            self.pantalla = superficie
        self.pantalla_completa = esta_completa()
        listo = self.pantalla_completa == quiere
        self.sonar("clic" if listo else "error")
        if not listo:
            self.mensaje = t("pantalla_error")
        else:
            self.mensaje = t("pantalla_on" if quiere else "pantalla_off")
        return listo
