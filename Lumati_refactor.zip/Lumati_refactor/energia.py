"""Redes de cables: qué cuadros de cable están conectados entre sí.

Dos cables forman parte de la misma red si se tocan por un lado (arriba,
abajo, izquierda o derecha; las diagonales no cuentan). El mapa da la vuelta
como en Pac-Man, así que los vecinos se calculan con módulo: el cable de la
fila 31 toca al de la fila 0.

Una red tiene energía si toca una fuente (panel solar) por un lado; ver
celdas_con_energia. Una máquina funciona si toca un cable de una red con energía.

Colores: si se pasa `colores` ({(fila, col): color}), dos cables vecinos solo
son de la misma red si tienen el MISMO color (cada color es su propio
circuito). Las máquinas y los paneles se conectan a cables de cualquier color.
Sin `colores` todo funciona como antes (un solo circuito).

Piezas (ronda 11): si se pasa `une(a, b)`, esa función decide si dos cables
vecinos se unen (conectores +, T, L y cable negro, que solo unen por ciertos lados).

No depende de pygame: solo recibe el mapa (lista de listas) y el número que
significa "cable" (y "fuente").
"""

from collections import deque


def vecinos(fila, col, filas, columnas):
    """Los 4 cuadros que tocan a (fila, col), con módulo en los bordes."""
    return [((fila - 1) % filas, col),
            ((fila + 1) % filas, col),
            (fila, (col - 1) % columnas),
            (fila, (col + 1) % columnas)]


def tiene_cable_vecino(mapa, tipo_cable, fila, col):
    """True si algún cuadro que toca a (fila, col) es cable. Es la regla de
    "conectado" para una máquina: debe tocar un cable por un lado."""
    filas, columnas = len(mapa), len(mapa[0])
    return any(mapa[f][c] == tipo_cable
               for f, c in vecinos(fila % filas, col % columnas, filas, columnas))


def _mismo_color(colores, a, b):
    """True si los cuadros a y b tienen cable del mismo color (o no hay colores)."""
    return colores is None or colores.get(a) == colores.get(b)


def red_de(mapa, tipo_cable, fila, col, colores=None, une=None):
    """Conjunto de (fila, col) de toda la red que incluye a ese cuadro.

    Si el cuadro no es cable devuelve un conjunto vacío. Usa una cola en vez
    de recursión y marca cada cuadro al verlo, así que no se cicla aunque los
    cables formen un anillo alrededor del mapa.
    """
    filas, columnas = len(mapa), len(mapa[0])
    if mapa[fila % filas][col % columnas] != tipo_cable:
        return set()
    inicio = (fila % filas, col % columnas)
    visitados = {inicio}
    pendientes = deque([inicio])
    while pendientes:
        f, c = pendientes.popleft()
        for vecino in vecinos(f, c, filas, columnas):
            if (vecino not in visitados and mapa[vecino[0]][vecino[1]] == tipo_cable
                    and (une((f, c), vecino) if une else _mismo_color(colores, (f, c), vecino))):
                visitados.add(vecino)
                pendientes.append(vecino)
    return visitados


def celdas_con_energia(mapa, tipo_cable, tipo_fuente, colores=None, une=None):
    """Conjunto de cuadros de CABLE cuya red toca al menos una fuente de energía
    (por ejemplo un panel solar) por un lado. Una red sin fuente no aparece.

    Regla de la versión fácil: una fuente da energía a toda su red, sin límite
    de capacidad (la sobrecarga es de la versión completa). Una máquina pegada
    directamente a la fuente, sin cable, NO recibe energía: necesita cable.
    """
    filas, columnas = len(mapa), len(mapa[0])
    con_energia = set()
    for red in encontrar_redes(mapa, tipo_cable, colores, une):
        toca_fuente = any(mapa[vf][vc] == tipo_fuente
                          for f, c in red
                          for vf, vc in vecinos(f, c, filas, columnas))
        if toca_fuente:
            con_energia |= red
    return con_energia


def toca_celdas(celdas, fila, col, filas, columnas):
    """True si algún cuadro que toca a (fila, col) está en `celdas`. Es la regla
    de "máquina conectada a una red con energía"."""
    return any(v in celdas for v in vecinos(fila % filas, col % columnas, filas, columnas))


def encontrar_redes(mapa, tipo_cable, colores=None, une=None):
    """Lista de redes; cada una es un conjunto de (fila, col)."""
    redes = []
    vistos = set()
    for f, fila in enumerate(mapa):
        for c, tipo in enumerate(fila):
            if tipo == tipo_cable and (f, c) not in vistos:
                red = red_de(mapa, tipo_cable, f, c, colores, une)
                vistos |= red
                redes.append(red)
    return redes
