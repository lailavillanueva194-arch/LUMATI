"""Datos reales de la NASA para las etiquetas "Dato real NASA". Datos puros:
no usa pygame.

PROVISIONAL: la guía dice que ya existe un datos.py con 28 datos bilingües,
pero ese archivo no está en el repo. Este lo reemplaza con 14 datos que se
comprobaron contra los archivos originales de la NASA (DONKI y OSDR). Tiene la
MISMA API que describe la guía, así que cuando llegue el original basta con
copiarlo encima: obtener, etiqueta, referencias, pendientes_de_verificar.

Reglas de honestidad que siguen los textos:
- "contexto" dice de dónde viene el dato: vuelo (ISS), laboratorio_tierra
  (estudios en tierra) o historico (ejemplos de DONKI de 2016 y 2017).
- Los estudios en ratas o en células lo dicen en el propio texto.
- Ningún dato menciona la Luna: estas fuentes no tienen datos lunares.
- Ronda 20: los datos de Marte (solo_marte=True) vienen del encargo del equipo
  (NASA/JPL, misiones Curiosity, InSight y MRO, y DONKI). Están marcados
  verificado=False porque falta contrastarlos con la fuente primaria. En la
  Luna la antena no los manda.
"""

import textos

ETIQUETA = {"es": "Dato real NASA", "en": "Real NASA fact"}

VUELO = "vuelo"
LABORATORIO = "laboratorio_tierra"
HISTORICO = "historico"

# Fuentes: clave -> (nombre, enlace o DOI del conjunto de datos, artículo)
FUENTES = {
    "donki": ("DONKI / NASA CCMC", "https://ccmc.gsfc.nasa.gov/DONKI-API", None),
    "osd767": ("NASA OSDR OSD-767", "DOI 10.26030/rrtk-h481",
               "BMC Plant Biology, DOI 10.1186/s12870-025-07621-4"),
    "osd1018": ("NASA OSDR OSD-1018", "DOI 10.26030/8g54-4745",
                "Life 2023, DOI 10.3390/life13030826"),
    "osd1010": ("NASA OSDR OSD-1010", "DOI 10.26030/y1ww-ep94", None),
    # Ronda 20 (Marte). El encargo no trae enlaces: por eso el enlace es None.
    "nasa_jpl": ("NASA/JPL", None, None),
    "curiosity": ("NASA/JPL - Curiosity", None, None),
    "insight": ("NASA/JPL - InSight", None, None),
    "insight_mro": ("NASA/JPL - InSight y MRO", None, None),
}

# id -> textos es/en, fuente, contexto, fecha (o None), verificado.
# verificado=True: contrastado con los archivos originales entregados.
DATOS = {
    "llamarada_clases": {
        "es": "Las llamaradas solares se nombran con una letra y un número, "
              "como M2.3 o C9.6.",
        "en": "Solar flares are named with a letter and a number, such as "
              "M2.3 or C9.6.",
        "fuente": "donki", "contexto": HISTORICO, "fecha": "2016-01", "verificado": True,
    },
    "llamarada_cadena": {
        "es": "Una llamarada M2.3 del 1 de enero de 2016 estuvo ligada a una "
              "eyección de masa coronal y a dos eventos de partículas solares.",
        "en": "An M2.3 flare on January 1, 2016 was linked to a coronal mass "
              "ejection and to two solar energetic particle events.",
        "fuente": "donki", "contexto": HISTORICO, "fecha": "2016-01-01", "verificado": True,
    },
    "cme_escala": {
        "es": "Las eyecciones de masa coronal se clasifican por velocidad: de "
              "menos de 500 km/s (tipo S) a más de 3000 km/s (tipo ER, "
              "extremadamente rara).",
        "en": "Coronal mass ejections are classified by speed: from under "
              "500 km/s (type S) to over 3000 km/s (type ER, extremely rare).",
        "fuente": "donki", "contexto": HISTORICO, "fecha": None, "verificado": True,
    },
    "kp_escala": {
        "es": "El índice Kp mide la actividad geomagnética de 0 a 9. Una "
              "tormenta de enero de 2016 llegó a Kp 6.",
        "en": "The Kp index measures geomagnetic activity from 0 to 9. A storm "
              "in January 2016 reached Kp 6.",
        "fuente": "donki", "contexto": HISTORICO, "fecha": "2016-01-21", "verificado": True,
    },
    "cme_645": {
        "es": "Un análisis de una eyección de masa coronal del 3 de enero de "
              "2017 midió 645 km/s: tipo C en la escala de la NASA.",
        "en": "An analysis of a coronal mass ejection from January 3, 2017 "
              "measured 645 km/s: type C on the NASA scale.",
        "fuente": "donki", "contexto": HISTORICO, "fecha": "2017-01-03", "verificado": True,
    },
    "radiacion_brookhaven": {
        "es": "En un laboratorio de la NASA en Nueva York se irradiaron ratas "
              "con 15 cGy de una simulación de rayos cósmicos de 5 tipos de iones.",
        "en": "At a NASA laboratory in New York, rats were irradiated with "
              "15 cGy of a 5-ion simulation of cosmic rays.",
        "fuente": "osd1018", "contexto": LABORATORIO, "fecha": None, "verificado": True,
    },
    "ratas_aislamiento": {
        "es": "En un estudio con 80 ratas, el aislamiento social y la radiación "
              "espacial simulada afectaron de forma distinta el equilibrio y las "
              "emociones. Es un estudio en ratas, no en astronautas.",
        "en": "In a study with 80 rats, social isolation and simulated space "
              "radiation affected balance and emotions differently. It is a "
              "study in rats, not in astronauts.",
        "fuente": "osd1018", "contexto": LABORATORIO, "fecha": None, "verificado": True,
    },
    "ratas_viga": {
        "es": "Para medir el equilibrio, las ratas cruzaban una viga de 1 m de "
              "largo y 2 cm de ancho, a 90 cm de altura, 5 veces al día durante 7 días.",
        "en": "To measure balance, rats crossed a beam 1 m long and 2 cm wide, "
              "90 cm high, 5 times a day for 7 days.",
        "fuente": "osd1018", "contexto": LABORATORIO, "fecha": None, "verificado": True,
    },
    "chip_intestino": {
        "es": "En células intestinales humanas cultivadas en un chip de "
              "laboratorio, 50 cGy de iones de hierro o de silicio activaron "
              "inflamación y daño de ADN.",
        "en": "In human intestinal cells grown on a lab chip, 50 cGy of iron or "
              "silicon ions triggered inflammation and DNA damage.",
        "fuente": "osd1010", "contexto": LABORATORIO, "fecha": None, "verificado": True,
    },
    "probiotico": {
        "es": "En ese chip, las células con el probiótico L. rhamnosus GG "
              "tuvieron menos daño de ADN. Resultado preliminar, en células de "
              "laboratorio.",
        "en": "On that chip, cells with the probiotic L. rhamnosus GG had less "
              "DNA damage. Preliminary result, in lab cells.",
        "fuente": "osd1010", "contexto": LABORATORIO, "fecha": None, "verificado": True,
    },
    "let_hierro_silicio": {
        "es": "Los iones de hierro-56 depositan 147 keV/µm y los de silicio-28 "
              "unos 50 keV/µm: no toda la radiación espacial es igual.",
        "en": "Iron-56 ions deposit 147 keV/µm and silicon-28 ions about "
              "50 keV/µm: not all space radiation is the same.",
        "fuente": "osd1010", "contexto": LABORATORIO, "fecha": None, "verificado": True,
    },
    "tomate_iss": {
        "es": "Un tomate 'Red Robin' creció 100 días en la Estación Espacial "
              "Internacional, en el sistema Veggie.",
        "en": "A 'Red Robin' tomato grew for 100 days on the International "
              "Space Station, in the Veggie system.",
        "fuente": "osd767", "contexto": VUELO, "fecha": "2022-11", "verificado": True,
    },
    "tomate_raices": {
        "es": "En órbita, los tomates formaron muchas raíces extra y activaron "
              "genes de estrés y antioxidantes. La luz roja dio una expresión "
              "de genes más estable que la azul.",
        "en": "In orbit, tomato plants grew many extra roots and switched on "
              "stress and antioxidant genes. Red light gave steadier gene "
              "expression than blue light.",
        "fuente": "osd767", "contexto": VUELO, "fecha": None, "verificado": True,
    },
    "tomate_fechas": {
        "es": "Las semillas de tomate llegaron a la Estación Espacial el 26 de "
              "noviembre de 2022 y se cosecharon los días 83, 90 y 100.",
        "en": "The tomato seeds reached the Space Station on November 26, 2022 "
              "and were harvested on days 83, 90 and 100.",
        "fuente": "osd767", "contexto": VUELO, "fecha": "2022-11-26", "verificado": True,
    },
    # ---- Marte (ronda 20): del encargo del equipo, falta contrastar ----------
    "marte_remolinos": {
        "es": "Los remolinos de polvo de Marte aparecen cuando el suelo está más "
              "caliente que el aire. Durante una tormenta de polvo hay menos.",
        "en": "Martian dust devils form when the ground is warmer than the air. "
              "There are fewer of them during a dust storm.",
        "fuente": "nasa_jpl", "contexto": VUELO, "fecha": None, "verificado": False, "solo_marte": True,
    },
    "marte_sismos": {
        "es": "La sonda InSight detectó 1,318 sismos en Marte desde 2018. El mayor "
              "fue de magnitud 4.7 (mayo de 2022): son pequeños comparados con la Tierra.",
        "en": "The InSight lander detected 1,318 marsquakes since 2018. The largest "
              "was magnitude 4.7 (May 2022): small compared with Earth.",
        "fuente": "insight", "contexto": VUELO, "fecha": "2022-05", "verificado": False, "solo_marte": True,
    },
    "marte_polvo_regional": {
        "es": "En Marte hay tormentas de polvo locales y regionales todos los años "
              "marcianos, durante la temporada de polvo.",
        "en": "Mars has local and regional dust storms every Martian year, during "
              "the dust season.",
        "fuente": "nasa_jpl", "contexto": VUELO, "fecha": None, "verificado": False, "solo_marte": True,
    },
    "marte_polvo_efectos": {
        "es": "El polvo quita luz solar directa (bajan los paneles y el cultivo), "
              "hace los días más fríos y las noches menos frías (aísla) y cubre "
              "los paneles solares.",
        "en": "Dust blocks direct sunlight (solar panels and crops drop), makes "
              "days colder and nights less cold (it insulates) and covers the "
              "solar panels.",
        "fuente": "nasa_jpl", "contexto": VUELO, "fecha": None, "verificado": False, "solo_marte": True,
    },
    "marte_polvo_global": {
        "es": "Las tormentas globales envuelven todo Marte cada 6 a 8 años terrestres "
              "(3 a 4 marcianos). En 2018, una tormenta pequeña vista el 30 de mayo "
              "ya era global el 20 de junio y duró al menos un par de meses.",
        "en": "Global storms wrap all of Mars every 6 to 8 Earth years (3 to 4 "
              "Martian years). In 2018, a small storm seen on May 30 was global by "
              "June 20 and lasted at least a couple of months.",
        "fuente": "nasa_jpl", "contexto": HISTORICO, "fecha": "2018-06-20", "verificado": False,
        "solo_marte": True,
    },
    "marte_polvo_altura": {
        "es": "El polvo puede subir unos 20 km. El viento llega a unos 60 mph, pero "
              "el aire tiene cerca del 1 % de la densidad de la Tierra: el peligro "
              "es el polvo, no la fuerza del viento.",
        "en": "Dust can rise about 20 km. Wind reaches about 60 mph, but the air is "
              "about 1% as dense as Earth's: the danger is the dust, not the force "
              "of the wind.",
        "fuente": "nasa_jpl", "contexto": VUELO, "fecha": None, "verificado": False, "solo_marte": True,
    },
    "marte_gcr": {
        "es": "En la superficie de Marte los rayos cósmicos dan una dosis casi "
              "constante de unos 210 microgray por día (medida por Curiosity).",
        "en": "On the surface of Mars, cosmic rays give an almost constant dose of "
              "about 210 micrograys per day (measured by Curiosity).",
        "fuente": "curiosity", "contexto": VUELO, "fecha": None, "verificado": False, "solo_marte": True,
    },
    "marte_sep": {
        "es": "En la superficie de Marte las partículas solares pueden dominar la "
              "radiación durante horas o días, porque la atmósfera es muy delgada. "
              "Protección: refugios con blindaje extra.",
        "en": "On the surface of Mars, solar particles can dominate radiation for "
              "hours or days because the atmosphere is very thin. Protection: "
              "shelters with extra shielding.",
        "fuente": "nasa_jpl", "contexto": VUELO, "fecha": None, "verificado": False, "solo_marte": True,
    },
    "marte_sep_frecuencia": {
        "es": "Las partículas solares son irregulares: en sus primeros 10 meses, "
              "Curiosity vio solo 1 evento y fue débil. Con el Sol muy activo se "
              "esperan unos 8 en 300 soles.",
        "en": "Solar particle events are irregular: in its first 10 months, "
              "Curiosity saw only 1, and it was weak. With a very active Sun, "
              "about 8 are expected in 300 sols.",
        "fuente": "curiosity", "contexto": VUELO, "fecha": None, "verificado": False, "solo_marte": True,
    },
    "marte_cme_viaje": {
        "es": "Una eyección solar tipo C de 645 km/s del 3 de enero de 2017 llegó a "
              "Marte el 7 de enero a las 06:00Z: unos 4 días de viaje.",
        "en": "A type C solar ejection at 645 km/s from January 3, 2017 reached "
              "Mars on January 7 at 06:00Z: about 4 days of travel.",
        "fuente": "donki", "contexto": HISTORICO, "fecha": "2017-01-07", "verificado": False, "solo_marte": True,
    },
    "marte_forbush": {
        "es": "Las eyecciones solares también causan caídas súbitas de la radiación "
              "cósmica (Forbush decreases), porque hacen de escudo extra.",
        "en": "Solar ejections also cause sudden drops in cosmic radiation "
              "(Forbush decreases), because they act as an extra shield.",
        "fuente": "nasa_jpl", "contexto": VUELO, "fecha": None, "verificado": False, "solo_marte": True,
    },
    "marte_impacto": {
        "es": "En diciembre de 2021 un cuerpo de 5 a 12 m abrió en Marte un cráter "
              "de unos 150 m, lanzó escombros hasta unos 37 km, causó un sismo de "
              "magnitud 4 y dejó hielo expuesto cerca de la superficie.",
        "en": "In December 2021 a 5 to 12 m object opened a crater about 150 m wide "
              "on Mars, threw debris up to about 37 km, caused a magnitude 4 quake "
              "and left ice exposed near the surface.",
        "fuente": "insight_mro", "contexto": HISTORICO, "fecha": "2021-12", "verificado": False,
        "solo_marte": True,
    },
}


def _idioma(idioma):
    return idioma or textos.IDIOMA


def ids(destino=None):
    """Todos los id de datos. Con destino="luna" quita los que son solo de Marte."""
    if destino == "luna":
        return [i for i, d in DATOS.items() if not d.get("solo_marte")]
    return list(DATOS)


def obtener(id_dato, idioma=None):
    """Texto del dato en el idioma pedido (por defecto, el del juego)."""
    return DATOS[id_dato][_idioma(idioma)]


def etiqueta(id_dato, idioma=None):
    """Texto listo para mostrar: 'Dato real NASA: ...' / 'Real NASA fact: ...'."""
    idioma = _idioma(idioma)
    return f"{ETIQUETA[idioma]}: {DATOS[id_dato][idioma]}"


def fuente(id_dato):
    """(nombre, enlace o DOI, artículo o None) de la fuente de ese dato."""
    return FUENTES[DATOS[id_dato]["fuente"]]


def referencias(idioma=None):
    """Lista de textos con las fuentes realmente usadas, para créditos."""
    usadas = []
    for dato in DATOS.values():
        if dato["fuente"] not in usadas:
            usadas.append(dato["fuente"])
    lineas = []
    for clave in usadas:
        nombre, enlace, articulo = FUENTES[clave]
        linea = f"{nombre} ({enlace})" if enlace else nombre
        if articulo:
            linea += f" - {articulo}"
        lineas.append(linea)
    return lineas


def pendientes_de_verificar():
    """Ids de datos que aún no se contrastan con la fuente primaria."""
    return [i for i, d in DATOS.items() if not d["verificado"]]
