"""Partida guardada: pasar el juego a un diccionario y de vuelta, y
guardar/cargar en las ranuras de partidas/ (F5, F9, terminal y menús).
"""

import os

import clima as modulo_clima
import maquinas
import partidas
from clima import CALMA, CALMA_SIN_FIN, POLVO_EN_CALMA
from eventos_marte import CONFIG as CONFIG_MARTE
from maquinas import Maquina, RECURSOS, Taladro, Tanque
from supervivencia import BARRAS, DOSIS, OXIGENO
from textos import t
from config import (CABLE_COLORES, CARPETA, COLOR_CABLE_DE, COLUMNAS, ESCENA_BASE, ESCENA_MAPA,
                    FILAS, LADOS_FORMA, LUNA, MACETAS_BASE, MAPA_ALTO, MAPA_ANCHO, MARTE, OBJETOS,
                    OPCIONES_CABLE, PARTIDA_VERSION, RAPIDA_N, TRAJE_NIVEL_MAX)
from jugador import calcular_camara


class GuardadoMixin:
    """Partida guardada: pasar el juego a un diccionario y de vuelta, y
    guardar/cargar en las ranuras de partidas/ (F5, F9, terminal y menús)."""

    # -- partida guardada -----------------------------------------------------
    def estado_a_dict(self):
        """Todo lo necesario para volver a esta partida, en tipos de JSON."""
        c = self.clima
        d = {
            "version": PARTIDA_VERSION,
            "destino": self.destino,
            "escena": self.escena,
            "mapa": [list(fila) for fila in self.mapa],
            "colores_cable": [[f, col, color] for (f, col), color in self.colores_cable.items()],
            "piezas_cable": [[f, col, forma, giro] for (f, col), (forma, giro) in self.piezas_cable.items()],
            "taladros": [[f, col, {"nivel": tl.nivel, "almacen": list(tl.almacen), "progreso": tl.progreso}]
                         for (f, col), tl in self.taladros.items()],
            "maquinas": [[f, col, {"clase": "tanque", "hidrogeno": mq.hidrogeno} if isinstance(mq, Tanque) else
                          {"clase": "maquina", "tipo": mq.tipo, "cultivo": mq.cultivo, "entrada": mq.entrada,
                           "salida": mq.salida, "progreso": mq.progreso, "producidas": mq.producidas}]
                         for (f, col), mq in self.maquinas.items()],
            "antenas": [list(a) for a in self.antenas],
            "macetas": [None if mq is None else
                        {"cultivo": mq.cultivo, "entrada": mq.entrada, "salida": mq.salida,
                         "progreso": mq.progreso, "producidas": mq.producidas} for mq in self.macetas],
            "baterias": [[f, col, q] for (f, col), q in self.baterias.items()],
            "tanques_agua": [[f, col, q] for (f, col), q in self.tanques_agua.items()],
            "contacto_hecho": self.contacto_hecho,
            "msg_tierra": self._msg_tierra,
            "inventario": dict(self.inventario),
            "almacen": dict(self.almacen),
            "objetos": dict(self.objetos),
            "rapida": list(self.rapida),
            "en_mano": self.en_mano,
            "color_cable": self.color_cable,
            "astronauta": {k: getattr(self.astronauta, k) for k in
                           ("oxigeno", "energia", "comida", "dosis", "segundos_sin_oxigeno", "causa_muerte")},
            "jugador": {"x": self.jugador.x, "y": self.jugador.y, "direccion": self.jugador.direccion},
            "pos_base": list(self.pos_base),
            "fuera_pos": list(self._fuera_pos) if self._fuera_pos else None,
            "reloj": {"segundos": c.reloj.segundos, "ciclos": c.reloj.ciclos},
            "clima": {"fase": c.fase, "segundos_restantes": c.segundos_restantes, "proximo": c._proximo,
                      "intensidad": c.intensidad,
                      "evento": c.eventos.index(c.evento) if c.evento in c.eventos else None},
            "polvo": ({"fase": self.polvo.fase, "segundos_restantes": self.polvo.segundos_restantes,
                       "tipo": self.polvo.tipo} if self.polvo else None),
            "eventos_marte": self.eventos_marte.a_dict() if self.eventos_marte else None,
            "crateres": [list(cr) for cr in self.crateres],
            "amortiguar": c.reloj.amortiguar,
            "producido": dict(self.producido),
            "sembrados": self._sembrados,
            "datos_vistos": sorted(self._datos_vistos),
            "companero": {**self.companero.a_dict(),        # dónde está (ronda 32: sin carga no te sigue)
                          "lugar": list(self._comp_lugar) if self._comp_lugar else None},
        }
        if any(self.traje.values()):         # ronda 33: solo si hay alguna mejora (partidas viejas: nivel 0)
            d["traje"] = dict(self.traje)
        if self.es_demo:                     # ronda 28: solo la partida de demostración lleva estas claves
            d["demo"] = True
        if self.letreros:
            d["letreros"] = [list(l) for l in self.letreros]
        return d

    def aplicar_dict(self, d):
        """Pone el juego en el estado `d` (de estado_a_dict). Lanza un error si el
        archivo no tiene lo esperado; cargar_partida se encarga de recuperarse."""
        if d.get("version") != PARTIDA_VERSION or d["destino"] not in (LUNA, MARTE):
            raise ValueError("versión o destino desconocidos")
        mapa = d["mapa"]
        if len(mapa) != FILAS or any(len(fila) != COLUMNAS for fila in mapa):
            raise ValueError("mapa de otro tamaño")
        self.nueva_partida(d["destino"])
        self.mapa = [[int(v) for v in fila] for fila in mapa]
        self.colores_cable = {(int(f), int(c)): color for f, c, color in d["colores_cable"]
                              if color in COLOR_CABLE_DE}
        self.piezas_cable = {(int(f), int(c)): (forma, int(giro) % 4)
                             for f, c, forma, giro in d.get("piezas_cable", []) if forma in LADOS_FORMA}
        if self.eventos_marte:               # cráteres de impacto (partidas viejas: ninguno)
            for f0, c0 in d.get("crateres", []):
                self.poner_crater(int(f0) % FILAS, int(c0) % COLUMNAS)
        for f, c, datos_tl in d["taladros"]:
            tl = Taladro(self._azar_botin)
            tl.nivel = int(datos_tl["nivel"])
            tl.almacen = [r for r in datos_tl["almacen"] if r in RECURSOS]
            tl.progreso = float(datos_tl["progreso"])
            self.taladros[(int(f), int(c))] = tl
            self.hielo_de_crater(tl, int(f), int(c))
        for f, c, datos_mq in d["maquinas"]:
            if datos_mq["clase"] == "tanque":
                mq = Tanque()
                mq.hidrogeno = int(datos_mq["hidrogeno"])
            else:
                mq = Maquina(datos_mq["tipo"], datos_mq["cultivo"])
                for campo in ("entrada", "salida", "producidas"):
                    setattr(mq, campo, int(datos_mq[campo]))
                mq.progreso = float(datos_mq["progreso"])
            self.maquinas[(int(f), int(c))] = mq
        self.antenas = {(int(f), int(c)) for f, c in d["antenas"]}
        self.macetas = [None] * MACETAS_BASE
        self.cuarto = "habitable"
        for i, dm in enumerate(d.get("macetas", [])[:MACETAS_BASE]):
            if dm:
                mq = Maquina(maquinas.INVERNADERO, dm["cultivo"])
                mq.entrada, mq.salida, mq.producidas = int(dm["entrada"]), int(dm["salida"]), int(dm["producidas"])
                mq.progreso = float(dm["progreso"])
                self.macetas[i] = mq
        self.baterias = {(int(f), int(c)): float(q) for f, c, q in d.get("baterias", [])}
        self.tanques_agua = {(int(f), int(c)): int(q) for f, c, q in d.get("tanques_agua", [])}
        self.contacto_hecho = bool(d["contacto_hecho"])
        self._msg_tierra = int(d["msg_tierra"])
        for recurso in RECURSOS:
            self.inventario[recurso] = int(d["inventario"].get(recurso, 0))
            self.almacen[recurso] = int(d["almacen"].get(recurso, 0))
        self.objetos = {o: int(d["objetos"].get(o, 0)) for o in OBJETOS}
        self.rapida = [o if o in OBJETOS else None for o in d["rapida"]][:RAPIDA_N]
        self.rapida += [None] * (RAPIDA_N - len(self.rapida))
        self.en_mano = d["en_mano"] if d["en_mano"] in OBJETOS else None
        self.color_cable = d["color_cable"] if d["color_cable"] in OPCIONES_CABLE else CABLE_COLORES[0]
        for campo, valor in d["astronauta"].items():
            setattr(self.astronauta, campo, valor if campo == "causa_muerte" else float(valor))
        self.jugador.x = float(d["jugador"]["x"]) % MAPA_ANCHO
        self.jugador.y = float(d["jugador"]["y"]) % MAPA_ALTO
        self.jugador.direccion = d["jugador"]["direccion"]
        self.pos_base = [float(v) for v in d["pos_base"]]
        self._fuera_pos = tuple(d["fuera_pos"]) if d["fuera_pos"] else None
        self.escena = ESCENA_BASE if d["escena"] == ESCENA_BASE else ESCENA_MAPA
        c = self.clima
        c.reloj.segundos = float(d["reloj"]["segundos"]) % modulo_clima.DURACION_CICLO
        c.reloj.ciclos = int(d["reloj"]["ciclos"])
        c.fase = d["clima"]["fase"]
        c.segundos_restantes = float(d["clima"]["segundos_restantes"])
        c._proximo = int(d["clima"]["proximo"])
        c.intensidad = d["clima"]["intensidad"]
        indice = d["clima"]["evento"]
        c.evento = c.eventos[indice] if indice is not None else None
        self._fase_clima = c.fase
        if not c.automatico and c.fase == CALMA:      # Marte: la calma espera a eventos_marte
            c.segundos_restantes = CALMA_SIN_FIN      # (en partidas viejas traía una cuenta regresiva)
        if self.polvo and d["polvo"]:
            self.polvo.fase = d["polvo"]["fase"]
            self.polvo.segundos_restantes = float(d["polvo"]["segundos_restantes"])
            tipo = d["polvo"].get("tipo", "regional")
            if tipo in ("regional", "global"):
                cfg = CONFIG_MARTE["polvo_" + tipo]
                self.polvo.tipo, self.polvo.aviso, self.polvo.duracion = tipo, cfg["aviso"], cfg["duracion"]
            if self.polvo.fase == POLVO_EN_CALMA:
                self.polvo.segundos_restantes = CALMA_SIN_FIN
        if self.eventos_marte and d.get("eventos_marte"):
            self.eventos_marte.de_dict(d["eventos_marte"])
        c.reloj.amortiguar = float(d.get("amortiguar", 0.0)) if self.eventos_marte else 0.0
        self.producido.update({k: int(v) for k, v in d["producido"].items()})
        self._sembrados = int(d["sembrados"])
        self._datos_vistos = set(d["datos_vistos"])
        if d.get("companero"):               # partidas viejas: sin compañero
            self.companero.de_dict(d["companero"])
            lugar = d["companero"].get("lugar")          # partidas viejas: donde está el astronauta
            self._comp_lugar = tuple(lugar) if lugar and self.companero.sin_carga else self.lugar_actual()
        self.es_demo = bool(d.get("demo", False))      # partida de demostración (ronda 28)
        for linea in self.traje:                       # mejoras del traje (ronda 33); sin el dato: nivel 0
            self.traje[linea] = max(0, min(TRAJE_NIVEL_MAX, int(d.get("traje", {}).get(linea, 0))))
        self.letreros = [[int(l[0]), int(l[1]), str(l[2]), str(l[3]), str(l[4]), l[5]]
                         for l in d.get("letreros", []) if len(l) == 6]
        self.dato = None                     # sin el dato de bienvenida de Marte al cargar
        # Lo que se calcula solo: energía, contacto, cámara y barras dibujadas.
        self._energia_sucia = True
        self.actualizar_antena(0.0, avisar=False)
        self.camara = calcular_camara(self.jugador)
        self._cam = [float(v) for v in self.camara]
        self._barra_vista = {b: self.astronauta.fraccion(b) for b in BARRAS}
        self._nivel_previo = {OXIGENO: self.astronauta.nivel_aviso(OXIGENO), DOSIS: self.astronauta.nivel_aviso(DOSIS)}
        self.reiniciar_sonido()          # ronda 37: lo que cambió al cargar no suena como si acabara de pasar

    def puede_guardar(self):
        """Solo se guarda jugando: no muerto ni en el final."""
        return self.astronauta.vivo and self.escena_final is None

    def nombre_ranura(self, ruta):
        """Nombre de la ranura: el que ya tenía, o "Partida N" si es nueva."""
        try:
            nombre = partidas.leer(ruta).get("meta", {}).get("nombre")
            if nombre:
                return nombre
        except (OSError, ValueError, AttributeError):
            pass
        numero = partidas._numero(os.path.basename(ruta))
        return t("partida_nombre", n=numero if numero is not None else "?")

    def guardar_partida(self, ruta=None):
        """Guarda en `ruta`, o en el slot actual, o en el primer slot libre (ronda
        25: 3 slots). Si los 3 están llenos y no hay slot actual, avisa que se elija
        uno en Partidas. partidas.escribir usa un temporal: si algo falla a medias,
        la partida anterior no se pierde."""
        if not self.puede_guardar():
            self.mensaje = t("partida_no_ahora")
            self.sonar("error")
            return False
        if ruta is None:
            if partidas.numero_slot(self.ranura_actual) is not None:
                ruta = self.ranura_actual
            else:
                libre = partidas.primer_libre(CARPETA)
                if libre is None:
                    self.mensaje = t("slots_llenos")
                    self.sonar("error")
                    return False
                ruta = partidas.ruta_slot(CARPETA, libre)
        try:
            nombre = self.nombre_ranura(ruta)
            partidas.escribir(ruta, self.estado_a_dict(), nombre)
        except (OSError, TypeError, ValueError):
            self.mensaje = t("partida_error_guardar")
            self.sonar("error")
            return False
        self.ranura_actual = ruta
        self.refrescar_partidas()
        self.mensaje = t("partida_guardada_en", nombre=nombre)
        self.sonar("guardar")
        return True

    def cargar_partida(self, ruta=None):
        """Carga `ruta` (o la ranura más reciente). Si no hay o está dañada, avisa
        y deja la partida actual tal como estaba (nunca a medias)."""
        try:
            ruta = ruta or partidas.mas_reciente(CARPETA)
        except OSError:
            ruta = None
        if not ruta or not os.path.exists(ruta):
            self.mensaje = t("partida_no_hay")
            self.sonar("error")
            return False
        try:
            d = partidas.leer(ruta)
        except (OSError, ValueError):
            self.mensaje = t("partida_danada")
            self.sonar("error")
            return False
        respaldo, anterior = self.estado_a_dict(), self.ranura_actual
        try:
            self.aplicar_dict(d)
        except (KeyError, ValueError, TypeError, AttributeError, IndexError):
            self.aplicar_dict(respaldo)
            self.ranura_actual = anterior
            self.mensaje = t("partida_danada")
            return False
        self.ranura_actual = ruta
        nombre = (d.get("meta") or {}).get("nombre") or os.path.basename(ruta)
        self.mensaje = t("partida_cargada_de", nombre=nombre)
        self.sonar("exito")
        return True

    def info_partida(self):
        """Texto corto de la partida (la ranura actual o la más reciente): día,
        hora y lugar; o el de "no hay"."""
        try:
            ruta = self.ranura_actual or partidas.mas_reciente(CARPETA)
            d = partidas.leer(ruta)
            dia, hora = partidas.dia_y_hora(d)
            return t("terminal_hay", dia=dia, hora=hora, lugar=t("lugar_" + d["destino"]))
        except (OSError, ValueError, KeyError, TypeError):
            return t("terminal_no_hay")
