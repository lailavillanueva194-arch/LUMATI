"""Sonido del juego (ronda 37): efectos, música y ambiente.

Los sonidos se fabrican en sonido.py (por código; si existe assets/sonidos/<nombre>.wav
se usa ese). Aquí se reproducen:

- `self.sonar("nombre")` es lo único que llama el resto del juego. Nunca falla: si no
  hay dispositivo de audio, si el sonido está apagado o si todavía no está listo, no hace nada.
- `actualizar_sonido(dt)` corre una vez por cuadro (desde Juego.run, no desde
  avanzar_mundo, así dormir no hace una avalancha de sonidos). Mueve los bucles
  (música, ambiente, viento, zumbido de máquinas), los pasos, el Geiger, el latido y
  avisa de los cambios del mundo (fases de la tormenta solar, polvo, antena, muerte...).
- Nada de esto cambia las reglas del juego ni el guardado. El azar del sonido es
  propio (no toca el `random` del juego).

Modos (tecla O o botón de la pausa): todo, solo efectos, silencio.
"""

import math
import os
import queue
import random
import threading

import pygame

import sonido
from clima import CALMA, CME_EN_CAMINO, LLAMARADA, PARTICULAS, POLVO_ACTIVA, POLVO_EN_AVISO, POLVO_EN_CALMA
from config import (ANTENA, BATERIA, BLOQUE, CARPETA, ESCENA_BASE, ESCENA_MAPA, ESCENAS_FINAL, INVERNADERO, MAQUINAS,
                    MARTE, TANQUE_AGUA, TILE)
from maquinas import Maquina
from supervivencia import CRITICO, OXIGENO
from textos import t

TODO, SOLO_EFECTOS, SILENCIO = 0, 1, 2
MODOS = (TODO, SOLO_EFECTOS, SILENCIO)
CARPETA_SONIDOS = os.path.join(CARPETA, "assets", "sonidos")

VOLUMEN_EFECTOS = 0.65         # efectos (bajado de 0.9)
VOLUMEN_MUSICA = 0.38          # música (bajada de 0.55)
VOLUMEN_AMBIENTE = 0.7         # zumbidos, viento y máquinas de fondo
PASO_PX = 64                  # un paso suena cada tantos píxeles caminados (~2.8 por segundo)
MAQUINA_RADIO = 6.0           # cuadros: a esta distancia se deja de oír el zumbido de una máquina
LISTO_RADIO = 9.0             # cuadros: a esta distancia se oye que una máquina terminó algo

# Segundos mínimos entre dos sonidos iguales (para que clics rápidos no se amontonen).
ESPERA = {"error": 0.35, "clic": 0.03, "colocar": 0.05, "cable": 0.045, "cable_quitar": 0.045, "quitar": 0.05,
          "listo": 0.8, "alerta_baja": 2.0, "alerta_critica": 2.0, "geiger": 0.0, "latido": 0.0,
          "paso_luna": 0.0, "paso_marte": 0.0, "paso_base": 0.0, "pieza": 0.06, "pestana": 0.06,
          "recoger": 0.06, "agua": 0.08, "puerta": 0.4, "dato": 0.6}

# Orden en que se fabrican (lo que se usa primero, primero).
PRIORIDAD = ("clic", "volver", "abrir", "cerrar", "seleccion", "error", "musica_menu", "exito", "pestana", "guardar")


class _Bucle:
    """Un canal que repite un sonido y cambia de uno a otro con fundido: baja el
    volumen, cambia de sonido y vuelve a subir. El volumen sigue a `meta` poco a poco."""

    def __init__(self, canal, fundido=0.8):
        self.canal = canal
        self.fundido = fundido
        self.nombre = None
        self.volumen = 0.0

    def paso(self, dt, sonidos, nombre, meta):
        if nombre is not None and nombre not in sonidos:
            nombre = self.nombre                      # aún no está listo: se queda como estaba
        if nombre is None or nombre != self.nombre:
            meta = 0.0                                # primero se apaga el anterior (o no suena nada)
        salto = dt / self.fundido
        self.volumen = min(meta, self.volumen + salto) if self.volumen < meta else max(meta, self.volumen - salto)
        if nombre != self.nombre and self.volumen <= 0.002:
            self.canal.stop()
            self.nombre = None
            if nombre is not None:
                self.canal.play(sonidos[nombre], loops=-1)
                self.nombre = nombre
        self.canal.set_volume(self.volumen if self.nombre is not None else 0.0)

    def parar(self):
        self.canal.stop()
        self.nombre = None
        self.volumen = 0.0


class SonidoMixin:
    """Efectos, música y ambiente. Todo es opcional: sin audio, el juego sigue igual."""

    _snd_ok = False                  # hay dispositivo de audio y todo arrancó
    _modo_sonido = TODO

    # -- arranque ------------------------------------------------------------
    @staticmethod
    def preparar_mixer():
        """Antes de pygame.init(): audio con poca latencia (si no, los clics suenan tarde)."""
        try:
            pygame.mixer.pre_init(44100, -16, 2, 512)
        except pygame.error:
            pass

    def iniciar_sonido(self):
        """Después de pygame.init(): abre el mixer y empieza a fabricar los sonidos en
        otro hilo (el juego no espera: lo que aún no está listo, no suena)."""
        self._sonidos = {}
        self._llegan = queue.SimpleQueue()
        self._ultimo = {}
        self._azar_sonido = random.Random()
        self._ref_sonido = None
        self._paso_pos = None
        self._paso_dist = 0.0
        self._geiger_t = 0.0
        self._latido_t = 0.0
        self._maq_t = 0.0
        self._maq_cerca = 0.0
        self._maq_cuenta = {}
        self._atenuado = 1.0
        self._snd_ok = False
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init()
            if not pygame.mixer.get_init():
                return
            pygame.mixer.set_num_channels(24)
            pygame.mixer.set_reserved(4)
            self._bucle_musica = _Bucle(pygame.mixer.Channel(0), 1.2)
            self._bucle_ambiente = _Bucle(pygame.mixer.Channel(1), 1.0)
            self._bucle_maquina = _Bucle(pygame.mixer.Channel(2), 0.5)
            self._bucle_viento = _Bucle(pygame.mixer.Channel(3), 1.2)
        except (pygame.error, NotImplementedError):
            return
        self._snd_ok = True
        nombres = list(PRIORIDAD) + [n for n in sonido.nombres() if n not in PRIORIDAD]
        hilo = threading.Thread(target=self._fabricar_sonidos, args=(nombres,), daemon=True)
        hilo.start()

    def _fabricar_sonidos(self, nombres):
        """(Otro hilo) Sintetiza cada sonido y lo deja en la cola; no toca pygame."""
        for nombre in nombres:
            try:
                self._llegan.put((nombre, sonido.preparar(nombre, CARPETA_SONIDOS)))
            except Exception:                                  # un sonido malo no tumba a los demás
                continue

    def _recibir_sonidos(self):
        """(Hilo principal) Pasa a pygame los sonidos que ya se fabricaron."""
        for _ in range(4):
            try:
                nombre, preparado = self._llegan.get_nowait()
            except queue.Empty:
                return
            snd = sonido.a_sonido(preparado)
            if snd is not None:
                self._sonidos[nombre] = snd

    # -- modos -----------------------------------------------------------------------
    def ciclar_sonido(self):
        """Tecla O o botón de la pausa: todo -> solo efectos -> silencio -> todo."""
        self._modo_sonido = MODOS[(MODOS.index(self._modo_sonido) + 1) % len(MODOS)]
        if self._snd_ok:
            if self._modo_sonido == SILENCIO:
                pygame.mixer.stop()                       # corta lo que suena (y los bucles, que se rearman solos)
                for b in (self._bucle_musica, self._bucle_ambiente, self._bucle_maquina, self._bucle_viento):
                    b.parar()
            elif self._modo_sonido == SOLO_EFECTOS:
                self._bucle_musica.parar()
        self.mensaje = t("sonido_" + ("todo", "efectos", "silencio")[self._modo_sonido])
        self.sonar("clic")

    @property
    def texto_modo_sonido(self):
        return t("sonido_modo_" + ("todo", "efectos", "silencio")[self._modo_sonido])

    # -- efectos puntuales -----------------------------------------------------------
    def sonar(self, nombre, vol=1.0):
        """Hace sonar un efecto (vol de 0 a 1). Nunca falla ni espera."""
        if not self._snd_ok or self._modo_sonido == SILENCIO:
            return
        snd = self._sonidos.get(nombre)
        if snd is None:
            return
        ahora = pygame.time.get_ticks() / 1000.0
        if ahora - self._ultimo.get(nombre, -9.0) < ESPERA.get(nombre, 0.04):
            return
        self._ultimo[nombre] = ahora
        try:
            canal = snd.play()           # respeta los 4 canales reservados de los bucles (find_channel no)
            if canal is not None:
                canal.set_volume(max(0.0, min(1.0, vol * VOLUMEN_EFECTOS)))
        except pygame.error:
            pass

    def sonar_mundo(self, nombre):
        """Un estruendo del mundo (sismo, impacto, remolino): dentro de la base llega más bajo."""
        self.sonar(nombre, 0.45 if self.escena == ESCENA_BASE else 1.0)

    @staticmethod
    def sonido_de_construir(tipo):
        """Qué suena al colocar algo: bloque, máquina, batería, invernadero..."""
        if tipo == BATERIA:
            return "bateria"
        if tipo == INVERNADERO:
            return "sembrar"
        if tipo in MAQUINAS or tipo in (ANTENA, TANQUE_AGUA):
            return "maquina"
        return "colocar"

    def sonar_cerca(self, nombre, fila, col, radio=LISTO_RADIO):
        """Un efecto que viene de un cuadro del mapa: más bajo cuanto más lejos (y mudo pasado `radio`)."""
        if self.escena != ESCENA_MAPA:
            return
        d = self._distancia_cuadros(fila, col)
        if d < radio:
            self.sonar(nombre, 1.0 - 0.8 * d / radio)

    def _distancia_cuadros(self, fila, col):
        from config import MAPA_ALTO, MAPA_ANCHO
        from mapa import distancia_corta
        jx, jy = self.jugador.centro
        dx = distancia_corta(col * TILE + TILE / 2, jx, MAPA_ANCHO)
        dy = distancia_corta(fila * TILE + TILE / 2, jy, MAPA_ALTO)
        return math.hypot(dx, dy) / TILE

    def reiniciar_sonido(self):
        """Partida nueva o cargada, o tras dormir: lo que cambió "de golpe" no debe sonar
        como si acabara de pasar. La próxima vez, actualizar_sonido solo toma nota."""
        self._ref_sonido = None
        self._paso_pos = None
        self._maq_cuenta = {}

    # -- cada cuadro -----------------------------------------------------------------
    def actualizar_sonido(self, dt):
        if not self._snd_ok:
            return
        self._recibir_sonidos()
        jugando = self.opciones is None
        modo = self._modo_sonido
        self._atenuado += ((0.3 if (not jugando and not self.en_inicio) else 1.0) - self._atenuado) * min(1.0, 6 * dt)
        en_juego = (jugando and self.cinematica is None and self.escena_final is None
                    and self.astronauta.vivo and not self._fundido)
        if jugando:
            self._avisos_del_mundo()
        if en_juego:
            self._pasos(dt)
            self._peligros(dt)
            self._sonido_maquinas(dt)
        else:
            self._paso_pos = None
            self._maq_cerca = 0.0
        # bucles
        self._bucle_musica.paso(dt, self._sonidos, self._musica_objetivo() if modo == TODO else None,
                                VOLUMEN_MUSICA * self._atenuado)
        ambiente, viento, v_ambiente, v_viento = self._ambiente_objetivo(jugando)
        silencio = modo == SILENCIO
        self._bucle_ambiente.paso(dt, self._sonidos, None if silencio else ambiente, v_ambiente * VOLUMEN_AMBIENTE * self._atenuado)
        self._bucle_viento.paso(dt, self._sonidos, None if silencio else viento, v_viento * VOLUMEN_AMBIENTE * self._atenuado)
        self._bucle_maquina.paso(dt, self._sonidos, None if silencio or not self._maq_cerca else "ambiente_maquina",
                                 self._maq_cerca * 0.5 * VOLUMEN_AMBIENTE * self._atenuado)

    def _musica_objetivo(self):
        if self.opciones is not None:
            if self.en_inicio:
                return "musica_menu"
            return self._bucle_musica.nombre            # pausa: sigue la que estaba (más baja)
        if self.cinematica is not None:
            return "musica_viaje"
        if self.escena_final is not None:
            return "musica_final"
        if not self.astronauta.vivo:
            return None
        if self.escena == ESCENA_BASE:
            return "musica_base"
        return "musica_marte" if self.destino == MARTE else "musica_luna"

    def _ambiente_objetivo(self, jugando):
        """(sonido de fondo, viento, volumen del fondo, volumen del viento)."""
        if self.en_inicio or self.cinematica is not None or self.escena_final is not None or not self.astronauta.vivo:
            return None, None, 0.0, 0.0
        if self.escena == ESCENA_BASE:
            return "ambiente_base", None, 0.45, 0.0
        viento = None
        v_viento = 0.0
        if self.destino == MARTE:                       # la Luna no tiene aire: ahí no hay viento
            viento = "ambiente_viento"
            v_viento = 0.12 + 0.55 * min(1.0, self._polvo_velo / 1.6)
            if self.polvo is not None and self.polvo.fase == POLVO_EN_AVISO:
                v_viento = max(v_viento, 0.3)
        return "ambiente_traje", viento, 0.3, v_viento

    # -- pasos ---------------------------------------------------------------------
    def _pasos(self, dt):
        if self.escena == ESCENA_BASE:
            pos = (ESCENA_BASE, self.pos_base[0], self.pos_base[1])
        else:
            pos = (ESCENA_MAPA, self.jugador.x, self.jugador.y)
        previo, self._paso_pos = self._paso_pos, pos
        if previo is None or previo[0] != pos[0]:
            self._paso_dist = 0.0
            return
        d = math.hypot(pos[1] - previo[1], pos[2] - previo[2])
        if d > 80:                                      # se teletransportó (cruzó el borde, rescate...)
            return
        self._paso_dist += d
        if self._paso_dist >= PASO_PX:
            self._paso_dist -= PASO_PX
            if self.escena == ESCENA_BASE:
                self.sonar("paso_base")
            else:
                self.sonar("paso_marte" if self.destino == MARTE else "paso_luna")

    # -- peligros: Geiger y latido -------------------------------------------------------
    def _peligros(self, dt):
        if self.clima.en_peligro:
            _, blindaje = self.blindaje_total()
            # El contador clica más rápido cuanto menos te protege el lugar: se oye por qué la base sirve.
            ritmo = 2.0 + 26.0 * (1.0 - blindaje)
            self._geiger_t -= dt
            veces = 0
            while self._geiger_t <= 0 and veces < 6:
                self.sonar("geiger", 0.5 + 0.5 * (1.0 - blindaje))
                self._geiger_t += self._azar_sonido.expovariate(ritmo)
                veces += 1
            self._geiger_t = max(self._geiger_t, -0.2)
        else:
            self._geiger_t = 0.0
        if self.astronauta.nivel_aviso(OXIGENO) == CRITICO:
            self._latido_t -= dt
            if self._latido_t <= 0:
                self.sonar("latido")
                self._latido_t = 1.05
        else:
            self._latido_t = 0.0

    # -- máquinas: zumbido cerca y aviso de que terminaron -----------------------------
    def _sonido_maquinas(self, dt):
        self._maq_t -= dt
        if self._maq_t > 0:
            return
        self._maq_t = 0.25
        if self.escena != ESCENA_MAPA:
            self._maq_cerca = 0.0
            return
        cerca = 0.0
        cuenta = {}
        for (f, c), mq in self.maquinas.items():
            if not isinstance(mq, Maquina):
                continue
            cuenta[(f, c)] = mq.producidas
            if self.estado_maquina(f, c) == "produciendo":
                cerca = max(cerca, 1.0 - self._distancia_cuadros(f, c) / MAQUINA_RADIO)
        for (f, c), td in self.taladros.items():
            cuenta[(f, c)] = td.cantidad
            if td.estado(self.tiene_energia(f, c)) == "produciendo":
                cerca = max(cerca, 1.0 - self._distancia_cuadros(f, c) / MAQUINA_RADIO)
        self._maq_cerca = max(0.0, cerca)
        for clave, n in cuenta.items():                 # algo nuevo salió: un "pling" suave (más bajo si está lejos)
            if n > self._maq_cuenta.get(clave, n):
                self.sonar_cerca("listo", *clave)
        self._maq_cuenta = cuenta

    # -- lo que pasa en el mundo --------------------------------------------------------
    def _estado_para_sonido(self):
        dato = self.dato[0] if self.dato else None
        return {"destino": self.destino, "fase": self.clima.fase, "polvo": self.polvo.fase if self.polvo else None,
                "contacto": self.contacto, "vivo": self.astronauta.vivo, "dato": dato,
                "final": self.escena_final is not None and self.escena_final >= ESCENAS_FINAL}

    def _avisos_del_mundo(self):
        """Compara con el cuadro anterior y suena lo que cambió: fases de la tormenta solar
        y del polvo, contacto con la Tierra, datos, muerte y rescate, el final."""
        ahora = self._estado_para_sonido()
        antes, self._ref_sonido = self._ref_sonido, ahora
        if antes is None or antes["destino"] != ahora["destino"]:
            return
        if ahora["fase"] != antes["fase"]:
            if ahora["fase"] == LLAMARADA:
                self.sonar("sirena")
            elif ahora["fase"] == CME_EN_CAMINO:
                self.sonar("cme")
            elif ahora["fase"] == PARTICULAS:
                self.sonar("alarma")
            elif ahora["fase"] == CALMA and antes["fase"] == PARTICULAS:
                self.sonar("calma")
        if ahora["polvo"] != antes["polvo"]:
            if ahora["polvo"] == POLVO_EN_AVISO:
                self.sonar("polvo_aviso")
            elif ahora["polvo"] == POLVO_ACTIVA:
                self.sonar("polvo_llega")
            elif ahora["polvo"] == POLVO_EN_CALMA and antes["polvo"] == POLVO_ACTIVA:
                self.sonar("calma")
        if ahora["contacto"] != antes["contacto"]:
            self.sonar("antena_contacto" if ahora["contacto"] else "antena_perdida")
        if ahora["dato"] is not None and ahora["dato"] != antes["dato"]:
            self.sonar("dato")
        if ahora["vivo"] != antes["vivo"]:
            self.sonar("rescate" if ahora["vivo"] else "muerte")
        if ahora["final"] and not antes["final"]:
            self.sonar("final")
