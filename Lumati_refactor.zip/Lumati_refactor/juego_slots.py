"""Pantalla de Partidas con 3 slots de guardado (ronda 25): una tarjeta grande por
slot con el nombre, el destino (con su planeta), día y hora del juego, la fecha
real del guardado y estadísticas sacadas del propio guardado. Acciones: Cargar,
Guardar aquí (solo desde la pausa) y Borrar (mueve el archivo a
partidas/_borradas/). Desde el menú principal se dibuja sobre el fondo decorado;
desde la pausa, sobre el juego oscurecido.
"""

import pygame

import estilo
import fondo_menu
import partidas
from supervivencia import COMIDA, DOSIS, OXIGENO
from textos import t
from arte import ajustar_texto
from config import ALTO, ANCHO, CARPETA, GENERADOR, SLOT_ARRIBA, SLOT_MARGEN, SLOT_SEP

COLOR_TEXTO_CLARO = (206, 212, 224)       # texto sobre el espacio o el juego oscurecido
SLOT_ENTRE_COLUMNAS = 16                  # espacio entre las dos columnas de estadísticas


class SlotsMixin:
    """Pantalla de Partidas con 3 slots: tarjetas, estadísticas y acciones."""

    def slots(self):
        """Los 3 slots con su información (se lee una vez y se guarda hasta que
        algo cambie: guardar, borrar o abrir la pantalla)."""
        if self._slots is None:
            try:
                self._slots = partidas.leer_slots(CARPETA, GENERADOR)
            except OSError:
                self._slots = []
        return self._slots

    def refrescar_partidas(self):
        """Olvida lo leído de las partidas (después de guardar o borrar)."""
        self._lista_partidas = None
        self._slots = None

    # ---- rectángulos ------------------------------------------------------
    def rects_slots(self):
        """Rectángulo de cada tarjeta, lado a lado."""
        ancho = (ANCHO - 2 * SLOT_MARGEN - 2 * SLOT_SEP) // 3
        alto = ALTO - SLOT_ARRIBA - 82
        return [pygame.Rect(SLOT_MARGEN + i * (ancho + SLOT_SEP), SLOT_ARRIBA, ancho, alto) for i in range(3)]

    def botones_slot(self, i):
        """{acción: rect} de los botones de la tarjeta i según lo que se puede hacer."""
        r = self.rects_slots()[i]
        slot = self.slots()[i] if i < len(self.slots()) else {"ocupado": False, "danada": False}
        x, ancho = r.x + 14, r.w - 28
        abajo = pygame.Rect(x, r.bottom - 54, ancho, 40)
        arriba = pygame.Rect(x, r.bottom - 102, ancho, 40)
        mitad = (ancho - 10) // 2
        botones = {}
        if slot["ocupado"] and not slot["danada"]:
            botones["cargar"] = arriba
        if not self.en_inicio:                                   # guardar solo desde la pausa
            if slot["ocupado"]:
                botones["guardar"] = pygame.Rect(x, abajo.y, mitad, 40)
                botones["borrar"] = pygame.Rect(x + mitad + 10, abajo.y, mitad, 40)
            else:
                botones["guardar"] = abajo
        elif slot["ocupado"]:
            botones["borrar"] = abajo
        return botones

    def boton_volver_slots(self):
        return pygame.Rect(ANCHO // 2 - 75, ALTO - 58, 150, 44)

    # ---- acciones ----------------------------------------------------------
    def clic_slots(self, pos):
        if self.boton_volver_slots().collidepoint(pos):
            self.sonar("volver")
            self.opciones = self.pagina_principal()
            return
        for i, slot in enumerate(self.slots()):
            for accion, rect in self.botones_slot(i).items():
                if not rect.collidepoint(pos):
                    continue
                self.sonar("clic")
                if accion == "cargar":
                    self.cargar_desde_menu(slot["ruta"])
                elif accion == "guardar":
                    if not self.puede_guardar():
                        self.mensaje = t("partida_no_ahora")
                    elif slot["ocupado"]:                        # ocupado: pregunta antes de pisarlo
                        self._confirmar = ("sobrescribir", slot["ruta"], slot.get("nombre", ""))
                    else:
                        self.guardar_partida(slot["ruta"])
                elif accion == "borrar":
                    self._confirmar = ("borrar", slot["numero"], slot.get("nombre", ""))
                return

    def borrar_slot(self, n):
        """Deja libre el Slot n. El archivo no se elimina: va a partidas/_borradas/."""
        try:
            partidas.borrar_slot(CARPETA, n)
        except OSError:
            self.mensaje = t("partida_error_guardar")
            return False
        if partidas.numero_slot(self.ranura_actual) == n:
            self.ranura_actual = None
        self.refrescar_partidas()
        self.mensaje = t("slot_borrado", n=n)
        return True

    # ---- dibujo ------------------------------------------------------------
    def _icono_slot(self, clave):
        """Ícono chico (20 px) para las estadísticas, hecho una vez."""
        cache = self._iconos_slot
        if clave not in cache:
            if clave in (OXIGENO, COMIDA, DOSIS):
                img = self.iconos_vitales[clave]
            elif clave == "agua":
                img = self.iconos_recurso_chico["agua"]
            else:
                img = self.iconos_objeto[clave]
            cache[clave] = pygame.transform.smoothscale(img, (20, 20)) if img.get_size() != (20, 20) else img
        return cache[clave]

    def dibujar_slots(self):
        p = self.pantalla
        titulo = self.fuente_grande.render(t("slots_titulo"), True, estilo.CREMA)
        p.blit(titulo, titulo.get_rect(midtop=(ANCHO // 2, 20)))
        ayuda = self.fuente_chica.render(t("slots_ayuda_inicio" if self.en_inicio else "slots_ayuda_pausa"),
                                         True, COLOR_TEXTO_CLARO)
        p.blit(ayuda, ayuda.get_rect(midtop=(ANCHO // 2, 60)))
        raton = pygame.mouse.get_pos()
        for i, (r, slot) in enumerate(zip(self.rects_slots(), self.slots())):
            self._dibujar_slot(i, r, slot, r.collidepoint(raton))
        self._boton(self.boton_volver_slots(), t("opc_volver"))

    def _dibujar_slot(self, i, r, slot, encima):
        p = self.pantalla
        tinta, suave = estilo.TINTA, estilo.TINTA_SUAVE
        actual = slot["ocupado"] and slot["ruta"] == self.ranura_actual and not self.en_inicio
        estilo.panel(p, r, borde=estilo.ACENTO if (actual or encima) else None)
        x, y, ancho = r.x + 14, r.y + 14, r.w - 28
        p.blit(self.fuente_chica.render(t("slot_n", n=slot["numero"]), True, estilo.ACENTO), (x, y))
        if actual:
            marca = self.fuente_chica.render(t("partidas_actual"), True, estilo.ACENTO)
            p.blit(marca, marca.get_rect(topright=(r.right - 14, y)))
        if not slot["ocupado"]:                                  # slot libre: un + grande
            centro = (r.centerx, r.y + 150)
            pygame.draw.circle(p, estilo.CASILLA, centro, 46)
            pygame.draw.circle(p, estilo.ACENTO, centro, 46, 3)
            pygame.draw.line(p, estilo.ACENTO, (centro[0] - 22, centro[1]), (centro[0] + 22, centro[1]), 6)
            pygame.draw.line(p, estilo.ACENTO, (centro[0], centro[1] - 22), (centro[0], centro[1] + 22), 6)
            libre = self.fuente.render(t("slot_libre"), True, tinta)
            p.blit(libre, libre.get_rect(midtop=(r.centerx, r.y + 214)))
            if self.en_inicio:
                for k, linea in enumerate(self._cortar(t("slot_libre_inicio"), self.fuente_chica, ancho)):
                    img = self.fuente_chica.render(linea, True, suave)
                    p.blit(img, img.get_rect(midtop=(r.centerx, r.y + 246 + k * 18)))
        elif slot["danada"]:
            p.blit(self.fuente.render(t("partidas_danada").split(":")[0], True, tinta), (x, y + 30))
        else:
            self._dibujar_slot_ocupado(r, slot, x, y, ancho)
        for accion, rect in self.botones_slot(i).items():
            activo = accion != "guardar" or self.puede_guardar()
            self._boton(rect, t("slot_" + accion), activo,
                        borde=fondo_menu.COLOR_AVISO_SALIR if accion == "borrar" else None)

    def _cortar(self, texto, fuente, ancho):
        return ajustar_texto(texto, fuente, ancho)

    def _dibujar_slot_ocupado(self, r, slot, x, y, ancho):
        p = self.pantalla
        tinta, suave = estilo.TINTA, estilo.TINTA_SUAVE
        nombre = self._cortar(slot["nombre"], self.fuente, ancho)[0]
        p.blit(self.fuente.render(nombre, True, tinta), (x, y + 24))
        # Destino con su planeta, día y hora del juego
        planeta = fondo_menu.icono("luna" if slot["destino"] == "luna" else "marte", estilo.CONTORNO, 36)
        p.blit(planeta, (x, y + 52))
        p.blit(self.fuente.render(t("lugar_" + slot["destino"]), True, tinta), (x + 44, y + 52))
        p.blit(self.fuente_chica.render(t("slot_dia", dia=slot["dia"], hora=slot["hora"]), True, suave),
               (x + 44, y + 72))
        p.blit(self.fuente_chica.render(t("slot_guardada", fecha=slot["guardado"]), True, suave), (x, y + 96))
        estilo.separador(p, x, x + ancho, y + 118)
        # Estadísticas: ícono + nombre + número, en 2 columnas
        s = slot["stats"]
        izquierda = [(OXIGENO, "stat_oxigeno", str(s["oxigeno"])), ("agua", "stat_agua", str(s["agua"])),
                     (COMIDA, "stat_comida", str(s["comida"])), (DOSIS, "stat_dosis", f"{s['dosis_msv']:.0f} mSv"),
                     ("invernadero", "stat_macetas", str(s["macetas"]))]
        derecha = [("taladro", "stat_taladros", str(s["taladros"])),
                   ("purificador", "stat_maquinas", str(s["maquinas"])),
                   ("generador", "stat_paneles", str(s["paneles"])),
                   ("bateria", "stat_baterias", str(s["baterias"])),
                   ("antena", "stat_tierra", t("stat_si" if s["contacto"] else "stat_no"))]
        columna = (ancho - SLOT_ENTRE_COLUMNAS) // 2
        medio = x + columna + SLOT_ENTRE_COLUMNAS // 2         # línea fina entre las dos columnas
        pygame.draw.line(p, estilo.BISEL, (medio, y + 128), (medio, y + 128 + 5 * 26 - 6))
        for col, filas in enumerate((izquierda, derecha)):
            cx = x + col * (columna + SLOT_ENTRE_COLUMNAS)
            for k, (icono, clave, valor) in enumerate(filas):
                fy = y + 128 + k * 26
                p.blit(self._icono_slot(icono), (cx, fy))
                p.blit(self.fuente_chica.render(t(clave), True, suave), (cx + 24, fy + 3))
                numero = self.fuente_chica.render(valor, True, tinta)
                p.blit(numero, numero.get_rect(topright=(cx + columna, fy + 3)))
        # Hidrógeno del tanque más lleno: x/6 con barrita
        fy = y + 128 + 5 * 26 + 4
        p.blit(self.fuente_chica.render(t("stat_hidrogeno", h=s["hidrogeno"], max=s["hidrogeno_max"]), True, tinta),
               (x, fy))
        estilo.barra(p, pygame.Rect(x + ancho - 110, fy - 1, 110, 14), s["hidrogeno"] / s["hidrogeno_max"],
                     (240, 240, 250))
