"""Lumati - juego educativo de supervivencia espacial (pygame-ce).

Mapa toroidal de 32x32, jugador con colisión, cámara que lo sigue, redes de
cables, taladros de 3 niveles, inventario y una máquina de crafteo (el
Fabricador). Es de supervivencia: no hay barra con todo disponible; lo que
se construye primero se fabrica.

Controles
---------
WASD / flechas   Mover al astronauta
1 a 5            Acceso rápido: lleva a la mano lo que tenga esa casilla (también con
                 clic en la casilla). Para asignar: en el inventario (E), mouse sobre
                 un objeto y tecla 1 a 5
E                Abrir o cerrar el inventario. Abajo están los OBJETOS fabricados:
                 clic en uno para llevarlo en la mano (otro clic lo guarda)
Clic en el       Abrir el Fabricador: clic en una receta la fabrica (gasta recursos
Fabricador       y el objeto va al inventario)
Batería          Se fabrica; guarda energía de día y la da de noche o con polvo.
                 Clic en ella: cuánta carga tiene
Cable en la mano C o rueda: verde, azul, amarillo, NEGRO (troncal: une todos los colores,
                 solo en su dirección) y conectores +, T, L (unen cualquier color, solo
                 por los lados de su forma). R gira la pieza
TAB              Mostrar u ocultar el minimapa
Pico en la mano  Clic en el suelo: liso -> picado -> camino -> liso. El taladro
                 solo se pone en suelo picado
Clic en el mapa  Colocar lo que llevas en la mano (gasta una unidad). Con cable o
                 panel en la mano, clic sobre uno igual lo quita y vuelve al inventario
C / rueda        Color del siguiente cable: verde, azul o amarillo. Cada color es un
                 circuito aparte (no se juntan); máquinas y paneles toman cualquier color.
                 Con cable en la mano: clic en un cable de otro color lo pinta; del
                 mismo color, lo quita
Clic en la base  Entrar. Dentro se camina con WASD y se usa con clic (de cerca): cama
                 (dormir de noche), almacén, panel de sistemas, rack de cables,
                 terminal (guardar/cargar) y la puerta (o caminar hacia ella) para salir
F5 / F9          F5 guarda en la ranura actual (o en una nueva); F9 carga la partida más
                 reciente. Las ranuras están en la carpeta partidas/ junto a main.py
M                Mejorar el taladro bajo el mouse
X                Quitar el taladro o la máquina bajo el mouse (vuelve al inventario)
Clic en máquina  Recoger lo producido y meterle su ingrediente (lleves lo que lleves).
                 En un taladro: recoger lo que sacó
Clic en la nave  Despegar cuando un tanque de hidrógeno esté lleno
Espacio          En el final: pasar a la siguiente imagen
T                Disparar una tormenta solar ahora (modo demo). En Marte es el evento
                 de partículas solares (SEP), con su aviso previo
N                Adelantar el reloj hasta las 6, 12, 18 o 24 h (modo demo)
R                Tras morir: rescate (sin aire) o empezar de nuevo (radiación)
L                Cambiar el idioma (español / inglés)
O                Sonido: todo (música y efectos) -> solo efectos -> apagado. También en la pausa (Esc)
Cmd+F            Pantalla completa o ventana (en cualquier momento; en la Mac también
                 Ctrl+Cmd+F). Con el menú principal o la pausa abiertos, también F.
                 Botón arriba a la derecha del menú principal y opción en la pausa
Clic en la nave  Con un tanque de hidrógeno lleno: despegas. Desde la Luna se ve de
                 inmediato el viaje a Marte (Espacio lo salta) y empieza la partida en
                 Marte. Desde Marte: su cinemática final y la comparación con datos reales
M (en el final)  Al final de Marte: de vuelta a la Luna
Pausa (Esc) >    "Ver cinemáticas": las dos cinemáticas (Luna -> Marte y la final de
Ver cinemáticas  Marte) sin jugar. Al terminar se vuelve al juego como estaba
P (solo Marte)   Disparar una tormenta de polvo REGIONAL ahora (modo demo)
G (solo Marte)   Disparar una tormenta de polvo GLOBAL ahora (modo demo)
V (solo Marte)   Hacer pasar un remolino de polvo ahora (modo demo)
K (solo Marte)   Disparar un sismo ahora (modo demo)
I (solo Marte)   Disparar un impacto de meteorito ahora: cráter con hielo (modo demo)
Al abrir         Menú principal: Continuar (la partida más reciente), Nueva partida (Luna
                 o Marte), Partidas, Guía del juego y Salir
Esc              Menú de opciones (pausa): continuar, guía, partidas, guardar, menú
                 principal y salir (estos dos preguntan si guardar antes). Con otro menú
                 abierto, Esc solo lo cierra. Dentro de la guía o las partidas, Esc vuelve
I (en el final)  Volver al menú principal

Para empezar directo en Marte:  python main.py marte  (partida nueva en Marte, sin
pasar por el menú principal)
Para arrancar en pantalla completa:  python main.py --completa   (también "pantalla_completa";
se puede combinar: python main.py marte --completa)
"""

# Los mismos imports que tenía main.py antes del refactor: se conservan para que
# main.modulo_clima, main.Taladro, main.t... sigan existiendo (pruebas y herramientas).
import json
import math
import os
import random
import sys

import pygame

import datos
import estilo
import eventos_marte
import fondo_menu
from eventos_marte import CONFIG as CONFIG_MARTE
import partidas
import suelo
from clima import (CALMA, CALMA_SIN_FIN, CME_EN_CAMINO, LLAMARADA, PARTICULAS, POLVO_ACTIVA,
                   POLVO_EN_AVISO, POLVO_EN_CALMA, TEMP_DIA_MARTE, TEMP_NOCHE_MARTE, Clima, Reloj,
                   TormentaPolvo)
import clima as modulo_clima
from energia import (celdas_con_energia, encontrar_redes, red_de, tiene_cable_vecino,
                     toca_celdas, vecinos)
import maquinas
from maquinas import (ALMACEN_MAX, BOTIN, RECURSOS, CASILLAS, COMIDA_POR_UNIDAD, COSTO_CONSTRUIR,
                      ENTRADA_MAX, LIMITE_INVENTARIO, LLENO,
                      OXIGENO_POR_UNIDAD, PILA_MAX, PRODUCIENDO, SALIDA_MAX,
                      SIN_ENERGIA, SIN_ENTRADA, SIN_TANQUE, TANQUE_LLENO, TANQUE_MAX,
                      Maquina, Taladro, Tanque)
from supervivencia import (BAJO, BARRAS, COMIDA, COMIDA_MAX, CRITICO, DOSIS, ENERGIA,
                           NORMAL, OXIGENO, OXIGENO_MAX, Supervivencia)
import textos
from textos import cambiar_idioma, t

# Refactor: el código se dividió en módulos (ver CAMBIOS.md). Aquí se vuelven a
# exportar todos sus nombres para que main.TILE, main.Juego, main.Taladro... sigan
# existiendo igual que antes.
from config import *  # noqa: F401,F403
from arte import *  # noqa: F401,F403
from mapa import *  # noqa: F401,F403
from jugador import *  # noqa: F401,F403
from juego import Juego  # noqa: F401
from juego_pantalla import ARGUMENTOS as ARGUMENTOS_COMPLETA


def main():
    # "python main.py marte" empieza directo en Marte; sin nada, en la Luna.
    # Sin nada: abre el menú principal. "marte": partida nueva en Marte directo (como antes).
    argumentos = [a.lower() for a in sys.argv[1:]]
    marte = "marte" in argumentos
    completa = any(a in ARGUMENTOS_COMPLETA for a in argumentos)     # ronda 29: --completa
    Juego(MARTE if marte else DESTINO_INICIAL, inicio=not marte, completa=completa).run()


if __name__ == "__main__":
    main()
