"""Generador del piso lunar: cráteres, polvo y piedritas. Lógica pura: no usa
pygame; devuelve matrices de colores y main.py las convierte en imágenes.

Cada variante mide LADO x LADO píxeles (16 px por cuadro, 4x4 cuadros) y se
agranda x3 en pantalla igual que el resto del arte. Misma semilla = mismo piso.

Cada variante es de un TIPO de terreno (ver TIPOS), para que el piso no se vea
siempre igual: "mixto" (cráteres, algún monte y piedritas), "planicie" (zona
casi lisa con piedritas), "lomas" (montes pequeños) y "pedregal" (muchas
piedritas). El tipo depende solo del número de variante.

Reglas de forma (para que no haya "colitas"):
- Un cráter es redondo o apenas irregular, con el borde claro del lado de la luz
  (arriba a la izquierda) y un arco de sombra de 1 px del lado contrario.
- NADA sale del borde exterior del cráter: ningún trazo suelto. Lo mismo vale
  para los montes (más claros que el suelo, luz arriba a la izquierda) y las
  piedritas (de 2 o 4 px, nunca pegadas entre sí).
- Los cráteres, bordes y sombras quedan dentro de un margen de cada variante;
  en el borde solo hay moteado de 1 píxel. Así dos variantes cualquiera se
  pueden poner una junto a otra (y el mapa da la vuelta) sin costuras.

Paleta corta de grises secos y neutros (regolito lunar), con apenas un toque frío.
La guía pide "suelo azul apagado": si se decide, basta con cambiar los colores de
abajo. Contraste bajo a propósito: las rocas, vetas, cables y máquinas deben leerse
encima del piso.
"""

import math
import random

LADO = 64                       # píxeles de una variante (4x4 cuadros de 16 px)
MARGEN = 2                      # píxeles libres de cráteres alrededor de cada variante

# Paleta (10 colores). Los cráteres usan fondo, sombra interior, borde claro,
# borde medio (pared iluminada) y sombra exterior.
BASE = (104, 105, 107)          # suelo: gris seco
POLVO_OSCURO = (98, 99, 101)    # manchas de polvo apenas más oscuras
POLVO_CLARO = (111, 112, 114)   # manchas de polvo y halo de los cráteres, más claros
PUNTO_CLARO = (118, 119, 121)   # grano claro
PUNTO_OSCURO = (91, 92, 94)     # grano oscuro
FONDO = (78, 79, 82)            # fondo del cráter
SOMBRA_INT = (58, 59, 62)       # pared interior que no da la luz
BORDE_CLARO = (138, 139, 141)   # borde que da la luz (arriba a la izquierda)
BORDE_MEDIO = (122, 123, 125)   # pared interior iluminada y borde de transición
SOMBRA_EXT = (84, 85, 88)       # sombra de 1 px del lado contrario a la luz
PALETA = (BASE, POLVO_OSCURO, POLVO_CLARO, PUNTO_CLARO, PUNTO_OSCURO, FONDO,
          SOMBRA_INT, BORDE_CLARO, BORDE_MEDIO, SOMBRA_EXT)

LUZ = (-0.7071, -0.7071)        # hacia dónde está la luz: arriba a la izquierda

# Cráteres por variante: (mínimo, máximo) de cada tamaño y su radio en píxeles.
GRANDES = (0, 1)
MEDIANOS = (1, 2)
CHICOS = (2, 5)
RADIO_GRANDE = (8.0, 11.0)
RADIO_MEDIANO = (5.0, 7.5)
RADIO_CHICO = (2.5, 4.0)
SEPARACION = 3                  # píxeles mínimos entre bordes de dos cráteres
INTENTOS = 80                   # intentos de colocar cada cráter

PROB_SUAVE = 0.35               # cráteres medianos y grandes "viejos": hueco liso, sin pared ni sombra
RADIO_PICO = 6.5                # los cráteres de este radio o más pueden llevar un pico central
PROB_PICO = 0.5
BORDE_TRAMADO = 1.8             # ancho (px) del borde punteado de los cráteres suaves
FORMA_OVAL = (1.0, 1.35)        # cuánto se deforma el borde (1 = como siempre; más = más ovalado)

# Montes pequeños: más claros que el suelo (lo contrario de un cráter). Anchos
# en píxeles, no en fracción del radio, como el borde de los cráteres.
SEMIEJE_LOMA = (4.0, 8.0)       # semieje mayor
ACHATAR_LOMA = (0.55, 0.9)      # semieje menor / semieje mayor
ANCHO_BANDA_LOMA = 1.6          # banda iluminada (arriba-izq.) y banda en sombra (abajo-der.)
ANCHO_SOMBRA_LOMA = 1.3         # sombra proyectada afuera, del lado contrario a la luz

PIEDRITAS = (8, 14)             # piedritas por variante (el tipo de terreno lo cambia)
SEPARACION_PIEDRITAS = 4       # píxeles mínimos entre dos piedritas
MANCHAS_POLVO = (4, 6)
RADIO_MANCHA = (4.0, 10.0)
PROB_MOTEADO = 0.045            # grano fino, por cada tono (claro y oscuro)
HALO = 0.30                     # ancho del halo claro, como fracción del radio
HALO_MINIMO = 2.4               # ancho mínimo del halo en px (en cráteres medianos, 0.3 x radio es menos de 2 px)
PROB_HALO = 0.55                # densidad del halo junto al borde (baja hacia afuera)
SUELO_LIBRE = (BASE, POLVO_OSCURO, POLVO_CLARO)   # colores donde se puede poner grano

# Piedritas: (dx, dy, color) de cada forma. Claro arriba-izquierda, sombra abajo-derecha.
PIEDRITA_CHICA = ((0, 0, BORDE_CLARO), (1, 1, SOMBRA_EXT))
PIEDRITA_MEDIANA = ((0, 0, BORDE_CLARO), (1, 0, BORDE_CLARO), (1, 1, SOMBRA_EXT), (2, 1, SOMBRA_EXT))

# Tipos de terreno. Todos los números son (mínimo, máximo) salvo los sueltos.
#   medianas: fracción de piedritas de 4 px | grupos: fracción que se junta en
#   2 o 3 pedregales | grano: multiplica el grano fino (1 = normal, menos = más liso)
TIPOS = {
    "mixto":    dict(grandes=(0, 1), medianos=(1, 2), chicos=(2, 5), lomas=(0, 2),
                     piedritas=(8, 14), medianas=0.2, grupos=0.0,
                     manchas=(4, 6), r_mancha=(4.0, 10.0), grano=1.0),
    "planicie": dict(grandes=(0, 0), medianos=(0, 1), chicos=(0, 2), lomas=(0, 0),
                     piedritas=(16, 26), medianas=0.4, grupos=0.6,
                     manchas=(3, 4), r_mancha=(9.0, 16.0), grano=0.6),
    "lomas":    dict(grandes=(0, 0), medianos=(1, 1), chicos=(1, 3), lomas=(3, 5),
                     piedritas=(6, 10), medianas=0.2, grupos=0.0,
                     manchas=(4, 6), r_mancha=(4.0, 9.0), grano=1.0),
    "pedregal": dict(grandes=(0, 0), medianos=(0, 1), chicos=(1, 3), lomas=(0, 1),
                     piedritas=(34, 50), medianas=0.5, grupos=0.7,
                     manchas=(3, 5), r_mancha=(5.0, 12.0), grano=0.8),
}
TIPOS_POR_VARIANTE = ("mixto", "planicie", "lomas", "pedregal")   # la variante i es de TIPOS_POR_VARIANTE[i % 4]


class Crater:
    """Un cráter ya colocado: centro, radio y hasta dónde llega todo su dibujo
    (borde + sombra). Ningún píxel suyo queda más lejos de `alcance`."""

    def __init__(self, cx, cy, radio, azar):
        self.cx, self.cy, self.radio = cx, cy, radio
        # El borde se deforma un poco según el ángulo (más en los grandes, y en
        # algunos más que en otros para que no salgan todos iguales).
        fuerza = (0.04 + 0.05 * min(1.0, radio / 9.0)) * azar.uniform(*FORMA_OVAL)
        self.armonicos = [(k, azar.uniform(0.4, 1.0) * fuerza, azar.uniform(0, 2 * math.pi))
                          for k in (2, 3)]
        self.alcance = radio * (1 + sum(a for _, a, _ in self.armonicos)) * 1.2 + 1.2
        # "fresco": borde claro, pared y sombra. "suave": hueco liso y viejo.
        self.estilo = "suave" if radio >= 4.5 and azar.random() < PROB_SUAVE else "fresco"
        self.pico = radio >= RADIO_PICO and azar.random() < PROB_PICO   # pico central

    def radio_en(self, angulo):
        """Radio del borde en una dirección (círculo + pequeñas ondas)."""
        return self.radio * (1 + sum(a * math.sin(k * angulo + fase)
                                     for k, a, fase in self.armonicos))


class Loma:
    """Un monte pequeño: elipse más ancha que alta, más clara que el suelo. Tiene
    una banda iluminada arriba a la izquierda, una banda en sombra abajo a la
    derecha y una sombra proyectada de 1 px afuera. `alcance` incluye la sombra."""

    def __init__(self, cx, cy, semieje, azar):
        self.cx, self.cy = cx, cy
        self.rx = semieje
        self.ry = max(3.5, semieje * azar.uniform(*ACHATAR_LOMA))
        self.alcance = max(self.rx, self.ry) + ANCHO_SOMBRA_LOMA + 1.2

    def medir(self, x, y):
        """(px hacia adentro del borde, cuánto da la luz) del píxel (x, y).
        Hacia adentro es negativo afuera. La luz va de -1 a 1 (1 = de frente)."""
        u, v = (x + 0.5 - self.cx) / self.rx, (y + 0.5 - self.cy) / self.ry
        r = math.hypot(u, v)
        if r < 1e-6:
            return min(self.rx, self.ry), 0.0
        gx, gy = u / (self.rx * r), v / (self.ry * r)      # gradiente de r: apunta hacia afuera
        grad = math.hypot(gx, gy)
        dentro = (1 - r) / grad                              # distancia al borde, en px (1er orden)
        return dentro, (gx * LUZ[0] + gy * LUZ[1]) / grad


def _dentro_del_margen(cx, cy, alcance):
    limite = LADO - MARGEN
    return (cx - alcance >= MARGEN and cx + alcance <= limite
            and cy - alcance >= MARGEN and cy + alcance <= limite)


def _colocar(azar, tipo):
    """(cráteres, lomas) de la variante, sin salirse del margen ni tocarse. Se
    colocan primero los grandes, luego los medianos, los montes y al final los chicos."""
    p = TIPOS[tipo]
    pedidos = []                                  # (clase, rango de tamaño)
    for clave, rango_r in (("grandes", RADIO_GRANDE), ("medianos", RADIO_MEDIANO)):
        pedidos += [("crater", rango_r)] * azar.randint(*p[clave])
    pedidos += [("loma", SEMIEJE_LOMA)] * azar.randint(*p["lomas"])
    pedidos += [("crater", RADIO_CHICO)] * azar.randint(*p["chicos"])
    crateres, lomas = [], []
    for clase, rango in pedidos:
        for _ in range(INTENTOS):
            tamano = azar.uniform(*rango)
            x, y = azar.uniform(0, LADO), azar.uniform(0, LADO)
            c = Crater(x, y, tamano, azar) if clase == "crater" else Loma(x, y, tamano, azar)
            if not _dentro_del_margen(c.cx, c.cy, c.alcance):
                continue
            if all(math.hypot(c.cx - o.cx, c.cy - o.cy) >= c.alcance + o.alcance + SEPARACION
                   for o in crateres + lomas):
                (crateres if clase == "crater" else lomas).append(c)
                break
    return crateres, lomas


def _pintar_crater(img, c):
    """Dibuja un cráter con zonas de ANCHO FIJO en píxeles (no en fracción del
    radio), para que el borde salga continuo: borde claro, pared interior, fondo
    y un arco de sombra de 1 px afuera. Los cráteres chicos no llevan pared. Los
    "suaves" (viejos) son un hueco liso con apenas un borde iluminado, sin pared
    ni sombra, con el borde punteado. Los muy grandes pueden llevar un pico central."""
    suave = c.estilo == "suave"
    tramado = set()                       # píxeles punteados del borde de un cráter suave
    ancho_borde = 1.2
    ancho_pared = 1.4 if c.radio >= 4.5 and not suave else 0.0
    x0, x1 = int(c.cx - c.alcance), int(c.cx + c.alcance) + 1
    y0, y1 = int(c.cy - c.alcance), int(c.cy + c.alcance) + 1
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            dx, dy = x + 0.5 - c.cx, y + 0.5 - c.cy
            dist = math.hypot(dx, dy)
            if dist == 0:
                img[y][x] = FONDO
                continue
            dentro = c.radio_en(math.atan2(dy, dx)) - dist     # píxeles hacia adentro del borde
            hacia_luz = (dx * LUZ[0] + dy * LUZ[1]) / dist      # 1 = lado de la luz, -1 = lado opuesto
            if dentro < -1.0:
                continue                                        # fuera del cráter y de su sombra
            if dentro < 0:                                      # sombra exterior (1 px)
                if hacia_luz < -0.45 and ancho_pared:           # solo los medianos y grandes frescos
                    img[y][x] = SOMBRA_EXT
            elif dentro < ancho_borde:                          # borde
                if suave:
                    img[y][x] = BORDE_MEDIO if hacia_luz > 0.15 else FONDO
                elif hacia_luz > 0.15:
                    img[y][x] = BORDE_CLARO
                elif hacia_luz < -0.15:
                    img[y][x] = SOMBRA_EXT
                else:
                    img[y][x] = BORDE_MEDIO
            elif dentro < ancho_borde + ancho_pared:            # pared interior
                if hacia_luz > 0.25:
                    img[y][x] = SOMBRA_INT                      # pared que no da la luz
                elif hacia_luz < -0.25:
                    img[y][x] = BORDE_MEDIO                     # pared iluminada
                else:
                    img[y][x] = FONDO
            elif suave and dentro < ancho_borde + BORDE_TRAMADO and (x + y) % 2 == 0:
                img[y][x] = POLVO_OSCURO                        # borde erosionado: punteado, sin corte duro
                tramado.add((x, y))
            else:
                img[y][x] = FONDO
    if c.pico:                                                  # pico central: unos 3x3 px
        for y in range(int(c.cy) - 2, int(c.cy) + 3):
            for x in range(int(c.cx) - 2, int(c.cx) + 3):
                dx, dy = x + 0.5 - c.cx, y + 0.5 - c.cy
                if math.hypot(dx, dy) <= 1.9:
                    img[y][x] = BORDE_MEDIO if dx + dy <= 0.3 else SOMBRA_INT
    return tramado


def _pintar_loma(img, m):
    """Cuerpo claro; banda iluminada (arriba-izquierda) y banda en sombra
    (abajo-derecha) de ancho fijo; sombra proyectada de 1 px afuera."""
    x0, x1 = int(m.cx - m.alcance), int(m.cx + m.alcance) + 1
    y0, y1 = int(m.cy - m.alcance), int(m.cy + m.alcance) + 1
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            dentro, luz = m.medir(x, y)
            if dentro < -ANCHO_SOMBRA_LOMA:
                continue
            if dentro < 0:                                      # sombra proyectada
                if luz < -0.35:
                    img[y][x] = SOMBRA_EXT
            elif dentro < ANCHO_BANDA_LOMA and luz > 0.25:
                img[y][x] = BORDE_MEDIO                         # lado de la luz
            elif dentro < ANCHO_BANDA_LOMA and luz < -0.25:
                img[y][x] = PUNTO_OSCURO                        # lado en sombra
            else:
                img[y][x] = POLVO_CLARO


def _halo(img, c, azar):
    """Halo claro y difuso alrededor de un cráter (material que sale del impacto):
    puntitos de polvo claro, más densos junto al borde y cada vez más escasos
    hacia afuera. Son píxeles sueltos: nunca forman una raya."""
    ancho = max(HALO * c.radio, HALO_MINIMO)
    x0, x1 = int(c.cx - c.alcance) - 1, int(c.cx + c.alcance) + 2
    y0, y1 = int(c.cy - c.alcance) - 1, int(c.cy + c.alcance) + 2
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            if not (0 <= x < LADO and 0 <= y < LADO):
                continue
            dx, dy = x + 0.5 - c.cx, y + 0.5 - c.cy
            fuera = math.hypot(dx, dy) - c.radio_en(math.atan2(dy, dx))   # px afuera del borde
            if 1.0 < fuera <= ancho and img[y][x] in SUELO_LIBRE:
                if azar.random() < PROB_HALO * (1 - fuera / ancho):
                    img[y][x] = POLVO_CLARO


def _manchas_de_polvo(img, azar, cantidad, rango_radio):
    """Manchas redondeadas, unas apenas más claras y otras más oscuras que el
    suelo, bordeadas con un punteado (tramado) para que no se vea un corte duro.
    Las grandes dan las "planicies": zonas anchas de un solo tono."""
    for _ in range(azar.randint(*cantidad)):
        radio = azar.uniform(*rango_radio)
        color = azar.choice((POLVO_CLARO, POLVO_OSCURO))
        cx = azar.uniform(radio + MARGEN + 1, LADO - radio - MARGEN - 1)
        cy = azar.uniform(radio + MARGEN + 1, LADO - radio - MARGEN - 1)
        for y in range(int(cy - radio) - 1, int(cy + radio) + 2):
            for x in range(int(cx - radio) - 1, int(cx + radio) + 2):
                if not (0 <= x < LADO and 0 <= y < LADO):
                    continue
                d = math.hypot(x + 0.5 - cx, y + 0.5 - cy) / radio
                if d < 0.8 or (d < 1.0 and (x + y) % 2 == 0):
                    img[y][x] = color


def _piedritas(img, crateres, lomas, azar, p):
    """Piedritas de 2 px (chicas) o 4 px (medianas) fuera de los cráteres, los
    montes y el margen. Nunca se tocan entre sí (ni en diagonal): dos pegadas
    formarían una raya quebrada. Algunas se juntan en grupos (pedregales).
    Devuelve [lista de (x, y, color)] por piedrita, para poder comprobarlas."""
    n = azar.randint(*p["piedritas"])
    centros = [(azar.uniform(14, LADO - 14), azar.uniform(14, LADO - 14))
               for _ in range(azar.randint(2, 3))] if p["grupos"] else []
    ocupados = set()
    hechas = []
    for _ in range(n):
        forma = PIEDRITA_MEDIANA if azar.random() < p["medianas"] else PIEDRITA_CHICA
        ancho = max(dx for dx, _, _ in forma) + 1
        alto = max(dy for _, dy, _ in forma) + 1
        for _ in range(4):                          # algunos intentos por piedrita
            if centros and azar.random() < p["grupos"]:
                cx, cy = azar.choice(centros)
                x, y = int(round(azar.gauss(cx, 6))), int(round(azar.gauss(cy, 6)))
            else:
                x, y = azar.randint(MARGEN, LADO - MARGEN - ancho), azar.randint(MARGEN, LADO - MARGEN - alto)
            if not (MARGEN <= x <= LADO - MARGEN - ancho and MARGEN <= y <= LADO - MARGEN - alto):
                continue
            holgura = 3.5 + (ancho - 2)             # la forma mediana mide 3 px de ancho
            if not (all(math.hypot(x - c.cx, y - c.cy) > c.alcance + holgura for c in crateres)
                    and all(math.hypot(x - m.cx, y - m.cy) > m.alcance + holgura for m in lomas)):
                continue
            pixeles = [(x + dx, y + dy, color) for dx, dy, color in forma]
            if any((px + ex, py + ey) in ocupados for px, py, _ in pixeles
                   for ex in (-1, 0, 1) for ey in (-1, 0, 1)):
                continue                            # tocaría a otra piedrita
            for px, py, color in pixeles:
                img[py][px] = color
                ocupados.add((px, py))
            hechas.append(pixeles)
            break
    return hechas


def _moteado(img, azar, grano, protegidos=()):
    """Grano fino de 1 px sobre el suelo libre (esto sí llega hasta el borde).
    Los píxeles `protegidos` (el punteado de los cráteres suaves) no se tocan."""
    for y in range(LADO):
        for x in range(LADO):
            if img[y][x] in SUELO_LIBRE and (x, y) not in protegidos:
                tirada = azar.random()
                if tirada < PROB_MOTEADO * grano:
                    img[y][x] = PUNTO_CLARO
                elif tirada < 2 * PROB_MOTEADO * grano:
                    img[y][x] = PUNTO_OSCURO


class Detalle:
    """Una variante con todo lo que se colocó, para poder revisarla en las pruebas."""

    def __init__(self, tipo, pixeles, crateres, lomas, piedritas):
        self.tipo, self.pixeles = tipo, pixeles
        self.crateres, self.lomas, self.piedritas = crateres, lomas, piedritas


def generar_detalle(semilla, tipo="mixto"):
    """Variante completa (Detalle) de ese tipo de terreno (ver TIPOS)."""
    if tipo not in TIPOS:
        raise ValueError(f"tipo de terreno desconocido: '{tipo}'")
    p = TIPOS[tipo]
    azar = random.Random(semilla)
    img = [[BASE] * LADO for _ in range(LADO)]
    _manchas_de_polvo(img, azar, p["manchas"], p["r_mancha"])
    crateres, lomas = _colocar(azar, tipo)
    protegidos = set()
    for c in crateres:
        if c.radio >= 4.5:                  # los chicos no llevan halo
            _halo(img, c, azar)
        protegidos |= _pintar_crater(img, c)
    for m in lomas:
        _pintar_loma(img, m)
    piedritas = _piedritas(img, crateres, lomas, azar, p)
    _moteado(img, azar, p["grano"], protegidos)
    return Detalle(tipo, img, crateres, lomas, piedritas)


def generar_variante(semilla, tipo="mixto"):
    """(pixeles, crateres) de una variante. pixeles[y][x] es un color (r, g, b);
    crateres es la lista de objetos Crater (centro y radio, en píxeles)."""
    d = generar_detalle(semilla, tipo)
    return d.pixeles, d.crateres


def generar_detalles(semilla, cantidad=4):
    """Lista de Detalle. Cada variante usa su propia semilla derivada y su tipo
    (TIPOS_POR_VARIANTE), así cambiar la cantidad no cambia las demás."""
    return [generar_detalle(semilla * 1000 + i, TIPOS_POR_VARIANTE[i % len(TIPOS_POR_VARIANTE)])
            for i in range(cantidad)]


def generar_variantes(semilla, cantidad=4):
    """(variantes, crateres): una lista de pixeles y una de cráteres por variante."""
    detalles = generar_detalles(semilla, cantidad)
    return [d.pixeles for d in detalles], [d.crateres for d in detalles]
