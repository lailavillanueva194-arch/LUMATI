"""Eventos de Marte: remolinos de polvo, sismos, tormentas de polvo regional y
global, partículas solares (SEP) e impactos de meteoritos. Solo se usan cuando
el destino es Marte: la Luna no cambia.

Lógica pura: no usa pygame, no dibuja y no sabe del mapa ni del jugador. Cada
cuadro, main.py llama a EventosMarte.actualizar() y recibe una lista de avisos
("remolino", "sismo", "polvo", "sep", "impacto"...). main.py decide qué pasa en
la pantalla y conecta los efectos con lo que ya existía:

- La tormenta de polvo REGIONAL es la tormenta de polvo que ya había
  (clima.TormentaPolvo); la GLOBAL es la misma clase con más duración y fuerza.
- Las partículas solares (SEP) son la cadena solar que ya había en clima.py
  (llamarada -> CME -> partículas, con su aviso previo y la escala de CME
  S/C/O/R/ER). En Marte esa cadena ya no se dispara sola: la programa este
  módulo con la frecuencia de abajo.

TODOS los números están en CONFIG y ESCALA. Cada uno dice si es:
  DATO NASA (fuente)   -> sale del encargo del equipo (NASA/JPL, Curiosity,
                          InSight, MRO, DONKI).
  SUPUESTO DEL JUEGO   -> lo eligió el juego para que se pueda jugar. Cámbialo
                          sin miedo.

IMPORTANTE: las escalas de tiempo son SUPUESTOS. En el juego un año marciano
dura 3 minutos y un sol (para las partículas solares) dura 3 segundos. No son
proporcionales entre sí ni con la realidad: están comprimidas para que en una
partida se vea de todo. Lo que sí respeta el juego es el ORDEN de frecuencias y
las proporciones que dan los datos (por ejemplo, "una global cada 3 a 4 años").
"""

import random
from dataclasses import dataclass, field

DATO = "DATO NASA"
SUPUESTO = "SUPUESTO DEL JUEGO"

# Categorías (lo pide el encargo)
POLVO, RADIACION, SUELO = "polvo", "radiacion", "suelo"

SIN_FIN = 1e9                   # "nunca" en segundos de juego (cabe en el JSON de la partida)

# --------------------------------------------------------------------------
# Escalas de tiempo del juego (TODAS son SUPUESTO DEL JUEGO)
# --------------------------------------------------------------------------
ESCALA = {
    "segundos_por_anio": 180.0,     # SUPUESTO DEL JUEGO: un año marciano dura 3 min de juego
    "temporada_polvo": (0.5, 1.0),  # SUPUESTO DEL JUEGO: la 2a mitad de cada año es la temporada de
                                    # polvo (= primavera y verano del hemisferio sur; que las globales
                                    # se den ahí es DATO NASA, NASA/JPL)
    "inicio_anio": 0.3,             # SUPUESTO DEL JUEGO: la partida empieza al 30 % del año, así la
                                    # primera temporada de polvo llega en ~36 s
    "segundos_por_sol": 3.0,        # SUPUESTO DEL JUEGO: para las partículas solares, 1 sol = 3 s
    "luz_de_dia": 0.6,              # SUPUESTO DEL JUEGO: con más luz que esto (0 a 1) "es de día"
}

# --------------------------------------------------------------------------
# Parámetros de cada evento (ordenados de más a menos frecuente)
# --------------------------------------------------------------------------
CONFIG = {
    # 1) Remolinos de polvo (dust devils): constantes, de día.
    "remolino": {
        "categoria": POLVO,
        "intervalo": (15.0, 35.0),      # SUPUESTO DEL JUEGO: segundos entre remolinos (de día)
        "duracion": 10.0,               # SUPUESTO DEL JUEGO: lo que tarda en cruzar la pantalla
        "aviso": 0.0,                   # SUPUESTO DEL JUEGO: no hay aviso
        "solo_de_dia": True,            # DATO NASA (NASA/JPL): aparecen cuando el suelo está más caliente
                                        # que el aire. Que eso sea "de día" es SUPUESTO DEL JUEGO
        "factor_en_tormenta": 0.25,     # DATO NASA (NASA/JPL): son menos frecuentes durante una tormenta.
                                        # El 0.25 (4 veces menos) es SUPUESTO DEL JUEGO
        "max_a_la_vez": 2,              # SUPUESTO DEL JUEGO
        "dano": False,                  # SUPUESTO DEL JUEGO: no hacen daño (solo se ven)
        "dato": "marte_remolinos",
    },
    # 2) Sismos pequeños (marsquakes): constantes.
    "sismo": {
        "categoria": SUELO,
        "intervalo": (25.0, 60.0),      # SUPUESTO DEL JUEGO: segundos entre sismos
        "magnitud_min": 1.0,            # SUPUESTO DEL JUEGO
        "magnitud_max": 4.7,            # DATO NASA (InSight): el mayor fue de magnitud 4.7 (mayo de 2022)
        "sesgo_pequenos": 3.0,          # SUPUESTO DEL JUEGO: casi todos salen pequeños (sorteo al cubo)
        "duracion_base": 0.8,           # SUPUESTO DEL JUEGO: segundos que tiembla la cámara...
        "duracion_por_magnitud": 0.3,   # SUPUESTO DEL JUEGO: ...más esto por cada punto de magnitud
        "pixeles_por_magnitud": 1.2,    # SUPUESTO DEL JUEGO: sacudida suave (M4.7 = ~6 px)
        "aviso": 0.0,                   # SUPUESTO DEL JUEGO: no hay aviso
        "dano": False,                  # SUPUESTO DEL JUEGO: sin daño (DATO NASA, InSight: son pequeños
                                        # comparados con los de la Tierra)
        "dato": "marte_sismos",
    },
    # 3) Tormenta de polvo regional: una por año, en la temporada de polvo.
    "polvo_regional": {
        "categoria": POLVO,
        "por_anio": 1,                  # DATO NASA (NASA/JPL): hay tormentas locales y regionales todos los
                                        # años marcianos, en la temporada de polvo. "Una" es SUPUESTO DEL JUEGO
        "aviso": 8.0,                   # SUPUESTO DEL JUEGO (el valor que ya tenía la tormenta de polvo)
        "duracion": 20.0,               # SUPUESTO DEL JUEGO (el valor que ya tenía la tormenta de polvo)
        "fuerza": 1.0,                  # SUPUESTO DEL JUEGO: qué tanto tapa la vista el velo de polvo
        "cultivo": 0.6,                 # SUPUESTO DEL JUEGO: las plantas crecen al 60 % (DATO NASA: menos luz
                                        # directa baja el cultivo)
        "amortiguar_temp": 0.35,        # SUPUESTO DEL JUEGO: la diferencia día-noche baja 35 % (DATO NASA:
                                        # días más fríos, noches menos frías porque el polvo aísla)
        "tapa_paneles": True,           # DATO NASA: menos luz directa y polvo sobre los paneles. Que los
                                        # apague del todo es SUPUESTO DEL JUEGO (ya era así)
        "dato_aviso": "marte_polvo_regional",
        "dato_activa": "marte_polvo_efectos",
    },
    # 4) Tormenta de polvo global: rara, más larga y fuerte.
    "polvo_global": {
        "categoria": POLVO,
        "cada_anios": (3, 4),           # DATO NASA (NASA/JPL): cada 3 a 4 años marcianos (6 a 8 terrestres)
        "aviso": 15.0,                  # SUPUESTO DEL JUEGO: empieza pequeña y crece (DATO NASA: en 2018 una
                                        # tormenta pequeña del 30 de mayo ya era global el 20 de junio)
        "duracion": 60.0,               # SUPUESTO DEL JUEGO: 3 veces la regional (DATO NASA: la de 2018
                                        # duró al menos un par de meses)
        "fuerza": 1.6,                  # SUPUESTO DEL JUEGO: velo más espeso que la regional
        "cultivo": 0.35,                # SUPUESTO DEL JUEGO: las plantas crecen al 35 %
        "amortiguar_temp": 0.6,         # SUPUESTO DEL JUEGO: la diferencia día-noche baja 60 %
        "tapa_paneles": True,           # (igual que la regional)
        "dato_aviso": "marte_polvo_global",
        "dato_activa": "marte_polvo_altura",
    },
    # 5) Partículas solares (SEP): irregulares, con aviso previo (la cadena de clima.py).
    "sep": {
        "categoria": RADIACION,
        "actividad_solar": "baja",      # SUPUESTO DEL JUEGO: con qué actividad solar se juega. Con "alta"
                                        # las SEP salen más seguido que las tormentas globales (como en la
                                        # realidad); con "baja" se respeta el orden de la lista del encargo
        "eventos_por_300_soles": {
            "alta": 8,                  # DATO NASA (Curiosity): con actividad solar alta se esperan ~8 en 300 soles
            "baja": 1,                  # DATO NASA (Curiosity): en sus primeros 10 meses solo vio 1 (y débil).
                                        # Tomar 10 meses como ~300 soles es SUPUESTO DEL JUEGO
        },
        "intervalo_minimo": 60.0,       # SUPUESTO DEL JUEGO: nunca dos seguidas en menos de esto
        "reintento": 10.0,              # SUPUESTO DEL JUEGO: si ya hay una tormenta solar, espera esto
        # Aviso previo: el de clima.py (llamarada 6 s + CME en camino 30 s). DATO NASA (DONKI): en el
        # ejemplo del 2016-01-01 las partículas llegaron 3.5 a 5.5 h después de la llamarada.
        "duracion_particulas": {"S": 20.0, "C": 30.0, "O": 40.0},
                                        # SUPUESTO DEL JUEGO: el doble que en la Luna (DATO NASA: en Marte las
                                        # partículas pueden dominar la radiación por horas o días porque la
                                        # atmósfera es muy delgada)
        "forbush_factor": 0.85,         # SUPUESTO DEL JUEGO: la radiación de fondo baja 15 % un rato (DATO NASA:
                                        # las CME causan caídas súbitas de radiación, Forbush decreases)
        "forbush_duracion": 20.0,       # SUPUESTO DEL JUEGO
        "dato": "marte_sep",
    },
    # 6) Impacto grande de meteorito: muy raro.
    "impacto": {
        "categoria": SUELO,
        "intervalo": (1500.0, 2700.0),  # SUPUESTO DEL JUEGO: de 25 a 45 min de juego
        "aviso": 0.0,                   # SUPUESTO DEL JUEGO: no hay aviso
        "radio_crater": 1,              # SUPUESTO DEL JUEGO: el cráter mide 3x3 cuadros (DATO NASA: el de
                                        # dic. 2021 midió unos 150 m; el juego no tiene escala en metros)
        "magnitud_sismo": 4.0,          # DATO NASA (InSight): ese impacto causó un sismo de magnitud 4
        "bonus_hielo": 70,              # SUPUESTO DEL JUEGO: peso extra de hielo para un taladro en el cráter
                                        # (DATO NASA: el impacto dejó hielo expuesto cerca de la superficie)
        "distancia": (3, 6),            # SUPUESTO DEL JUEGO: cae a 3-6 cuadros del astronauta (a la vista)
        "dano": False,                  # SUPUESTO DEL JUEGO: nunca cae sobre construcciones
        "dato": "marte_impacto",
    },
}

# Ejemplos reales de DONKI para la cadena solar en Marte: se reutilizan los de
# clima.EVENTOS que tienen partículas o llegan a Marte (por id).
#  - cme_2017_01_03: CME tipo C de 645 km/s; DATO NASA (DONKI): llegó a Marte el
#    2017-01-07 a las 06:00Z (unos 4 días de viaje).
#  - flr_2016_01_01: llamarada M2.3 -> CME -> partículas (DATO NASA, DONKI).
IDS_SEP_MARTE = ("cme_2017_01_03", "flr_2016_01_01")


# --------------------------------------------------------------------------
# El evento (lo que pide el encargo: MarsEvent)
# --------------------------------------------------------------------------
@dataclass
class EventoMarte:
    """Ficha de un evento de Marte. nombre es la clave de textos.py."""
    id: str
    nombre: str
    categoria: str
    frecuencia_relativa: float      # veces por año marciano del juego (calculado de CONFIG)
    duracion: float                 # segundos de juego (0 = instantáneo)
    aviso: float                    # segundos de aviso previo (0 = sin aviso)
    efectos: list = field(default_factory=list)   # en qué sistemas del juego pega
    dato: str = None                # id del dato real (datos.py) que se muestra


def _media(par):
    return (par[0] + par[1]) / 2


def segundos_medios_sep():
    """Segundos de juego en promedio entre dos eventos de partículas solares."""
    cfg = CONFIG["sep"]
    por_300 = cfg["eventos_por_300_soles"][cfg["actividad_solar"]]
    return 300.0 / por_300 * ESCALA["segundos_por_sol"]


def fichas():
    """Lista de EventoMarte ordenada de más a menos frecuente."""
    anio = ESCALA["segundos_por_anio"]
    global_cada = _media(CONFIG["polvo_global"]["cada_anios"])
    r, s = CONFIG["remolino"], CONFIG["sismo"]
    rg, gl, sep, imp = CONFIG["polvo_regional"], CONFIG["polvo_global"], CONFIG["sep"], CONFIG["impacto"]
    lista = [
        EventoMarte("remolino", "ev_remolino_nombre", POLVO,
                    anio / _media(r["intervalo"]) * (0.5 if r["solo_de_dia"] else 1.0),   # ~medio día con sol
                    r["duracion"], r["aviso"], ["visual"], r["dato"]),
        EventoMarte("sismo", "ev_sismo_nombre", SUELO, anio / _media(s["intervalo"]),
                    s["duracion_base"] + s["duracion_por_magnitud"] * s["magnitud_max"], s["aviso"],
                    ["camara", "mensaje"], s["dato"]),
        EventoMarte("polvo_regional", "ev_regional_nombre", POLVO, rg["por_anio"] * (1 - 1 / global_cada),
                    rg["duracion"], rg["aviso"], ["paneles", "cultivo", "temperatura", "visual"],
                    rg["dato_aviso"]),
        EventoMarte("polvo_global", "ev_global_nombre", POLVO, 1 / global_cada,
                    gl["duracion"], gl["aviso"], ["paneles", "cultivo", "temperatura", "visual"],
                    gl["dato_aviso"]),
        EventoMarte("sep", "ev_sep_nombre", RADIACION, anio / segundos_medios_sep(),
                    sep["duracion_particulas"]["C"], 36.0, ["radiacion", "refugio"], sep["dato"]),
        EventoMarte("impacto", "ev_impacto_nombre", SUELO, anio / _media(imp["intervalo"]),
                    0.0, imp["aviso"], ["mapa", "sismo", "hielo"], imp["dato"]),
    ]
    return sorted(lista, key=lambda e: -e.frecuencia_relativa)


# --------------------------------------------------------------------------
# Programador de eventos
# --------------------------------------------------------------------------
class EventosMarte:
    """Lleva los relojes de cada evento y avisa cuándo toca uno. No aplica los
    efectos (eso lo hace main.py con los sistemas que ya existen).

    actualizar() devuelve una lista de avisos, cada uno una tupla:
      ("temporada", año)        empieza la temporada de polvo
      ("polvo", "regional" | "global")
      ("remolino",)
      ("sismo", magnitud)
      ("sep",)                  que empiece la cadena solar de clima.py
      ("impacto",)
      ("forbush_fin",)
    """

    def __init__(self, semilla=29):
        self.semilla = semilla
        self._azar = random.Random(semilla)
        self.anio = 1
        self.t_anio = ESCALA["inicio_anio"] * ESCALA["segundos_por_anio"]   # segundos dentro del año
        g = CONFIG["polvo_global"]["cada_anios"]
        self.anios_para_global = self._azar.randint(*g)    # años que faltan para la siguiente global
        self.tormenta_anio = None   # (segundo del año en que empieza, tipo) o None si ya pasó
        self._programar_temporada()
        self.t_remolino = self._azar.uniform(*CONFIG["remolino"]["intervalo"])
        self.t_sismo = self._azar.uniform(*CONFIG["sismo"]["intervalo"])
        self.t_sep = self._espera_sep()
        self.t_impacto = self._azar.uniform(*CONFIG["impacto"]["intervalo"])
        self.forbush = 0.0          # segundos que le quedan a la caída Forbush

    # ---- sorteos ----------------------------------------------------------
    def _espera_sep(self):
        """Espera irregular (exponencial) hasta las siguientes partículas solares."""
        cfg = CONFIG["sep"]
        return max(cfg["intervalo_minimo"], self._azar.expovariate(1.0 / segundos_medios_sep()))

    def sortear_magnitud(self):
        """Magnitud de un sismo pequeño: casi siempre baja, nunca más que la máxima real."""
        s = CONFIG["sismo"]
        u = self._azar.random() ** s["sesgo_pequenos"]
        return round(s["magnitud_min"] + (s["magnitud_max"] - s["magnitud_min"]) * u, 1)

    def azar(self):
        """El generador de este módulo (main.py lo usa para elegir el lugar del cráter)."""
        return self._azar

    def _programar_temporada(self):
        """Elige cuándo empieza la tormenta de este año (dentro de la temporada) y
        si es regional o global."""
        anio = ESCALA["segundos_por_anio"]
        ini, fin = ESCALA["temporada_polvo"]
        tipo = "global" if self.anios_para_global <= 1 else "regional"
        cfg = CONFIG["polvo_" + tipo]
        ultimo = max(ini * anio, fin * anio - cfg["aviso"] - cfg["duracion"])
        self.tormenta_anio = (self._azar.uniform(ini * anio, ultimo), tipo)

    # ---- consulta ---------------------------------------------------------
    @property
    def en_temporada(self):
        ini, fin = ESCALA["temporada_polvo"]
        f = self.t_anio / ESCALA["segundos_por_anio"]
        return ini <= f < fin

    @property
    def mult_radiacion(self):
        """Multiplicador extra de la radiación (Forbush la baja un rato)."""
        return CONFIG["sep"]["forbush_factor"] if self.forbush > 0 else 1.0

    def iniciar_forbush(self):
        self.forbush = CONFIG["sep"]["forbush_duracion"]

    # ---- paso del tiempo --------------------------------------------------
    def actualizar(self, dt, de_dia=True, hay_tormenta=False, polvo_libre=True, clima_libre=True):
        """Avanza dt segundos. de_dia: hay sol fuerte; hay_tormenta: una tormenta de
        polvo en aviso o activa; polvo_libre / clima_libre: se puede empezar una
        tormenta de polvo / solar ahora. Devuelve la lista de avisos."""
        if dt <= 0:
            return []
        avisos = []
        anio = ESCALA["segundos_por_anio"]
        ini = ESCALA["temporada_polvo"][0] * anio

        # Año y temporada de polvo
        antes = self.t_anio
        self.t_anio += dt
        if antes < ini <= self.t_anio:
            avisos.append(("temporada", self.anio))
        if self.tormenta_anio and self.t_anio >= self.tormenta_anio[0]:
            if polvo_libre:
                avisos.append(("polvo", self.tormenta_anio[1]))
                if self.tormenta_anio[1] == "global":
                    self.anios_para_global = self._azar.randint(*CONFIG["polvo_global"]["cada_anios"]) + 1
                self.tormenta_anio = None
            elif not self.en_temporada:                 # ocupada toda la temporada: este año no hay
                self.tormenta_anio = None
        if self.t_anio >= anio:                         # año nuevo
            self.t_anio -= anio
            self.anio += 1
            self.anios_para_global = max(1, self.anios_para_global - 1)
            self._programar_temporada()

        # Remolinos: solo de día y menos con tormenta
        r = CONFIG["remolino"]
        ritmo = 0.0 if (r["solo_de_dia"] and not de_dia) else 1.0
        if hay_tormenta:
            ritmo *= r["factor_en_tormenta"]
        self.t_remolino -= dt * ritmo
        if self.t_remolino <= 0:
            self.t_remolino = self._azar.uniform(*r["intervalo"])
            avisos.append(("remolino",))

        # Sismos pequeños
        self.t_sismo -= dt
        if self.t_sismo <= 0:
            self.t_sismo = self._azar.uniform(*CONFIG["sismo"]["intervalo"])
            avisos.append(("sismo", self.sortear_magnitud()))

        # Partículas solares (irregulares)
        self.t_sep -= dt
        if self.t_sep <= 0:
            if clima_libre:
                self.t_sep = self._espera_sep()
                avisos.append(("sep",))
            else:
                self.t_sep = CONFIG["sep"]["reintento"]

        # Impacto (muy raro)
        self.t_impacto -= dt
        if self.t_impacto <= 0:
            self.t_impacto = self._azar.uniform(*CONFIG["impacto"]["intervalo"])
            avisos.append(("impacto",))

        # Forbush
        if self.forbush > 0:
            self.forbush -= dt
            if self.forbush <= 0:
                self.forbush = 0.0
                avisos.append(("forbush_fin",))
        return avisos

    # ---- partida guardada -------------------------------------------------
    CAMPOS = ("anio", "t_anio", "anios_para_global", "t_remolino", "t_sismo", "t_sep", "t_impacto", "forbush")

    def a_dict(self):
        d = {k: getattr(self, k) for k in self.CAMPOS}
        d["tormenta_anio"] = list(self.tormenta_anio) if self.tormenta_anio else None
        return d

    def de_dict(self, d):
        """Carga lo guardado. Lo que falte se queda como está (partidas viejas)."""
        for k in self.CAMPOS:
            if k in d:
                setattr(self, k, int(d[k]) if k in ("anio", "anios_para_global") else float(d[k]))
        if "tormenta_anio" in d:
            ta = d["tormenta_anio"]
            self.tormenta_anio = (float(ta[0]), ta[1]) if ta and ta[1] in ("regional", "global") else None
        # El azar sigue desde otra semilla (no se guarda su estado).
        self._azar = random.Random(self.semilla + self.anio * 1000 + int(self.t_anio))
