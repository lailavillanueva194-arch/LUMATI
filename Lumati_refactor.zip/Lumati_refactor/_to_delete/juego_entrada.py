"""Entrada del jugador: clic, rueda del mouse y teclado (incluidas las teclas del
modo demo), y reiniciar tras morir.
"""

import pygame

import estilo
from textos import cambiar_idioma, t
from config import (CABLE_PIEZAS, ESCENAS_FINAL, ESCENA_BASE, ESCENA_MAPA, LUNA, MARTE, OBJETOS,
                    RAPIDA_N, TALADRO, TILE)


class EntradaMixin:
    """Entrada del jugador: clic, rueda del mouse y teclado (incluidas las teclas del
    modo demo), y reiniciar tras morir."""

    # -- eventos -----------------------------------------------------------
    def clic(self, pos):
        if self.opciones is not None:        # menú de opciones abierto: el clic es suyo
            self.clic_opciones(pos)
            return
        if self.cinematica is not None:      # durante una cinemática el clic la salta
            self.saltar_cinematica()
            return
        if self.escena_final is not None:    # final: el clic pasa a la siguiente imagen
            self.avanzar_final()
            return
        if not self.astronauta.vivo:         # muerto: el juego está congelado
            return
        if self.inventario_abierto:          # con el menú abierto, el clic es del menú (no del mapa)
            self.clic_inventario(pos)
            return
        if self._fundido:                    # durmiendo
            return
        if self.crafteo_abierto:             # igual con el Fabricador
            self.clic_crafteo(pos)
            return
        if self.menu_base is not None:       # y con los menús de la base
            self.clic_menu_base(pos)
            return
        if self.dato and self.dato_bajo(pos):     # clic en la tarjeta de datos: se cierra (ronda 30)
            self.cerrar_dato()
            return
        i = self.rapida_bajo_mouse(pos)
        if i is not None:                    # clic en una casilla del acceso rápido
            self.usar_rapida(i)
            return
        if self.rect_inventario.collidepoint(pos) or self.rect_mano.collidepoint(pos):
            self.alternar_inventario()       # la etiqueta de la esquina y el recuadro de la mano abren el menú
            return
        if self.companero_bajo_mouse(pos):  # clic en el compañero: su cofre (ronda 27) o cambiarle la pila (32)
            self.clic_companero()
            return
        if self.escena == ESCENA_BASE:       # dentro: clic en un mueble
            self.clic_interior(pos)
            return
        # La nariz de la nave sobresale de sus cuadros: un clic ahí cuenta como clic en
        # la nave (si no, con el cable o el panel se construiría algo escondido debajo).
        if (self.nave_grande and self.rect_nave().collidepoint(pos)
                and not any(r.collidepoint(pos) for r in self.rects_interfaz())):
            self.usar_herramienta(*self._cuadro_de_la_nave(pos))
            return
        cuadro = self.cuadro_bajo_mouse(pos)
        if cuadro is not None:
            self._usar_con_efecto(*cuadro)

    def _usar_con_efecto(self, fila, col):
        """Usa la herramienta y, según lo que cambió, suelta partículas: un soplo
        de polvo si se puso o quitó algo en el cuadro, chispas si se recogió algo
        o subió una barra. Solo adorno: las reglas están en usar_herramienta."""
        tipo_antes = self.mapa[fila][col]
        cosas_antes = sum(self.inventario.values())
        barras_antes = self.astronauta.oxigeno + self.astronauta.comida
        self.usar_herramienta(fila, col)
        x, y = col * TILE + TILE / 2, fila * TILE + TILE / 2
        if self.mapa[fila][col] != tipo_antes:
            self.particulas.emitir(x, y + TILE / 4, self.colores_polvo(), cantidad=10, velocidad=70, vida=0.5)
        elif (sum(self.inventario.values()) > cosas_antes
              or self.astronauta.oxigeno + self.astronauta.comida > barras_antes):
            self.particulas.emitir(x, y, estilo.CHISPA, cantidad=7, velocidad=40, vida=0.6, tam=5, subir=40)

    def colores_polvo(self):
        return estilo.POLVO_MARTE if self.destino == MARTE else estilo.POLVO

    def rueda(self, y):
        """Rueda del mouse: con el cable en la mano cambia su color."""
        if self.opciones is not None:        # en los menús la rueda no hace nada (ronda 25: sin páginas)
            return
        if y and self.en_mano == "cable" and not self.menu_visible and self.astronauta.vivo and not self._fundido \
                and self.escena_final is None:
            self.cambiar_color_cable(-1 if y > 0 else 1)

    def reiniciar(self):
        """R tras morir: rescate si fue por oxígeno; partida nueva si fue por
        radiación (la dosis es permanente, no hay forma de bajarla)."""
        self.inventario_abierto = False      # si murió con un menú abierto, no reaparece
        self.crafteo_abierto = False
        self.menu_base = None
        self.escena = ESCENA_MAPA            # el rescate lo deja afuera, en el inicio
        self.casilla_elegida = None
        if self.rescatar_astronauta():
            self.mensaje = t("rescatado")
        else:
            self.nueva_partida()

    def tecla(self, tecla):
        if self.tecla_pantalla(tecla):       # F11 o Cmd+F: pantalla completa (ronda 29), siempre
            return
        if self.opciones is not None:        # menú de opciones abierto: sus teclas, nada más
            self.tecla_opciones(tecla)
            return
        if tecla == pygame.K_ESCAPE and not self.menu_visible and not self._fundido:
            self.abrir_opciones()            # Esc sin otro menú abierto: menú de opciones (pausa)
            return
        if self.cinematica is not None:      # cinemática: Espacio o Enter la saltan (Esc ya pausó arriba)
            if tecla in (pygame.K_SPACE, pygame.K_RETURN):
                self.saltar_cinematica()
            return
        if tecla == pygame.K_l:              # español <-> inglés (también muerto)
            cambiar_idioma()
            self.mensaje = t("idioma_cambiado")
            return
        if not self.astronauta.vivo:         # muerto: solo R, L y Esc funcionan
            if tecla == pygame.K_r:
                self.reiniciar()
            return
        if self.escena_final is not None:    # final: Espacio/Enter avanza; R al terminar
            if tecla in (pygame.K_SPACE, pygame.K_RETURN):
                self.avanzar_final()
            elif tecla == pygame.K_r and self.escena_final >= ESCENAS_FINAL:
                self.nueva_partida()
            elif tecla == pygame.K_m and self.escena_final >= ESCENAS_FINAL:
                # Siguiente misión. De la Luna a Marte, primero el viaje (si están sus PNG).
                if not (self.destino == LUNA and self.iniciar_cinematica_luna_marte()):
                    self.nueva_partida(MARTE if self.destino == LUNA else LUNA)
            elif tecla == pygame.K_i and self.escena_final >= ESCENAS_FINAL:
                self.abrir_inicio()                                             # menú principal
            return
        if self._fundido:                    # durmiendo: no se hace nada
            return
        if tecla == pygame.K_F5:             # guardar y cargar partida (también en la terminal de la base)
            self.guardar_partida()
            return
        if tecla == pygame.K_F9:
            self.cargar_partida()
            return
        if self.crafteo_abierto:             # Fabricador abierto: E o Esc lo cierran, nada más
            if tecla in (pygame.K_e, pygame.K_ESCAPE):
                self.crafteo_abierto = False
            return
        if self.menu_base is not None:       # menú de la base abierto: E o Esc lo cierran
            if tecla in (pygame.K_e, pygame.K_ESCAPE):
                self.menu_base = None
            return
        if tecla == pygame.K_e or (tecla == pygame.K_ESCAPE and self.inventario_abierto):
            self.alternar_inventario()       # E abre y cierra el menú; Esc solo lo cierra
            return
        if self.inventario_abierto:          # con el menú abierto no se usan las demás teclas
            if pygame.K_1 <= tecla < pygame.K_1 + RAPIDA_N:   # salvo 1 a 5: asignar al acceso rápido
                o = self.objeto_bajo_mouse(pygame.mouse.get_pos())
                if o is not None:
                    self.asignar_rapida(tecla - pygame.K_1, OBJETOS[o])
            return
        if pygame.K_1 <= tecla < pygame.K_1 + RAPIDA_N:        # acceso rápido
            self.usar_rapida(tecla - pygame.K_1)
            return
        if tecla == pygame.K_TAB:            # mostrar u ocultar el minimapa
            self.minimapa_visible = not self.minimapa_visible
            return
        if tecla == pygame.K_c:              # color o pieza del siguiente cable
            self.cambiar_color_cable()
            return
        if tecla == pygame.K_r and self.en_mano == "cable" and self.color_cable in CABLE_PIEZAS:
            self.girar_pieza()
            return
        if tecla == pygame.K_n:              # modo demo: adelantar el reloj
            self.clima.reloj.adelantar_a_proximo(6)
            self.mensaje = t("reloj_adelantado", hora=self.clima.reloj.hora_texto)
        elif tecla == pygame.K_t:            # modo demo: tormenta ahora
            if not self.clima.iniciar_tormenta():
                self.mensaje = t("tormenta_en_curso")
        elif tecla == pygame.K_p and self.polvo:      # modo demo (solo Marte): tormenta de polvo ahora
            if not self.iniciar_tormenta_polvo("regional"):
                self.mensaje = t("polvo_ya")
        elif tecla == pygame.K_g and self.polvo:      # modo demo (solo Marte): tormenta GLOBAL ahora
            if not self.iniciar_tormenta_polvo("global"):
                self.mensaje = t("polvo_ya")
        elif tecla == pygame.K_v and self.eventos_marte:   # modo demo (solo Marte): remolino
            self.crear_remolino()
        elif tecla == pygame.K_k and self.eventos_marte:   # modo demo (solo Marte): sismo
            self.sismo(self.eventos_marte.sortear_magnitud())
        elif tecla == pygame.K_i and self.eventos_marte:   # modo demo (solo Marte): impacto
            self.impacto()
        elif self.escena == ESCENA_BASE:  # dentro de la base no hay taladros ni máquinas bajo el mouse
            return
        elif tecla == pygame.K_m:        # mejorar el taladro bajo el mouse
            cuadro = self.taladro_bajo_mouse()
            if cuadro:
                self.mejorar_taladro(*cuadro)
        elif tecla == pygame.K_x:        # quitar el taladro o la máquina bajo el mouse
            cuadro = self.maquina_bajo_mouse()
            if cuadro and self.mapa[cuadro[0]][cuadro[1]] == TALADRO:
                self.retirar_taladro(*cuadro)
            elif cuadro:
                self.quitar_construccion(*cuadro)
            elif self.companero_bajo_mouse(pygame.mouse.get_pos()):   # X sobre el compañero: guardarlo
                self.guardar_companero()
