"""El paso del tiempo: actualizar cada cuadro (movimiento, cámara, adornos) y
avanzar el mundo (reloj, tormentas, barras del astronauta, taladros, máquinas, antena).
"""

import pygame

import datos
import maquinas
from clima import POLVO_ACTIVA, POLVO_EN_CALMA
from eventos_marte import CONFIG as CONFIG_MARTE
from maquinas import Maquina
from supervivencia import BAJO, BARRAS, CRITICO, DOSIS, NORMAL, OXIGENO
from textos import t
from config import (ANTENA_CADA, ANTENA_PRIMERO, CAMARA_SALTO, CAMARA_SUAVE, DATO_SEGUNDOS,
                    ESCENA_BASE, JUGADOR_TAM, JUGADOR_VEL, MAPA_ALTO, MAPA_ANCHO, POLVO_CADA,
                    VINETA_VELOCIDAD)
from mapa import distancia_corta


class MundoMixin:
    """El paso del tiempo: actualizar cada cuadro (movimiento, cámara, adornos) y
    avanzar el mundo (reloj, tormentas, barras del astronauta, taladros, máquinas, antena)."""

    # -- lógica ------------------------------------------------------------
    def avisar_barras(self):
        """Mensaje cuando el oxígeno o la radiación entran en nivel bajo o
        crítico (una sola vez por cambio de nivel, no en cada cuadro)."""
        for barra, clave in ((OXIGENO, "aviso_oxigeno"), (DOSIS, "aviso_dosis")):
            nivel = self.astronauta.nivel_aviso(barra)
            if nivel != self._nivel_previo[barra] and nivel in (BAJO, CRITICO):
                self.mensaje = t(clave)
            self._nivel_previo[barra] = nivel

    def actualizar_pulido(self, dt):
        """Lo que solo es adorno: partículas, barras que se mueven suave, vinetas
        y la aparición del menú. No cambia ninguna regla."""
        self._tiempo += dt
        self.particulas.actualizar(dt)
        self.actualizar_cielo(dt)
        for clave in list(self._riegos):        # las gotas del riego se acaban solas
            self._riegos[clave] -= dt
            if self._riegos[clave] <= 0:
                del self._riegos[clave]
        self.actualizar_cables(dt)
        for barra in BARRAS:                    # la barra dibujada alcanza a la real poco a poco
            real = self.astronauta.fraccion(barra)
            self._barra_vista[barra] += (real - self._barra_vista[barra]) * min(1.0, 6.0 * dt)
        # Viñetas: morada mientras llega la radiación de una tormenta solar (menos si
        # hay blindaje); azul oscuro con poco oxígeno. Suben y bajan despacio.
        vivo = self.astronauta.vivo and self.escena_final is None
        _, blindaje = self.proteccion()
        metas = {"radiacion": (1.0 - blindaje) if vivo and self.clima.en_peligro else 0.0,
                 "oxigeno": {NORMAL: 0.0, BAJO: 0.55, CRITICO: 1.0}[self.astronauta.nivel_aviso(OXIGENO)]
                 if vivo else 0.0}
        paso = VINETA_VELOCIDAD * dt
        for nombre, meta in metas.items():
            actual = self._vinetas[nombre]
            self._vinetas[nombre] = min(meta, actual + paso) if actual < meta else max(meta, actual - paso)
        meta = 0.0
        if self.polvo and self.polvo.tapa_paneles:   # la global tapa más (fuerza 1.6)
            meta = CONFIG_MARTE["polvo_" + self.polvo.tipo]["fuerza"]
        self._polvo_velo = min(meta, self._polvo_velo + paso) if self._polvo_velo < meta \
            else max(meta, self._polvo_velo - paso)
        if self.eventos_marte:
            self.actualizar_eventos_visuales(dt)
        self._menu_t = min(1.0, self._menu_t + dt / 0.12) if self.menu_visible else 0.0

    def seguir_con_camara(self, dt):
        """La cámara alcanza al astronauta con un pequeño retraso (más agradable
        que ir pegada). Mide por el camino corto, así que cruzar el borde del
        mapa no la hace saltar. Si quedó muy lejos (rescate), salta de una vez."""
        objetivo = self.jugador.centro
        dx = distancia_corta(objetivo[0], self._cam[0], MAPA_ANCHO)
        dy = distancia_corta(objetivo[1], self._cam[1], MAPA_ALTO)
        if CAMARA_SUAVE <= 0 or abs(dx) > CAMARA_SALTO or abs(dy) > CAMARA_SALTO:
            self._cam = [float(objetivo[0]), float(objetivo[1])]
        else:
            k = min(1.0, CAMARA_SUAVE * dt)
            self._cam[0] = (self._cam[0] + dx * k) % MAPA_ANCHO
            self._cam[1] = (self._cam[1] + dy * k) % MAPA_ALTO
        self.camara = (int(self._cam[0]), int(self._cam[1]))

    def actualizar_polvo(self, dt, avisar=True):
        """Marte: avanza la tormenta de polvo y avisa cuando cambia de fase."""
        for fase in self.polvo.actualizar(dt):
            if not avisar:
                continue
            es_global = self.polvo.tipo == "global"
            if fase == POLVO_ACTIVA:
                self.mensaje = t("polvo_llega_global" if es_global else "polvo_llega")
                self.mostrar_dato(CONFIG_MARTE["polvo_" + self.polvo.tipo]["dato_activa"], repetir=es_global)
            elif fase == POLVO_EN_CALMA:
                self.mensaje = t("polvo_fin")

    def actualizar(self, dt):
        if self.opciones is not None:        # menú de opciones abierto: todo en pausa
            self.actualizar_menu(dt)         # (solo se mueve la decoración del menú)
            return
        if self.cinematica is not None:      # cinemática final: solo avanza ella
            self.actualizar_cinematica(dt)
            return
        self._mensaje_t = max(0.0, self._mensaje_t - dt)
        if self.dato:
            self.dato[1] -= dt
            if self.dato[1] <= 0:
                self.dato = None
        self.actualizar_pulido(dt)
        if self._fundido:                    # durmiendo: solo corre el fundido
            self.actualizar_fundido(dt)
            return
        if not self.astronauta.vivo or self.escena_final is not None:   # congelado
            return
        teclas = pygame.key.get_pressed()
        dir_x = (teclas[pygame.K_d] or teclas[pygame.K_RIGHT]) - \
                (teclas[pygame.K_a] or teclas[pygame.K_LEFT])
        dir_y = (teclas[pygame.K_s] or teclas[pygame.K_DOWN]) - \
                (teclas[pygame.K_w] or teclas[pygame.K_UP])
        if self.hay_menu:                    # quieto con un menú abierto; el tiempo sigue
            dir_x = dir_y = 0
        if dir_x and dir_y:
            # En diagonal el vector (1, 1) mide 1.41; dividimos entre la raíz
            # de 2 para que no corra más rápido que en línea recta.
            dir_x *= 0.7071
            dir_y *= 0.7071
        if self.escena == ESCENA_BASE:       # dentro de la base: se camina por la sala
            self.mover_interior(dir_x, dir_y, dt)
            self.jugador.animar(dir_x, dir_y, dt)
        else:
            antes = (self.jugador.x, self.jugador.y)
            self.jugador.mover(dir_x * JUGADOR_VEL * dt,
                               dir_y * JUGADOR_VEL * dt, self.mapa)
            self.jugador.animar(dir_x, dir_y, dt)
            self.polvo_al_caminar(dt, antes != (self.jugador.x, self.jugador.y))
            if antes != (self.jugador.x, self.jugador.y):
                self.pisar_cable(dir_x, dir_y, dt)
            self.seguir_con_camara(dt)
        self.actualizar_companero(dt)        # el compañero te sigue (ronda 27)
        self.avanzar_mundo(dt)

    def avanzar_mundo(self, dt, avisar=True):
        """Todo lo que pasa con el tiempo, esté el astronauta donde esté: reloj y
        tormentas, barras del astronauta, taladros, máquinas y antena. Dormir
        llama a esto muchas veces seguidas con avisar=False (sin mensajes)."""
        cambios_clima = self.clima.actualizar(dt)
        if self.polvo:
            self.actualizar_polvo(dt, avisar)
        if self.eventos_marte:
            self.actualizar_eventos_marte(dt, cambios_clima, avisar)
        self.actualizar_baterias(dt, avisar)
        # La base y los bloques de regolito protegen. TODAVÍA NO EXISTEN las zonas
        # de radiación (zona): todo el mapa es zona normal.
        en_base, blindaje = self.proteccion()
        mult = self.clima.multiplicador_radiacion
        if self.eventos_marte:               # Marte: la caída Forbush baja la radiación un rato
            mult *= self.eventos_marte.mult_radiacion
        self.astronauta.actualizar(dt, en_base=en_base, zona=1.0, blindaje=blindaje,
                                   mult_tormenta=mult)
        if avisar:
            self.avisar_barras()
        for (fila, col), taladro in self.taladros.items():
            taladro.actualizar(dt, self.tiene_energia(fila, col))
        cultivo = self.factor_cultivo()      # Marte: con polvo las plantas crecen más lento
        for (fila, col), maquina in self.maquinas.items():
            if isinstance(maquina, Maquina):
                antes = maquina.producidas
                paso = dt * cultivo if maquina.tipo == maquinas.INVERNADERO else dt
                maquina.actualizar(paso, self.tiene_energia(fila, col), self.tanque_de(fila, col))
                self.producido[maquina.recurso_salida] += maquina.producidas - antes
        self.mover_agua()
        for mq in self.macetas:              # invernadero de la base: siempre con energía
            if mq is not None:
                antes = mq.producidas
                mq.actualizar(dt * cultivo, True)
                self.producido[mq.recurso_salida] += mq.producidas - antes
        self.actualizar_antena(dt, avisar)

    def actualizar_antena(self, dt, avisar=True):
        """Contacto con la Tierra: alguna antena con energía. Mientras dura, cada
        ANTENA_CADA segundos llega un mensaje (un dato real de datos.py, con su
        fuente). No cambia cómo se gana: es información y un logro del final."""
        contacto = any(self.tiene_energia(f, c) for f, c in self.antenas)
        if contacto and not self.contacto:
            self.contacto_hecho = True
            self._tierra_t = ANTENA_PRIMERO
            if avisar:
                self.mensaje = t("antena_contacto")
        elif self.contacto and not contacto and avisar:
            self.mensaje = t("antena_perdida")
        self.contacto = contacto
        if not contacto:
            return
        self._tierra_t -= dt
        if self._tierra_t <= 0 and self.dato is None and avisar:
            lista = datos.ids(self.destino)     # en la Luna, sin los datos de Marte
            self.dato = [lista[self._msg_tierra % len(lista)], DATO_SEGUNDOS, "tierra"]
            self._msg_tierra += 1
            self._tierra_t = ANTENA_CADA

    def polvo_al_caminar(self, dt, se_movio):
        """Un soplo de polvo en los pies cada POLVO_CADA segundos mientras camina."""
        if not se_movio:
            self._polvo_t = 0.0
            return
        self._polvo_t -= dt
        if self._polvo_t <= 0:
            self._polvo_t = POLVO_CADA
            self.particulas.emitir(self.jugador.x + JUGADOR_TAM / 2, self.jugador.y + JUGADOR_TAM,
                                   self.colores_polvo(), cantidad=3, velocidad=34, vida=0.7, tam=8, subir=10)
