"""Laylu, la compañera robot, en el juego (ronda 27): fabricarlo, ponerlo, que te siga
(afuera, en la base y en el cuarto de cultivos), guardarlo con X y su cofre
(meter y sacar recursos). La lógica de moverse está en companero.py; aquí se
conecta con el mapa, la base, el mouse y el dibujo. Los dibujos son de las
diseñadoras (assets/companero/laylu_*.png).
"""

import math
import os

import pygame

from textos import t
from config import (ALCANCE, ALCANCE_MUEBLE, ANCHO, ALTO, COFRE_CASILLAS, COMPANERO_CARPETA,
                    COMPANERO_ESCALA, COMPANERO_FPS, ESCENA_BASE, JUGADOR_TAM,
                    MAPA_ALTO, MAPA_ANCHO, SOLIDOS, TILE)
from mapa import distancia_corta
from jugador import pos_pantalla

DIBUJOS_COMPANERO = ("frente", "espaldas", "izquierda", "derecha")
CUADROS_COMPANERO = 4


def cargar_companero(carpeta=COMPANERO_CARPETA):
    """{dibujo: [4 cuadros agrandados]} o None si falta algún PNG. Se agrandan
    COMPANERO_ESCALA veces sin suavizado (píxeles parejos)."""
    cuadros = {}
    for d in DIBUJOS_COMPANERO:
        lista = []
        for k in range(1, CUADROS_COMPANERO + 1):
            ruta = os.path.join(carpeta, f"laylu_{d}_{k}.png")
            try:
                img = pygame.image.load(ruta).convert_alpha()
            except (pygame.error, FileNotFoundError):
                return None
            lista.append(pygame.transform.scale(img, (img.get_width() * COMPANERO_ESCALA,
                                                      img.get_height() * COMPANERO_ESCALA)))
        cuadros[d] = lista
    return cuadros


class CompaneroMixin:
    """El compañero en el juego: ponerlo, guardarlo, seguir, dibujarlo y su cofre."""

    # ---- poner y guardar -------------------------------------------------------
    def colocar_companero(self, fila, col):
        """Con el compañero en la mano, clic en suelo libre: se activa ahí."""
        if self.companero.activo:
            self.mensaje = t("companero_ya")
            return
        if self.mapa[fila][col] in SOLIDOS:
            self.mensaje = t("companero_no_cabe")
            return
        if not self.tiene_objeto("companero"):
            return
        self.objetos["companero"] -= 1
        self.companero.poner(col * TILE + (TILE - JUGADOR_TAM) / 2, fila * TILE + (TILE - JUGADOR_TAM) / 2)
        self._comp_lugar = (self.escena, self.cuarto)
        self.mensaje = t("companero_puesto")

    def guardar_companero(self):
        """X sobre el compañero: vuelve al inventario, solo si su cofre está vacío."""
        if not self.companero.vacio:
            self.mensaje = t("companero_cofre_lleno")
            return False
        self.companero.activo = False
        self.objetos["companero"] += 1
        self.mensaje = t("companero_guardado")
        return True

    # ---- seguir ------------------------------------------------------------------
    def _libre_interior(self, x, y):
        """True si la caja del compañero cabe en (x, y) de la sala (piso, sin muebles)."""
        _, piso = self.sala()
        caja = self.caja_interior(x, y)
        return piso.contains(caja) and not any(
            caja.colliderect(r) for n, r in self.muebles().items() if not n.startswith("puerta"))

    def actualizar_companero(self, dt):
        """Cada cuadro: el compañero sigue al astronauta. Si cambió de lugar (entró
        a la base, cambió de cuarto o salió), aparece junto a él."""
        c = self.companero
        if not c.activo:
            return
        lugar = (self.escena, self.cuarto)
        if lugar != self._comp_lugar:
            self._comp_lugar = lugar
            self.companero_junto_a_ti()
            return
        if self.escena == ESCENA_BASE:
            c.seguir_interior(self.caja_interior().center, self._libre_interior, dt)
        elif c.seguir(self.jugador.centro, self.mapa, dt):     # "lejos" o "atorado"
            self.companero_junto_a_ti()

    def companero_junto_a_ti(self):
        """Pone al compañero en un lugar libre pegado al astronauta (detrás de él
        si se puede)."""
        c = self.companero
        atras = {"abajo": (0, -1), "arriba": (0, 1), "izquierda": (1, 0), "derecha": (-1, 0)}[self.jugador.direccion]
        vecinos = [atras, (1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (-1, 1), (1, -1), (-1, -1)]
        if self.escena == ESCENA_BASE:
            x0, y0 = self.pos_base
            for dx, dy in vecinos + [(0, 0)]:
                x, y = x0 + dx * 40, y0 + dy * 34
                if self._libre_interior(x, y) or (dx, dy) == (0, 0):
                    c.pos_base = [x, y]
                    break
            c.cuerpo.direccion = self.jugador.direccion
            return
        j = self.jugador
        for radio in (1, 2, 3):
            for dx, dy in vecinos:
                x, y = (j.x + dx * radio * TILE) % MAPA_ANCHO, (j.y + dy * radio * TILE) % MAPA_ALTO
                if not c.cuerpo.choca(self.mapa, x, y):
                    c.cuerpo.x, c.cuerpo.y = x, y
                    c._atorado = 0.0
                    return
        c.cuerpo.x, c.cuerpo.y = j.x, j.y                     # sin lugar: en el mismo sitio

    # ---- dónde está en la pantalla ----------------------------------------------------
    def _caja_companero_pantalla(self):
        """(x, y) de la esquina de su caja en la pantalla."""
        c = self.companero
        if self.escena == ESCENA_BASE:
            return int(c.pos_base[0]), int(c.pos_base[1])
        cam_x, cam_y = self.camara
        return (pos_pantalla(c.cuerpo.x, cam_x, MAPA_ANCHO, ANCHO / 2),
                pos_pantalla(c.cuerpo.y, cam_y, MAPA_ALTO, ALTO / 2))

    def _imagen_companero(self):
        c = self.companero
        lista = self.sprites_companero[c.dibujo]
        k = int(c.cuerpo.t_anim * COMPANERO_FPS) % len(lista) if c.cuerpo.camina else 0
        return lista[k]

    def rect_companero(self):
        """Rectángulo del dibujo del compañero en la pantalla (o None si no está)."""
        if not self.companero.activo or not self.sprites_companero:
            return None
        x, y = self._caja_companero_pantalla()
        img = self._imagen_companero()
        return img.get_rect(midbottom=(x + JUGADOR_TAM // 2, y + JUGADOR_TAM + 2))

    def companero_bajo_mouse(self, pos):
        rect = self.rect_companero()
        return rect is not None and rect.collidepoint(pos)

    def companero_cerca(self):
        """True si el astronauta está lo bastante cerca para abrir el cofre."""
        c = self.companero
        if self.escena == ESCENA_BASE:
            ax, ay = self.caja_interior().center
            bx, by = c.pos_base[0] + JUGADOR_TAM / 2, c.pos_base[1] + JUGADOR_TAM / 2
            return math.hypot(ax - bx, ay - by) <= ALCANCE_MUEBLE * 1.5
        ax, ay = self.jugador.centro
        bx, by = c.cuerpo.centro
        return math.hypot(distancia_corta(ax, bx, MAPA_ANCHO), distancia_corta(ay, by, MAPA_ALTO)) <= ALCANCE * TILE

    # ---- dibujo ------------------------------------------------------------------
    def dibujar_con_companero(self):
        """El astronauta y el compañero, primero el que está más arriba (así el de
        abajo queda encima). Sin compañero, solo el astronauta (como antes)."""
        if not self.companero.activo or not self.sprites_companero:
            self.dibujar_astronauta()
            return
        if self.escena == ESCENA_BASE:
            mio, suyo = self.pos_base[1], self.companero.pos_base[1]
        else:
            mio, suyo = 0.0, distancia_corta(self.companero.cuerpo.y, self.jugador.y, MAPA_ALTO)
        if suyo < mio:
            self.dibujar_companero()
            self.dibujar_astronauta()
        else:
            self.dibujar_astronauta()
            self.dibujar_companero()

    def dibujar_companero(self):
        """El robot (con su animación al caminar) y un cofre chiquito encima."""
        p = self.pantalla
        x, y = self._caja_companero_pantalla()
        sombra = self._sombra_astronauta
        p.blit(sombra, sombra.get_rect(center=(x + JUGADOR_TAM // 2, y + JUGADOR_TAM)))
        img = self._imagen_companero()
        r = img.get_rect(midbottom=(x + JUGADOR_TAM // 2, y + JUGADOR_TAM + 2))
        p.blit(img, r)
        cofre = pygame.Rect(0, 0, 18, 13)                       # el cofre, sobre su cabeza
        cofre.midbottom = (r.centerx, r.top + 4)
        pygame.draw.rect(p, (120, 74, 40), cofre, border_radius=2)
        pygame.draw.rect(p, (70, 40, 20), cofre, 1, border_radius=2)
        pygame.draw.line(p, (70, 40, 20), (cofre.x, cofre.y + 5), (cofre.right - 1, cofre.y + 5))
        pygame.draw.rect(p, (232, 198, 58), (cofre.centerx - 2, cofre.y + 4, 4, 4))   # cerradura

    # ---- cofre ---------------------------------------------------------------------
    def abrir_cofre(self):
        """Clic en el compañero: abre su cofre si estás cerca."""
        if not self.companero_cerca():
            self.mensaje = t("acercate")
            return
        self.inventario_abierto = self.crafteo_abierto = False
        self.menu_base = "cofre"

    def meter_cofre(self, recurso, cantidad):
        n = min(cantidad, self.inventario[recurso], self.companero.espacio(recurso))
        if n <= 0:
            self.mensaje = t("cofre_lleno")
            return
        self.inventario[recurso] -= n
        self.companero.cofre[recurso] += n
        self.mensaje = t("cofre_metiste", n=n, recurso=t("recurso_" + recurso))

    def sacar_cofre(self, recurso, cantidad):
        n = self.inventario.agregar(recurso, min(cantidad, self.companero.cofre.get(recurso, 0)))
        if n <= 0:
            self.mensaje = self._mensaje_lleno(recurso)
            return
        self.companero.cofre[recurso] -= n
        self.mensaje = t("cofre_sacaste", n=n, recurso=t("recurso_" + recurso))

    def titulo_cofre(self):
        return t("cofre_titulo", usadas=sum(1 for x in self.companero.casillas() if x), total=COFRE_CASILLAS)

    def contenedor_abierto(self):
        """(casillas, meter, sacar) del almacén o del cofre, según el menú abierto."""
        if self.menu_base == "cofre":
            return self.companero.casillas(), self.meter_cofre, self.sacar_cofre
        return self.casillas_almacen(), self.meter_almacen, self.sacar_almacen
