"""Objeto en la mano del astronauta (ronda 26): lo que está elegido en la barra
de acceso rápido ("en la mano") se dibuja chiquito en su guante, según hacia
dónde mira, en el mapa y dentro de la base. Con la mano vacía no se dibuja nada.
Solo es dibujo: no cambia ninguna regla.
"""

import pygame

from config import ASTRONAUTA_ESCALA, MANO_EMPUJE, MANO_LADO, MANO_POS


class ManoMixin:
    """Dibuja el objeto de la mano junto al guante del astronauta."""

    def icono_en_mano(self, objeto, espejo=False):
        """Ícono del objeto a MANO_LADO píxeles (hecho una vez). Con espejo se
        voltea para que la herramienta apunte hacia donde mira."""
        clave = (objeto, espejo)
        if clave not in self._iconos_mano:
            img = self.iconos_objeto[objeto]
            chico = pygame.transform.smoothscale(img, (MANO_LADO, MANO_LADO))
            self._iconos_mano[clave] = pygame.transform.flip(chico, True, False) if espejo else chico
        return self._iconos_mano[clave]

    def dibujar_en_mano(self, x, y, direccion, cuadro):
        """(x, y): esquina del dibujo del astronauta en pantalla; cuadro: cuál de
        la animación se ve. Pone el objeto centrado en el guante (la posición sale
        de MANO_POS, medida en el dibujo de las diseñadoras)."""
        if self.en_mano is None:
            return
        posiciones = MANO_POS[direccion]
        px, py = posiciones[min(cuadro, len(posiciones) - 1)]
        dx, dy = MANO_EMPUJE[direccion]
        cx = x + px * ASTRONAUTA_ESCALA // 3 + dx
        cy = y + py * ASTRONAUTA_ESCALA // 3 + dy
        img = self.icono_en_mano(self.en_mano, espejo=direccion == "izquierda")
        self.pantalla.blit(img, img.get_rect(center=(cx, cy)))
        if self.en_mano == "cable":                      # el cable muestra su color (y su patrón)
            self._muestra_color((cx + MANO_LADO // 2 - 2, cy - MANO_LADO // 2 + 2), self.color_cable, 5)
