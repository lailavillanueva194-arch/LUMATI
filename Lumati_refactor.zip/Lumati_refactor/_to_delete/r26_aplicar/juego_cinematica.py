"""Cinemática final del juego (ronda 26): al despegar desde Marte se ve la
animación de assets/cinematica/ (ver cinematica.py) y después la pantalla final
con las estadísticas. Espacio, Enter o un clic la saltan. Si faltan los PNG,
el final es el de siempre (las imágenes fijas y luego las estadísticas).
"""

import cinematica
from textos import t
from config import ALTO, ANCHO, CINE_CARPETA, CINE_FPS, CINE_FUNDIDO, ESCENAS_FINAL


class CinematicaMixin:
    """Cinemática final al salir de Marte: empezarla, avanzarla, saltarla y dibujarla."""

    def iniciar_cinematica(self):
        """Empieza la cinemática si hay cuadros. Devuelve False si no hay (entonces
        sigue el final de siempre)."""
        if self._cuadros_cine is None:                  # se cargan la primera vez
            self._cuadros_cine = cinematica.cargar(CINE_CARPETA)
        if not self._cuadros_cine:
            return False
        self.cinematica = cinematica.Cinematica(self._cuadros_cine, (ANCHO, ALTO), CINE_FPS, CINE_FUNDIDO)
        return True

    def actualizar_cinematica(self, dt):
        if self.cinematica.actualizar(dt):
            self.terminar_cinematica()

    def terminar_cinematica(self):
        """Fin (o salto) de la cinemática: directo a la pantalla de estadísticas."""
        self.cinematica = None
        self.escena_final = ESCENAS_FINAL

    def dibujar_cinematica(self):
        aviso = self.fuente_chica.render(t("cine_saltar"), True, (150, 150, 160))
        self.cinematica.dibujar(self.pantalla, aviso)
