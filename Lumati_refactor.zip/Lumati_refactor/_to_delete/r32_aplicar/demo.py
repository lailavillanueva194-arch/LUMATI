"""Partida de demostración (ronda 28): circuitos ya armados en tres zonas
(BÁSICOS, MEDIOS y DIFÍCILES) y materiales ilimitados, para enseñar el juego.

La partida se arma con el código del propio juego (poner cables, paneles,
taladros y máquinas igual que con el mouse, plantar y regar las macetas,
activar a Laylu...) y se guarda como un guardado normal en
partidas/demo_luna.json (y demo_marte.json). La única diferencia con una
partida normal es la bandera "demo" del guardado (fabricar y colocar no
gastan nada) y los letreros pintados en el suelo.

Para volver a generar los archivos: python3 demo.py   (o borrarlos: el menú
los vuelve a crear la próxima vez).

Dónde está cada zona (fila, columna del mapa de 32x32; la base está en 14,14):
    BÁSICOS    filas 19-24, columnas 2-14   (abajo a la izquierda de la base;
                                             el astronauta aparece aquí, fila 22)
    MEDIOS     filas 10-16, columnas 20-31  (a la derecha, arriba de la nave)
    DIFÍCILES  filas  0-9,  columnas 12-24  (arriba de la base)
Cada zona cabe en la pantalla parado en medio de ella.
Ninguna toca las montañas (COLINAS de config.py).
"""

import os

import maquinas
import partidas
from config import (BATERIA_MAX, CARPETA, JUGADOR_TAM, LUNA, MACETAS_BASE, MARTE, OBJETOS,
                    OBJETO_TIPO, TILE)
from textos import t

ARCHIVO = "demo_{destino}.json"
CANTIDAD = 99                    # lo que dice tener de cada objeto (se muestra como infinito)

# Letreros del suelo: (fila, col, clave de textos.py, tipo, zona, ¿debe tener energía?)
# tipo "zona": cartel grande; "nota": explicación de un circuito, en la fila de abajo del
# circuito (con un punto verde si debe funcionar y rojo si está roto a propósito).
LETREROS = [
    (19, 2, "demo_zona_basicos", "zona", "basicos", None),
    (21, 2, "demo_b1", "nota", "basicos", True),
    (21, 9, "demo_b2", "nota", "basicos", True),
    (24, 2, "demo_b3", "nota", "basicos", False),
    (24, 9, "demo_b4", "nota", "basicos", False),
    (10, 20, "demo_zona_medios", "zona", "medios", None),
    (13, 20, "demo_m1", "nota", "medios", None),
    (13, 26, "demo_m2", "nota", "medios", True),
    (16, 20, "demo_m3", "nota", "medios", True),
    (16, 26, "demo_m4", "nota", "medios", True),
    (0, 12, "demo_zona_dificiles", "zona", "dificiles", None),
    (4, 12, "demo_d1", "nota", "dificiles", None),
    (4, 19, "demo_d2", "nota", "dificiles", True),
    (9, 12, "demo_d3", "nota", "dificiles", True),
    (9, 19, "demo_d4", "nota", "dificiles", False),
]

# Circuitos. Cada pieza: (fila, col, qué). qué = "panel", "taladro", un objeto de
# OBJETO_TIPO (purificador, tanque_agua, bateria, antena...) o ("cable", opción, giro)
# con la opción de OPCIONES_CABLE ("verde", "azul", "amarillo", "negro", "con_mas",
# "con_t", "con_l") y el giro de 0 a 3 (R en el juego).
V, A, Y = ("cable", "verde", 0), ("cable", "azul", 0), ("cable", "amarillo", 0)
K = ("cable", "negro", 0)                # cable negro troncal: une colores solo izq-der
MAS = ("cable", "con_mas", 0)
L_BIEN = ("cable", "con_l", 2)           # L girada: entra por la izquierda y baja
L_MAL = ("cable", "con_l", 0)            # L sin girar: arriba-derecha (no toca a nadie)
P, T, U = "panel", "taladro", maquinas.PURIFICADOR

CIRCUITOS = {
    # ---- BÁSICOS --------------------------------------------------------------
    # B1: panel + cable verde + taladro -> con energía
    "b1": [(20, 2, P), (20, 3, V), (20, 4, V), (20, 5, V), (20, 6, V), (20, 7, T)],
    # B2: panel + cable + purificador (con hielo) -> con energía
    "b2": [(20, 9, P), (20, 10, V), (20, 11, V), (20, 12, U)],
    # B3: cable cortado a propósito -> el taladro sin energía
    "b3": [(23, 2, P), (23, 3, V), (23, 4, V), (23, 6, V), (23, 7, T)],
    # B4: purificador pegado al panel, sin cable -> sin energía (hace falta cable)
    "b4": [(23, 9, P), (23, 10, U)],
    # ---- MEDIOS ---------------------------------------------------------------
    # M1: verde y azul juntos pero separados: el verde tiene energía, el azul no
    "m1": [(11, 20, P), (11, 21, V), (11, 22, V), (11, 23, V), (11, 24, U),
           (12, 21, A), (12, 22, A), (12, 23, A), (12, 24, T)],
    # M2: el conector + une el verde (con panel) con el azul (con taladro)
    "m2": [(12, 26, P), (12, 27, V), (12, 28, MAS), (12, 29, A), (12, 30, A), (12, 31, T)],
    # M3: batería llena: guarda energía de día y la da de noche
    "m3": [(14, 21, P), (14, 22, V), (14, 23, V), (14, 24, V), (14, 25, T), (15, 23, "bateria")],
    # M4: purificador -> tanque de agua -> electrolizador -> tanque de hidrógeno
    "m4": [(14, 27, P), (14, 28, V), (14, 29, V), (14, 30, V), (14, 31, V),
           (15, 28, U), (15, 29, "tanque_agua"), (15, 30, maquinas.ELECTROLIZADOR),
           (15, 31, maquinas.TANQUE)],
    # ---- DIFÍCILES --------------------------------------------------------------
    # D1: el cable negro lleva la energía del verde al azul (solo izquierda-derecha);
    # el amarillo que lo toca por abajo NO la recibe
    "d1": [(1, 12, P), (1, 13, V), (1, 14, K), (1, 15, K), (1, 16, A), (1, 17, U),
           (2, 14, Y), (3, 14, Y), (3, 15, U)],
    # D2: conector L girado para bajar el circuito
    "d2": [(1, 19, P), (1, 20, V), (1, 21, V), (1, 22, L_BIEN), (2, 22, A), (3, 22, T)],
    # D3: dos redes con panel y batería; la verde enciende la antena (contacto con la Tierra)
    "d3": [(5, 12, P), (5, 13, V), (5, 14, V), (5, 15, V), (5, 16, "antena"), (6, 15, "bateria"),
           (7, 12, "bateria"), (7, 13, A), (7, 14, A), (7, 15, U), (8, 14, P)],
    # D4: la misma L pero mal girada: no conecta y el taladro se queda sin energía
    "d4": [(5, 19, P), (5, 20, V), (5, 21, V), (5, 22, L_MAL), (6, 22, A), (7, 22, T)],
}

# Lo que cada máquina debe hacer (lo comprueban las pruebas con tiene_energia):
# (fila, col) -> True (con energía) o False (sin energía, a propósito).
ESPERADO = {
    (20, 7): True, (20, 12): True, (23, 7): False, (23, 10): False,
    (11, 24): True, (12, 24): False, (12, 31): True, (14, 25): True,
    (15, 28): True, (15, 30): True,
    (1, 17): True, (3, 15): False, (3, 22): True, (5, 16): True, (7, 15): True, (7, 22): False,
}

JUGADOR = (22, 8)                # cuadro donde aparece: en el pasillo de BÁSICOS, con sus 4 circuitos a la vista
LAYLU = (22, 11)                 # Laylu, a su derecha
MOCHILA = {"regolito": 20, "hierro": 20, "metal": 20, "cristal": 10, "hielo": 3, "agua": 10}
COFRE_LAYLU = {"hierro": 20, "metal": 10, "cristal": 5, "regolito": 20}
RAPIDA = ["cable", "generador", "taladro", maquinas.PURIFICADOR, "regadera"]
# Macetas del cuarto de cultivos: (cultivo, fracción de crecimiento). None: hueco vacío;
# 0: recién plantada (sin regar); 1: con fruto listo para cosechar.
MACETAS = [("tomate", 1.0), ("lechuga", 0.8), ("zanahoria", 0.55), ("nopal", 0.3),
           ("tomate", 0.1), ("lechuga", 0.0), ("zanahoria", 1.0), ("nopal", 0.65),
           None, None, None, None]


def ruta(destino, base=CARPETA):
    """Ruta del archivo de la demo de ese destino (en partidas/)."""
    return os.path.join(partidas.carpeta(base), ARCHIVO.format(destino=destino))


def _poner(j, f, c, que):
    """Pone una pieza como lo haría el jugador con el mouse (sin pedir alcance)."""
    if isinstance(que, tuple):                       # cable o pieza
        _, opcion, giro = que
        j.color_cable, j.giro_cable = opcion, giro
        j.usar_cable(f, c)
    elif que == "panel":
        j.usar_generador(f, c)
    elif que == "taladro":
        j.usar_pico(f, c)                            # supervivencia: primero se pica el suelo
        j.usar_taladro(f, c)
    else:
        j.construir(f, c, OBJETO_TIPO[que], que)


def construir(j, destino=LUNA):
    """Arma la partida de demostración en el juego `j` (lo deja listo para jugar)."""
    j.nueva_partida(destino)
    j.es_demo = True
    j.objetos = {o: CANTIDAD for o in OBJETOS}
    for piezas in CIRCUITOS.values():
        for f, c, que in piezas:
            _poner(j, f, c, que)
    # Lo que llevan dentro las máquinas para que se vean trabajando.
    for (f, c), mq in j.maquinas.items():
        if isinstance(mq, maquinas.Maquina) and mq.tipo in (maquinas.PURIFICADOR, maquinas.ELECTROLIZADOR):
            mq.depositar(maquinas.ENTRADA_MAX)
        elif isinstance(mq, maquinas.Tanque):
            mq.hidrogeno = 2
    for clave in j.tanques_agua:
        j.tanques_agua[clave] = 10
    for clave in j.baterias:                         # baterías llenas (dan energía de noche)
        j.baterias[clave] = BATERIA_MAX
    j._energia_sucia = True
    j.letreros = [list(l) for l in LETREROS]
    # Mochila, almacén de la base y acceso rápido.
    for recurso, n in MOCHILA.items():
        j.inventario[recurso] = 0
        j.inventario.agregar(recurso, n)
    for recurso in j.almacen:
        j.almacen[recurso] = 20
    j.rapida = list(RAPIDA)
    j.en_mano = "cable"
    j.color_cable, j.giro_cable = "verde", 0
    # Macetas del cuarto de cultivos: se plantan, se riegan y se dejan crecer (con el
    # mismo código del juego), cada una hasta una etapa distinta.
    j.en_mano = maquinas.INVERNADERO
    for i, maceta in enumerate(MACETAS[:MACETAS_BASE]):
        if maceta is None:
            continue
        cultivo, parte = maceta
        j.usar_maceta(i)                             # plantar
        mq = j.macetas[i]
        mq.cultivo = cultivo
        if parte <= 0:
            continue
        mq.depositar(1)                              # regar
        if parte < 1:
            mq.actualizar(parte * mq.tiempo_unidad, True)          # crecer hasta esa etapa
        else:
            mq.actualizar(mq.tiempo_unidad + 0.01, True)           # fruto listo para cosechar
    j.en_mano = "cable"
    # Astronauta frente a BÁSICOS y Laylu a su lado, con su cofre.
    f, c = JUGADOR
    j.jugador.x, j.jugador.y = c * TILE + (TILE - JUGADOR_TAM) / 2, f * TILE + (TILE - JUGADOR_TAM) / 2
    j.jugador.direccion = "abajo"
    f, c = LAYLU
    j.colocar_companero(f, c)
    j.companero.cofre.update(COFRE_LAYLU)
    j.companero.cuerpo.direccion = "abajo"
    j._comp_lugar = j.lugar_actual()
    j.dato = None                                    # sin el dato de bienvenida de Marte
    j.aplicar_dict(j.estado_a_dict())                # deja cámara, energía y antena al día
    j.mensaje = t("demo_bienvenida")
    return j


def guardar(j, destino, base=CARPETA):
    """Guarda la demo ya armada como guardado normal. Devuelve la ruta."""
    destino_ruta = ruta(destino, base)
    partidas.escribir(destino_ruta, j.estado_a_dict(), t("demo_nombre_" + destino))
    return destino_ruta


if __name__ == "__main__":                           # python3 demo.py: vuelve a hacer los archivos
    import main
    juego = main.Juego(LUNA)
    for lugar in (LUNA, MARTE):
        construir(juego, lugar)
        print("Demo guardada en", guardar(juego, lugar))
