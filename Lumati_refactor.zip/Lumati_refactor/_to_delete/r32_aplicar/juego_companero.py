"""Laylu, la compañera robot, en el juego (ronda 27): fabricarlo, ponerlo, que te siga
(afuera, en la base y en el cuarto de cultivos), guardarlo con X y su cofre
(meter y sacar recursos). La lógica de moverse está en companero.py; aquí se
conecta con el mapa, la base, el mouse y el dibujo. Los dibujos son de las
diseñadoras (assets/companero/laylu_*.png).
"""

import math
import os

import pygame

from textos import t
from config import (ALCANCE, ALCANCE_MUEBLE, ANCHO, ALTO, COFRE_CASILLAS, COLUMNAS, COMPANERO_AVISO_BAJA,
                    COMPANERO_BATERIA_COSTO, COMPANERO_CARPETA, COMPANERO_DISTANCIA, COMPANERO_ESCALA,
                    COMPANERO_FACTOR_BASE, COMPANERO_FPS, COMPANERO_GASTO_CAMINANDO, COMPANERO_GASTO_QUIETA,
                    COMPANERO_RECARGA_BASE, COMPANERO_RECARGA_BATERIA, ESCENA_BASE, FILAS, JUGADOR_TAM,
                    MAPA_ALTO, MAPA_ANCHO, SOLIDOS, TILE)
from mapa import distancia_corta
from jugador import pos_pantalla

DIBUJOS_COMPANERO = ("frente", "espaldas", "izquierda", "derecha")
CUADROS_COMPANERO = 4


def cargar_companero(carpeta=COMPANERO_CARPETA):
    """{dibujo: [4 cuadros agrandados]} o None si falta algún PNG. Se agrandan
    COMPANERO_ESCALA veces sin suavizado (píxeles parejos)."""
    cuadros = {}
    for d in DIBUJOS_COMPANERO:
        lista = []
        for k in range(1, CUADROS_COMPANERO + 1):
            ruta = os.path.join(carpeta, f"laylu_{d}_{k}.png")
            try:
                img = pygame.image.load(ruta).convert_alpha()
            except (pygame.error, FileNotFoundError):
                return None
            lista.append(pygame.transform.scale(img, (img.get_width() * COMPANERO_ESCALA,
                                                      img.get_height() * COMPANERO_ESCALA)))
        cuadros[d] = lista
    return cuadros


def icono_pila(lado=32):
    """Ícono de la Pila para Laylu (dibujado): una pila verde con su punta y un rayo."""
    img = pygame.Surface((lado, lado), pygame.SRCALPHA)
    s = lado / 32
    cuerpo = pygame.Rect(round(9 * s), round(7 * s), round(14 * s), round(22 * s))
    pygame.draw.rect(img, (40, 46, 58), cuerpo.inflate(4, 4), border_radius=round(4 * s))
    pygame.draw.rect(img, (70, 190, 110), cuerpo, border_radius=round(3 * s))
    pygame.draw.rect(img, (150, 230, 170), (cuerpo.x + 2, cuerpo.y + 2, round(3 * s), cuerpo.h - 4), border_radius=2)
    pygame.draw.rect(img, (40, 46, 58), (round(13 * s), round(3 * s), round(6 * s), round(4 * s)), border_radius=1)
    cx, cy = cuerpo.centerx, cuerpo.centery
    rayo = [(cx + 2 * s, cy - 8 * s), (cx - 4 * s, cy + 1 * s), (cx, cy + 1 * s),
            (cx - 2 * s, cy + 8 * s), (cx + 4 * s, cy - 1 * s), (cx, cy - 1 * s)]
    pygame.draw.polygon(img, (255, 255, 255), rayo)
    pygame.draw.polygon(img, (40, 46, 58), rayo, 1)
    return img


class CompaneroMixin:
    """El compañero en el juego: ponerlo, guardarlo, seguir, dibujarlo y su cofre."""

    # ---- poner y guardar -------------------------------------------------------
    def colocar_companero(self, fila, col):
        """Con el compañero en la mano, clic en suelo libre: se activa ahí."""
        if self.companero.activo:
            self.mensaje = t("companero_ya")
            return
        if self.mapa[fila][col] in SOLIDOS:
            self.mensaje = t("companero_no_cabe")
            return
        if not self.tiene_objeto("companero"):
            return
        self.gastar_objeto("companero")
        self.companero.poner(col * TILE + (TILE - JUGADOR_TAM) / 2, fila * TILE + (TILE - JUGADOR_TAM) / 2)
        self._comp_lugar = self.lugar_actual()
        self.mensaje = t("companero_puesto")

    def guardar_companero(self):
        """X sobre el compañero: vuelve al inventario, solo si su cofre está vacío."""
        if not self.companero.vacio:
            self.mensaje = t("companero_cofre_lleno")
            return False
        self.companero.activo = False
        self.devolver_objeto("companero")
        self.mensaje = t("companero_guardado")
        return True

    # ---- seguir ------------------------------------------------------------------
    def _libre_interior(self, x, y):
        """True si la caja del compañero cabe en (x, y) de la sala (piso, sin muebles)."""
        _, piso = self.sala()
        caja = self.caja_interior(x, y)
        return piso.contains(caja) and not any(
            caja.colliderect(r) for n, r in self.muebles().items() if not n.startswith("puerta"))

    def actualizar_companero(self, dt):
        """Cada cuadro: el compañero sigue al astronauta. Si cambió de lugar (entró
        a la base, cambió de cuarto o salió), aparece junto a él.

        Ronda 32: su batería se gasta (más caminando que quieta) y se recarga en la
        base o junto a una batería del circuito con carga. Sin carga se queda quieta
        donde está: no te sigue ni aparece junto a ti (su cofre sí se puede abrir)."""
        c = self.companero
        if not c.activo:
            return
        if c.sin_carga:
            c._caminando = False
            c.cuerpo.animar(0, 0, dt)
            self._bateria_companero(0.0, dt)                # solo puede recargarse donde está
            return
        lugar = self.lugar_actual()
        if lugar != self._comp_lugar:
            self._comp_lugar = lugar
            self.companero_junto_a_ti()
            return
        if self.escena == ESCENA_BASE:
            c.seguir_interior(self.caja_interior().center, self._libre_interior, dt)
        elif c.seguir(self.jugador.centro, self.mapa, dt):     # "lejos" o "atorado"
            self.companero_junto_a_ti()
        gasto = COMPANERO_GASTO_CAMINANDO if c._caminando else COMPANERO_GASTO_QUIETA
        self._bateria_companero(gasto * dt, dt)

    # ---- batería (ronda 32) ---------------------------------------------------------
    def bateria_cercana(self):
        """(fila, col) de una batería del circuito con carga a 1 cuadro o menos de
        Laylu (afuera), o None."""
        if not self._comp_lugar or self._comp_lugar[0] == ESCENA_BASE:
            return None
        cx, cy = self.companero.cuerpo.centro
        f0, c0 = int(cy // TILE) % FILAS, int(cx // TILE) % COLUMNAS
        for df in (-1, 0, 1):
            for dc in (-1, 0, 1):
                b = ((f0 + df) % FILAS, (c0 + dc) % COLUMNAS)
                if self.baterias.get(b, 0) > 0:
                    return b
        return None

    def recargando_companero(self):
        """"base", "bateria" o None: dónde se está recargando ahora."""
        if not self.companero.activo or self.companero.bateria >= 100:
            return None
        if self._comp_lugar and self._comp_lugar[0] == ESCENA_BASE:
            return "base"
        return "bateria" if self.bateria_cercana() else None

    def _bateria_companero(self, gasto, dt):
        """Gasta `gasto` % y suma la recarga de este cuadro. En la base se recarga
        sola; junto a una batería, la recarga sale de esa batería (le quita
        COMPANERO_BATERIA_COSTO segundos de energía por segundo). Avisa al 20 % y al 0 %."""
        c = self.companero
        donde = self.recargando_companero()
        if donde == "base":
            gasto -= COMPANERO_RECARGA_BASE * dt
        elif donde == "bateria":
            b = self.bateria_cercana()
            gasto -= COMPANERO_RECARGA_BATERIA * dt
            self.baterias[b] = max(0.0, self.baterias[b] - COMPANERO_BATERIA_COSTO * dt)
        antes = c.gastar(gasto)
        if antes > COMPANERO_AVISO_BAJA >= c.bateria > 0:
            self.mensaje = t("laylu_bateria_baja", p=COMPANERO_AVISO_BAJA)
        elif antes > 0 >= c.bateria:
            self.mensaje = t("laylu_sin_bateria")

    def clic_companero(self):
        """Clic en Laylu: con la pila en la mano, se la cambia; si no, abre su cofre."""
        if self.en_mano == "pila_laylu":
            self.cambiar_pila()
        else:
            self.abrir_cofre()

    def cambiar_pila(self):
        """Pila nueva: la batería de Laylu al 100 % y se gasta la pila (la usada no vuelve)."""
        if not self.companero_cerca():
            self.mensaje = t("acercate")
            return False
        if not self.tiene_objeto("pila_laylu"):
            return False
        self.gastar_objeto("pila_laylu")
        self.companero.bateria = 100.0
        self.mensaje = t("pila_cambiada")
        return True

    def lugar_actual(self):
        """Dónde está el astronauta: ("mapa", None), o la base y su cuarto."""
        return (self.escena, self.cuarto if self.escena == ESCENA_BASE else None)

    def companero_aqui(self):
        """True si Laylu está activa y en el mismo lugar que el astronauta (afuera,
        en el cuarto habitable o en el de cultivos)."""
        return self.companero.activo and self._comp_lugar == self.lugar_actual()

    def companero_junto_a_ti(self):
        """Pone al compañero en un lugar libre pegado al astronauta (detrás de él
        si se puede)."""
        c = self.companero
        atras = {"abajo": (0, -1), "arriba": (0, 1), "izquierda": (1, 0), "derecha": (-1, 0)}[self.jugador.direccion]
        vecinos = [atras, (1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (-1, 1), (1, -1), (-1, -1)]
        c._caminando = False
        if self.escena == ESCENA_BASE:
            x0, y0 = self.pos_base
            # A la distancia de seguir en la sala (proporcional, ver COMPANERO_FACTOR_BASE).
            lejos_x = lejos_y = round(COMPANERO_DISTANCIA * COMPANERO_FACTOR_BASE / 1.2)
            for dx, dy in vecinos + [(0, 0)]:
                x, y = x0 + dx * lejos_x, y0 + dy * lejos_y
                if self._libre_interior(x, y) or (dx, dy) == (0, 0):
                    c.pos_base = [x, y]
                    break
            c.cuerpo.direccion = self.jugador.direccion
            return
        j = self.jugador
        for radio in (2, 3, 1):                               # primero a ~2 cuadros, como cuando te sigue
            for dx, dy in vecinos:
                x, y = (j.x + dx * radio * TILE) % MAPA_ANCHO, (j.y + dy * radio * TILE) % MAPA_ALTO
                if not c.cuerpo.choca(self.mapa, x, y):
                    c.cuerpo.x, c.cuerpo.y = x, y
                    c._atorado = 0.0
                    return
        c.cuerpo.x, c.cuerpo.y = j.x, j.y                     # sin lugar: en el mismo sitio

    # ---- dónde está en la pantalla ----------------------------------------------------
    def _caja_companero_pantalla(self):
        """(x, y) de la esquina de su caja en la pantalla."""
        c = self.companero
        if self.escena == ESCENA_BASE:
            return int(c.pos_base[0]), int(c.pos_base[1])
        cam_x, cam_y = self.camara
        return (pos_pantalla(c.cuerpo.x, cam_x, MAPA_ANCHO, ANCHO / 2),
                pos_pantalla(c.cuerpo.y, cam_y, MAPA_ALTO, ALTO / 2))

    def _imagen_companero(self):
        c = self.companero
        lista = self.sprites_companero[c.dibujo]
        k = int(c.cuerpo.t_anim * COMPANERO_FPS) % len(lista) if c.cuerpo.camina else 0
        return lista[k]

    def rect_companero(self):
        """Rectángulo del dibujo del compañero en la pantalla (o None si no está)."""
        if not self.companero_aqui() or not self.sprites_companero:
            return None
        x, y = self._caja_companero_pantalla()
        img = self._imagen_companero()
        return img.get_rect(midbottom=(x + JUGADOR_TAM // 2, y + JUGADOR_TAM + 2))

    def companero_bajo_mouse(self, pos):
        rect = self.rect_companero()
        return rect is not None and rect.collidepoint(pos)

    def companero_cerca(self):
        """True si el astronauta está lo bastante cerca para abrir el cofre."""
        c = self.companero
        if self.escena == ESCENA_BASE:
            ax, ay = self.caja_interior().center
            bx, by = c.pos_base[0] + JUGADOR_TAM / 2, c.pos_base[1] + JUGADOR_TAM / 2
            return math.hypot(ax - bx, ay - by) <= ALCANCE_MUEBLE * 1.5
        ax, ay = self.jugador.centro
        bx, by = c.cuerpo.centro
        return math.hypot(distancia_corta(ax, bx, MAPA_ANCHO), distancia_corta(ay, by, MAPA_ALTO)) <= ALCANCE * TILE

    # ---- dibujo ------------------------------------------------------------------
    def dibujar_con_companero(self):
        """El astronauta y el compañero, primero el que está más arriba (así el de
        abajo queda encima). Sin compañero, solo el astronauta (como antes)."""
        if not self.companero_aqui() or not self.sprites_companero:
            self.dibujar_astronauta()
            return
        if self.escena == ESCENA_BASE:
            mio, suyo = self.pos_base[1], self.companero.pos_base[1]
        else:
            mio, suyo = 0.0, distancia_corta(self.companero.cuerpo.y, self.jugador.y, MAPA_ALTO)
        if suyo < mio:
            self.dibujar_companero()
            self.dibujar_astronauta()
        else:
            self.dibujar_astronauta()
            self.dibujar_companero()

    def dibujar_companero(self):
        """El robot (con su animación al caminar) y un cofre chiquito encima."""
        p = self.pantalla
        x, y = self._caja_companero_pantalla()
        sombra = self._sombra_astronauta
        p.blit(sombra, sombra.get_rect(center=(x + JUGADOR_TAM // 2, y + JUGADOR_TAM)))
        img = self._imagen_companero()
        r = img.get_rect(midbottom=(x + JUGADOR_TAM // 2, y + JUGADOR_TAM + 2))
        p.blit(img, r)
        cofre = pygame.Rect(0, 0, 18, 13)                       # el cofre, sobre su cabeza
        cofre.midbottom = (r.centerx, r.top + 4)
        pygame.draw.rect(p, (120, 74, 40), cofre, border_radius=2)
        pygame.draw.rect(p, (70, 40, 20), cofre, 1, border_radius=2)
        pygame.draw.line(p, (70, 40, 20), (cofre.x, cofre.y + 5), (cofre.right - 1, cofre.y + 5))
        pygame.draw.rect(p, (232, 198, 58), (cofre.centerx - 2, cofre.y + 4, 4, 4))   # cerradura
        self.dibujar_pila((cofre.centerx, cofre.top - 3), self.companero.bateria,   # su batería, encima
                          self.recargando_companero() is not None)

    def dibujar_pila(self, midbottom, bateria, cargando=False, grande=False):
        """Barrita de batería con forma de pila (contorno, punta y relleno). Además del
        color: con poca carga, un "!"; sin carga, una X; cargando, un rayito."""
        p = self.pantalla
        w, h = (30, 14) if grande else (24, 11)
        caja = pygame.Rect(0, 0, w, h)
        caja.midbottom = (round(midbottom[0]) - 1, round(midbottom[1]))
        punta = pygame.Rect(caja.right, caja.centery - h // 4, 2 if not grande else 3, h // 2)
        pygame.draw.rect(p, (18, 22, 30), caja.inflate(2, 2), border_radius=3)
        pygame.draw.rect(p, (18, 22, 30), punta.inflate(1, 1))
        pygame.draw.rect(p, (232, 236, 242), caja, 1, border_radius=2)
        pygame.draw.rect(p, (232, 236, 242), punta)
        color = (70, 200, 110) if bateria > 50 else ((236, 176, 60) if bateria > COMPANERO_AVISO_BAJA else (232, 92, 72))
        lleno = round((w - 4) * bateria / 100)
        if lleno > 0:
            pygame.draw.rect(p, color, (caja.x + 2, caja.y + 2, lleno, h - 4))
        if bateria <= 0:                                    # sin carga: X
            pygame.draw.line(p, (232, 92, 72), (caja.centerx - 4, caja.y + 2), (caja.centerx + 4, caja.bottom - 3), 2)
            pygame.draw.line(p, (232, 92, 72), (caja.centerx + 4, caja.y + 2), (caja.centerx - 4, caja.bottom - 3), 2)
        elif cargando:                                      # rayito blanco
            cx, cy = caja.centerx, caja.centery
            pygame.draw.polygon(p, (255, 255, 255), [(cx + 1, cy - h // 2 + 2), (cx - 3, cy + 1), (cx, cy + 1),
                                                     (cx - 1, cy + h // 2 - 2), (cx + 3, cy - 1), (cx, cy - 1)])
            pygame.draw.polygon(p, (18, 22, 30), [(cx + 1, cy - h // 2 + 2), (cx - 3, cy + 1), (cx, cy + 1),
                                                  (cx - 1, cy + h // 2 - 2), (cx + 3, cy - 1), (cx, cy - 1)], 1)
        elif bateria <= COMPANERO_AVISO_BAJA:               # poca carga: "!"
            pygame.draw.line(p, (255, 255, 255), (caja.centerx, caja.y + 2), (caja.centerx, caja.bottom - 5), 2)
            pygame.draw.rect(p, (255, 255, 255), (caja.centerx - 1, caja.bottom - 4, 2, 2))
        return caja

    def rect_bateria_hud(self):
        """Cajita discreta "Laylu + pila + %" encima del recuadro de la mano, o None."""
        if not self.companero.activo:
            return None
        return pygame.Rect(self.rect_mano.x, self.rect_mano.y - 30, 128, 24)

    def dibujar_bateria_hud(self):
        rect = self.rect_bateria_hud()
        if rect is None:
            return
        caja = pygame.Surface(rect.size, pygame.SRCALPHA)
        pygame.draw.rect(caja, (18, 22, 30, 190), caja.get_rect(), border_radius=6)
        self.pantalla.blit(caja, rect)
        bateria = self.companero.bateria
        nombre = self.fuente_mini.render(t("herr_companero"), True, (244, 246, 250))
        self.pantalla.blit(nombre, (rect.x + 8, rect.centery - nombre.get_height() // 2 + 1))
        x = rect.x + 14 + nombre.get_width()
        self.dibujar_pila((x + 12, rect.centery + 6), bateria, self.recargando_companero() is not None)
        texto = self.fuente_mini.render(f"{math.ceil(bateria)} %", True, (244, 246, 250))
        self.pantalla.blit(texto, (x + 30, rect.centery - texto.get_height() // 2 + 1))

    # ---- cofre ---------------------------------------------------------------------
    def abrir_cofre(self):
        """Clic en el compañero: abre su cofre si estás cerca."""
        if not self.companero_cerca():
            self.mensaje = t("acercate")
            return
        self.inventario_abierto = self.crafteo_abierto = False
        self.menu_base = "cofre"

    def meter_cofre(self, recurso, cantidad):
        n = min(cantidad, self.inventario[recurso], self.companero.espacio(recurso))
        if n <= 0:
            self.mensaje = t("cofre_lleno")
            return
        self.inventario[recurso] -= n
        self.companero.cofre[recurso] += n
        self.mensaje = t("cofre_metiste", n=n, recurso=t("recurso_" + recurso))

    def sacar_cofre(self, recurso, cantidad):
        n = self.inventario.agregar(recurso, min(cantidad, self.companero.cofre.get(recurso, 0)))
        if n <= 0:
            self.mensaje = self._mensaje_lleno(recurso)
            return
        self.companero.cofre[recurso] -= n
        self.mensaje = t("cofre_sacaste", n=n, recurso=t("recurso_" + recurso))

    def titulo_cofre(self):
        return t("cofre_titulo", usadas=sum(1 for x in self.companero.casillas() if x), total=COFRE_CASILLAS)

    def contenedor_abierto(self):
        """(casillas, meter, sacar) del almacén o del cofre, según el menú abierto."""
        if self.menu_base == "cofre":
            return self.companero.casillas(), self.meter_cofre, self.sacar_cofre
        return self.casillas_almacen(), self.meter_almacen, self.sacar_almacen
