"""El compañero robot (ronda 27): sigue al astronauta por el mapa y lleva un
cofre. Lógica pura: no usa pygame ni dibuja (eso está en juego_companero.py).

Para moverse usa el mismo "cuerpo" que el astronauta (jugador.Jugador): una
caja de colisión que choca con lo sólido, se desliza por las paredes y da la
vuelta al mapa. Rodea los obstáculos de forma simple: si no puede avanzar
derecho, prueba de lado; si sigue atorado un rato o quedó muy lejos, avisa
para que el juego lo ponga junto al astronauta.
"""

import math

from maquinas import RECURSOS
from config import (COFRE_CASILLAS, COFRE_PILA, COMPANERO_ARRANCA, COMPANERO_ATORADO,
                    COMPANERO_DISTANCIA, COMPANERO_FACTOR_BASE, COMPANERO_LEJOS, COMPANERO_VEL, JUGADOR_TAM, MAPA_ALTO, MAPA_ANCHO)
from mapa import distancia_corta
from jugador import Jugador

# Dirección del cuerpo (como el astronauta) -> nombre de los dibujos del compañero.
DIBUJO_DE = {"abajo": "frente", "arriba": "espaldas", "izquierda": "izquierda", "derecha": "derecha"}


class Companero:
    """Estado del compañero: si está activo, dónde está (afuera: su cuerpo; en la
    base: pos_base), hacia dónde mira y qué guarda su cofre."""

    def __init__(self):
        self.activo = False
        self.cuerpo = Jugador(0, 0)          # misma caja de colisión que el astronauta
        self.pos_base = [0.0, 0.0]           # dentro de la base (coordenadas de la sala)
        self.cofre = {r: 0 for r in RECURSOS}
        self._atorado = 0.0
        self._caminando = False              # True: va hacia el astronauta (hasta COMPANERO_DISTANCIA)
        self.bateria = 100.0                 # ronda 32: % de batería (sin carga se queda quieta)

    @property
    def dibujo(self):
        """Nombre de la dirección para los dibujos (frente, espaldas, izquierda, derecha)."""
        return DIBUJO_DE[self.cuerpo.direccion]

    def poner(self, x, y):
        """Lo activa con la esquina de su caja en (x, y) del mapa."""
        self.activo = True
        self.cuerpo.x, self.cuerpo.y = x % MAPA_ANCHO, y % MAPA_ALTO
        self.cuerpo.direccion = "abajo"
        self._atorado = 0.0

    # ---- seguir al astronauta afuera ----------------------------------------
    def _quieto(self, dist, parar, arrancar):
        """True si se queda quieto: ya llegó a `parar`, o está parado y el
        astronauta no se ha alejado más de `arrancar` (histéresis)."""
        if self._caminando and dist <= parar:
            self._caminando = False
        elif not self._caminando and dist > arrancar:
            self._caminando = True
        return not self._caminando

    def seguir(self, objetivo, mapa, dt):
        """Camina hacia `objetivo` (centro del astronauta) cuando está a más de
        COMPANERO_ARRANCA y se detiene a COMPANERO_DISTANCIA. Devuelve "lejos" o
        "atorado" si hay que ponerlo junto al astronauta; si no, None."""
        cx, cy = self.cuerpo.centro
        dx = distancia_corta(objetivo[0], cx, MAPA_ANCHO)      # por el camino corto (el mapa da la vuelta)
        dy = distancia_corta(objetivo[1], cy, MAPA_ALTO)
        dist = math.hypot(dx, dy)
        if dist > COMPANERO_LEJOS:
            return "lejos"
        if self._quieto(dist, COMPANERO_DISTANCIA, COMPANERO_ARRANCA) or dt <= 0:
            self.cuerpo.animar(0, 0, dt)
            self._atorado = 0.0
            return None
        paso = min(COMPANERO_VEL * dt, dist - COMPANERO_DISTANCIA + 1)
        ux, uy = dx / dist, dy / dist
        antes = (self.cuerpo.x, self.cuerpo.y)
        self.cuerpo.mover(ux * paso, uy * paso, mapa)
        if self._avance(antes) < paso * 0.3:                    # bloqueado: probar de lado
            if abs(ux) >= abs(uy):
                self.cuerpo.mover(0, math.copysign(paso, uy if uy else 1), mapa)
            else:
                self.cuerpo.mover(math.copysign(paso, ux if ux else 1), 0, mapa)
        self.cuerpo.animar(ux, uy, dt)
        # Atorado = no se acerca (aunque tiemble contra una pared, eso no cuenta).
        nx, ny = self.cuerpo.centro
        acerco = dist - math.hypot(distancia_corta(objetivo[0], nx, MAPA_ANCHO),
                                   distancia_corta(objetivo[1], ny, MAPA_ALTO))
        if acerco < paso * 0.2:
            self._atorado += dt
            if self._atorado >= COMPANERO_ATORADO:
                return "atorado"
        else:
            self._atorado = 0.0
        return None

    def _avance(self, antes):
        return math.hypot(distancia_corta(self.cuerpo.x, antes[0], MAPA_ANCHO),
                          distancia_corta(self.cuerpo.y, antes[1], MAPA_ALTO))

    # ---- dentro de la base ---------------------------------------------------
    def seguir_interior(self, objetivo, libre, dt):
        """Igual que seguir(), en la sala de la base. libre(x, y) dice si su caja
        cabe ahí (dentro del piso y sin muebles). Cada eje por separado."""
        cx, cy = self.pos_base[0] + JUGADOR_TAM / 2, self.pos_base[1] + JUGADOR_TAM / 2
        dx, dy = objetivo[0] - cx, objetivo[1] - cy
        dist = math.hypot(dx, dy)
        parar = COMPANERO_DISTANCIA * COMPANERO_FACTOR_BASE
        if self._quieto(dist, parar, COMPANERO_ARRANCA * COMPANERO_FACTOR_BASE) or dt <= 0:
            self.cuerpo.animar(0, 0, dt)
            return
        paso = min(COMPANERO_VEL * dt, dist - parar + 1)
        ux, uy = dx / dist, dy / dist
        for eje, d in ((0, ux * paso), (1, uy * paso)):
            nuevo = list(self.pos_base)
            nuevo[eje] += d
            if libre(*nuevo):
                self.pos_base = nuevo
        self.cuerpo.animar(ux, uy, dt)

    # ---- cofre -----------------------------------------------------------------
    def casillas(self):
        """Las COFRE_CASILLAS del cofre: (recurso, cantidad) o None."""
        lista = []
        for recurso in RECURSOS:
            n = self.cofre.get(recurso, 0)
            while n > 0:
                lista.append((recurso, min(n, COFRE_PILA)))
                n -= COFRE_PILA
        return (lista + [None] * COFRE_CASILLAS)[:COFRE_CASILLAS]

    def espacio(self, recurso):
        """Cuántas unidades más de ese recurso caben."""
        usadas = sum(math.ceil(n / COFRE_PILA) for n in self.cofre.values() if n > 0)
        n = self.cofre.get(recurso, 0)
        suelto = (COFRE_PILA - n % COFRE_PILA) if n % COFRE_PILA else 0
        return max(0, COFRE_CASILLAS - usadas) * COFRE_PILA + suelto

    @property
    def sin_carga(self):
        return self.bateria <= 0

    def gastar(self, porcentaje):
        """Baja (o sube, si es negativo) la batería, entre 0 y 100. Devuelve la de antes."""
        antes = self.bateria
        self.bateria = max(0.0, min(100.0, self.bateria - porcentaje))
        return antes

    @property
    def vacio(self):
        return not any(self.cofre.values())

    # ---- partida guardada --------------------------------------------------------
    def a_dict(self):
        return {"activo": self.activo, "x": self.cuerpo.x, "y": self.cuerpo.y,
                "direccion": self.cuerpo.direccion, "pos_base": list(self.pos_base),
                "cofre": {r: n for r, n in self.cofre.items() if n}, "bateria": round(self.bateria, 3)}

    def de_dict(self, d):
        """Carga lo guardado (lo que falte se queda como está)."""
        self.activo = bool(d.get("activo", False))
        self.cuerpo.x = float(d.get("x", 0.0)) % MAPA_ANCHO
        self.cuerpo.y = float(d.get("y", 0.0)) % MAPA_ALTO
        if d.get("direccion") in DIBUJO_DE:
            self.cuerpo.direccion = d["direccion"]
        self.pos_base = [float(v) for v in d.get("pos_base", [0.0, 0.0])]
        self.cofre = {r: int(d.get("cofre", {}).get(r, 0)) for r in RECURSOS}
        self.bateria = max(0.0, min(100.0, float(d.get("bateria", 100.0))))   # partidas viejas: llena
