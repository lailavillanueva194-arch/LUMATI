"""Cinemáticas del juego.

- Final (ronda 26): al despegar desde Marte se ve la animación de assets/cinematica/
  y después la pantalla final con las estadísticas.
- Luna -> Marte (ronda 31): en la pantalla final de la Luna, al elegir la siguiente
  misión (tecla M), se ve el viaje de assets/cinematica_luna_marte/ (despegue de la
  Luna, el viaje entre las estrellas y la llegada a Marte) y luego empieza la partida
  en Marte, como antes. Va ahí y no al despegar: muestra la llegada a Marte, que solo
  tiene sentido cuando de verdad se va a Marte (después de ver los resultados de la Luna).
- Demostración (ronda 31): F7, o "Ver cinemáticas" en la pausa, reproduce las dos
  seguidas sin jugar y vuelve al juego tal como estaba (no cambia la partida).

Espacio, Enter o un clic saltan la que se está viendo; Esc la pausa. Si faltan los
PNG de una cinemática, todo sigue como antes (sin ella).
"""

import cinematica
from textos import t
from config import (ALTO, ANCHO, CINE_CARPETA, CINE_FPS, CINE_FUNDIDO, CINE_LM_CARPETA, CINE_LM_FPS,
                    CINE_LM_SOSTENER, ESCENAS_FINAL, MARTE)


class CinematicaMixin:
    """Cinemáticas: empezarlas, avanzarlas, saltarlas, dibujarlas y qué pasa al terminar."""

    # ---- cargar ----------------------------------------------------------------
    def _cine_marte(self):
        """La cinemática final (salir de Marte), o None si faltan los PNG."""
        if self._cuadros_cine is None:                  # se cargan la primera vez
            self._cuadros_cine = cinematica.cargar(CINE_CARPETA)
        if not self._cuadros_cine:
            return None
        return cinematica.Cinematica(self._cuadros_cine, (ANCHO, ALTO), CINE_FPS, CINE_FUNDIDO)

    def _cine_luna_marte(self):
        """El viaje de la Luna a Marte, o None si faltan los PNG."""
        if self.__dict__.get("_cuadros_lm") is None:
            self._cuadros_lm = cinematica.cargar_con_nombres(CINE_LM_CARPETA, ("lm",))
        if not self._cuadros_lm:
            return None
        nombres = [n for n, _ in self._cuadros_lm]
        return cinematica.Cinematica([img for _, img in self._cuadros_lm], (ANCHO, ALTO), CINE_LM_FPS,
                                     CINE_FUNDIDO, cinematica.duraciones(nombres, CINE_LM_FPS, CINE_LM_SOSTENER))

    # ---- empezar -----------------------------------------------------------------
    def iniciar_cinematica(self):
        """Cinemática final al salir de Marte. Devuelve False si no hay PNG (entonces
        sigue el final de siempre)."""
        self.cinematica = self._cine_marte()
        self._cine_fin = None                            # al terminar: las estadísticas
        return self.cinematica is not None

    def iniciar_cinematica_luna_marte(self):
        """Viaje Luna -> Marte (tecla M en el final de la Luna); al terminar empieza
        Marte. Devuelve False si no hay PNG (entonces Marte empieza directo)."""
        self.cinematica = self._cine_luna_marte()
        self._cine_fin = lambda: self.nueva_partida(MARTE)
        return self.cinematica is not None

    def ver_cinematicas(self):
        """Demostración para el jurado: Luna -> Marte y la final de Marte, una tras
        otra, sin jugar. Al terminar se vuelve al juego como estaba (solo cambia lo
        que se ve: la partida no se toca)."""
        cola = [c for c in (self._cine_luna_marte(), self._cine_marte()) if c is not None]
        if not cola:
            self.mensaje = t("cines_no_hay")
            return False

        def siguiente():
            self.cinematica = cola.pop(0) if cola else None
            self._cine_fin = siguiente if self.cinematica is not None else None

        siguiente()
        return True

    # ---- avanzar, saltar, terminar -------------------------------------------------
    def actualizar_cinematica(self, dt):
        if self.cinematica.actualizar(dt):
            self.terminar_cinematica()

    def saltar_cinematica(self):
        """Espacio, Enter o clic: se salta la que se está viendo."""
        if self.cinematica is not None:
            self.terminar_cinematica()

    def terminar_cinematica(self):
        """Fin (o salto) de la cinemática. Sin otra indicación (la final de Marte):
        directo a la pantalla de estadísticas."""
        fin = self.__dict__.get("_cine_fin")
        self.cinematica = None
        self._cine_fin = None
        if fin is not None:
            fin()
        else:
            self.escena_final = ESCENAS_FINAL

    def dibujar_cinematica(self):
        aviso = self.fuente_chica.render(t("cine_saltar"), True, (150, 150, 160))
        self.cinematica.dibujar(self.pantalla, aviso)
