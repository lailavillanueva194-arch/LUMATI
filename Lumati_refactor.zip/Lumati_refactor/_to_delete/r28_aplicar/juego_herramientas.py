"""Mouse y herramientas: qué hay bajo el mouse, usar lo que se lleva en la
mano, objetos fabricados, acceso rápido, Fabricador, pico, taladros, construir y quitar
máquinas, la nave y la protección contra la radiación.
"""

import math

import pygame

import maquinas
from energia import vecinos
from maquinas import (COMIDA_POR_UNIDAD, LIMITE_INVENTARIO, LLENO, Maquina, OXIGENO_POR_UNIDAD,
                      PRODUCIENDO, SIN_ENERGIA, SIN_ENTRADA, SIN_TANQUE, TANQUE_LLENO, TANQUE_MAX,
                      Taladro, Tanque)
from supervivencia import COMIDA, COMIDA_MAX, OXIGENO, OXIGENO_MAX
from textos import t
from config import (ALCANCE, ALTO, ANCHO, ANTENA, BASE, BATERIA, BLINDAJE_BASE, BLINDAJE_MAX,
                    BLINDAJE_POR_BLOQUE, BLOQUE, CAMINO, CICLO_PICO, COLUMNAS, COSTO_FABRICAR,
                    CRAFTEO, DATO_SEGUNDOS, ESCENAS_FINAL, ESCENA_BASE, FABRICA_CANTIDAD, FILAS,
                    INVERNADERO, MAPA_ALTO, MAPA_ANCHO, MAQUINAS, MARTE, NAVE, NAVE_LADO, NAVE_POS,
                    OBJETO_TIPO, PICADO, RAPIDA_CASILLA, RAPIDA_MARGEN, RAPIDA_N, RAPIDA_SEP,
                    RIEGO_SEGUNDOS, SUELO, TALADRO, TANQUE, TANQUE_AGUA, TILE, TIPO_OBJETO)
from mapa import distancia_corta


class HerramientasMixin:
    """Mouse y herramientas: qué hay bajo el mouse, usar lo que se lleva en la
    mano, objetos fabricados, acceso rápido, Fabricador, pico, taladros, construir y quitar
    máquinas, la nave y la protección contra la radiación."""

    # -- mouse y herramientas ---------------------------------------------
    def cuadro_bajo_mouse(self, pos):
        """(fila, columna) del cuadro del mapa bajo la posición de pantalla,
        o None si el mouse está sobre la interfaz (barra, inventario o mensaje).
        Los índices salen envueltos."""
        if any(r.collidepoint(pos) for r in self.rects_interfaz()):
            return None
        cx, cy = self.camara
        mundo_x = cx + (pos[0] - ANCHO / 2)
        mundo_y = cy + (pos[1] - ALTO / 2)
        return int(mundo_y // TILE) % FILAS, int(mundo_x // TILE) % COLUMNAS

    def _cuadro_de_la_nave(self, pos):
        """El cuadro de la nave más cercano a una posición de pantalla (aunque sea
        sobre la parte que sobresale por arriba o por los lados)."""
        cx, cy = self.camara
        fila = int((cy + (pos[1] - ALTO / 2)) // TILE) % FILAS
        col = int((cx + (pos[0] - ANCHO / 2)) // TILE) % COLUMNAS
        f0, c0 = NAVE_POS
        df = min(max(int(distancia_corta(fila, f0, FILAS)), 0), NAVE_LADO - 1)
        dc = min(max(int(distancia_corta(col, c0, COLUMNAS)), 0), NAVE_LADO - 1)
        return (f0 + df) % FILAS, (c0 + dc) % COLUMNAS

    def al_alcance(self, fila, col):
        """True si el centro del cuadro está a ALCANCE cuadros o menos del
        centro del jugador (distancia euclidiana: sqrt(dx^2 + dy^2)),
        midiendo por el camino corto aunque cruce el borde del mapa."""
        jx, jy = self.jugador.centro
        dx = distancia_corta(col * TILE + TILE / 2, jx, MAPA_ANCHO)
        dy = distancia_corta(fila * TILE + TILE / 2, jy, MAPA_ALTO)
        return dx * dx + dy * dy <= (ALCANCE * TILE) ** 2

    def usar_herramienta(self, fila, col):
        """Clic en un cuadro del mapa. El Fabricador, la nave, las máquinas y
        los taladros se usan lleves lo que lleves; en el resto se coloca (o se
        quita) lo que está en la mano. (El nombre viene de cuando había barra.)"""
        if not self.al_alcance(fila, col):
            self.mensaje = t("muy_lejos")
            return
        tipo = self.mapa[fila][col]
        if tipo == CRAFTEO:                 # abrir el menú del Fabricador
            self.abrir_crafteo()
            return
        if tipo == BASE:                    # entrar a la base
            self.entrar_base()
            return
        if tipo == NAVE:
            self.usar_nave()
            return
        if tipo in MAQUINAS:
            self.usar_maquina(fila, col)
            return
        if tipo == TALADRO:                 # recoger lo que sacó
            self.vaciar_taladro(fila, col)
            return
        if tipo == TANQUE_AGUA:             # guardar o sacar agua
            self.usar_tanque_agua(fila, col)
            return
        if tipo == BATERIA:                 # ver cuánta carga tiene
            self.mensaje = self._texto_bateria(fila, col)
            return
        if tipo == ANTENA:                  # ver si hay contacto
            self.mensaje = t("antena_info_on" if self.tiene_energia(fila, col) else "antena_info_off")
            return
        objeto = self.en_mano
        if self.alturas[fila][col] and objeto not in (None, "regadera"):
            self.mensaje = t("montana_no")          # en la montaña no se construye
            return
        if objeto is None:
            self.mensaje = t("mano_vacia")
        elif objeto == "cable":
            self.usar_cable(fila, col)
        elif objeto == "taladro":
            self.usar_taladro(fila, col)
        elif objeto == "generador":
            self.usar_generador(fila, col)
        elif objeto == "pico":              # el pico cambia el suelo: picado, camino o liso
            self.usar_pico(fila, col)
        elif objeto == "regadera":          # la regadera no se coloca: solo riega invernaderos
            self.mensaje = t("regadera_uso")
        elif objeto == "companero":         # el compañero se activa ahí (ronda 27)
            self.colocar_companero(fila, col)
        else:
            self.construir(fila, col, OBJETO_TIPO[objeto], objeto)

    # -- objetos fabricados: lo que hay en el inventario y en la mano ---------
    def tiene_objeto(self, objeto):
        """True si queda al menos uno; si no, avisa que hay que fabricarlo."""
        if self.es_demo or self.objetos[objeto] > 0:      # demo (ronda 28): no se acaba
            return True
        self.mensaje = t("no_tienes", nombre=t("herr_" + objeto))
        return False

    def devolver_objeto(self, objeto):
        """Algo que se quitó del mapa vuelve al inventario de objetos (en la demo
        no cambia: ya es ilimitado)."""
        if not self.es_demo:
            self.objetos[objeto] += 1

    def gastar_objeto(self, objeto):
        """Colocar algo gasta una unidad (en la demo, nada: ronda 28)."""
        if not self.es_demo:
            self.objetos[objeto] -= 1

    def elegir_en_mano(self, objeto):
        """Pone un objeto en la mano; si ya estaba, lo guarda (mano vacía)."""
        if self.en_mano == objeto:
            self.en_mano = None
            self.mensaje = t("mano_guardada")
        else:
            self.en_mano = objeto
            self.mensaje = t("a_la_mano", nombre=t("herr_" + objeto))

    # -- acceso rápido (5 casillas, teclas 1 a 5) ----------------------------
    def rect_rapida_casilla(self, i):
        r = self.rect_rapida
        return pygame.Rect(r.x + RAPIDA_MARGEN + i * (RAPIDA_CASILLA + RAPIDA_SEP),
                           r.y + RAPIDA_MARGEN, RAPIDA_CASILLA, RAPIDA_CASILLA)

    def rapida_bajo_mouse(self, pos):
        for i in range(RAPIDA_N):
            if self.rect_rapida_casilla(i).collidepoint(pos):
                return i
        return None

    def usar_rapida(self, i):
        """Tecla o clic en la casilla i: lleva su objeto a la mano (o lo guarda
        si ya estaba en la mano)."""
        objeto = self.rapida[i]
        if objeto is None:
            self.mensaje = t("rapida_vacia", n=i + 1)
        else:
            self.elegir_en_mano(objeto)

    def asignar_rapida(self, i, objeto):
        """Pone un objeto en la casilla i. Si ya estaba en otra, se intercambian
        (un objeto nunca ocupa dos casillas)."""
        if objeto in self.rapida:
            j = self.rapida.index(objeto)
            self.rapida[j] = self.rapida[i]
        self.rapida[i] = objeto
        self.mensaje = t("rapida_asignada", nombre=t("herr_" + objeto), n=i + 1)

    def abrir_crafteo(self):
        self.crafteo_abierto = True
        self.inventario_abierto = False
        self.casilla_elegida = None

    def fabricar(self, objeto):
        """Fabrica un objeto en el Fabricador: paga su costo con los recursos del
        inventario y el objeto (o el tramo de cable) se guarda en los objetos."""
        costo = COSTO_FABRICAR[objeto]
        n = FABRICA_CANTIDAD.get(objeto, 1)
        if self.es_demo:                     # demo (ronda 28): no gasta recursos (ya es ilimitado)
            self.mensaje = t("demo_fabricado", nombre=t("herr_" + objeto))
        else:
            falta = self.inventario.faltante(costo)
            if falta:
                self.mensaje = t("fabricar_faltan", nombre=t("herr_" + objeto), lista=self._lista(falta))
                return False
            self.inventario.pagar(costo)
            self.objetos[objeto] += n
            self.mensaje = t("fabricado", n=n, nombre=t("herr_" + objeto))
        if objeto not in self.rapida and None in self.rapida:   # lo nuevo entra solo al acceso rápido
            self.rapida[self.rapida.index(None)] = objeto
        return True

    def usar_pico(self, fila, col):
        """Pico: suelo liso -> picado (ahí se pone un taladro) -> camino -> liso.
        Solo cambia el suelo libre; no toca cables, máquinas ni la base."""
        tipo = self.mapa[fila][col]
        if tipo not in CICLO_PICO:
            self.mensaje = t("pico_nada")
            return
        nuevo = CICLO_PICO[tipo]
        self.mapa[fila][col] = nuevo
        self.mensaje = t({PICADO: "pico_picado", CAMINO: "pico_camino", SUELO: "pico_suelo"}[nuevo])

    def usar_taladro(self, fila, col):
        """Con la herramienta Taladro: clic en suelo libre pone un taladro (de
        nivel 1) que extrae lo que haya bajo ese cuadro; clic sobre un taladro
        vacía su almacén al inventario. No se pone sobre rocas ni cables, ni
        encima del astronauta (se quedaría atrapado en un cuadro sólido)."""
        tipo = self.mapa[fila][col]
        if tipo == TALADRO:
            self.vaciar_taladro(fila, col)
            return
        if tipo != PICADO:                        # supervivencia: primero se pica el suelo
            self.mensaje = t("taladro_pica" if tipo in (SUELO, CAMINO) else "solo_suelo")
            return
        if not self.tiene_objeto("taladro"):
            return
        self.mapa[fila][col] = TALADRO
        if self.jugador.choca(self.mapa, self.jugador.x, self.jugador.y):
            self.mapa[fila][col] = PICADO         # deshacer: estorba el astronauta
            self.mensaje = t("taladro_no_cabe")
            return
        self.gastar_objeto("taladro")
        taladro = Taladro(self._azar_botin)
        self.taladros[(fila, col)] = taladro
        if taladro.estado(self.tiene_energia(fila, col)) == SIN_ENERGIA:
            self.mensaje = t("taladro_sin_energia")
        else:
            self.mensaje = t("taladro_puesto", lista=self._nombres(taladro.botin))
        if self.hielo_de_crater(taladro, fila, col):
            self.mensaje = t("taladro_crater")

    # -- construcciones nuevas: bloques y cadena del agua --------------------
    def construir(self, fila, col, tipo, nombre):
        """Con un bloque o una máquina en la mano: clic en suelo libre la coloca
        (gasta una unidad; ya se pagó al fabricarla). Clic sobre un bloque con
        un bloque en la mano lo quita (las máquinas se quitan con X)."""
        actual = self.mapa[fila][col]
        if actual == BLOQUE and tipo == BLOQUE:
            self.quitar_construccion(fila, col)
            return
        if actual != SUELO:
            self.mensaje = t("solo_suelo")
            return
        if not self.tiene_objeto(nombre):
            return
        self.mapa[fila][col] = tipo
        if self.jugador.choca(self.mapa, self.jugador.x, self.jugador.y):
            self.mapa[fila][col] = SUELO          # deshacer: estorba el astronauta
            self.mensaje = t("no_cabe")
            return
        self.gastar_objeto(nombre)
        if tipo in MAQUINAS:
            if tipo == TANQUE:
                self.maquinas[(fila, col)] = Tanque()
            elif tipo == INVERNADERO:
                cultivo = maquinas.CULTIVOS[self._sembrados % len(maquinas.CULTIVOS)]
                self._sembrados += 1
                self.maquinas[(fila, col)] = Maquina(nombre, cultivo)
            else:
                self.maquinas[(fila, col)] = Maquina(nombre)
            self._energia_sucia = True
        if tipo == ANTENA:
            self.antenas.add((fila, col))
        if tipo == BATERIA:
            self.baterias[(fila, col)] = 0.0
            self._energia_sucia = True
        if tipo == TANQUE_AGUA:
            self.tanques_agua[(fila, col)] = 0
        self.mensaje = t("construido", nombre=t("herr_" + nombre))
        if tipo == INVERNADERO:
            self.mensaje = t("sembrado", cultivo=t("cultivo_" + self.maquinas[(fila, col)].cultivo))
            self.mostrar_dato("tomate_iss")

    def quitar_construccion(self, fila, col):
        """Quita un bloque o una máquina vacía y la regresa al inventario de
        objetos (dificultad fácil: no se pierde nada). Una máquina con algo
        dentro no se quita, para no perderlo."""
        tipo = self.mapa[fila][col]
        nombre = TIPO_OBJETO.get(tipo, maquinas.BLOQUE)
        maquina = self.maquinas.get((fila, col))
        if (maquina is not None and not maquina.vacia) or self.tanques_agua.get((fila, col)):
            self.mensaje = t("vacia_maquina")
            return
        self.tanques_agua.pop((fila, col), None)
        self.devolver_objeto(nombre)
        self.maquinas.pop((fila, col), None)
        self.antenas.discard((fila, col))
        self.baterias.pop((fila, col), None)
        self.mapa[fila][col] = SUELO
        self._energia_sucia = True
        self.mensaje = t("objeto_guardado", nombre=t("herr_" + nombre))

    def tanque_de(self, fila, col):
        """El tanque pegado (arriba, abajo, izquierda o derecha) a la máquina en
        (fila, col), o None. Si hay varios, el primero que no esté lleno."""
        tanques = [self.maquinas[v] for v in vecinos(fila, col, FILAS, COLUMNAS)
                   if self.mapa[v[0]][v[1]] == TANQUE]
        libres = [tq for tq in tanques if not tq.lleno]
        return (libres or tanques or [None])[0]

    def estado_maquina(self, fila, col):
        maquina = self.maquinas[(fila, col)]
        return maquina.estado(self.tiene_energia(fila, col), self.tanque_de(fila, col))

    def usar_maquina(self, fila, col):
        """Clic en una máquina (con cualquier herramienta): recoge lo que haya
        producido y le mete su ingrediente desde el inventario. El oxígeno y la
        comida van directo a sus barras; el agua va al inventario."""
        maquina = self.maquinas[(fila, col)]
        if isinstance(maquina, Tanque):
            clave = "tanque_info_lleno" if maquina.lleno else "tanque_info"
            self.mensaje = t(clave, h=maquina.hidrogeno, max=TANQUE_MAX)
            return
        partes = []
        salida = maquina.recurso_salida
        if maquina.salida:
            if salida == "agua":
                n = maquina.retirar(self.inventario.espacio("agua"))
                self.inventario.agregar("agua", n)
                texto = t("recogiste", n=n, recurso=t("recurso_agua")) if n else \
                    self._mensaje_lleno("agua")
            else:
                barra, por_unidad, maximo = ((OXIGENO, OXIGENO_POR_UNIDAD, OXIGENO_MAX)
                                             if salida == "oxigeno" else
                                             (COMIDA, COMIDA_POR_UNIDAD, COMIDA_MAX))
                hueco = maximo - self.astronauta.valor(barra)
                n = maquina.retirar(math.ceil(hueco / por_unidad - 1e-9)) if hueco > 0 else 0
                if n:
                    self.astronauta.agregar(barra, n * por_unidad)
                    texto = t("barra_subio", barra=t("barra_" + barra), n=int(n * por_unidad))
                    if maquina.cultivo:
                        texto = t("cosecha", cultivo=t("cultivo_" + maquina.cultivo)) + " · " + texto
                else:
                    texto = t("barra_llena", barra=t("barra_" + barra))
                if n and salida == "comida":
                    self.mostrar_dato("tomate_raices")
            partes.append(texto)
        entrada = maquina.recurso_entrada
        if maquina.tipo == maquinas.INVERNADERO and self.en_mano != "regadera":
            # Supervivencia: las plantas se riegan con la regadera en la mano.
            partes.append(t("regadera_necesaria"))
            self.mensaje = " · ".join(partes)
            return
        n = maquina.depositar(self.inventario[entrada])
        if n:
            self.inventario[entrada] -= n
            if maquina.tipo == maquinas.INVERNADERO:
                self._riegos[(fila, col)] = RIEGO_SEGUNDOS
            partes.append(t("regaste", n=n) if maquina.tipo == maquinas.INVERNADERO else
                          t("depositaste", n=n, recurso=t("recurso_" + entrada)))
        elif maquina.tipo == maquinas.INVERNADERO and not self.inventario[entrada]:
            partes.append(t("regadera_sin_agua"))
        if not partes:
            partes.append(f"{t('herr_' + maquina.tipo)}: {self._texto_estado(fila, col)}")
        self.mensaje = " · ".join(partes)

    def _texto_estado(self, fila, col):
        """Texto corto del estado de una máquina nueva ("Falta Hielo", "Sin energía"...)."""
        maquina = self.maquinas[(fila, col)]
        estado = self.estado_maquina(fila, col)
        if estado == SIN_ENTRADA:
            return t("falta", recurso=t("recurso_" + maquina.recurso_entrada))
        return t({LLENO: "listo_recoger", SIN_TANQUE: "sin_tanque", TANQUE_LLENO: "tanque_lleno",
                  SIN_ENERGIA: "sin_energia", PRODUCIENDO: "produciendo"}[estado])

    def usar_nave(self):
        """Clic en la nave: si algún tanque de hidrógeno está lleno, despega y
        empieza el final. Si no, dice cuánto falta."""
        tanques = [m for m in self.maquinas.values() if isinstance(m, Tanque)]
        if any(tq.lleno for tq in tanques):
            self.escena_final = 0
            self.mensaje = ""
            if self.destino == MARTE:        # al salir de Marte: la cinemática final (si están los PNG)
                self.iniciar_cinematica()
            return
        mejor = max((tq.hidrogeno for tq in tanques), default=0)
        self.mensaje = t("nave_falta", h=mejor, max=TANQUE_MAX)

    def avanzar_final(self):
        """Clic o Espacio en el final: siguiente imagen (la última es la comparación).
        Durante la cinemática, la salta."""
        if self.cinematica is not None:
            self.terminar_cinematica()
            return
        self.escena_final = min(ESCENAS_FINAL, self.escena_final + 1)

    def mostrar_dato(self, id_dato, repetir=False):
        """Muestra un dato real (con etiqueta y fuente) la primera vez. Con
        repetir=True sale cada vez (eventos raros de Marte)."""
        if id_dato in self._datos_vistos and not repetir:
            return
        self._datos_vistos.add(id_dato)
        self.dato = [id_dato, DATO_SEGUNDOS]

    def proteccion(self):
        """(en_base, blindaje) según el cuadro donde está el centro del astronauta:
        en la base protege BLINDAJE_BASE; cada bloque de regolito en los 8
        cuadros de alrededor suma BLINDAJE_POR_BLOQUE (con módulo en los bordes)."""
        if self.escena == ESCENA_BASE:          # dentro de la base: igual que en su piso
            return True, BLINDAJE_BASE
        cx, cy = self.jugador.centro
        f, c = int(cy // TILE) % FILAS, int(cx // TILE) % COLUMNAS
        en_base = self.mapa[f][c] == BASE
        bloques = sum(self.mapa[(f + df) % FILAS][(c + dc) % COLUMNAS] == BLOQUE
                      for df in (-1, 0, 1) for dc in (-1, 0, 1) if df or dc)
        blindaje = (BLINDAJE_BASE if en_base else 0.0) + bloques * BLINDAJE_POR_BLOQUE
        return en_base, min(BLINDAJE_MAX, blindaje)

    @staticmethod
    def _nombres(recursos):
        return ", ".join(t("recurso_" + r) for r in recursos)

    @staticmethod
    def _lista(costo):
        return ", ".join(f"{n} {t('recurso_' + r)}" for r, n in costo.items())

    def _mensaje_lleno(self, recurso):
        """Por qué no cabe más de `recurso`: el máximo de las manos (hielo) o las
        21 casillas llenas."""
        nombre = t("recurso_" + recurso)
        limite = LIMITE_INVENTARIO.get(recurso)
        if limite is not None and self.inventario[recurso] >= limite:
            return t("manos_llenas", max=limite, recurso=nombre)
        return t("inventario_lleno", recurso=nombre)

    def vaciar_taladro(self, fila, col):
        """Pasa lo que sacó el taladro al inventario, unidad por unidad. Lo que
        no cabe (inventario lleno o máximo de hielo en las manos) se queda en el
        taladro."""
        taladro = self.taladros[(fila, col)]
        if taladro.cantidad == 0:
            self.mensaje = t("almacen_vacio")
            return
        primero = taladro.almacen[0]
        sacado = taladro.retirar(lambda recurso: self.inventario.agregar(recurso, 1) == 1)
        if not sacado:
            self.mensaje = self._mensaje_lleno(primero)
            return
        lista = self._lista(sacado)
        if taladro.cantidad:
            self.mensaje = t("recogiste_varios_quedan", lista=lista, quedan=taladro.cantidad)
        else:
            self.mensaje = t("recogiste_varios", lista=lista)

    def mejorar_taladro(self, fila, col):
        """Sube el taladro un nivel si el inventario alcanza para el costo."""
        taladro = self.taladros[(fila, col)]
        costo = taladro.costo_mejora
        if costo is None:
            self.mensaje = t("nivel_maximo")
            return
        falta = {} if self.es_demo else self.inventario.faltante(costo)   # demo: mejorar es gratis
        if falta:
            lista = ", ".join(f"{n} {t('recurso_' + r)}" for r, n in falta.items())
            self.mensaje = t("faltan", n=taladro.nivel + 1, lista=lista)
            return
        antes = set(taladro.botin)
        if not self.es_demo:
            self.inventario.pagar(costo)
        taladro.mejorar()
        nuevos = [r for r in taladro.botin if r not in antes]
        self.mensaje = t("mejorado_botin", n=taladro.nivel, lista=self._nombres(nuevos))

    def retirar_taladro(self, fila, col):
        """Quita el taladro (la veta de abajo sigue ahí). Hay que vaciarlo antes
        para no perder lo que tenga guardado."""
        if self.taladros[(fila, col)].cantidad:
            self.mensaje = t("vacia_primero")
            return
        del self.taladros[(fila, col)]
        self.mapa[fila][col] = PICADO             # el hoyo queda: se puede volver a poner otro
        self.devolver_objeto("taladro")
        self.mensaje = t("objeto_guardado", nombre=t("herr_taladro"))

    def maquina_bajo_mouse(self):
        """(fila, col) del taladro o máquina bajo el mouse y al alcance, o None (con aviso)."""
        cuadro = self.cuadro_bajo_mouse(pygame.mouse.get_pos())
        if cuadro is None or self.mapa[cuadro[0]][cuadro[1]] not in (TALADRO, ANTENA, *MAQUINAS):
            self.mensaje = t("no_hay_maquina")
            return None
        if not self.al_alcance(*cuadro):
            self.mensaje = t("muy_lejos")
            return None
        return cuadro

    def taladro_bajo_mouse(self):
        """(fila, col) del taladro bajo el mouse y al alcance, o None (con aviso)."""
        cuadro = self.cuadro_bajo_mouse(pygame.mouse.get_pos())
        if cuadro is None or self.mapa[cuadro[0]][cuadro[1]] != TALADRO:
            self.mensaje = t("no_hay_taladro")
            return None
        if not self.al_alcance(*cuadro):
            self.mensaje = t("muy_lejos")
            return None
        return cuadro
