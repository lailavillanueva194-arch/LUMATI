"""Inventario (tecla E) y menú del Fabricador: casillas, objetos y su
dibujo.
"""

import pygame

import estilo
from maquinas import CASILLAS, LIMITE_INVENTARIO, PILA_MAX
from textos import t
from config import (ALTO, ANCHO, CABLE_PIEZAS, COLOR_CABLE_BORDE_DE, COLOR_CABLE_BRILLO_DE,
                    COLOR_CABLE_DE, COLOR_FONDO, COLOR_JUGADOR, COSTO_FABRICAR, CRAFTEO_ANCHO,
                    CRAFTEO_FILA, CRAFTEO_TITULO, DIRECCION, FABRICABLES, FABRICA_CANTIDAD,
                    INV_COLUMNAS, MENU_ABAJO, MENU_ATENUAR, MENU_CASILLA, MENU_HUECO, MENU_MARGEN,
                    MENU_SEPARACION, MENU_TITULO, OBJETOS, OBJ_CASILLA, OBJ_COLUMNAS, OBJ_PASO,
                    PATRON_CABLE)
from arte import ajustar_texto


class InventarioMixin:
    """Inventario (tecla E) y menú del Fabricador: casillas, objetos y su
    dibujo."""

    @property
    def menu_visible(self):
        """El menú del inventario o el del Fabricador está abierto y se ve (no si
        el astronauta murió o ya empezó el final: ahí las banderas se ignoran)."""
        return self.hay_menu and self.astronauta.vivo and self.escena_final is None

    @property
    def hay_menu(self):
        """Algún menú abierto: inventario, Fabricador o uno de la base."""
        return self.inventario_abierto or self.crafteo_abierto or self.menu_base is not None

    def alternar_inventario(self):
        """Abre o cierra el menú de las 21 casillas (tecla E o clic en la etiqueta)."""
        self.inventario_abierto = not self.inventario_abierto
        self.crafteo_abierto = False
        self.menu_base = None
        self.casilla_elegida = None

    def rect_casilla(self, i):
        """Rectángulo en pantalla de la casilla número i (0 a 20) del menú, por filas."""
        fila, col = divmod(i, INV_COLUMNAS)
        paso = MENU_CASILLA + MENU_SEPARACION
        return pygame.Rect(self.rect_menu.x + MENU_MARGEN + col * paso,
                           self.rect_menu.y + MENU_TITULO + fila * paso,
                           MENU_CASILLA, MENU_CASILLA)

    def casilla_bajo_mouse(self, pos):
        """Número de la casilla del menú bajo `pos`, o None."""
        for i in range(CASILLAS):
            if self.rect_casilla(i).collidepoint(pos):
                return i
        return None

    def paneles_menu(self):
        """(arriba, abajo): el panel de las 21 casillas y el de abajo (astronauta,
        objetos y misión)."""
        r = self.rect_menu
        ultima = self.rect_casilla(CASILLAS - 1)
        arriba = pygame.Rect(r.x, r.y, r.w, ultima.bottom + 12 - r.y)
        abajo = pygame.Rect(r.x, arriba.bottom + MENU_HUECO, r.w, MENU_ABAJO)
        return arriba, abajo

    def rect_objeto(self, i):
        """Casilla del objeto número i (de OBJETOS) en el panel de abajo: 2 filas de
        OBJ_COLUMNAS (caben 10 objetos)."""
        _, abajo = self.paneles_menu()
        fila, col = divmod(i, OBJ_COLUMNAS)
        return pygame.Rect(abajo.x + 130 + col * OBJ_PASO, abajo.y + 36 + fila * OBJ_PASO,
                           OBJ_CASILLA, OBJ_CASILLA)

    def objeto_bajo_mouse(self, pos):
        for i in range(len(OBJETOS)):
            if self.rect_objeto(i).collidepoint(pos):
                return i
        return None

    def clic_inventario(self, pos):
        """Clic con el menú abierto: elige (o suelta) una casilla de recursos, o
        pone un objeto en la mano; un clic fuera del menú lo cierra. Nada de esto
        llega al mapa."""
        i = self.casilla_bajo_mouse(pos)
        o = self.objeto_bajo_mouse(pos)
        if i is not None:
            self.casilla_elegida = None if self.casilla_elegida == i else i
        elif o is not None:
            self.elegir_en_mano(OBJETOS[o])
        elif not self.rect_menu.collidepoint(pos):
            self.alternar_inventario()

    # -- Fabricador (menú de crafteo) ---------------------------------------
    def rect_crafteo(self):
        alto = CRAFTEO_TITULO + len(FABRICABLES) * self.fila_crafteo() + 36
        return pygame.Rect((ANCHO - CRAFTEO_ANCHO) // 2, (ALTO - alto) // 2, CRAFTEO_ANCHO, alto)

    def rect_receta_crafteo(self, i):
        r = self.rect_crafteo()
        fila = self.fila_crafteo()
        return pygame.Rect(r.x + 14, r.y + CRAFTEO_TITULO + i * fila, r.w - 28, fila - 4)

    def fila_crafteo(self):
        """Alto de cada receta: CRAFTEO_FILA, o menos si con tantas recetas el menú
        no cabe en la pantalla (ronda 27: con el compañero son 12)."""
        return min(CRAFTEO_FILA, (ALTO - 16 - CRAFTEO_TITULO - 36) // len(FABRICABLES))

    def clic_crafteo(self, pos):
        """Clic con el Fabricador abierto: en una receta, la fabrica; fuera del
        menú, lo cierra."""
        for i, objeto in enumerate(FABRICABLES):
            if self.rect_receta_crafteo(i).collidepoint(pos):
                self.fabricar(objeto)
                return
        if not self.rect_crafteo().collidepoint(pos):
            self.crafteo_abierto = False

    def dibujar_inventario(self):
        """La etiqueta de la esquina: cuántas casillas se usan y cómo abrir el menú.
        Se pone color teja cuando las 21 están llenas."""
        pantalla = self.pantalla
        estilo.panel(pantalla, self.rect_inventario)
        usadas = self.inventario.casillas_usadas
        color = estilo.FALTA if usadas >= CASILLAS else estilo.TINTA
        texto = self.fuente_chica.render(t("inventario_tag", usadas=usadas, total=CASILLAS), True, color)
        pantalla.blit(texto, texto.get_rect(midleft=(self.rect_inventario.x + 10, self.rect_inventario.centery + 1)))

    def _dibujar_objeto(self, caja, recurso, cantidad):
        """Un objeto dentro de una casilla: su ícono y, abajo a la derecha, la cantidad."""
        pantalla = self.pantalla
        icono = self.iconos_recurso[recurso]
        pantalla.blit(icono, icono.get_rect(center=(caja.centerx, caja.centery - 6)))
        numero = self.fuente.render(str(cantidad), True, estilo.TINTA)
        pantalla.blit(numero, numero.get_rect(bottomright=(caja.right - 7, caja.bottom - 5)))

    def dibujar_menu_inventario(self):
        """El menú que abre la tecla E: oscurece el juego y muestra dos paneles
        blancos. Arriba, las 21 casillas de recursos en 3 filas de 7. Abajo, el
        astronauta, los objetos fabricados (clic: a la mano) y los datos de la
        misión (o el detalle de lo que está bajo el mouse o elegido)."""
        if not (self.inventario_abierto and self.menu_visible):
            return
        pantalla = self.pantalla
        tinta, suave = estilo.TINTA, estilo.TINTA_SUAVE
        self._velo.fill((0, 0, 0, int(MENU_ATENUAR * self._menu_t)))   # gris neutro; aparece suave
        pantalla.blit(self._velo, (0, 0))
        r = self.rect_menu
        arriba, abajo = self.paneles_menu()
        estilo.panel(pantalla, arriba)
        estilo.panel(pantalla, abajo)

        # --- panel de arriba: título y casillas
        usadas = self.inventario.casillas_usadas
        color = estilo.FALTA if usadas >= CASILLAS else tinta
        titulo = self.fuente.render(t("inventario_titulo", usadas=usadas, total=CASILLAS), True, color)
        pantalla.blit(titulo, (r.x + MENU_MARGEN, r.y + 15))
        cerrar = self.fuente_chica.render(t("inventario_cerrar"), True, suave)
        pantalla.blit(cerrar, cerrar.get_rect(topright=(r.right - MENU_MARGEN, r.y + 18)))
        casillas = self.inventario.casillas()
        sobre = self.casilla_bajo_mouse(pygame.mouse.get_pos())
        for i, contenido in enumerate(casillas):
            caja = self.rect_casilla(i)
            estilo.casilla(pantalla, caja, activa=i == self.casilla_elegida, mouse=i == sobre)
            if contenido is not None:
                self._dibujar_objeto(caja, *contenido)

        # --- panel de abajo, izquierda: retrato del astronauta
        retrato = pygame.Rect(abajo.x + 16, abajo.y + 16, 96, 96)
        pygame.draw.rect(pantalla, estilo.CONTORNO, retrato, border_radius=4)
        pygame.draw.rect(pantalla, COLOR_FONDO, retrato.inflate(-6, -6), border_radius=2)
        if self.sprites_astronauta:
            imagen = self.sprites_astronauta[0]["abajo"][0]
            figura = imagen.get_bounding_rect()
            pantalla.blit(imagen, (retrato.centerx - figura.centerx, retrato.centery - figura.centery))
        else:
            pygame.draw.rect(pantalla, COLOR_JUGADOR, pygame.Rect(0, 0, 36, 36).move(retrato.x + 30, retrato.y + 30))
        nombre = self.fuente_chica.render(t("astronauta"), True, tinta)
        pantalla.blit(nombre, nombre.get_rect(midtop=(retrato.centerx, retrato.bottom + 6)))

        # --- centro: los objetos fabricados (clic: a la mano)
        x = retrato.right + 18
        pantalla.blit(self.fuente_chica.render(t("objetos_titulo"), True, tinta), (x, abajo.y + 14))
        raton = pygame.mouse.get_pos()
        sobre_objeto = self.objeto_bajo_mouse(raton)
        for i, objeto in enumerate(OBJETOS):
            caja = self.rect_objeto(i)
            n = self.objetos[objeto]
            estilo.casilla(pantalla, caja, activa=objeto == self.en_mano, mouse=i == sobre_objeto)
            icono = self.iconos_objeto[objeto]
            if not n:                                   # sin unidades: ícono apagado
                icono = icono.copy()
                icono.set_alpha(70)
            pantalla.blit(icono, icono.get_rect(center=(caja.centerx, caja.centery - 3)))
            numero = self.render_cantidad(self.fuente_mini, "{n}", n, tinta if n else suave)
            pantalla.blit(numero, numero.get_rect(bottomright=(caja.right - 4, caja.bottom - 3)))
        x_linea = x + OBJ_COLUMNAS * OBJ_PASO + 2
        pygame.draw.line(pantalla, estilo.BISEL, (x_linea, abajo.y + 14), (x_linea, abajo.bottom - 14))
        pygame.draw.line(pantalla, estilo.PANEL_LUZ, (x_linea + 1, abajo.y + 14), (x_linea + 1, abajo.bottom - 14))

        # --- derecha: detalle del objeto o de la casilla (bajo el mouse o elegida) o datos de la misión
        x = x_linea + 16
        y = abajo.y + 16
        idx = sobre if sobre is not None else self.casilla_elegida
        if sobre_objeto is not None:
            objeto = OBJETOS[sobre_objeto]
            icono = self.iconos_objeto[objeto]
            pantalla.blit(icono, (x, y))
            pantalla.blit(self.fuente.render(t("herr_" + objeto), True, tinta), (x + 40, y + 8))
            lineas = [t("objeto_cuantos", n=self.texto_cantidad(self.objetos[objeto])),
                      t("objeto_en_mano") if objeto == self.en_mano else t("objeto_ayuda")]
            y += 44
        elif idx is not None and casillas[idx] is not None:
            recurso, cantidad = casillas[idx]
            limite = LIMITE_INVENTARIO.get(recurso)
            icono = self.iconos_recurso[recurso]
            pantalla.blit(icono, (x, y))
            pantalla.blit(self.fuente.render(t("recurso_" + recurso), True, tinta), (x + 44, y + 10))
            lineas = [t("inventario_total", n=self.inventario[recurso]),
                      t("inventario_pila", n=cantidad, max=PILA_MAX)]
            if limite:
                lineas.append(t("inventario_max_manos", max=limite))
            y += 46
        elif idx is not None:
            pantalla.blit(self.fuente.render(t("inventario_casilla_vacia"), True, tinta), (x, y))
            lineas = ajustar_texto(t("inventario_ayuda"), self.fuente_chica, abajo.right - 16 - x)
            y += 28
        else:
            lugar = t("lugar_" + self.destino)
            pantalla.blit(self.fuente.render(t("menu_mision", lugar=lugar), True, tinta), (x, y))
            reloj = self.clima.reloj
            lineas = [t("menu_dia", n=reloj.dia, hora=reloj.hora_texto),
                      t("menu_dosis", n=f"{self.astronauta.dosis_msv:.0f}"),
                      t("menu_oxigeno", n=self.producido["oxigeno"]),
                      t("menu_agua", n=self.producido["agua"]),
                      t("menu_comida", n=self.producido["comida"])]
            y += 26
        for linea in lineas:
            pantalla.blit(self.fuente_chica.render(linea, True, suave), (x, y))
            y += 18

    def _muestra_color(self, centro, color, radio):
        """Circulito con el color de cable y su patrón (rayas o punto), con contorno."""
        p = self.pantalla
        forma = CABLE_PIEZAS.get(color)
        color = self.color_visual(color)
        borde = COLOR_CABLE_BORDE_DE[color]
        pygame.draw.circle(p, COLOR_CABLE_DE[color], centro, radio)
        if forma and forma != "negro":                     # conector: dibuja su forma girada
            for lado in self.lados_de_pieza((forma, self.giro_cable)):
                df, dc = DIRECCION[lado]
                pygame.draw.line(p, borde, centro, (centro[0] + dc * (radio - 1), centro[1] + df * (radio - 1)), 2)
        elif forma == "negro":
            lado = self.lados_de_pieza(("negro", self.giro_cable))[0]
            df, dc = DIRECCION[lado]
            pygame.draw.line(p, COLOR_CABLE_BRILLO_DE["negro"], (centro[0] - dc * (radio - 2), centro[1] - df * (radio - 2)),
                             (centro[0] + dc * (radio - 2), centro[1] + df * (radio - 2)), 2)
        if PATRON_CABLE[color] == "rayas":
            pygame.draw.line(p, borde, (centro[0] - radio + 2, centro[1] + 2), (centro[0] + 2, centro[1] - radio + 2), 2)
            pygame.draw.line(p, borde, (centro[0] - 2, centro[1] + radio - 2), (centro[0] + radio - 2, centro[1] - 2), 2)
        elif PATRON_CABLE[color] == "puntos":
            pygame.draw.circle(p, borde, centro, max(1, radio // 3))
        pygame.draw.circle(p, estilo.CONTORNO, centro, radio, 1)

    def dibujar_crafteo(self):
        """El menú del Fabricador: una fila por objeto con su ícono, su nombre,
        lo que cuesta (ícono + cantidad; en color teja y con X lo que falta) y
        cuántos tienes. Clic en la fila la fabrica."""
        if not (self.crafteo_abierto and self.menu_visible):
            return
        pantalla = self.pantalla
        tinta, suave = estilo.TINTA, estilo.TINTA_SUAVE
        self._velo.fill((0, 0, 0, int(MENU_ATENUAR * self._menu_t)))
        pantalla.blit(self._velo, (0, 0))
        r = self.rect_crafteo()
        estilo.panel(pantalla, r)
        pantalla.blit(self.fuente.render(t("crafteo_titulo"), True, tinta), (r.x + 18, r.y + 16))
        ayuda = self.fuente_chica.render(t("crafteo_ayuda"), True, suave)
        pantalla.blit(ayuda, ayuda.get_rect(topright=(r.right - 18, r.y + 19)))
        estilo.separador(pantalla, r.x + 14, r.right - 14, r.y + CRAFTEO_TITULO - 8)
        raton = pygame.mouse.get_pos()
        for i, objeto in enumerate(FABRICABLES):
            fila = self.rect_receta_crafteo(i)
            costo = COSTO_FABRICAR[objeto]
            alcanza = self.es_demo or not self.inventario.faltante(costo)   # demo: todo se puede fabricar
            if fila.collidepoint(raton):                 # fila bajo el mouse: fondo resaltado
                pygame.draw.rect(pantalla, estilo.CASILLA_ACTIVA, fila, border_radius=4)
                pygame.draw.rect(pantalla, estilo.ACENTO, fila, 2, border_radius=4)
            caja = pygame.Rect(fila.x + 2, fila.y + 1, fila.h - 2, fila.h - 2)
            estilo.casilla(pantalla, caja)
            icono = self.iconos_objeto[objeto]
            pantalla.blit(icono, icono.get_rect(center=caja.center))
            nombre = t("herr_" + objeto)
            n = FABRICA_CANTIDAD.get(objeto, 1)
            if n > 1:
                nombre += " " + t("crafteo_da", n=n)
            pantalla.blit(self.fuente.render(nombre, True, tinta), (caja.right + 10, fila.y + 6))
            pantalla.blit(self.fuente_mini.render(t("crafteo_tienes", n=self.texto_cantidad(self.objetos[objeto])), True, suave),
                          (caja.right + 10, fila.y + 26))
            x = fila.x + 250                             # costo: un ícono chico y la cantidad por recurso
            if not costo or self.es_demo:
                pantalla.blit(self.fuente_chica.render(t("crafteo_gratis" if not costo else "demo_gratis"),
                                                       True, suave), (x, fila.y + 14))
            for recurso, pide in ({} if self.es_demo else costo).items():
                ok = self.inventario[recurso] >= pide
                pantalla.blit(self.iconos_recurso_chico[recurso], (x, fila.y + 8))
                texto = self.fuente_chica.render(f"{pide}/{self.inventario[recurso]}", True,
                                                 tinta if ok else estilo.FALTA)
                pantalla.blit(texto, (x + 28, fila.y + 14))
                x += 28 + texto.get_width() + 14
            cx, cy = fila.right - 18, fila.centery       # palomita o X, dibujadas (no dependen del color)
            color = estilo.OK if alcanza else estilo.FALTA
            if alcanza:
                pygame.draw.lines(pantalla, color, False, [(cx - 6, cy), (cx - 2, cy + 5), (cx + 6, cy - 5)], 3)
            else:
                pygame.draw.line(pantalla, color, (cx - 5, cy - 5), (cx + 5, cy + 5), 3)
                pygame.draw.line(pantalla, color, (cx - 5, cy + 5), (cx + 5, cy - 5), 3)
