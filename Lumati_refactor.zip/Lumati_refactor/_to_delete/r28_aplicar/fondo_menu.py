"""Decoración del menú de opciones (ronda 22): espacio con estrellas, planetas,
astronautas flotando y meteoros, más las tarjetas de los botones con su ícono.

Este archivo SOLO dibuja: no tiene reglas del juego. Todo el arte es propio,
hecho con figuras de pygame, salvo el astronauta, que es el dibujo de las
diseñadoras (assets/astronauta.png) que main.py le pasa ya cargado.

Accesibilidad: todo se mueve despacio. Las estrellas cambian de brillo con
periodos de 4 a 10 segundos y nada parpadea rápido.
"""

import math
import random

import pygame

import estilo

# --------------------------------------------------------------------------
# Ajustes (solo de dibujo)
# --------------------------------------------------------------------------
SEMILLA = 21
ESTRELLAS = 140                     # cuántas estrellas
BRILLO_LENTO = (0.6, 1.5)           # velocidad del brillo de las estrellas (radianes por segundo)
METEORO_CADA = (4.0, 9.0)           # segundos entre meteoros
METEORO_VEL = (220.0, 320.0)        # píxeles por segundo
METEORO_MAX = 2                     # a la vez, como mucho
ASTRONAUTA_LADO = 64                # tamaño del astronauta flotando
GIRO_MAX = 14                       # grados que se inclina al flotar
DISCRETO = 120                      # velo oscuro sobre la decoración en la guía y las partidas (0 a 255)
COLOR_CIELO_ARRIBA = (6, 6, 12)     # casi negro (nada de azul oscuro: en el juego es "poco oxígeno")
COLOR_CIELO_ABAJO = (22, 16, 32)    # un poco violeta abajo
COLOR_AVISO_SALIR = (186, 62, 44)   # "salir sin guardar": el mismo rojo discreto de estilo.FALTA


# --------------------------------------------------------------------------
# Planetas hechos por código
# --------------------------------------------------------------------------
def _recortar_circulo(img, radio):
    """Deja visible solo el círculo central (el resto transparente)."""
    mascara = pygame.Surface(img.get_size(), pygame.SRCALPHA)
    pygame.draw.circle(mascara, (255, 255, 255, 255), (img.get_width() // 2, img.get_height() // 2), radio)
    img.blit(mascara, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)


def _sombrear(img, radio):
    """Sombra del lado de abajo a la derecha (la luz viene de arriba a la izquierda)
    y un borde de luz fino: así se ve redondo."""
    lado = img.get_width()
    c = lado // 2
    sombra = pygame.Surface((lado, lado), pygame.SRCALPHA)
    sombra.fill((0, 0, 0, 170))
    for k, alfa in enumerate((130, 95, 60, 30, 0)):         # borde suave entre luz y sombra
        r = radio * (1.12 - k * 0.06)
        pygame.draw.circle(sombra, (0, 0, 0, alfa), (c - radio * 0.32, c - radio * 0.32), r)
    _recortar_circulo(sombra, radio)
    img.blit(sombra, (0, 0))
    pygame.draw.circle(img, (255, 255, 255, 50), (c, c), radio, 2)


def planeta_marte(radio, semilla=1):
    """Planeta rojizo con manchas oscuras, cráteres y un casquete de hielo."""
    azar = random.Random(semilla)
    lado = radio * 2 + 4
    img = pygame.Surface((lado, lado), pygame.SRCALPHA)
    img.fill((196, 98, 62, 255))
    for _ in range(14):
        w, h = azar.randint(radio // 3, radio), azar.randint(radio // 6, radio // 2)
        x, y = azar.randint(0, lado - w), azar.randint(0, lado - h)
        pygame.draw.ellipse(img, azar.choice(((160, 74, 48), (210, 120, 80), (140, 64, 44))), (x, y, w, h))
    for _ in range(7):
        r = azar.randint(3, max(4, radio // 7))
        x, y = azar.randint(r, lado - r), azar.randint(r, lado - r)
        pygame.draw.circle(img, (150, 70, 46), (x, y), r)
        pygame.draw.circle(img, (222, 140, 100), (x - 1, y - 1), r, 1)
    pygame.draw.ellipse(img, (240, 236, 232), (lado // 2 - radio * 0.45, 2, radio * 0.9, radio * 0.28))
    _recortar_circulo(img, radio)
    _sombrear(img, radio)
    return img


def planeta_tierra(radio, semilla=2):
    """Planeta azul con continentes verdes y cafés y nubes blancas."""
    azar = random.Random(semilla)
    lado = radio * 2 + 4
    img = pygame.Surface((lado, lado), pygame.SRCALPHA)
    img.fill((52, 112, 190, 255))
    for _ in range(9):
        w, h = azar.randint(radio // 2, radio + radio // 2), azar.randint(radio // 3, radio)
        x, y = azar.randint(-w // 3, lado - w // 2), azar.randint(0, lado - h)
        pygame.draw.ellipse(img, azar.choice(((70, 150, 80), (96, 160, 74), (150, 128, 82))), (x, y, w, h))
    nubes = pygame.Surface((lado, lado), pygame.SRCALPHA)
    for _ in range(8):
        w, h = azar.randint(radio // 2, radio + 6), azar.randint(4, radio // 4 + 4)
        x, y = azar.randint(0, lado - w), azar.randint(0, lado - h)
        pygame.draw.ellipse(nubes, (255, 255, 255, 150), (x, y, w, h))
    img.blit(nubes, (0, 0))
    _recortar_circulo(img, radio)
    _sombrear(img, radio)
    return img


def planeta_anillo(radio, semilla=3):
    """Planeta gigante con franjas y un anillo inclinado (la parte de atrás del
    anillo queda detrás del planeta y la de adelante, encima)."""
    azar = random.Random(semilla)
    lado = radio * 2 + 4
    cuerpo = pygame.Surface((lado, lado), pygame.SRCALPHA)
    cuerpo.fill((222, 196, 150, 255))
    y = 0
    while y < lado:
        alto = azar.randint(4, max(5, radio // 4))
        color = azar.choice(((206, 170, 120), (232, 210, 170), (190, 150, 106), (214, 186, 140)))
        pygame.draw.rect(cuerpo, color, (0, y, lado, alto))
        y += alto
    _recortar_circulo(cuerpo, radio)
    _sombrear(cuerpo, radio)
    ancho, alto = int(radio * 4.2), int(radio * 1.3)
    total = pygame.Surface((ancho, max(lado, alto) + 8), pygame.SRCALPHA)
    cx, cy = ancho // 2, total.get_height() // 2
    anillo = pygame.Surface(total.get_size(), pygame.SRCALPHA)
    for k, (color, grosor) in enumerate((((200, 182, 150, 210), 5), ((236, 222, 196, 230), 4), ((176, 160, 132, 190), 3))):
        caja = pygame.Rect(0, 0, ancho - k * 18, alto - k * 6)
        caja.center = (cx, cy)
        pygame.draw.ellipse(anillo, color, caja, grosor)
    atras = anillo.subsurface((0, 0, ancho, cy))
    adelante = anillo.subsurface((0, cy, ancho, total.get_height() - cy))
    total.blit(atras, (0, 0))
    total.blit(cuerpo, (cx - lado // 2, cy - lado // 2))
    total.blit(adelante, (0, cy))
    return pygame.transform.rotozoom(total, 16, 1.0)


# --------------------------------------------------------------------------
# Íconos de las tarjetas (hechos por código, 28 px)
# --------------------------------------------------------------------------
def icono(nombre, color, lado=28):
    img = pygame.Surface((lado, lado), pygame.SRCALPHA)
    s = lado / 28
    def P(x, y):
        return (x * s, y * s)
    if nombre == "continuar":                                   # "play"
        pygame.draw.polygon(img, color, [P(8, 5), P(23, 14), P(8, 23)])
    elif nombre == "guia":                                      # libro abierto
        pygame.draw.polygon(img, color, [P(2, 7), P(13, 9), P(13, 24), P(2, 22)], 2)
        pygame.draw.polygon(img, color, [P(26, 7), P(15, 9), P(15, 24), P(26, 22)], 2)
        for y in (13, 17):
            pygame.draw.line(img, color, P(5, y), P(10, y + 1), 1)
            pygame.draw.line(img, color, P(18, y + 1), P(23, y), 1)
    elif nombre == "partidas":                                  # disquete
        pygame.draw.rect(img, color, (*P(4, 4), 20 * s, 20 * s), 2, border_radius=2)
        pygame.draw.rect(img, color, (*P(8, 4), 11 * s, 7 * s))
        pygame.draw.rect(img, color, (*P(8, 15), 12 * s, 7 * s), 2)
    elif nombre == "guardar_salir":                             # disquete chico y flecha que sale
        pygame.draw.rect(img, color, (*P(2, 8), 13 * s, 13 * s), 2, border_radius=2)
        pygame.draw.rect(img, color, (*P(5, 8), 7 * s, 4 * s))
        pygame.draw.line(img, color, P(16, 14), P(26, 14), 3)
        pygame.draw.polygon(img, color, [P(22, 9), P(27, 14), P(22, 19)])
    elif nombre == "nueva":                                     # estrella de "nuevo"
        puntos = []
        for k in range(10):
            r = (11 if k % 2 == 0 else 5) * s
            a = math.pi / 2 + k * math.pi / 5
            puntos.append((14 * s + math.cos(a) * r, 14 * s - math.sin(a) * r))
        pygame.draw.polygon(img, color, puntos)
    elif nombre == "luna":                                      # Luna gris con cráteres
        pygame.draw.circle(img, (176, 178, 186), P(14, 14), 11 * s)
        for x, y, r in ((10, 10, 3), (17, 16, 2.5), (12, 19, 2)):
            pygame.draw.circle(img, (130, 132, 142), P(x, y), r * s)
        pygame.draw.circle(img, color, P(14, 14), 11 * s, 1)
    elif nombre == "marte":                                     # Marte rojizo con casquete
        pygame.draw.circle(img, (196, 98, 62), P(14, 14), 11 * s)
        pygame.draw.ellipse(img, (150, 70, 46), (*P(7, 13), 10 * s, 4 * s))
        pygame.draw.ellipse(img, (240, 236, 232), (*P(10, 3), 8 * s, 3 * s))
        pygame.draw.circle(img, color, P(14, 14), 11 * s, 1)
    elif nombre == "demo":                                      # rayo de energía (ronda 28)
        pygame.draw.polygon(img, color, [P(16, 3), P(7, 16), P(13, 16), P(11, 25), P(21, 11), P(15, 11), P(18, 3)])
    elif nombre == "volver":                                    # flecha a la izquierda
        pygame.draw.line(img, color, P(7, 14), P(23, 14), 3)
        pygame.draw.polygon(img, color, [P(12, 7), P(4, 14), P(12, 21)])
    else:                                                       # salir: X en un círculo
        pygame.draw.circle(img, color, P(14, 14), 11 * s, 2)
        pygame.draw.line(img, color, P(9, 9), P(19, 19), 3)
        pygame.draw.line(img, color, P(19, 9), P(9, 19), 3)
    return img


def tarjeta(pantalla, rect, texto, nombre_icono, resalte=0.0, aviso=False, activo=True):
    """Tarjeta flotante e independiente: sombra, panel blanco, franja de color a
    la izquierda, ícono en un círculo y el texto. `resalte` (0 a 1) la agranda
    un poco y pinta su borde del acento; `aviso` usa el rojo discreto."""
    color = COLOR_AVISO_SALIR if aviso else estilo.ACENTO
    if not activo:
        color = estilo.TINTA_SUAVE
    r = rect.inflate(int(10 * resalte), int(6 * resalte))
    estilo.sombra(pantalla, r, desplazar=(4, 6 + int(3 * resalte)), radio=12)
    pygame.draw.rect(pantalla, estilo.CONTORNO, r, border_radius=12)
    dentro = r.inflate(-4, -4)
    pygame.draw.rect(pantalla, estilo.PANEL if activo else estilo.CASILLA, dentro, border_radius=10)
    pygame.draw.line(pantalla, estilo.PANEL_LUZ, (dentro.x + 10, dentro.y + 1), (dentro.right - 10, dentro.y + 1))
    franja = pygame.Rect(dentro.x, dentro.y, 8, dentro.h)
    pygame.draw.rect(pantalla, color, franja, border_top_left_radius=10, border_bottom_left_radius=10)
    if resalte > 0.01:                                          # borde del acento al pasar el mouse
        pygame.draw.rect(pantalla, color, r, max(2, int(3 * resalte) + 1), border_radius=12)
    circulo = (dentro.x + 38, dentro.centery)
    pygame.draw.circle(pantalla, estilo.CASILLA_ACTIVA if activo else estilo.CASILLA, circulo, 20)
    pygame.draw.circle(pantalla, color, circulo, 20, 2)
    img = icono(nombre_icono, color)
    pantalla.blit(img, img.get_rect(center=circulo))
    pantalla.blit(texto, texto.get_rect(midleft=(dentro.x + 72, dentro.centery + 1)))


# --------------------------------------------------------------------------
# Fondo animado
# --------------------------------------------------------------------------
class FondoEspacial:
    """Espacio del menú: se dibuja una vez lo fijo (cielo y planetas) y en cada
    cuadro lo que se mueve (estrellas, astronautas y meteoros)."""

    def __init__(self, tam, astronautas=None):
        """astronautas: lista de 1 o 2 imágenes del astronauta (o vacía si falta el PNG)."""
        self.ancho, self.alto = tam
        self._azar = random.Random(SEMILLA)
        self.t = 0.0
        self.cielo = pygame.Surface(tam)
        for y in range(self.alto):                                  # degradado de arriba hacia abajo
            self.cielo.fill(estilo.mezclar(COLOR_CIELO_ARRIBA, COLOR_CIELO_ABAJO, y / self.alto),
                            (0, y, self.ancho, 1))
        for _ in range(60):                                         # polvo de estrellas fijo, muy tenue
            x, y = self._azar.randrange(self.ancho), self._azar.randrange(self.alto)
            self.cielo.set_at((x, y), (70, 70, 86))
        self.estrellas = [(self._azar.randrange(self.ancho), self._azar.randrange(self.alto),
                           self._azar.choice((1, 1, 1, 2)), self._azar.uniform(*BRILLO_LENTO),
                           self._azar.uniform(0, 6.3)) for _ in range(ESTRELLAS)]
        # Planetas: (imagen, centro, cuánto se mece, velocidad)
        self.planetas = [(planeta_anillo(46), (150, 118), 5, 0.05),
                         (planeta_tierra(34), (836, 104), 4, 0.07),
                         (planeta_marte(58), (838, 548), 6, 0.04)]
        # Astronautas: (cuadros girados por grado, centro, radio del vaivén, fase)
        self.astronautas = []
        lugares = (((150, 420), (26, 30), 0.0), ((800, 330), (22, 26), 2.1))
        for imagen, (centro, radio, fase) in zip(astronautas or [], lugares):
            base = pygame.transform.scale(imagen, (ASTRONAUTA_LADO, ASTRONAUTA_LADO))
            giros = {g: pygame.transform.rotate(base, g) for g in range(-GIRO_MAX, GIRO_MAX + 1)}
            self.astronautas.append((giros, centro, radio, fase))
        self.meteoros = []                                          # [x, y, vx, vy, vida, total]
        self._meteoro_t = 2.0
        self._velo = pygame.Surface(tam, pygame.SRCALPHA)           # velo de "discreto" (se hace una vez)
        self._velo.fill((0, 0, 0, DISCRETO))

    def actualizar(self, dt):
        self.t += dt
        for m in self.meteoros:
            m[0] += m[2] * dt
            m[1] += m[3] * dt
            m[4] -= dt
        self.meteoros = [m for m in self.meteoros if m[4] > 0]
        self._meteoro_t -= dt
        if self._meteoro_t <= 0:
            self._meteoro_t = self._azar.uniform(*METEORO_CADA)
            if len(self.meteoros) < METEORO_MAX:
                lado = self._azar.choice((-1, 1))
                vel = self._azar.uniform(*METEORO_VEL)
                ang = math.radians(self._azar.uniform(25, 40))
                x = self._azar.uniform(0.15, 0.85) * self.ancho
                vida = (self.alto * 0.8) / (vel * math.sin(ang))
                self.meteoros.append([x, -20.0, lado * vel * math.cos(ang), vel * math.sin(ang), vida, vida])

    def posicion_astronauta(self, i):
        """(centro x, centro y, grados) del astronauta i en este momento."""
        _, (cx, cy), (rx, ry), fase = self.astronautas[i]
        t = self.t * 0.35 + fase
        return (cx + math.sin(t) * rx, cy + math.sin(t * 0.73 + 1.0) * ry,
                round(GIRO_MAX * math.sin(self.t * 0.4 + fase)))

    def dibujar(self, pantalla, discreto=False):
        pantalla.blit(self.cielo, (0, 0))
        for x, y, tam, vel, fase in self.estrellas:                 # brillo suave y lento
            b = 0.55 + 0.45 * math.sin(self.t * vel + fase)
            color = estilo.mezclar((60, 60, 74), (255, 255, 246), b)
            if tam == 1:
                pantalla.set_at((x, y), color)
            else:
                pygame.draw.circle(pantalla, color, (x, y), tam)
        for imagen, (cx, cy), meneo, vel in self.planetas:
            dx = math.sin(self.t * vel * 6.28) * meneo
            dy = math.cos(self.t * vel * 5.0) * meneo * 0.6
            pantalla.blit(imagen, imagen.get_rect(center=(cx + dx, cy + dy)))
        for m in self.meteoros:                                     # cola que se apaga hacia atrás
            x, y, vx, vy, vida, total = m
            fuerza = min(1.0, vida / 0.4, (total - vida) / 0.3)
            largo = 70
            norma = math.hypot(vx, vy)
            ux, uy = vx / norma, vy / norma
            for k in range(6):
                a, b = k / 6, (k + 1) / 6
                color = estilo.mezclar(COLOR_CIELO_ARRIBA, (255, 236, 200), (1 - a) * fuerza)
                pygame.draw.line(pantalla, color, (x - ux * largo * a, y - uy * largo * a),
                                 (x - ux * largo * b, y - uy * largo * b), max(1, 3 - k // 2))
            pygame.draw.circle(pantalla, estilo.mezclar(COLOR_CIELO_ARRIBA, (255, 255, 240), fuerza), (x, y), 2)
        for i, (giros, *_resto) in enumerate(self.astronautas):
            x, y, grados = self.posicion_astronauta(i)
            img = giros[grados]
            pantalla.blit(img, img.get_rect(center=(x, y)))
        if discreto:                                                # guía y partidas: decoración más tenue
            pantalla.blit(self._velo, (0, 0))
