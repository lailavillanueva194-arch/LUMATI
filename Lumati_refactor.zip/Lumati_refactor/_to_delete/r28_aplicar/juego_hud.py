"""Interfaz encima del juego (HUD): mensajes, avisos de tormenta, barras vitales, reloj,
mano, acceso rápido, resaltado, viñetas, polvo, contacto con la Tierra, datos reales
emergentes y las imágenes del final.
"""

import math

import pygame

import datos
import estilo
import textos
from clima import CALMA, CME_EN_CAMINO, LLAMARADA, PARTICULAS, POLVO_EN_AVISO, POLVO_EN_CALMA
from supervivencia import BAJO, BARRAS, CRITICO, DOSIS, OXIGENO
from textos import t
from config import (ALTO, ANCHO, ARTE_CULTIVOS, BANNER_ANCHO, COLOR_ALCANZA, COLOR_ANTENA,
                    COLOR_AVISO, COLOR_AVISO_2, COLOR_BARRA, COLOR_BLOQUE, COLOR_BLOQUE_CLARO,
                    COLOR_CABLE, COLOR_CALOR, COLOR_CELDA_SOLAR, COLOR_FONDO, COLOR_FRIO,
                    COLOR_HIDROGENO, COLOR_HOJA, COLOR_LEJOS, COLOR_MAQUINA, COLOR_MORADO,
                    COLOR_NAVE, COLOR_NAVE_DETALLE, COLOR_NOCHE, COLOR_PANEL_SOLAR, COLOR_RECURSO,
                    COLOR_SALIDA, COLOR_TALADRO_BORDE, COLOR_TALADRO_NIVEL, COLOR_TEXTO,
                    COLOR_VELO_POLVO, CONTACTO_RECT_ALTO, DATO_ANCHO, DATO_POR_FASE,
                    DATO_POR_FASE_MARTE, ESCENAS_FINAL, ESCENA_MAPA, GRAMOS_POR_UNIDAD_O2,
                    ICONO_BARRA, INVENTARIO_RECT, MANO_CASILLA, MAPA_ALTO, MAPA_ANCHO, MARTE,
                    MENSAJE_ABAJO, MENSAJE_SEGUNDOS, MINIMAPA_RECT, OSCURIDAD_MAX, POLVO_RECT,
                    REFERENCIAS, RELOJ_RECT, TANQUE, TEMP_AVISO, TILE, VELO_POLVO_MAX,
                    VITALES_ANCHO, VITALES_FILA, VITALES_RECT)
from arte import ajustar_texto, icono_evento
from jugador import pos_pantalla


class HudMixin:
    """Interfaz encima del juego (HUD): mensajes, avisos de tormenta, barras vitales, reloj,
    mano, acceso rápido, resaltado, viñetas, polvo, contacto con la Tierra, datos reales
    emergentes y las imágenes del final."""

    @property
    def inventario(self):
        """Lo que lleva el astronauta (vive en supervivencia.Inventario)."""
        return self.astronauta.inventario

    # -- mensaje con temporizador -----------------------------------------
    @property
    def mensaje(self):
        """Último aviso, o "" cuando ya pasaron MENSAJE_SEGUNDOS."""
        return self._mensaje if self._mensaje_t > 0 else ""

    @mensaje.setter
    def mensaje(self, texto):
        # Cada vez que se asigna un mensaje, el reloj vuelve a empezar.
        self._mensaje = texto
        self._mensaje_t = MENSAJE_SEGUNDOS

    def rect_mensaje(self):
        """Rectángulo (con margen) de la caja del mensaje, o None si no hay."""
        if not self.mensaje:
            return None
        ancho, alto = self.fuente.size(self.mensaje)
        texto = pygame.Rect(0, 0, ancho, alto)
        texto.midbottom = (ANCHO // 2, MENSAJE_ABAJO - 7)
        caja = texto.inflate(24, 14)
        if caja.left < self.rect_mano.right + 8:        # un mensaje largo no tapa el recuadro de la mano
            caja.left = self.rect_mano.right + 8
        return caja

    def rects_interfaz(self):
        """Todo lo que está dibujado encima del mapa: lo de la mano, el inventario
        y el mensaje (solo mientras se ve). Sirve para dibujar y para saber si el
        mouse está sobre la interfaz y no sobre el mapa."""
        rects = [self.rect_mano, self.rect_rapida, self.rect_inventario, self.rect_vitales, self.rect_reloj]
        if self.minimapa_visible and self.escena == ESCENA_MAPA:
            rects.append(pygame.Rect(MINIMAPA_RECT))
        if self.menu_visible:
            rects.append(self.rect_menu if self.inventario_abierto else self.rect_crafteo())
        if self.polvo and self.polvo.fase != POLVO_EN_CALMA:
            rects.append(self.rect_polvo)
        if self.rect_contacto():
            rects.append(self.rect_contacto())
        if self.rect_chip():
            rects.append(self.rect_chip())
        mensaje = self.rect_mensaje()
        if mensaje:
            rects.append(mensaje)
        banner = self._banner()
        if banner:
            rects.append(banner[0])
        return rects

    def _banner(self):
        """(rect, líneas) del aviso de tormenta, o None en calma. Cada línea es
        (texto, fuente, color). Se recalcula solo cuando cambia la fase, el
        idioma o el segundo de la cuenta regresiva."""
        c = self.clima
        if c.fase == CALMA:
            return None
        segundos = math.ceil(c.segundos_restantes)
        clave = (c.fase, textos.IDIOMA, segundos, c.evento["id"], self.destino)
        if self._banner_cache[0] == clave:
            return self._banner_cache[1]
        evento = c.evento
        if c.fase == LLAMARADA:
            titulo = t("clima_alerta", etiqueta=evento["etiqueta"])
        elif c.fase == CME_EN_CAMINO:
            titulo = t("clima_cme", s=segundos)
        else:
            titulo = t("clima_particulas")
        gris = estilo.TINTA_SUAVE
        id_dato = (DATO_POR_FASE_MARTE if self.destino == MARTE else DATO_POR_FASE)[c.fase]
        if self.destino == MARTE and id_dato == "marte_cme_viaje" and evento["id"] != "cme_2017_01_03":
            id_dato = "cme_escala"          # el viaje a Marte solo se conoce de la CME de 2017
        ancho_texto = BANNER_ANCHO - 28
        lineas = [(titulo, self.fuente, estilo.TINTA),
                  (t("clima_ejemplo", fecha=evento["fecha"]), self.fuente_chica, gris)]
        # El dato real lleva su etiqueta ("Dato real NASA") y su fuente.
        lineas += [(l, self.fuente_chica, estilo.TINTA)
                   for l in ajustar_texto(datos.etiqueta(id_dato), self.fuente_chica, ancho_texto)]
        lineas.append((t("fuente_dato", nombre=datos.fuente(id_dato)[0]),
                       self.fuente_chica, gris))
        lineas += [(l, self.fuente_chica, gris)
                   for l in ajustar_texto(t("clima_no_oficial"), self.fuente_chica, ancho_texto)]
        alto = 18 + sum(f.get_linesize() for _, f, _ in lineas)
        rect = pygame.Rect(0, 8, BANNER_ANCHO, alto)
        # Centrado entre el inventario (izquierda) y las barras (derecha).
        rect.centerx = (INVENTARIO_RECT[0] + INVENTARIO_RECT[2] + VITALES_RECT[0]) // 2
        self._banner_cache = (clave, (rect, lineas))
        return self._banner_cache[1]

    def _icono_respaldo(self, objeto):
        """Ícono de color plano para un objeto sin PNG (provisional)."""
        lado = ICONO_BARRA
        s = pygame.Surface((lado, lado), pygame.SRCALPHA)
        borde = COLOR_TALADRO_BORDE
        nombre = "herr_" + objeto
        if nombre == "herr_cable":
            pygame.draw.rect(s, COLOR_CABLE, (4, 13, 24, 7))
            pygame.draw.rect(s, COLOR_CABLE, (13, 4, 7, 12))
        elif nombre == "herr_taladro":
            pygame.draw.rect(s, COLOR_TALADRO_NIVEL[1], (5, 3, 22, 18))
            pygame.draw.rect(s, borde, (5, 3, 22, 18), 2)
            pygame.draw.polygon(s, borde, [(10, 21), (22, 21), (16, 31)])
        elif nombre == "herr_generador":
            pygame.draw.rect(s, COLOR_PANEL_SOLAR, (3, 6, 26, 20))
            for f in range(2):
                for c in range(3):
                    pygame.draw.rect(s, COLOR_CELDA_SOLAR, (6 + c * 8, 9 + f * 8, 6, 6))
        elif nombre == "herr_bloque":
            pygame.draw.rect(s, COLOR_BLOQUE, (4, 6, 24, 20))
            pygame.draw.line(s, COLOR_BLOQUE_CLARO, (4, 6), (27, 6), 3)
            pygame.draw.rect(s, borde, (4, 6, 24, 20), 2)
        elif nombre == "herr_purificador":
            pygame.draw.circle(s, COLOR_SALIDA["agua"], (16, 20), 8)
            pygame.draw.polygon(s, COLOR_SALIDA["agua"], [(8, 18), (24, 18), (16, 3)])
        elif nombre == "herr_electrolizador":           # caja con ventana de agua
            pygame.draw.rect(s, (196, 204, 214), (3, 7, 26, 22), border_radius=3)
            pygame.draw.rect(s, borde, (3, 7, 26, 22), 2, border_radius=3)
            pygame.draw.rect(s, (34, 48, 64), (9, 11, 14, 14))
            pygame.draw.rect(s, COLOR_SALIDA["agua"], (9, 18, 14, 7))
            pygame.draw.rect(s, COLOR_SALIDA["oxigeno"], (6, 2, 6, 5))
            pygame.draw.rect(s, COLOR_HIDROGENO, (20, 2, 6, 5))
            pygame.draw.rect(s, borde, (6, 2, 6, 5), 1)
            pygame.draw.rect(s, borde, (20, 2, 6, 5), 1)
        elif nombre == "herr_tanque":
            pygame.draw.rect(s, COLOR_MAQUINA[TANQUE], (9, 2, 14, 28), border_radius=6)
            pygame.draw.rect(s, COLOR_HIDROGENO, (12, 15, 8, 12), border_radius=3)
            pygame.draw.rect(s, borde, (9, 2, 14, 28), 2, border_radius=6)
        elif nombre == "herr_tanque_agua":
            pygame.draw.rect(s, (214, 224, 234), (8, 3, 16, 26), border_radius=6)
            pygame.draw.rect(s, COLOR_SALIDA["agua"], (11, 13, 10, 13), border_radius=3)
            pygame.draw.rect(s, borde, (8, 3, 16, 26), 2, border_radius=6)
        elif nombre == "herr_antena":
            pygame.draw.rect(s, COLOR_ANTENA, (9, 24, 14, 6), border_radius=2)
            pygame.draw.rect(s, borde, (9, 24, 14, 6), 2, border_radius=2)
            pygame.draw.line(s, borde, (16, 24), (16, 13), 3)
            pygame.draw.ellipse(s, COLOR_ANTENA, (4, 3, 24, 13))
            pygame.draw.ellipse(s, borde, (4, 3, 24, 13), 2)
            pygame.draw.circle(s, estilo.ACENTO, (21, 4), 3)
        elif nombre == "herr_pico":
            pygame.draw.line(s, (150, 104, 70), (8, 28), (22, 9), 4)                # mango
            pygame.draw.arc(s, COLOR_TALADRO_NIVEL[3], (4, 2, 26, 16), 0.3, 2.9, 5)  # cabeza
            pygame.draw.arc(s, borde, (4, 2, 26, 16), 0.3, 2.9, 1)
        elif nombre == "herr_regadera":
            pygame.draw.rect(s, estilo.ACENTO, (6, 12, 16, 14), border_radius=3)      # tanque
            pygame.draw.rect(s, borde, (6, 12, 16, 14), 2, border_radius=3)
            pygame.draw.line(s, borde, (21, 16), (29, 8), 3)                        # pico de la regadera
            pygame.draw.arc(s, borde, (8, 5, 12, 12), 0, 3.14, 2)                   # asa
            for dx in (0, 3, 6):
                pygame.draw.circle(s, COLOR_RECURSO["agua"], (29 + dx // 3 - 1, 12 + dx), 1)
        elif nombre == "herr_invernadero":
            planta = self.plantas.get(ARTE_CULTIVOS["lechuga"][1])
            if planta:
                k = min(lado / planta.get_width(), lado / planta.get_height())
                planta = pygame.transform.scale(planta, (int(planta.get_width() * k),
                                                         int(planta.get_height() * k)))
                s.blit(planta, planta.get_rect(center=(lado // 2, lado // 2)))
            else:
                for dx, dy in ((-7, 2), (0, -5), (7, 2)):
                    pygame.draw.ellipse(s, COLOR_HOJA, (16 + dx - 4, 16 + dy - 6, 8, 12))
        return s

    def dibujar_interfaz(self):
        """Lo que va encima del mundo (o de la sala de la base): paneles, menús,
        muerte, final y el fundido al dormir."""
        self.dibujar_vinetas()               # bordes teñidos: radiación y poco oxígeno
        self.dibujar_inventario()
        self.dibujar_vitales()
        self.dibujar_reloj()
        if self.escena == ESCENA_MAPA and self.minimapa_visible and self._cielo < 0.5:
            self.dibujar_minimapa()
        self.dibujar_aviso_polvo()
        self.dibujar_contacto()
        self.dibujar_chip()                  # Marte: aviso corto con ícono (sismo, remolino...)
        self.dibujar_banner()
        self.dibujar_dato()
        self.dibujar_mano()
        self.dibujar_rapida()
        self.dibujar_menu_inventario()       # encima de todo lo demás (y oscurece el juego)
        self.dibujar_crafteo()
        self.dibujar_menu_base()
        self.dibujar_fin()
        self.dibujar_final()
        self.dibujar_opciones()              # menú de opciones (pausa): encima de todo
        if self._fundido:                    # dormir: la pantalla oscurece y aclara despacio
            self._velo.fill((0, 0, 0, int(255 * self._fundido[1])))
            self.pantalla.blit(self._velo, (0, 0))
        pygame.display.flip()

    def dibujar_dato(self):
        """Dato real emergente (etiqueta + texto + fuente), abajo al centro."""
        if not self.dato:
            return
        id_dato = self.dato[0]
        de_la_tierra = len(self.dato) > 2           # llegó por la antena
        lineas = [(t("mensaje_tierra"), estilo.ACENTO)] if de_la_tierra else []
        lineas += [(l, estilo.TINTA) for l in ajustar_texto(datos.etiqueta(id_dato), self.fuente_chica,
                                                            DATO_ANCHO - 28)]
        lineas.append((t("fuente_dato", nombre=datos.fuente(id_dato)[0]), estilo.TINTA_SUAVE))
        alto = 20 + len(lineas) * self.fuente_chica.get_linesize()
        rect = pygame.Rect(0, 0, DATO_ANCHO, alto)
        rect.midbottom = (ANCHO // 2, MENSAJE_ABAJO - 46)
        estilo.panel(self.pantalla, rect, borde=estilo.ACENTO if de_la_tierra else COLOR_CALOR)
        y = rect.y + 10
        for texto, color in lineas:
            self.pantalla.blit(self.fuente_chica.render(texto, True, color), (rect.x + 14, y))
            y += self.fuente_chica.get_linesize()

    def dibujar_final(self):
        """Final: ESCENAS_FINAL imágenes fijas (siluetas genéricas, sin logos ni
        personas) y luego la comparación "tu misión contra la real"."""
        if self.escena_final is None:
            return
        if self.cinematica is not None:      # al salir de Marte: la cinemática va primero
            self.dibujar_cinematica()
            return
        p = self.pantalla
        p.fill(COLOR_FONDO)
        for x, y, r in self._estrellas:
            pygame.draw.circle(p, (200, 200, 210), (x, y), r)
        tierra_agua, tierra_suelo = (90, 150, 210), (110, 165, 95)
        e = self.escena_final
        marte = self.destino == MARTE
        mundo = (176, 98, 64) if marte else (120, 121, 124)      # color del mundo que se deja atrás
        if e == 0:                                   # despegue desde la Luna (o Marte)
            pygame.draw.circle(p, mundo, (ANCHO // 2, ALTO + 380), 560)
            self._dibujar_cohete(ANCHO // 2, 95, 2.2, fuego=True)     # alto: la llama no debe llegar al título
        elif e == 1:                                 # de camino: la Luna atrás, la Tierra adelante
            pygame.draw.circle(p, (196, 112, 74) if marte else (150, 151, 154), (150, 420), 70)
            pygame.draw.circle(p, tierra_agua, (800, 180), 90)
            pygame.draw.ellipse(p, tierra_suelo, (760, 140, 70, 50))
            for i in range(8):
                pygame.draw.circle(p, (200, 200, 210), (230 + i * 62, 380 - i * 26), 3)
            self._dibujar_cohete(480, 230, 0.8, fuego=True)
        elif e == 2:                                 # la Tierra de cerca
            pygame.draw.circle(p, tierra_agua, (ANCHO // 2, ALTO // 2 + 20), 220)
            for caja in ((330, 170, 160, 110), (520, 300, 120, 140), (400, 360, 90, 60)):
                pygame.draw.ellipse(p, tierra_suelo, caja)
            for caja in ((300, 250, 200, 26), (480, 210, 150, 22), (420, 420, 180, 24)):
                pygame.draw.ellipse(p, (235, 240, 245), caja)
        elif e == 3:                                 # llegada: cápsula con paracaídas sobre el mar
            p.fill((150, 200, 235))
            pygame.draw.rect(p, tierra_agua, (0, ALTO - 170, ANCHO, 170))
            pygame.draw.arc(p, (240, 240, 245), (ANCHO // 2 - 120, 90, 240, 160), 0, math.pi, 60)
            for dx in (-110, 0, 110):
                pygame.draw.line(p, (90, 90, 100), (ANCHO // 2 + dx, 170), (ANCHO // 2, 330), 2)
            pygame.draw.polygon(p, COLOR_NAVE, [(ANCHO // 2 - 34, 370), (ANCHO // 2 + 34, 370),
                                                (ANCHO // 2 + 22, 330), (ANCHO // 2 - 22, 330)])
            pygame.draw.polygon(p, COLOR_NAVE_DETALLE, [(ANCHO // 2 - 34, 370), (ANCHO // 2 + 34, 370),
                                                        (ANCHO // 2 + 22, 330), (ANCHO // 2 - 22, 330)], 2)
        if e < ESCENAS_FINAL:
            clave = "final_escena_0_marte" if marte and e == 0 else f"final_escena_{e}"
            self._texto_centrado(t(clave), self.fuente_grande, ALTO - 110)
            self._texto_centrado(t("final_continuar"), self.fuente, ALTO - 60)
            return
        tinta, suave = estilo.TINTA, estilo.TINTA_SUAVE
        estilo.panel(p, (40, 50, ANCHO - 80, ALTO - 100))
        self._texto_centrado(t("final_titulo"), self.fuente_grande, 105, tinta)
        estilo.separador(p, 80, ANCHO - 80, 138)
        dosis, _ = REFERENCIAS["dosis_msv"]
        moxie, _ = REFERENCIAS["moxie_g"]
        iss, _ = REFERENCIAS["iss_agua_pct"]
        filas = [
            (t("comp_dosis", tu=f"{self.astronauta.dosis_msv:.0f}", ref=dosis), REFERENCIAS["dosis_msv"][1]),
            (t("comp_oxigeno", tu=self.producido["oxigeno"] * GRAMOS_POR_UNIDAD_O2, ref=moxie),
             REFERENCIAS["moxie_g"][1]),
            (t("comp_agua", tu=self.producido["agua"], ref=iss), REFERENCIAS["iss_agua_pct"][1]),
            (t("comp_dias_marte" if marte else "comp_dias", n=self.clima.reloj.dia), True),
            (t("comp_contacto_si" if self.contacto_hecho else "comp_contacto_no"), True),
        ]
        y = 180
        for texto, fuente in filas:
            self._texto_centrado(texto, self.fuente, y, tinta)
            if fuente is None:
                self._texto_centrado(t("fuente_pendiente"), self.fuente_chica, y + 22, suave)
            y += 52
        self._texto_centrado(t("comp_simplificacion", g=GRAMOS_POR_UNIDAD_O2), self.fuente_chica, y, suave)
        estilo.separador(p, 80, ANCHO - 80, ALTO - 150)
        self._texto_centrado(t("final_reiniciar"), self.fuente, ALTO - 130, tinta)
        otro = t("lugar_luna" if marte else "lugar_marte")
        self._texto_centrado(t("final_otro_destino", lugar=otro), self.fuente, ALTO - 104, tinta)
        self._texto_centrado(t("final_menu_principal"), self.fuente, ALTO - 78, tinta)

    def _texto_centrado(self, texto, fuente, y, color=COLOR_TEXTO):
        for i, linea in enumerate(ajustar_texto(texto, fuente, ANCHO - 120)):
            imagen = fuente.render(linea, True, color)
            self.pantalla.blit(imagen, imagen.get_rect(center=(ANCHO // 2, y + i * fuente.get_linesize())))

    def dibujar_vitales(self):
        """Panel de 4 barras: oxígeno, energía, comida y radiación, cada una con su
        ícono. El borde de una barra se pone naranja cuando está baja y pulsa
        despacio (sin parpadear) cuando es crítica. El relleno se mueve suave."""
        pantalla = self.pantalla
        estilo.panel(pantalla, self.rect_vitales)
        x0 = self.rect_vitales.x + 10
        for i, barra in enumerate(BARRAS):
            y = self.rect_vitales.y + 6 + i * VITALES_FILA
            pantalla.blit(self.iconos_vitales[barra], (x0, y + 1))
            pantalla.blit(self.fuente_chica.render(t("barra_" + barra), True, estilo.TINTA),
                          (x0 + 22, y + 3))
            caja = pygame.Rect(x0 + 96, y + 1, 72, 16)
            nivel = self.astronauta.nivel_aviso(barra)
            if nivel == CRITICO:
                borde = estilo.mezclar(COLOR_AVISO, COLOR_AVISO_2, estilo.pulso())
            elif nivel == BAJO:
                borde = COLOR_AVISO
            else:
                borde = estilo.CONTORNO
            estilo.barra(pantalla, caja, self._barra_vista[barra], COLOR_BARRA[barra], borde)
            valor = (f"{self.astronauta.dosis_msv:.0f} mSv" if barra == DOSIS
                     else f"{self.astronauta.fraccion(barra) * 100:.0f}%")
            pantalla.blit(self.fuente_chica.render(valor, True, estilo.TINTA), (x0 + 174, y + 3))

    def dibujar_noche(self):
        """Velo oscuro y neutro sobre el mundo, más fuerte cuanto más cae la
        noche. De día (oscuridad 0) no se dibuja nada."""
        alfa = int(255 * OSCURIDAD_MAX * self.clima.reloj.oscuridad)
        if alfa <= 0:
            return
        self._velo.fill((*COLOR_NOCHE, alfa))
        self.pantalla.blit(self._velo, (0, 0))

    def dibujar_reloj(self):
        """Panel con el día, la hora, el momento del día y la temperatura. La
        temperatura lleva un cuadrito naranja con calor y celeste con frío."""
        reloj = self.clima.reloj
        estilo.panel(self.pantalla, self.rect_reloj)
        arriba = (f"{t('reloj_dia', n=reloj.dia)} · {reloj.hora_texto} · "
                  f"{t('momento_' + reloj.momento)}")
        grados = reloj.temperatura
        abajo = t("temperatura", t=f"{grados:.0f}")
        x, y = self.rect_reloj.x + 10, self.rect_reloj.y + 9
        self.pantalla.blit(self.fuente_chica.render(arriba, True, estilo.TINTA), (x, y))
        texto = self.fuente_chica.render(abajo, True, estilo.TINTA)
        self.pantalla.blit(texto, (x, y + 18))
        if abs(grados) >= TEMP_AVISO:           # calor o frío fuerte: una marca de color junto al número
            marca = pygame.Rect(x + texto.get_width() + 8, y + 20, 10, 10)
            pygame.draw.rect(self.pantalla, COLOR_CALOR if grados > 0 else COLOR_FRIO, marca, border_radius=2)
            pygame.draw.rect(self.pantalla, estilo.CONTORNO, marca, 1, border_radius=2)
        en_base, blindaje = self.proteccion()
        lugar = t("lugar_base" if en_base else "lugar_afuera", p=round(blindaje * 100))
        self.pantalla.blit(self.fuente_chica.render(lugar, True, estilo.TINTA_SUAVE), (x, y + 36))

    def dibujar_banner(self):
        """Aviso de tormenta solar con un dato real, su etiqueta y su fuente."""
        banner = self._banner()
        if not banner:
            return
        rect, lineas = banner
        borde = COLOR_MORADO if self.clima.fase == PARTICULAS else COLOR_AVISO
        estilo.panel(self.pantalla, rect, borde=borde)
        y = rect.y + 9
        for texto, fuente, color in lineas:
            self.pantalla.blit(fuente.render(texto, True, color), (rect.x + 14, y))
            y += fuente.get_linesize()

    def dibujar_fin(self):
        """Pantalla de muerte: tapa el juego y explica qué pasó y qué hacer."""
        if self.astronauta.vivo:
            return
        velo = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
        velo.fill((10, 10, 18, 200))
        self.pantalla.blit(velo, (0, 0))
        por_oxigeno = self.astronauta.causa_muerte == OXIGENO
        lineas = ajustar_texto(t("fin_rescate" if por_oxigeno else "fin_nueva"), self.fuente, ANCHO - 280)
        caja = pygame.Rect(0, 0, ANCHO - 200, 120 + len(lineas) * 26)
        caja.center = (ANCHO // 2, ALTO // 2 - 10)
        estilo.panel(self.pantalla, caja)
        titulo = self.fuente_grande.render(
            t("fin_oxigeno" if por_oxigeno else "fin_dosis"), True, estilo.TINTA)
        self.pantalla.blit(titulo, titulo.get_rect(center=(ANCHO // 2, caja.y + 46)))
        estilo.separador(self.pantalla, caja.x + 30, caja.right - 30, caja.y + 78)
        for i, linea in enumerate(lineas):
            imagen = self.fuente.render(linea, True, estilo.TINTA)
            self.pantalla.blit(imagen, imagen.get_rect(center=(ANCHO // 2, caja.y + 104 + i * 26)))

    def dibujar_resaltado(self):
        """Contorno del cuadro bajo el mouse: verde si está al alcance, rojo
        si no. Con el pico se resalta el área completa que se rompería."""
        cuadro = self.cuadro_bajo_mouse(pygame.mouse.get_pos())
        if cuadro is None:
            return
        fila, col = cuadro
        color = COLOR_ALCANZA if self.al_alcance(fila, col) else COLOR_LEJOS
        radio = 0
        cam_x, cam_y = self.camara
        lado = (2 * radio + 1) * TILE
        rect = pygame.Rect(
            pos_pantalla((col - radio) * TILE, cam_x, MAPA_ANCHO, ANCHO / 2),
            pos_pantalla((fila - radio) * TILE, cam_y, MAPA_ALTO, ALTO / 2),
            lado, lado)
        pygame.draw.rect(self.pantalla, color, rect, 2)

    def dibujar_mano(self):
        """Abajo a la izquierda: lo que lleva el astronauta en la mano (ícono,
        nombre y cuántos quedan). Ya no hay barra de herramientas. Encima del
        centro, el último mensaje."""
        pantalla = self.pantalla
        rect = self.rect_mano
        estilo.panel(pantalla, rect)
        caja = pygame.Rect(rect.x + 8, rect.centery - MANO_CASILLA // 2, MANO_CASILLA, MANO_CASILLA)
        estilo.casilla(pantalla, caja, activa=self.en_mano is not None)
        x = caja.right + 10
        pantalla.blit(self.fuente_mini.render(t("en_mano"), True, estilo.TINTA_SUAVE), (x, rect.y + 10))
        if self.en_mano is None:
            for i, linea in enumerate(ajustar_texto(t("en_mano_nada"), self.fuente_mini, rect.right - x - 6)):
                pantalla.blit(self.fuente_mini.render(linea, True, estilo.TINTA), (x, rect.y + 26 + i * 14))
        else:
            icono = self.iconos_objeto[self.en_mano]
            n = self.objetos[self.en_mano]
            pantalla.blit(icono, icono.get_rect(center=caja.center))
            color = estilo.TINTA if n else estilo.FALTA
            nombre = t("herr_" + self.en_mano)
            if self.en_mano == "cable":         # el cable muestra su color y cómo cambiarlo
                nombre += " · " + t("color_" + self.color_cable)
                self._muestra_color((caja.right - 8, caja.y + 8), self.color_cable, 7)
                pantalla.blit(self.fuente_mini.render(t("color_ayuda"), True, estilo.TINTA_SUAVE),
                              (x, rect.y + 42))
            pantalla.blit(self.fuente.render(nombre, True, estilo.TINTA), (x, rect.y + 22))
            numero = self.render_cantidad(self.fuente_chica, "x{n}", n, color)
            pantalla.blit(numero, numero.get_rect(topright=(rect.right - 10, rect.y + 10)))
        caja = self.rect_mensaje()
        if caja:
            texto = self.fuente.render(self.mensaje, True, estilo.TINTA)
            estilo.panel(pantalla, caja)
            pantalla.blit(texto, texto.get_rect(center=caja.center))

    def dibujar_rapida(self):
        """Las 5 casillas de acceso rápido: número arriba a la izquierda, ícono
        y cuántos quedan. La del objeto en la mano va resaltada."""
        pantalla = self.pantalla
        estilo.panel(pantalla, self.rect_rapida)
        sobre = (self.rapida_bajo_mouse(pygame.mouse.get_pos())
                 if not self.menu_visible and self.opciones is None else None)
        for i, objeto in enumerate(self.rapida):
            caja = self.rect_rapida_casilla(i)
            estilo.casilla(pantalla, caja, activa=objeto is not None and objeto == self.en_mano,
                           mouse=i == sobre)
            if objeto is not None:
                n = self.objetos[objeto]
                icono = self.iconos_objeto[objeto]
                if not n:                       # sin unidades: ícono apagado
                    icono = icono.copy()
                    icono.set_alpha(70)
                pantalla.blit(icono, icono.get_rect(center=(caja.centerx, caja.centery + 2)))
                numero = self.render_cantidad(self.fuente_mini, "{n}", n, estilo.TINTA if n else estilo.FALTA)
                pantalla.blit(numero, numero.get_rect(bottomright=(caja.right - 4, caja.bottom - 3)))
                if objeto == "cable":
                    self._muestra_color((caja.right - 9, caja.y + 9), self.color_cable, 6)
            tecla = self.fuente_mini.render(str(i + 1), True, estilo.TINTA_SUAVE)
            pantalla.blit(tecla, (caja.x + 5, caja.y + 4))

    def dibujar_vinetas(self):
        """Tiñe los bordes de la pantalla: morado mientras llega la radiación de
        una tormenta solar, azul oscuro con poco oxígeno. Aparecen y se van
        despacio (ver actualizar_pulido); nunca parpadean."""
        for nombre, imagen, tope in (("oxigeno", self._vineta_oxigeno, 190),
                                     ("radiacion", self._vineta_radiacion, 120)):
            fuerza = self._vinetas[nombre]
            if fuerza > 0.01:
                imagen.set_alpha(int(tope * fuerza))
                self.pantalla.blit(imagen, (0, 0))

    def dibujar_polvo(self):
        """Marte: velo color polvo sobre el mundo y rachas que cruzan la pantalla
        mientras dura la tormenta de polvo. Entra y sale despacio."""
        if self._polvo_velo <= 0.01:
            return
        self._velo.fill((*COLOR_VELO_POLVO, int(VELO_POLVO_MAX * self._polvo_velo)))
        self.pantalla.blit(self._velo, (0, 0))
        color = estilo.RACHA_POLVO
        for i in range(int(46 * self._polvo_velo)):
            # Cada racha tiene su altura y su velocidad fijas (salen de su número).
            velocidad = 260 + (i * 53) % 180
            x = (i * 137 + self._tiempo * velocidad) % (ANCHO + 80) - 40
            y = (i * 89) % ALTO + math.sin(self._tiempo * 1.3 + i) * 6
            largo = 14 + (i * 7) % 22
            pygame.draw.line(self.pantalla, color, (x, y), (x + largo, y + 2), 2)

    def rect_contacto(self):
        """Cartel "Tierra: en contacto" debajo del reloj (o del aviso de polvo), o None."""
        if not self.contacto:
            return None
        y = RELOJ_RECT[1] + RELOJ_RECT[3] + 6
        if self.polvo and self.polvo.fase != POLVO_EN_CALMA:
            y = POLVO_RECT[1] + POLVO_RECT[3] + 6
        return pygame.Rect(VITALES_RECT[0], y, VITALES_ANCHO, CONTACTO_RECT_ALTO)

    def dibujar_contacto(self):
        rect = self.rect_contacto()
        if rect is None:
            return
        estilo.panel(self.pantalla, rect, borde=estilo.ACENTO)
        icono = self.iconos_objeto["antena"]
        chico = pygame.transform.scale(icono, (20, 20))
        self.pantalla.blit(chico, (rect.x + 8, rect.y + 5))
        texto = self.fuente_chica.render(t("contacto_chip"), True, estilo.TINTA)
        self.pantalla.blit(texto, texto.get_rect(midleft=(rect.x + 34, rect.centery + 1)))

    def dibujar_aviso_polvo(self):
        """Marte: cartel bajo el reloj con la cuenta regresiva de la tormenta de polvo."""
        if not self.polvo or self.polvo.fase == POLVO_EN_CALMA:
            return
        segundos = math.ceil(self.polvo.segundos_restantes)
        clave = "polvo_aviso" if self.polvo.fase == POLVO_EN_AVISO else "polvo_activa"
        if self.polvo.tipo == "global":
            clave += "_global"
        estilo.panel(self.pantalla, self.rect_polvo, borde=COLOR_AVISO)
        if "polvo" not in self._iconos_evento:
            self._iconos_evento["polvo"] = icono_evento("polvo")
        self.pantalla.blit(self._iconos_evento["polvo"], (self.rect_polvo.x + 8, self.rect_polvo.y + 5))
        texto = self.fuente_chica.render(t(clave, s=segundos), True, estilo.TINTA)
        self.pantalla.blit(texto, texto.get_rect(midleft=(self.rect_polvo.x + 34, self.rect_polvo.centery + 1)))
