"""Partida de demostración en el juego (ronda 28): abrirla desde el menú
principal, mostrar los objetos como ilimitados (signo de infinito) y dibujar los
letreros del suelo de cada zona. Cómo se arma la demo está en demo.py.
"""

import os

import pygame

import demo
import estilo
from textos import t
from arte import ajustar_texto
from config import ALTO, ANCHO, TILE

# Color de la franja de cada zona: verde (básicos), ámbar (medios), teja (difíciles).
COLOR_ZONA = {"basicos": (70, 160, 105), "medios": (214, 150, 40), "dificiles": (196, 80, 64)}
NOTA_ANCHO = 5 * TILE             # ancho máximo de la explicación de un circuito (px)
LUZ_ESPERA = {True: (60, 190, 90), False: (210, 70, 60)}   # punto: debe funcionar / roto a propósito


def infinito(alto, color):
    """Signo de infinito dibujado (la letra de pygame no lo trae): dos aros que se
    tocan, dibujados 4 veces más grandes y achicados con suavizado (se leen bien chicos)."""
    k = 4
    r = alto * 0.42 * k                                  # radio de cada aro
    grueso = max(2, round(alto * 0.2)) * k
    grande = pygame.Surface((round(4 * r + grueso), round(2 * r + grueso)), pygame.SRCALPHA)
    cy = grande.get_height() / 2
    for cx in (grueso / 2 + r, grueso / 2 + 3 * r):
        pygame.draw.circle(grande, color, (cx, cy), r + grueso / 2, grueso)
    return pygame.transform.smoothscale(grande, (max(1, grande.get_width() // k), max(1, grande.get_height() // k)))


class DemoMixin:
    """Partida de demostración: abrirla, cantidades infinitas y letreros del suelo."""

    # ---- abrir la demo desde el menú principal -------------------------------------
    def abrir_demo(self, destino):
        """Carga partidas/demo_<destino>.json. Si no existe, la arma con demo.py y
        la guarda (así el archivo siempre está). Los 3 slots no se tocan."""
        ruta = demo.ruta(destino)
        if not os.path.exists(ruta):
            try:
                demo.construir(self, destino)
                demo.guardar(self, destino)
            except OSError:
                self.mensaje = t("partida_error_guardar")
        if self.cargar_partida(ruta):
            self.mensaje = t("demo_bienvenida")
            self.cerrar_opciones()
            return True
        return False

    # ---- cantidades: en la demo se ven como infinito ------------------------------
    def render_cantidad(self, fuente, plantilla, n, color):
        """Imagen de una cantidad ("x{n}" o "{n}"). En la demo, el número se cambia
        por el signo de infinito."""
        if not self.es_demo:
            return fuente.render(plantilla.format(n=n), True, color)
        antes = fuente.render(plantilla.format(n=""), True, color) if plantilla.format(n="") else None
        signo = infinito(max(8, fuente.get_height() - 4), color)
        ancho = (antes.get_width() + 1 if antes else 0) + signo.get_width()
        img = pygame.Surface((ancho, fuente.get_height()), pygame.SRCALPHA)
        if antes:
            img.blit(antes, (0, 0))
        img.blit(signo, signo.get_rect(midright=(ancho, fuente.get_height() // 2)))
        return img

    def texto_cantidad(self, n):
        """La cantidad para un texto: el número, o "ilimitado" en la demo."""
        return t("demo_ilimitado") if self.es_demo else n

    # ---- letreros del suelo --------------------------------------------------------
    def dibujar_letreros(self, xs, ys):
        """Los letreros pintados en el suelo (solo la demo los tiene): el cartel de
        cada zona y la explicación de cada circuito."""
        p = self.pantalla
        for f, c, clave, tipo, zona, espera in self.letreros:
            x, y = xs[c % len(xs)], ys[f % len(ys)]
            if not (-6 * TILE < x < ANCHO and -TILE < y < ALTO):
                continue
            color = COLOR_ZONA.get(zona, estilo.ACENTO)
            if tipo == "zona":
                texto = self.fuente_grande.render(t(clave), True, estilo.TINTA)
                caja = pygame.Rect(x + 4, y + 4, texto.get_width() + 34, TILE - 8)
                lineas = None
            else:
                lineas = ajustar_texto(t(clave), self.fuente_chica, NOTA_ANCHO)[:2]
                alto = len(lineas) * self.fuente_chica.get_linesize() + 8
                ancho = max(self.fuente_chica.size(l)[0] for l in lineas) + 24
                caja = pygame.Rect(x + 4, y + 4, ancho, alto)        # debajo de su circuito
            fondo = pygame.Surface(caja.size, pygame.SRCALPHA)
            pygame.draw.rect(fondo, (*estilo.PANEL, 225), fondo.get_rect(), border_radius=5)
            p.blit(fondo, caja)
            pygame.draw.rect(p, estilo.CONTORNO, caja, 2, border_radius=5)
            pygame.draw.rect(p, color, (caja.x + 2, caja.y + 2, 8, caja.h - 4),
                             border_top_left_radius=4, border_bottom_left_radius=4)
            if lineas is None:
                p.blit(texto, texto.get_rect(midleft=(caja.x + 20, caja.centery + 1)))
                continue
            ty = caja.y + 4
            for linea in lineas:
                p.blit(self.fuente_chica.render(linea, True, estilo.TINTA), (caja.x + 16, ty))
                ty += self.fuente_chica.get_linesize()
            if espera is not None:                   # punto: verde = funciona, rojo = roto a propósito
                centro = (caja.right - 1, caja.y + 1)
                pygame.draw.circle(p, estilo.CONTORNO, centro, 6)
                pygame.draw.circle(p, LUZ_ESPERA[espera], centro, 4)
