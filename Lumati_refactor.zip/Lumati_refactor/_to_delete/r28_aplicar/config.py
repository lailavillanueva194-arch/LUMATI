"""Configuración de Lumati: todas las constantes del juego (tamaños, colores, balance,
teclas de arte, rectángulos de la interfaz, menús). Solo valores: no hay lógica.
"""

import os

import maquinas
from clima import CME_EN_CAMINO, LLAMARADA, PARTICULAS
from maquinas import CASILLAS, COSTO_CONSTRUIR
from supervivencia import BARRAS, COMIDA, DOSIS, ENERGIA, OXIGENO


# --------------------------------------------------------------------------
# Configuración (valores que se pueden ajustar)
# --------------------------------------------------------------------------
ANCHO, ALTO = 960, 640          # tamaño de la ventana en píxeles
FPS = 60

TILE = 48                       # lado de un cuadro en pantalla (16 px x3 cuando haya arte)
COLUMNAS, FILAS = 32, 32        # tamaño del mapa en cuadros
MAPA_ANCHO = COLUMNAS * TILE    # 1536 px
MAPA_ALTO = FILAS * TILE        # 1536 px
# La ventana (960x640) muestra menos de 32 cuadros por lado: así nunca se ve
# el mapa repetido.

# Tipos de cuadro
SUELO = 0
ROCA = 1
CABLE = 2                       # cable sobre el suelo (se puede caminar encima)
TALADRO = 3                     # máquina: ocupa un cuadro y bloquea el paso
GENERADOR = 4                   # panel solar: fuente de energía, bloquea el paso
BLOQUE = 5                      # bloque de regolito: blindaje contra la radiación, bloquea el paso
BASE = 6                        # piso de la base: se camina encima y protege
NAVE = 7                        # la nave para volver a la Tierra (bloquea el paso)
PURIFICADOR = 8                 # hielo -> agua
ELECTROLIZADOR = 9              # agua -> oxígeno + hidrógeno (al tanque pegado)
TANQUE = 10                     # tanque de hidrógeno
INVERNADERO = 11                # agua -> comida
CRAFTEO = 12                    # el Fabricador: máquina de crafteo fija junto a la nave
ANTENA = 13                     # antena de comunicación: con energía, contacto con la Tierra
PICADO = 14                     # suelo picado con el pico: ahí se pone un taladro (se camina encima)
CAMINO = 15                     # camino decorativo hecho con el pico (se camina encima)
# Pico: cada clic cambia el suelo en este orden (suelo -> picado -> camino -> suelo).
CICLO_PICO = {0: PICADO, PICADO: CAMINO, CAMINO: 0}
BATERIA = 16                    # batería / panel de control: guarda energía y la reparte
TANQUE_AGUA = 17                # tanque de agua: guarda agua y la pasa a las máquinas pegadas
SOLIDOS = {ROCA, TALADRO, GENERADOR, BLOQUE, NAVE,
           PURIFICADOR, ELECTROLIZADOR, TANQUE, INVERNADERO, CRAFTEO, ANTENA, BATERIA, TANQUE_AGUA}   # tipos que bloquean el paso
# Máquinas nuevas: tipo de cuadro -> nombre en maquinas.py (y en textos.py, "herr_" + nombre)
MAQUINAS = {PURIFICADOR: maquinas.PURIFICADOR, ELECTROLIZADOR: maquinas.ELECTROLIZADOR,
            TANQUE: maquinas.TANQUE, INVERNADERO: maquinas.INVERNADERO}
CON_ENERGIA = {TALADRO, PURIFICADOR, ELECTROLIZADOR, INVERNADERO, ANTENA}   # se conectan a un cable
# Estructuras fijas de 2x2 cuadros en la zona de inicio: (fila, columna) de la esquina
# de arriba a la izquierda. El astronauta empieza en el cuadro (16, 16), entre las dos.
BASE_POS = (14, 14)
NAVE_POS = (17, 17)
CRAFTEO_POS = (14, 17)          # el Fabricador (1 cuadro), arriba de la nave y a la derecha de la base
ESTRUCTURA_LADO = 2             # la base mide 2x2 cuadros
NAVE_LADO = 3                   # la nave es más grande: 3x3 cuadros (su esquina NAVE_POS)
NAVE_ESCALA = 6                 # píxeles de pantalla por píxel de su dibujo. El mundo va a x3: con x6 cada
                                # píxel de la nave mide justo 2x2 del mundo y no desentona
# Blindaje (0 a 1, cuánto frena la radiación). Dentro de la base protege casi todo;
# afuera, cada bloque de regolito en los 8 cuadros de alrededor suma un poco.
BLINDAJE_BASE = 0.8
BLINDAJE_POR_BLOQUE = 0.12
BLINDAJE_MAX = 0.95

ALCANCE = 4                     # distancia máxima de uso, en cuadros

# Destino de la misión. La Luna es el juego principal. Marte reutiliza todo y solo
# cambia el color del suelo, la temperatura y agrega las tormentas de polvo.
LUNA, MARTE = "luna", "marte"
DESTINO_INICIAL = LUNA          # para empezar en Marte: python main.py marte

# Pulido visual (solo adorno: nada de esto cambia las reglas del juego)
CAMARA_SUAVE = 12.0             # qué tan rápido alcanza la cámara al astronauta (0 = pegada, como antes)
CAMARA_SALTO = 3 * 48           # si el astronauta está más lejos que esto (rescate), la cámara salta
POLVO_CADA = 0.12               # segundos entre soplos de polvo al caminar
# Objetos que se fabrican en el Fabricador y se colocan en el mapa, en el orden en
# que salen en el inventario y en el Fabricador (nombre en textos.py: "herr_" + nombre).
# Ya no hay barra de herramientas: es supervivencia, lo que se pone primero se fabrica.
OBJETOS = ["cable", "taladro", "generador", maquinas.BLOQUE, maquinas.PURIFICADOR,
           maquinas.ELECTROLIZADOR, maquinas.TANQUE, maquinas.INVERNADERO, "antena", "bateria", "tanque_agua", "regadera", "pico",
           "companero"]                    # ronda 27: el compañero robot (se fabrica; no es un cuadro del mapa)
# Herramientas de mano: no se colocan ni se fabrican, se usan (la regadera riega).
HERRAMIENTAS_MANO = {"regadera", "pico"}
FABRICABLES = [o for o in OBJETOS if o not in HERRAMIENTAS_MANO]
# objeto -> tipo de cuadro que pone en el mapa
OBJETO_TIPO = {"cable": CABLE, "taladro": TALADRO, "generador": GENERADOR,
               maquinas.BLOQUE: BLOQUE, maquinas.PURIFICADOR: PURIFICADOR,
               maquinas.ELECTROLIZADOR: ELECTROLIZADOR, maquinas.TANQUE: TANQUE,
               maquinas.INVERNADERO: INVERNADERO, "antena": ANTENA, "bateria": BATERIA,
               "tanque_agua": TANQUE_AGUA}
TIPO_OBJETO = {tipo: nombre for nombre, tipo in OBJETO_TIPO.items()}
# Lo que cuesta fabricar cada objeto. Los costos son los MISMOS de antes
# (maquinas.COSTO_CONSTRUIR); cable, taladro y panel solar ya eran gratis y lo
# siguen siendo. BALANCE: si quieres que cuesten, ponles un costo aquí.
# Antena (ronda 4): BALANCE provisional, ajústalo aquí. Pide metal valioso, que sale
# del taladro de nivel 2: es un objetivo de mitad de partida.
# Ronda 27: más cara (antes {"hierro": 4, "metal": 2}): ahora pide también cristal raro,
# que solo saca el taladro de nivel 3. BALANCE provisional.
COSTO_ANTENA = {"hierro": 8, "metal": 5, "cristal": 2}
# Batería (panel de control de las diseñadoras): se carga mientras su red tiene un
# panel solar activo y da energía a su red cuando los paneles no rinden (noche o
# polvo). BALANCE provisional: ajústalo aquí.
COSTO_BATERIA = {"hierro": 3, "regolito": 2}
# Tanque de agua: guarda hasta AGUA_MAX. Recibe el agua de un purificador pegado y
# se la pasa sola al electrolizador o invernadero pegados (sin energía: es pasivo).
# Clic: si llevas agua la guarda; si no, te da agua. BALANCE provisional.
COSTO_TANQUE_AGUA = {"hierro": 2, "regolito": 2}
AGUA_MAX = 20
BATERIA_MAX = 90.0              # segundos de energía que guarda llena
BATERIA_CARGA = 1.5             # segundos de energía que gana por segundo con sol
NOCHE_APAGA_PANELES = True      # de noche los paneles no rinden (False: como antes)
LUZ_MINIMA_PANEL = 0.15         # con menos luz que esto (0 a 1) el panel no da energía
# Compañero (ronda 27): robot que te sigue con un cofre. BALANCE provisional: pide metal
# (taladro de nivel 2), así es un objetivo de mitad de partida.
COSTO_COMPANERO = {"hierro": 6, "metal": 3, "regolito": 4}
COSTO_FABRICAR = {**{nombre: {} for nombre in ("cable", "taladro", "generador")}, **COSTO_CONSTRUIR,
                  "antena": COSTO_ANTENA, "bateria": COSTO_BATERIA,
                  "tanque_agua": COSTO_TANQUE_AGUA, "companero": COSTO_COMPANERO}
ANTENA_CADA = 40.0              # segundos entre mensajes de la Tierra mientras hay contacto
ANTENA_PRIMERO = 4.0            # el primer mensaje llega poco después del contacto
FABRICA_CANTIDAD = {"cable": 5}  # unidades que salen por fabricación (el cable sale en tramos de 5)
# Con lo que empieza el astronauta: lo justo para el primer circuito (taladro
# básico + panel solar + cables). Todo lo demás se fabrica.
OBJETOS_INICIALES = {"taladro": 1, "generador": 1, "cable": 5, "regadera": 1, "pico": 1,
                     maquinas.INVERNADERO: 1}          # una maceta para el primer cultivo
AGUA_INICIAL = 3                # agua con la que empieza (para la primera regada)

DENSIDAD_ROCAS = 0.0            # fracción de cuadros que son roca (0: mapa despejado; los
                                # recursos salen de los taladros, ver maquinas.BOTIN)
SEMILLA = 7                     # misma semilla = mismo mapa en cada partida

JUGADOR_TAM = 24                # lado de la caja de colisión (menor que TILE
                                # para poder pasar entre rocas vecinas)
JUGADOR_VEL = 180               # píxeles por segundo
DT_MAX = 0.05                   # tope del paso de tiempo (evita "teletransportes")
EPS = 0.001                     # margen para que tocar un borde no cuente como choque

# Textura del suelo: una imagen de 64x64 px que se parte en 4x4 trozos de
# 16x16. Cada cuadro del mapa usa el trozo (columna % 4, fila % 4), así los
# cráteres quedan completos y el patrón encaja con el mapa que da la vuelta
# (32 es múltiplo de 4).
CARPETA = os.path.dirname(os.path.abspath(__file__))
TEXTURA_SUELO = os.path.join(CARPETA, "assets", "suelo_luna.png")
TEXTURA_CUADROS = 4             # cada variante mide 4x4 cuadros
TEXTURA_VARIANTES = 4           # el PNG es una tira con 4 variantes una al lado de otra
SEMILLA_SUELO = SEMILLA + 1     # semilla del sorteo de variantes (mismo piso en cada partida)
SUELO_PROCEDURAL = True         # True: piso generado por suelo.py; False: el PNG de los diseñadores (assets/suelo_luna.png)
SUELO_VARIANTES = 16            # cuántas variantes genera suelo.py: 4 de cada tipo de terreno (la tira del PNG trae 4)

# Astronauta: una tira de cuadros de 32x32 px, uno al lado del otro, tal como la
# exportó la diseñadora (assets/astronauta.png). Aquí se dice qué cuadros son de
# cada dirección, en el orden de la animación. El último cuadro de la tira (10)
# está vacío y no se usa. Si el PNG falta, se dibuja un cuadrito amarillo.
ASTRONAUTA_PNG = os.path.join(CARPETA, "assets", "astronauta.png")
ASTRONAUTA_LADO = 32            # lado de cada cuadro de la tira, en píxeles del PNG
ASTRONAUTA_ESCALA = 3           # igual que el resto del arte (16 px -> 48); mide ~1.7 cuadros
ASTRONAUTA_CUADROS = {          # dirección -> índices de cuadro; el primero es el de quieto
    "derecha": [0, 1],          # mira a la derecha (confirmado jugando; el visor se ve desplazado a la izquierda)
    "izquierda": [2, 3],        # espejo del anterior, dibujado aparte
    "abajo": [4, 5, 6],         # de frente
    "arriba": [7, 8, 9],        # de espaldas (casco sin visor)
}
ASTRONAUTA_FPS = 6              # cuadros de caminata por segundo (el 2 de Piskel es solo su vista previa)
ASTRONAUTA_BANDA_CASCO = 12     # filas desde la cabeza con las que se centra cada cuadro

COLOR_FONDO = (10, 10, 18)
COLOR_SUELO_A = (150, 150, 156)
COLOR_SUELO_B = (144, 144, 150)  # tono apenas distinto para ver la cuadrícula
COLOR_ROCA = (168, 162, 180)      # más clara que el suelo texturizado (~84,80,80)
COLOR_ROCA_BORDE = (46, 44, 54)   # contorno oscuro para que se lea sobre los cráteres
COLOR_CABLE = (205, 140, 60)    # cobre (solo para íconos de respaldo); cada cable tiene su color
COLOR_CABLE_BORDE = (92, 56, 30)      # contorno oscuro del cable
COLOR_CABLE_BRILLO = (240, 190, 120)  # brillo fino encima del cable
# Colores de cable: cada color es su propio circuito (no se conectan entre sí; las
# máquinas y paneles sí toman cable de cualquier color). Ninguno es rojo (luz de
# apagado) ni azul oscuro (poco oxígeno). Además del color llevan un PATRÓN, para
# quien no distingue colores: verde liso, azul con rayas, amarillo con puntos.
CABLE_COLORES = ["verde", "azul", "amarillo"]
# Piezas especiales (ronda 11), se eligen con C igual que los colores y se giran con R:
#  - cable negro (troncal): une cables de CUALQUIER color, pero solo en la dirección
#    elegida (horizontal o vertical). Lleva toda la electricidad en esa línea.
#  - conectores +, T y L: neutros, unen cualquier color, solo por los lados de su forma.
CABLE_PIEZAS = {"negro": "negro", "con_mas": "+", "con_t": "T", "con_l": "L"}
OPCIONES_CABLE = CABLE_COLORES + list(CABLE_PIEZAS)
# Lados de cada forma sin girar; girar 1 vez = 90 grados en el sentido del reloj.
LADOS_FORMA = {"negro": ("izq", "der"), "+": ("arr", "der", "aba", "izq"),
               "T": ("izq", "der", "aba"), "L": ("arr", "der")}
GIRO = {"arr": "der", "der": "aba", "aba": "izq", "izq": "arr"}
OPUESTO = {"arr": "aba", "aba": "arr", "izq": "der", "der": "izq"}
DIRECCION = {"arr": (-1, 0), "aba": (1, 0), "izq": (0, -1), "der": (0, 1)}
COLOR_CABLE_DE = {"verde": (70, 175, 115), "azul": (88, 156, 228), "amarillo": (232, 198, 58),
                  "negro": (44, 44, 50), "conector": (206, 210, 218)}
COLOR_CABLE_BORDE_DE = {"verde": (24, 74, 46), "azul": (30, 62, 108), "amarillo": (104, 82, 18),
                        "negro": (8, 8, 10), "conector": (78, 84, 96)}
COLOR_CABLE_BRILLO_DE = {"verde": (170, 230, 190), "azul": (190, 220, 250), "amarillo": (252, 236, 170),
                         "negro": (110, 110, 122), "conector": (245, 246, 250)}
PATRON_CABLE = {"verde": "liso", "azul": "rayas", "amarillo": "puntos", "negro": "liso", "conector": "liso"}
CABLE_GROSOR = 8                # grosor del cable en píxeles
# Cables flexibles (solo se ven distinto: la red de energía es la misma de siempre,
# un cable por cuadro). Cada tramo entre dos cuadros es una curva con holgura y el
# centro de cada cable es un "nodo" con un resorte amortiguado: si el astronauta
# camina encima o se pone/quita un cable vecino, el nodo se mueve y se asienta solo.
CABLE_FISICA = True             # False: cables rectos como antes
# Ronda 4: menos elásticos (menos holgura, resorte más duro y más freno: se mueven
# poco y se asientan en ~1 s). Valores anteriores entre paréntesis.
CABLE_HOLGURA = 2.5             # cuánto se curva cada tramo, en píxeles (5.0)
CABLE_RESORTE = 150.0           # qué tan fuerte regresa el nodo a su lugar (60)
CABLE_FRENO = 16.0              # amortiguación: qué tan rápido deja de balancearse (4)
CABLE_ACOPLE = 20.0             # cuánto jala cada nodo a sus vecinos (la onda viaja por el cable) (25)
CABLE_MAX = 5.0                 # desplazamiento máximo de un nodo, en píxeles (10)
CABLE_PISAR = 450.0             # empuje al caminar encima (px/s² en la dirección del paso) (900)
CABLE_SACUDIDA = 70.0           # empujón al poner o quitar un cable vecino (px/s) (140)
CABLE_PUNTOS = 6                # puntos por medio tramo al dibujar la curva
COLOR_TALADRO = (120, 134, 150)       # gris azulado claro (nada de azul oscuro)
COLOR_TALADRO_BORDE = (40, 46, 58)
COLOR_LUZ_ON = (70, 220, 100)         # verde = máquina encendida
COLOR_LUZ_OFF = (225, 60, 60)         # rojo = máquina apagada
COLOR_PANEL_SOLAR = (150, 158, 172)   # marco del panel solar (nada de azul oscuro)
COLOR_CELDA_SOLAR = (232, 206, 96)    # celdas del panel, provisional
COLOR_TALADRO_NIVEL = {1: (120, 134, 150), 2: (150, 166, 184), 3: (186, 202, 220)}

SEMILLA_BOTIN = SEMILLA + 2      # azar de lo que sacan los taladros (igual en cada partida)
# Colores de los recursos (inventario y almacén de los taladros), provisionales.
# Ninguno es morado (radiación), ni el amarillo del jugador, ni rojo/verde (luces).
COLOR_RECURSO = {
    "regolito": (150, 146, 140),
    "hielo": (200, 235, 250),       # blanco-azulado, brillante
    "hierro": (150, 88, 58),        # óxido
    "metal": (225, 200, 110),       # dorado pálido
    "cristal": (235, 120, 180),     # rosa
    "agua": (120, 200, 235),        # celeste claro (nada de azul oscuro)
}
COLOR_JUGADOR = (255, 204, 0)

COLOR_ALCANZA = (80, 230, 110)   # resaltado verde: está al alcance
COLOR_LEJOS = (230, 80, 80)      # resaltado rojo: fuera de alcance
# Los colores de paneles, casillas y texto de la interfaz están en estilo.py (paleta única).
COLOR_TEXTO = (235, 235, 240)

# Ya no hay barra de herramientas. Abajo a la izquierda, un recuadro chico dice
# qué lleva el astronauta en la mano (clic en él abre el inventario).
MANO_RECT = (8, ALTO - 8 - 58, 210, 58)
MANO_CASILLA = 42               # lado de la casilla del ícono dentro del recuadro
ICONO_OBJETO = 32               # lado de los íconos de objetos, en píxeles de pantalla
# Acceso rápido: 5 casillas abajo al centro. Las teclas 1 a 5 ponen en la mano
# lo que tenga cada una. No es una barra de construcción: solo guarda atajos a
# objetos que ya fabricaste (sin unidades, la casilla se ve apagada).
RAPIDA_N = 5
RAPIDA_CASILLA, RAPIDA_SEP, RAPIDA_MARGEN = 48, 6, 8
_RAPIDA_ANCHO = RAPIDA_N * RAPIDA_CASILLA + (RAPIDA_N - 1) * RAPIDA_SEP + 2 * RAPIDA_MARGEN
_RAPIDA_ALTO = RAPIDA_CASILLA + 2 * RAPIDA_MARGEN
RAPIDA_RECT = ((ANCHO - _RAPIDA_ANCHO) // 2, ALTO - 8 - _RAPIDA_ALTO, _RAPIDA_ANCHO, _RAPIDA_ALTO)
RAPIDA_INICIAL = ["pico", "taladro", "cable", "generador", "regadera"]   # lo que trae al empezar
MENSAJE_ABAJO = RAPIDA_RECT[1] - 6   # los mensajes salen justo encima del acceso rápido
MENSAJE_SEGUNDOS = 3.0          # cuánto se queda visible un mensaje
# Fabricador (menú de crafteo): una fila por objeto, centrado.
CRAFTEO_ANCHO, CRAFTEO_FILA, CRAFTEO_TITULO = 600, 48, 52
# Inventario: arriba a la izquierda solo hay una etiqueta "[E] Inventario 7/21"
# (ancho <= 200 px: más ancho y el aviso de tormenta, de 520 px y centrado entre
# ella y las barras, se encimaría). Con E (o un clic en la etiqueta) se abre el
# menú con las CASILLAS (21) en 3 filas de 7, en el centro de la pantalla.
INVENTARIO_RECT = (8, 8, 160, 28)           # la etiqueta
INV_COLUMNAS = 7
INV_FILAS = CASILLAS // INV_COLUMNAS
MENU_CASILLA, MENU_SEPARACION, MENU_MARGEN = 72, 8, 20
MENU_TITULO, MENU_DETALLE = 44, 148         # alto de la franja del título y de la parte de abajo
MENU_HUECO = 6                              # espacio entre el panel de casillas y el panel de abajo
MENU_ABAJO = 150                            # alto del panel de abajo (astronauta, equipo y misión)
MENU_ANCHO = 2 * MENU_MARGEN + INV_COLUMNAS * MENU_CASILLA + (INV_COLUMNAS - 1) * MENU_SEPARACION
MENU_ALTO = (MENU_TITULO + INV_FILAS * MENU_CASILLA + (INV_FILAS - 1) * MENU_SEPARACION
             + MENU_DETALLE + MENU_MARGEN)
MENU_RECT = ((ANCHO - MENU_ANCHO) // 2, (ALTO - MENU_ALTO) // 2 - 24, MENU_ANCHO, MENU_ALTO)
OBJ_COLUMNAS, OBJ_PASO, OBJ_CASILLA = 7, 40, 37   # objetos y herramientas en el menú: 2 filas de 6 (caben 12)
MENU_ATENUAR = 110              # cuánto se oscurece el juego detrás del menú (0 a 255): gris neutro, nada azulado

# Panel de las 4 barras vitales, arriba a la derecha.
VITALES_ANCHO, VITALES_FILA = 250, 24
VITALES_RECT = (ANCHO - 8 - VITALES_ANCHO, 8, VITALES_ANCHO, 8 + len(BARRAS) * VITALES_FILA)
# Colores de las barras: morado SOLO para la radiación; nada de azul oscuro
# (significa poco oxígeno) ni rojo/verde (luces de máquinas). Provisionales.
COLOR_BARRA = {OXIGENO: (110, 205, 245), ENERGIA: (235, 225, 90),
               COMIDA: (190, 135, 80), DOSIS: (175, 95, 225)}
COLOR_AVISO = (255, 170, 40)    # borde de una barra baja (naranja)
COLOR_AVISO_2 = (255, 255, 255) # el borde crítico pulsa despacio entre naranja y blanco
COLOR_MORADO = (150, 70, 210)   # borde del aviso mientras llegan las partículas

# Reloj y temperatura: debajo de las barras vitales, arriba a la derecha.
RELOJ_RECT = (VITALES_RECT[0], VITALES_RECT[1] + VITALES_RECT[3] + 6, VITALES_ANCHO, 68)
# Aviso de tormenta de polvo (solo Marte): debajo del reloj.
POLVO_RECT = (RELOJ_RECT[0], RELOJ_RECT[1] + RELOJ_RECT[3] + 6, VITALES_ANCHO, 30)
# Minimapa (ronda 18): todo el mapa de 32x32, 3 px por cuadro, centrado en el
# astronauta (el mapa da la vuelta). Tecla TAB lo muestra u oculta.
MINIMAPA_ESCALA = 3
_MINI = 32 * MINIMAPA_ESCALA
MINIMAPA_RECT = (8, 8 + 28 + 6, _MINI + 12, _MINI + 26)   # arriba a la izquierda, bajo la etiqueta del inventario
MINIMAPA_CADA = 0.3             # segundos entre redibujos del minimapa
COLOR_VELO_POLVO = (196, 128, 84)       # velo de la tormenta de polvo
VELO_POLVO_MAX = 95                     # qué tanto tapa (0 a 255)
# Viñetas: el borde de la pantalla se tiñe despacio. Morado = radiación de una
# tormenta solar; azul oscuro = poco oxígeno (los mismos significados de siempre).
COLOR_VINETA_RADIACION = (150, 70, 210)
COLOR_VINETA_OXIGENO = (16, 26, 70)
VINETA_VELOCIDAD = 1.5                  # qué tan rápido aparece y se va (por segundo)
# Noche: un velo gris casi negro y neutro sobre el mundo (nada de azul: el azul
# oscuro significa "poco oxígeno"). No llega a negro para que se pueda jugar.
OSCURIDAD_MAX = 0.62            # 0 = nunca oscurece, 1 = negro total
COLOR_NOCHE = (6, 6, 9)
COLOR_CALOR = (255, 170, 40)    # temperatura de 50 °C o más (naranja)
COLOR_FRIO = (150, 225, 245)    # temperatura de -50 °C o menos (celeste claro)
TEMP_AVISO = 50.0

# Aviso de tormenta solar: arriba, entre el inventario y las barras. Cada fase
# muestra un dato real con su etiqueta y su fuente (ids de datos.py).
BANNER_ANCHO = 520
DATO_POR_FASE = {LLAMARADA: "llamarada_cadena", CME_EN_CAMINO: "cme_escala",
                 PARTICULAS: "let_hierro_silicio"}

# Marte (ronda 20): la misma cadena solar, con datos de Marte en el aviso.
DATO_POR_FASE_MARTE = {LLAMARADA: "llamarada_cadena", CME_EN_CAMINO: "marte_cme_viaje",
                       PARTICULAS: "marte_sep"}

# Dato real que aparece la primera vez que pasa algo (ids de datos.py).
DATO_SEGUNDOS = 9.0
DATO_ANCHO = 560

# Eventos de Marte (ronda 20). Los números de los eventos (frecuencias, duraciones,
# magnitudes) están en eventos_marte.py; aquí solo lo que es de dibujo.
CHIP_EVENTO_SEGUNDOS = 5.0      # cuánto se ve el aviso corto con ícono (bajo el reloj)
CHIP_EVENTO_ALTO = 30
SACUDIDA_ACTIVA = True          # accesibilidad: False = los sismos no mueven la cámara
SACUDIDA_HZ = 4.0               # sacudida lenta y suave (no es un parpadeo)
REMOLINO_VEL = (70.0, 110.0)    # píxeles por segundo con que cruza la pantalla
COLOR_REMOLINO = (240, 204, 166)
COLOR_CRATER_BORDE = (214, 150, 110)
COLOR_CRATER_FONDO = (104, 54, 38)
COLOR_HIELO_CRATER = (226, 242, 252)
PANEL_POLVO_SUBE = 0.25         # qué tan rápido se cubre de polvo un panel en la tormenta (por s)
PANEL_POLVO_BAJA = 1 / 40.0     # y qué tan rápido se ve limpio otra vez (solo adorno)

# Construcciones nuevas, en color plano hasta que lleguen los PNG.
COLOR_BLOQUE = (132, 128, 120)
COLOR_BLOQUE_CLARO = (160, 156, 148)
COLOR_BASE_PISO = (96, 100, 110)
COLOR_BASE_BORDE = (190, 196, 206)
COLOR_NAVE = (205, 208, 214)
COLOR_NAVE_DETALLE = (110, 116, 128)
COLOR_FUEGO = (255, 170, 40)
COLOR_MAQUINA = {PURIFICADOR: (150, 170, 178), ELECTROLIZADOR: (170, 160, 186),
                 TANQUE: (178, 178, 170), INVERNADERO: (150, 168, 120)}
COLOR_HOJA = (130, 175, 80)
COLOR_HIDROGENO = (240, 240, 250)
COLOR_SALIDA = {"agua": (120, 200, 235), "oxigeno": (110, 205, 245), "comida": (190, 135, 80)}
# Lo que lleva sombra suave debajo (para que se despegue del piso).
CON_SOMBRA = {ROCA, TALADRO, GENERADOR, BLOQUE, PURIFICADOR, ELECTROLIZADOR, TANQUE, INVERNADERO, CRAFTEO,
              ANTENA, BATERIA, TANQUE_AGUA}
COLOR_ANTENA = (206, 212, 222)          # antena: blanco de estación
CONTACTO_RECT_ALTO = 30                 # cartel "Tierra: en contacto", debajo del reloj
COLOR_FABRICADOR = (214, 220, 228)      # cuerpo del Fabricador (blanco de estación)

# Base por dentro (ronda 4): una sala vista desde arriba, en coordenadas de pantalla
# (no da la vuelta como el mapa). Se entra con clic en la base y se sale por la puerta.
ESCENA_MAPA, ESCENA_BASE = "mapa", "base"
SALA_RECT = (40, 92, 624, 384)          # la sala completa (paredes incluidas): 13 x 8 cuadros; a la
                                        # izquierda para que no la tapen las barras ni el reloj
SALA_PARED = 18                         # grosor de las paredes
ALCANCE_MUEBLE = 70                     # distancia máxima (px) del astronauta a un mueble para usarlo
COLOR_PISO_SALA = (226, 231, 237)
COLOR_JUNTA_SALA = (212, 218, 226)      # líneas del piso
COLOR_COBIJA = (178, 210, 228)          # cobija de la cama (cian pálido)
# Almacén de la base: casillas aparte de la mochila (BALANCE: ajústalo aquí).
ALMACEN_CASILLAS = 12
ALMACEN_PILA = 20                       # unidades por casilla (el doble que la mochila)
# Dormir: solo de noche; se despierta a esta hora.
HORA_DORMIR, HORA_DESPERTAR = 18.0, 6.0
FUNDIDO_SEGUNDOS = 0.8                  # lo que tarda la pantalla en oscurecer y aclarar (suave)
DORMIR_PASO = 0.5                       # al dormir, el mundo avanza en pasos de 0.5 s (las máquinas trabajan)
# Partida guardada: un JSON junto a main.py (F5 guarda, F9 carga, o la terminal de la base).
# Ronda 21: ya no se escribe aquí; se usan ranuras en partidas/ (ver partidas.py). Este
# archivo viejo solo se copia a una ranura la primera vez que se abre el juego.
PARTIDA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "partida_lumati.json")
# Menú de opciones (ronda 21): panel principal, guía y lista de partidas.
OPCIONES_RECT = (0, 0, 380, 452)            # (ronda 21; ya no se dibuja: ahora son tarjetas sueltas)
# Ronda 22: cada opción es una tarjeta flotante aparte, en una columna al centro.
TARJETA_ANCHO, TARJETA_ALTO, TARJETA_SEP = 360, 58, 16
TARJETA_ARRIBA = 214                        # y de la primera tarjeta
TARJETA_FLOTA = 3.0                         # píxeles que sube y baja cada tarjeta (escalonado, lento)
TARJETA_RESALTE_VEL = 7.0                   # qué tan rápido crece al pasar el mouse (por segundo)
COLOR_TEXTO_CIELO = (206, 212, 224)         # texto claro sobre el espacio del menú
OPCIONES_GRANDE = (0, 0, 820, 560)          # guía y partidas
GUIA_SECCIONES = ("objetivo", "controles", "energia", "recursos", "agua", "comida", "base", "peligros")
# Ronda 25: la pantalla de Partidas son 3 tarjetas (slots) lado a lado.
SLOT_ARRIBA = 92                            # y de las tarjetas (arriba van el título y la ayuda)
SLOT_MARGEN, SLOT_SEP = 16, 14              # margen a los lados y separación entre tarjetas
CONFIRMAR_RECT = (0, 0, 470, 176)
CONFIRMAR_ANCHO_3 = 540                     # la pregunta con 3 botones (guardar / no guardar / cancelar)
# Ronda 23: menú principal (inicio) y menú de pausa.
INICIO_BOTONES = ("continuar", "nueva", "demo", "partidas", "guia", "salir")   # ronda 28: + Demostración
INICIO_ALTO, INICIO_SEP = 50, 10            # con 6 tarjetas van un poco más juntas (antes 58 y 16)
NUEVA_BOTONES = ("luna", "marte", "volver")
DEMO_BOTONES = ("demo_luna", "demo_marte", "volver")   # ronda 28: partida de demostración
PAUSA_BOTONES = ("continuar", "guia", "partidas", "guardar", "inicio", "salir")
PAUSA_RECT = (0, 0, 360, 456)
PARTIDA_VERSION = 1

# --------------------------------------------------------------------------
# Arte de los diseñadores (assets/). Si un PNG falta, se usa el color plano.
# --------------------------------------------------------------------------
# nombre del archivo (sin .png) -> ((ancho, alto) de cada cuadro en Piskel, cuadros en la tira).
# Todo se agranda x3 como el resto (16 px -> 48 px en pantalla).
SPRITES = {
    "roca": ((16, 16), 1),
    "taladro": ((16, 16), 1),
    "panel_solar": ((16, 16), 1),
    "bloque_regolito": ((16, 16), 1),
    "purificador": ((16, 16), 1),
    "electrolizador": ((16, 16), 1),
    "invernadero": ((16, 16), 1),
    "tanque": ((16, 16), 4),      # tira de 4 cuadros: vacío, poco, mitad, lleno
    "base": ((32, 32), 1),
    "nave": ((30, 38), 1),        # recortada a su dibujo: se centra sobre su zona de 2x2 y sobresale por arriba
    # Cable: cada pieza dibujada en UNA orientación; el código la gira.
    "cable_punta": ((16, 16), 1),   # sale solo hacia la DERECHA
    "cable_recto": ((16, 16), 1),   # de IZQUIERDA a DERECHA
    "cable_l": ((16, 16), 1),       # ARRIBA y DERECHA
    "cable_t": ((16, 16), 1),       # IZQUIERDA, DERECHA y ABAJO
    "cable_cruz": ((16, 16), 1),    # los 4 lados
    # Íconos de la barra de herramientas (se dibujan a 32 px, ver ICONOS_HERRAMIENTA).
    "icono_pinza": ((16, 16), 1),
    "icono_panel_solar": ((32, 32), 1),   # el panel solar de 32x32 de las diseñadoras
    # Arte nuevo de las diseñadoras (Piskel, 14 nov; fondo quitado):
    "panel_solar_mapa": ((32, 32), 3),    # panel solar en el mapa: 3 posiciones según la hora
    "icono_regadera": ((32, 32), 1),
    "gotas": ((32, 32), 1),               # gotas que caen al regar un invernadero
    "icono_o2": ((16, 9), 1),             # "O2 H": ícono del electrolizador
    "bateria": ((32, 32), 3),             # panel de control: aguja llena / media / baja
    "taladro_niveles": ((40, 40), 3),     # taladro de nivel 1, 2 y 3
    "cubeta": ((32, 32), 2),              # maceta del invernadero: vacía / con tierra
    "recursos_taladro": ((32, 32), 3),    # lo que sueltan los taladros: cristal, hierro, regolito
}
# Recurso -> cuadro de recursos_taladro.png (los demás usan su ícono hecho por código).
ARTE_RECURSO = {"cristal": 0, "hierro": 1, "regolito": 2}
ESCALA_ARTE = 3

# Plantas del invernadero: assets/plantas/sprite_NN.png (lienzo de 32x32, exportado
# a cualquier múltiplo: 32, 64 o 96 px). Cada dibujo se recorta a la planta sola,
# se agranda ESCALA_PLANTAS veces (entero: píxeles parejos) y se "planta" con la
# base en el mismo punto, abajo al centro del cuadro: al cambiar de etapa no salta.
# Las plantas altas crecen hacia arriba y pueden salir del cuadro.
# Cada cultivo crece en 4 etapas (números de sprite) y con comida lista se ve su fruto.
CARPETA_PLANTAS = os.path.join(CARPETA, "assets", "plantas")
LIENZO_PLANTAS = 32             # lado del lienzo en Piskel
ESCALA_PLANTAS = 2
SUELO_PLANTAS = 6               # píxeles desde el borde de abajo del cuadro hasta la base de la planta
PLANTA_MAX = (TILE, TILE + 4)   # tamaño máximo en pantalla: las más grandes se achican para no tapar
                                # a los vecinos (sobresalen ~10 px por arriba del cuadro como mucho)
ARTE_CULTIVOS = {
    "tomate": ([11, 1, 4, 0], 3),
    "lechuga": ([11, 8, 2, 6], 6),
    "zanahoria": ([11, 7, 5, 9], 10),
    "nopal": ([12, 13, 14, 15], 16),    # sprites 12-16: nopal provisional (hecho por código, no de las diseñadoras)
}
MACETAS_BASE = 12               # huecos del cuarto de cultivos de la base (2 filas de 6)
MACETAS_COLUMNAS = 6
MACETA_LADO, MACETA_SEP, MACETA_FILA = 44, 40, 110
ICONO_BARRA = ICONO_OBJETO      # lado del ícono de un objeto (se conserva el nombre de antes)
# objeto -> sprite de ícono de las diseñadoras. Las pinzas son la herramienta de
# cables del documento de diseño. Los demás usan un ícono de color (_icono_respaldo).
ICONOS_OBJETO = {"cable": "icono_pinza", "generador": "icono_panel_solar",
                 "regadera": "icono_regadera",
                 "bateria": "bateria", "taladro": "taladro_niveles",
                 maquinas.BLOQUE: "bloque_regolito"}
VIBRA_TALADRO = 1.5             # píxeles que tiembla un taladro mientras trabaja
# Ronda 21: taladros más grandes. El dibujo (40x40 en Piskel) se recorta a la figura
# y se dibuja a TALADRO_PIXEL píxeles de pantalla por píxel del dibujo: 1.75 = ~60x56
# (antes la figura medía ~34 px). Sale un poco del cuadro hacia arriba y a los lados,
# como las plantas. Con 2 los píxeles quedan perfectamente parejos, pero mide ~68x64 y
# dos taladros pegados se tapan mucho; con 1.75 casi no se nota la diferencia.
TALADRO_PIXEL = 1.75
RIEGO_SEGUNDOS = 1.2            # cuánto se ven las gotas sobre el invernadero al regar
# Lados de cada pieza de cable tal como viene dibujada (arriba, abajo, izquierda, derecha).
PIEZAS_CABLE = {
    "cable_punta": {"der"},
    "cable_recto": {"izq", "der"},
    "cable_l": {"arr", "der"},
    "cable_t": {"izq", "der", "aba"},
    "cable_cruz": {"arr", "aba", "izq", "der"},
}
GIRO_IZQUIERDA = {"arr": "izq", "izq": "aba", "aba": "der", "der": "arr"}   # 90° antihorario

# Final: "tu misión contra la real". Valores que pide la guía del equipo.
# PENDIENTE: llevar cada uno a datos.py con su fuente; mientras la fuente sea
# None se muestra "(fuente por confirmar)" y NO la etiqueta "Dato real NASA".
REFERENCIAS = {
    "dosis_msv": (600, None),          # límite de carrera de un astronauta, en mSv
    "moxie_g": (122, None),            # oxígeno total que produjo MOXIE en Marte, en gramos
    "iss_agua_pct": (98, None),        # % del agua que recicla la Estación Espacial
}
GRAMOS_POR_UNIDAD_O2 = 10          # SIMPLIFICACIÓN del juego: 1 unidad de oxígeno = 10 g
ESCENAS_FINAL = 4                  # imágenes fijas antes de la comparación


# --------------------------------------------------------------------------
# Texturas
# --------------------------------------------------------------------------


# Relieve (ronda 15): colinas solo de adorno (se camina y se construye encima). La
# punta de cada colina es la cima: parado ahí, se ve el espacio con estrellas y
# de vez en cuando un cometa.
COLINAS = [(6, 6, 4), (25, 24, 3)]   # (fila, col, radio en cuadros): pocas, para que sean raras
ALTURA_MAX = 3
CIELO_VELOCIDAD = 1.2           # qué tan rápido aparece/desaparece la vista del cielo
COMETA_CADA = (3.0, 7.0)        # segundos entre cometas (al azar en ese rango)
COMETAS_MAX = 2                 # nunca más de 2 a la vez: solo unos cuantos


# --------------------------------------------------------------------------
# Ronda 26: objeto en la mano y cinemática final
# --------------------------------------------------------------------------
# Objeto en la mano: se dibuja chiquito junto al guante. MANO_POS es el centro del
# guante en el dibujo del astronauta ya agrandado x3 (96x96 px), medido en los
# PNG de las diseñadoras, por dirección y por cuadro de la animación. Mirando a la
# izquierda o a la derecha, la mano de ese lado; de frente, su mano derecha (a la
# izquierda de la pantalla); de espaldas, la mano derecha, detrás del cuerpo.
MANO_LADO = 18                  # tamaño del ícono en la mano, en píxeles
MANO_POS = {
    "abajo": [(20, 72), (20, 72), (20, 72)],
    "arriba": [(80, 72), (80, 72), (77, 74)],
    "derecha": [(67, 70), (67, 71)],
    "izquierda": [(28, 70), (28, 71)],
}
MANO_EMPUJE = {"abajo": (-4, 2), "arriba": (5, -2), "derecha": (7, 0), "izquierda": (-7, 0)}   # hacia afuera
# Cinemática final (al despegar desde Marte): PNG de assets/cinematica/ (ver cinematica.py).
CINE_CARPETA = os.path.join(CARPETA, "assets", "cinematica")
CINE_FPS = 10                   # cuadros por segundo (89 cuadros = unos 9 segundos)
CINE_FUNDIDO = 0.7              # segundos del fundido a negro al empezar y al terminar


# --------------------------------------------------------------------------
# Ronda 27: compañero robot con cofre
# --------------------------------------------------------------------------
COMPANERO_CARPETA = os.path.join(CARPETA, "assets", "companero")   # laylu_{direccion}_{1..4}.png
COMPANERO_ESCALA = 2            # el dibujo (~28x32) se agranda x2: un poco más chico que el astronauta
COMPANERO_FPS = 8               # cuadros de caminar por segundo
COMPANERO_VEL = 200             # píxeles por segundo (un poco más rápido que el astronauta, 180)
# Ronda 28: va más separada (antes se quedaba a 56 px). Se detiene a COMPANERO_DISTANCIA y no
# vuelve a caminar hasta que el astronauta se aleja más de COMPANERO_ARRANCA (así no da
# pasitos cada vez que te mueves un poco).
COMPANERO_DISTANCIA = 2.5 * 48  # se detiene a ~2.5 cuadros del astronauta
COMPANERO_ARRANCA = 3 * 48      # camina otra vez si estás a más de ~3 cuadros
COMPANERO_FACTOR_BASE = 0.6     # dentro de la base (sala de 13x8 cuadros) usa el 60 %: ~1.5 a 1.8 cuadros
COMPANERO_LEJOS = 6 * 48        # más lejos que esto (6 cuadros): aparece junto al astronauta
COMPANERO_ATORADO = 1.2         # segundos sin poder avanzar: aparece junto al astronauta
COFRE_CASILLAS = 8              # el cofre del compañero: 8 casillas de 20 (el almacén de la base: 12)
COFRE_PILA = 20
