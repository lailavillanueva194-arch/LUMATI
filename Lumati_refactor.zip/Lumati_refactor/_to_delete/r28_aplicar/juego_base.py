"""La base por dentro: cuartos, muebles, macetas del cuarto de cultivos, entrar y
salir, dormir, almacén, menús de la base (almacén, sistemas, terminal) y su dibujo.
"""

import math

import pygame

import clima as modulo_clima
import estilo
import maquinas
from energia import encontrar_redes, toca_celdas
from maquinas import COMIDA_POR_UNIDAD, Maquina, RECURSOS
from supervivencia import COMIDA, COMIDA_MAX, DOSIS, OXIGENO
from textos import t
from config import (ALCANCE_MUEBLE, ALMACEN_CASILLAS, ALMACEN_PILA, ALTO, ANCHO, BASE_POS, CABLE,
                    CABLE_COLORES, COLOR_AVISO, COLOR_CABLE_BORDE_DE, COLOR_CABLE_DE, COLOR_COBIJA,
                    COLOR_FONDO, COLOR_JUNTA_SALA, COLOR_LUZ_OFF, COLOR_LUZ_ON, COLOR_PISO_SALA,
                    COLOR_RECURSO, COLOR_TALADRO_BORDE, COLOR_TEXTO, COLUMNAS, DORMIR_PASO,
                    ESCENA_BASE, ESCENA_MAPA, ESTRUCTURA_LADO, FILAS, FUNDIDO_SEGUNDOS, GENERADOR,
                    HORA_DESPERTAR, HORA_DORMIR, INV_COLUMNAS, JUGADOR_TAM, JUGADOR_VEL,
                    MACETAS_BASE, MACETAS_COLUMNAS, MACETA_FILA, MACETA_LADO, MACETA_SEP,
                    MAPA_ALTO, MAPA_ANCHO, MENU_ATENUAR, PATRON_CABLE, RIEGO_SEGUNDOS, SALA_PARED,
                    SALA_RECT, TILE)
from jugador import calcular_camara


class BaseMixin:
    """La base por dentro: cuartos, muebles, macetas del cuarto de cultivos, entrar y
    salir, dormir, almacén, menús de la base (almacén, sistemas, terminal) y su dibujo."""

    # -- base por dentro ------------------------------------------------------
    def sala(self):
        """(sala, piso): la sala completa y la parte por donde se camina."""
        sala = pygame.Rect(SALA_RECT)
        return sala, sala.inflate(-2 * SALA_PARED, -2 * SALA_PARED)

    def muebles(self):
        """{nombre: rectángulo en pantalla} de lo que hay en el cuarto actual de la
        base. Todo es sólido menos las puertas. El módulo habitable tiene la puerta
        de salida (abajo) y la del invernadero (pared izquierda); el invernadero,
        solo las macetas y la puerta de regreso (pared derecha)."""
        sala, piso = self.sala()
        alto_puerta = 60
        y_puerta = piso.bottom - alto_puerta - 14
        if self.cuarto == "invernadero":
            return {
                "puerta_hab": pygame.Rect(sala.right - SALA_PARED, y_puerta, SALA_PARED, alto_puerta),
                **{f"maceta{i}": r for i, r in enumerate(self.rects_macetas())},
            }
        return {
            "puerta_inv": pygame.Rect(sala.x, y_puerta, SALA_PARED, alto_puerta),
            "cama": pygame.Rect(piso.x + 10, piso.y + 10, 112, 64),
            "sistemas": pygame.Rect(piso.centerx - 82, piso.y, 164, 40),
            "almacen": pygame.Rect(piso.right - 114, piso.y + 8, 106, 58),
            "terminal": pygame.Rect(piso.x + 6, piso.centery + 6, 62, 70),
            "rack": pygame.Rect(piso.right - 46, piso.centery - 6, 40, 98),
            "puerta": pygame.Rect(sala.centerx - 40, sala.bottom - SALA_PARED, 80, SALA_PARED),
        }

    def rects_macetas(self):
        """Huecos del cuarto de cultivos: 2 filas de 6, con pasillos entre ellas."""
        _, piso = self.sala()
        ancho = MACETAS_COLUMNAS * MACETA_LADO + (MACETAS_COLUMNAS - 1) * MACETA_SEP
        x0, y0 = piso.centerx - ancho // 2 - 20, piso.y + 60
        rects = []
        for i in range(MACETAS_BASE):
            fila, col = divmod(i, MACETAS_COLUMNAS)
            rects.append(pygame.Rect(x0 + col * (MACETA_LADO + MACETA_SEP), y0 + fila * MACETA_FILA,
                                     MACETA_LADO, MACETA_LADO))
        return rects

    def cambiar_cuarto(self, cuarto):
        """Pasa por la puerta lateral entre el módulo habitable y el invernadero."""
        _, piso = self.sala()
        self.cuarto = cuarto
        puerta = self.muebles()["puerta_hab" if cuarto == "invernadero" else "puerta_inv"]
        y = puerta.centery - JUGADOR_TAM / 2
        if cuarto == "invernadero":
            self.pos_base = [piso.right - JUGADOR_TAM - 8, y]
            self.jugador.direccion = "izquierda"
        else:
            self.pos_base = [piso.x + 8, y]
            self.jugador.direccion = "derecha"
        self.mensaje = t("entraste_" + cuarto)

    def usar_maceta(self, i):
        """Clic en un hueco del invernadero de la base. Vacío: con Invernadero
        (maceta) en la mano, pone una. Con fruto: cosecha. Con la regadera: riega.
        Sin regar todavía: cada clic cambia el cultivo."""
        mq = self.macetas[i]
        nombre = maquinas.INVERNADERO
        if mq is None:
            if self.en_mano != nombre:
                self.mensaje = t("maceta_vacia")
                return
            if not self.tiene_objeto(nombre):
                return
            cultivo = maquinas.CULTIVOS[self._sembrados % len(maquinas.CULTIVOS)]
            self._sembrados += 1
            self.gastar_objeto(nombre)
            self.macetas[i] = Maquina(nombre, cultivo)
            self.mensaje = t("maceta_puesta", cultivo=t("cultivo_" + cultivo))
            return
        if mq.salida:                       # cosechar: la comida va a su barra
            hueco = COMIDA_MAX - self.astronauta.valor(COMIDA)
            n = mq.retirar(math.ceil(hueco / COMIDA_POR_UNIDAD - 1e-9)) if hueco > 0 else 0
            if n:
                self.astronauta.agregar(COMIDA, n * COMIDA_POR_UNIDAD)
                self.mensaje = t("cosecha", cultivo=t("cultivo_" + mq.cultivo)) + " · " + \
                    t("barra_subio", barra=t("barra_" + COMIDA), n=int(n * COMIDA_POR_UNIDAD))
            else:
                self.mensaje = t("barra_llena", barra=t("barra_" + COMIDA))
            return
        if self.en_mano == "regadera":      # regar con el agua del inventario
            n = mq.depositar(self.inventario["agua"])
            if n:
                self.inventario["agua"] -= n
                self._riegos[("maceta", i)] = RIEGO_SEGUNDOS
                self.mensaje = t("regaste", n=n)
            else:
                self.mensaje = t("regadera_sin_agua" if not self.inventario["agua"] else "maceta_llena")
            return
        if not mq.entrada and mq.progreso <= 0:     # aún sin regar: cambiar de cultivo
            k = maquinas.CULTIVOS.index(mq.cultivo)
            mq.cultivo = maquinas.CULTIVOS[(k + 1) % len(maquinas.CULTIVOS)]
            self.mensaje = t("maceta_cultivo", cultivo=t("cultivo_" + mq.cultivo))
            return
        p = round(100 * mq.progreso / mq.tiempo_unidad)
        self.mensaje = t("maceta_crece", cultivo=t("cultivo_" + mq.cultivo), p=p) + \
            (t("maceta_lenta") if self.factor_cultivo() < 1.0 else "")

    def entrar_base(self):
        """Clic en la base: el astronauta pasa a la sala, junto a la puerta."""
        sala, piso = self.sala()
        self._fuera_pos = (self.jugador.x, self.jugador.y)
        self.escena = ESCENA_BASE
        self.cuarto = "habitable"
        self.pos_base = [sala.centerx - JUGADOR_TAM / 2, piso.bottom - JUGADOR_TAM - 14]
        self.jugador.direccion = "arriba"
        self.inventario_abierto = self.crafteo_abierto = False
        self.menu_base = None
        self.mensaje = t("entraste_base")

    def salir_base(self):
        """Por la puerta: el astronauta aparece afuera, abajo de la base (o donde
        estaba al entrar, si ahí construyeron algo)."""
        self.escena = ESCENA_MAPA
        self.menu_base = None
        f0, c0 = BASE_POS
        x = (c0 + ESTRUCTURA_LADO / 2) * TILE - JUGADOR_TAM / 2
        y = (f0 + ESTRUCTURA_LADO) * TILE + (TILE - JUGADOR_TAM) / 2
        if self.jugador.choca(self.mapa, x, y) and self._fuera_pos:
            x, y = self._fuera_pos
        self.jugador.x, self.jugador.y = x % MAPA_ANCHO, y % MAPA_ALTO
        self.jugador.direccion = "abajo"
        self.camara = calcular_camara(self.jugador)
        self._cam = [float(v) for v in self.camara]
        self.mensaje = t("saliste_base")

    def caja_interior(self, x=None, y=None):
        x = self.pos_base[0] if x is None else x
        y = self.pos_base[1] if y is None else y
        return pygame.Rect(round(x), round(y), JUGADOR_TAM, JUGADOR_TAM)

    def mover_interior(self, dir_x, dir_y, dt):
        """Camina por la sala: cada eje por separado (como afuera), sin salir del
        piso ni atravesar muebles. Empujar contra la puerta saca de la base."""
        _, piso = self.sala()
        solidos = [r for n, r in self.muebles().items() if not n.startswith("puerta")]
        for eje, paso in ((0, dir_x * JUGADOR_VEL * dt), (1, dir_y * JUGADOR_VEL * dt)):
            if not paso:
                continue
            nuevo = list(self.pos_base)
            nuevo[eje] += paso
            caja = self.caja_interior(*nuevo)
            if piso.contains(caja) and not any(caja.colliderect(r) for r in solidos):
                self.pos_base = nuevo
        caja = self.caja_interior()
        m = self.muebles()
        if self.cuarto == "habitable":
            puerta, lateral = m["puerta"], m["puerta_inv"]
            if dir_y > 0 and caja.bottom >= piso.bottom - 1 and puerta.left < caja.centerx < puerta.right:
                self.salir_base()
            elif dir_x < 0 and caja.left <= piso.left + 1 and lateral.top < caja.centery < lateral.bottom:
                self.cambiar_cuarto("invernadero")
        else:
            lateral = m["puerta_hab"]
            if dir_x > 0 and caja.right >= piso.right - 1 and lateral.top < caja.centery < lateral.bottom:
                self.cambiar_cuarto("habitable")

    def mueble_bajo(self, pos):
        for nombre, rect in self.muebles().items():
            if rect.collidepoint(pos):
                return nombre
        return None

    def cerca_de(self, rect):
        """True si el astronauta (dentro de la base) está a ALCANCE_MUEBLE px o menos del mueble."""
        cx, cy = self.caja_interior().center
        dx = max(rect.left - cx, 0, cx - rect.right)
        dy = max(rect.top - cy, 0, cy - rect.bottom)
        return dx * dx + dy * dy <= ALCANCE_MUEBLE ** 2

    def clic_interior(self, pos):
        """Clic en un mueble de la base, si el astronauta está cerca."""
        nombre = self.mueble_bajo(pos)
        if nombre is None:
            return
        if not self.cerca_de(self.muebles()[nombre]):
            self.mensaje = t("acercate")
            return
        if nombre == "puerta":
            self.salir_base()
        elif nombre == "puerta_inv":
            self.cambiar_cuarto("invernadero")
        elif nombre == "puerta_hab":
            self.cambiar_cuarto("habitable")
        elif nombre == "cama":
            self.dormir()
        elif nombre == "almacen":
            self.menu_base = "almacen"
        elif nombre in ("sistemas", "rack"):
            self.menu_base = "sistemas"
        elif nombre == "terminal":
            self._info_partida = self.info_partida()
            self.menu_base = "terminal"
        elif nombre.startswith("maceta"):
            self.usar_maceta(int(nombre[len("maceta"):]))

    # -- dormir ---------------------------------------------------------------
    def puede_dormir(self):
        hora = self.clima.reloj.hora
        return hora >= HORA_DORMIR or hora < HORA_DESPERTAR

    def dormir(self):
        """La cama: solo de noche. La pantalla se oscurece despacio, el mundo
        avanza hasta las 06:00 (las máquinas siguen trabajando) y vuelve a aclarar."""
        if not self.puede_dormir():
            self.mensaje = t("dormir_no")
            return
        self.menu_base = None
        self._fundido = ["bajando", 0.0]

    def actualizar_fundido(self, dt):
        fase, valor = self._fundido
        if fase == "bajando":
            valor = min(1.0, valor + dt / FUNDIDO_SEGUNDOS)
            if valor >= 1.0:
                self.dormir_simular()
                fase = "subiendo"
            self._fundido = [fase, valor]
        else:
            valor = max(0.0, valor - dt / FUNDIDO_SEGUNDOS)
            self._fundido = None if valor <= 0 else [fase, valor]

    def dormir_simular(self):
        """Avanza el mundo hasta las HORA_DESPERTAR en pasos de DORMIR_PASO s, igual
        que si pasara el tiempo jugando (taladros, máquinas, tormentas, barras).
        El astronauta está en la base, así que casi no gasta oxígeno."""
        horas = (HORA_DESPERTAR - self.clima.reloj.hora) % 24.0
        restante = horas / 24.0 * modulo_clima.DURACION_CICLO + 1e-3
        while restante > 0 and self.astronauta.vivo:
            paso = min(DORMIR_PASO, restante)
            self.avanzar_mundo(paso, avisar=False)
            restante -= paso
        self._nivel_previo = {OXIGENO: self.astronauta.nivel_aviso(OXIGENO), DOSIS: self.astronauta.nivel_aviso(DOSIS)}
        self.mensaje = t("dormiste", hora=self.clima.reloj.hora_texto)

    # -- almacén de la base ---------------------------------------------------
    def casillas_almacen(self):
        """Las ALMACEN_CASILLAS del almacén: (recurso, cantidad) o None, por recurso."""
        lista = []
        for recurso in RECURSOS:
            n = self.almacen.get(recurso, 0)
            while n > 0:
                lista.append((recurso, min(n, ALMACEN_PILA)))
                n -= ALMACEN_PILA
        return (lista + [None] * ALMACEN_CASILLAS)[:ALMACEN_CASILLAS]

    def espacio_almacen(self, recurso):
        usadas = sum(math.ceil(n / ALMACEN_PILA) for n in self.almacen.values() if n > 0)
        n = self.almacen.get(recurso, 0)
        suelto = (ALMACEN_PILA - n % ALMACEN_PILA) if n % ALMACEN_PILA else 0
        return max(0, ALMACEN_CASILLAS - usadas) * ALMACEN_PILA + suelto

    def meter_almacen(self, recurso, cantidad):
        n = min(cantidad, self.inventario[recurso], self.espacio_almacen(recurso))
        if n <= 0:
            self.mensaje = t("almacen_lleno")
            return
        self.inventario[recurso] -= n
        self.almacen[recurso] += n
        self.mensaje = t("almacen_metiste", n=n, recurso=t("recurso_" + recurso))

    def sacar_almacen(self, recurso, cantidad):
        n = self.inventario.agregar(recurso, min(cantidad, self.almacen.get(recurso, 0)))
        if n <= 0:
            self.mensaje = self._mensaje_lleno(recurso)
            return
        self.almacen[recurso] -= n
        self.mensaje = t("almacen_sacaste", n=n, recurso=t("recurso_" + recurso))

    # -- menús de la base -------------------------------------------------------
    BASE_CASILLA, BASE_SEP = 52, 6

    def rect_menu_base(self):
        tam = {"almacen": (720, 300), "cofre": (720, 300), "sistemas": (640, 380),
               "terminal": (480, 250)}[self.menu_base]
        r = pygame.Rect(0, 0, *tam)
        r.center = (ANCHO // 2, ALTO // 2 - 10)
        return r

    def rect_mochila_base(self, i):
        r = self.rect_menu_base()
        fila, col = divmod(i, INV_COLUMNAS)
        paso = self.BASE_CASILLA + self.BASE_SEP
        return pygame.Rect(r.x + 20 + col * paso, r.y + 76 + fila * paso, self.BASE_CASILLA, self.BASE_CASILLA)

    def rect_almacen_base(self, i):
        r = self.rect_menu_base()
        fila, col = divmod(i, 4)
        paso = self.BASE_CASILLA + self.BASE_SEP
        x0 = r.right - 20 - 4 * paso + self.BASE_SEP
        return pygame.Rect(x0 + col * paso, r.y + 76 + fila * paso, self.BASE_CASILLA, self.BASE_CASILLA)

    def botones_terminal(self):
        r = self.rect_menu_base()
        guardar = pygame.Rect(r.x + 30, r.y + 120, (r.w - 80) // 2, 54)
        cargar = pygame.Rect(guardar.right + 20, guardar.y, guardar.w, guardar.h)
        return guardar, cargar

    def clic_menu_base(self, pos):
        """Clic con un menú de la base abierto; fuera del menú, lo cierra."""
        r = self.rect_menu_base()
        if not r.collidepoint(pos):
            self.menu_base = None
            return
        if self.menu_base in ("almacen", "cofre"):     # el cofre del compañero funciona igual
            guardadas, meter, sacar = self.contenedor_abierto()
            casillas = self.inventario.casillas()
            for i, contenido in enumerate(casillas):
                if contenido and self.rect_mochila_base(i).collidepoint(pos):
                    meter(*contenido)
                    return
            for i, contenido in enumerate(guardadas):
                if contenido and self.rect_almacen_base(i).collidepoint(pos):
                    sacar(*contenido)
                    return
        elif self.menu_base == "terminal":
            guardar, cargar = self.botones_terminal()
            if guardar.collidepoint(pos):
                self.guardar_partida()
                self._info_partida = self.info_partida()
            elif cargar.collidepoint(pos):       # la lista de partidas del menú de opciones
                self.menu_base = None
                self.abrir_opciones("partidas")

    def resumen_sistemas(self):
        """Datos del panel de sistemas: por color, cuántos cables, redes, redes con
        energía y máquinas conectadas; y cuántas máquinas están encendidas."""
        if self._energia_sucia:
            self.recalcular_energia()
        con_energia = set(self._energizados) if not (self.polvo and self.polvo.tapa_paneles) else set()
        consumidores = list(self.taladros) + [k for k, mq in self.maquinas.items() if isinstance(mq, Maquina)] \
            + list(self.antenas)
        por_color = {color: {"cables": 0, "redes": 0, "con": 0, "maquinas": set()} for color in CABLE_COLORES}
        for red in encontrar_redes(self.mapa, CABLE, self.colores_cable, self.puede_unir):
            colores_red = [self.color_de(*x) for x in red if self.color_de(*x) in por_color]
            if not colores_red:                     # red hecha solo de piezas neutras
                continue
            datos_color = por_color[colores_red[0]]
            datos_color["cables"] += len(red)
            datos_color["redes"] += 1
            datos_color["con"] += bool(red & con_energia)
            for f, c in consumidores:
                if toca_celdas(red, f, c, FILAS, COLUMNAS):
                    datos_color["maquinas"].add((f, c))
        encendidas = sum(self.tiene_energia(f, c) for f, c in consumidores)
        paneles = sum(fila.count(GENERADOR) for fila in self.mapa)
        return por_color, encendidas, len(consumidores) - encendidas, paneles

    # -- dibujo de la base por dentro -----------------------------------------
    def dibujar_interior(self):
        """La sala de la base vista desde arriba: paredes blancas, piso claro con
        juntas, los muebles dibujados por código y el astronauta. Fuera de la sala,
        el espacio oscuro con estrellas."""
        p = self.pantalla
        p.fill(COLOR_FONDO)
        for x, y, r in self._estrellas:
            pygame.draw.circle(p, (90, 92, 104), (x, y), r)
        sala, piso = self.sala()
        estilo.sombra(p, sala, desplazar=(6, 8), radio=14)
        pygame.draw.rect(p, estilo.PANEL, sala, border_radius=14)
        pygame.draw.rect(p, estilo.CONTORNO, sala, 3, border_radius=14)
        pygame.draw.rect(p, COLOR_PISO_SALA, piso)
        for x in range(piso.x + TILE, piso.right, TILE):
            pygame.draw.line(p, COLOR_JUNTA_SALA, (x, piso.y), (x, piso.bottom - 1))
        for y in range(piso.y + TILE, piso.bottom, TILE):
            pygame.draw.line(p, COLOR_JUNTA_SALA, (piso.x, y), (piso.right - 1, y))
        pygame.draw.rect(p, estilo.MARCO, piso, 2)
        pygame.draw.line(p, estilo.ACENTO, (sala.x + 24, sala.y + 6), (sala.right - 24, sala.y + 6), 3)
        invernadero = self.cuarto == "invernadero"
        if invernadero:                          # piso del cuarto de cultivos: tinte verde
            tinte = pygame.Surface(piso.size, pygame.SRCALPHA)
            tinte.fill((120, 190, 110, 60))
            p.blit(tinte, piso)
        titulo = self.fuente_chica.render(t("invernadero_titulo" if invernadero else "base_titulo"),
                                          True, COLOR_TEXTO)
        p.blit(titulo, titulo.get_rect(midbottom=(sala.centerx, sala.y - 6)))
        m = self.muebles()
        # Orden de dibujo por altura (como se ve desde arriba en ángulo): lo que está
        # más arriba que los pies del astronauta va detrás de él; lo de abajo, delante.
        if invernadero:
            for i in range(MACETAS_BASE):             # cama de tierra bajo cada hueco
                pygame.draw.rect(p, (196, 222, 190), m[f"maceta{i}"].inflate(14, 14), border_radius=8)
                pygame.draw.rect(p, (150, 190, 150), m[f"maceta{i}"].inflate(14, 14), 2, border_radius=8)
            dibujos = [(m[f"maceta{i}"].bottom, lambda r, i=i: self._dibujar_maceta(i, r), m[f"maceta{i}"])
                       for i in range(MACETAS_BASE)]
        else:
            dibujos = [(m["cama"].bottom, self._dibujar_cama, m["cama"]),
                       (m["almacen"].bottom, self._dibujar_almacen_mueble, m["almacen"]),
                       (m["sistemas"].bottom, self._dibujar_panel_sistemas, m["sistemas"]),
                       (m["terminal"].bottom, self._dibujar_terminal, m["terminal"]),
                       (m["rack"].bottom, self._dibujar_rack, m["rack"])]
        pies = self.caja_interior().bottom
        for abajo, dibujo, rect in dibujos:
            if abajo <= pies:
                dibujo(rect)
        if "puerta" in m:                        # salida al exterior (pared de abajo)
            puerta = m["puerta"]
            pygame.draw.rect(p, COLOR_PISO_SALA, puerta)
            for i in range(3):
                pygame.draw.line(p, estilo.ACENTO, (puerta.x + 6, puerta.y + 4 + i * 5),
                                 (puerta.right - 6, puerta.y + 4 + i * 5), 2)
        lateral = m["puerta_hab" if invernadero else "puerta_inv"]   # puerta entre cuartos
        pygame.draw.rect(p, COLOR_PISO_SALA, lateral)
        for i in range(3):
            pygame.draw.line(p, (110, 170, 100), (lateral.x + 4 + i * 5, lateral.y + 6),
                             (lateral.x + 4 + i * 5, lateral.bottom - 6), 2)
        flecha = self.fuente_mini.render(t("ir_habitable" if invernadero else "ir_invernadero"), True, estilo.TINTA)
        if invernadero:                          # rótulo dentro del cuarto, arriba de la puerta
            p.blit(flecha, flecha.get_rect(bottomright=(lateral.x - 4, lateral.y - 4)))
        else:
            p.blit(flecha, flecha.get_rect(bottomleft=(lateral.right + 4, lateral.y - 4)))
        pista = self.fuente_mini.render(t("inv_volver" if invernadero else "base_salir"), True, COLOR_TEXTO)
        p.blit(pista, pista.get_rect(midtop=(sala.centerx, sala.bottom + 6)))
        self.dibujar_con_companero()         # el astronauta (y el compañero, si lo tienes)
        for abajo, dibujo, rect in dibujos:
            if abajo > pies:
                dibujo(rect)
        if not self.menu_visible and not self._fundido and self.opciones is None:   # mueble bajo el mouse
            nombre = self.mueble_bajo(pygame.mouse.get_pos())
            if nombre:
                rect = m[nombre]
                color = estilo.ACENTO if self.cerca_de(rect) else estilo.TINTA_SUAVE
                pygame.draw.rect(p, color, rect.inflate(6, 6), 2, border_radius=6)
                texto = self.texto_mueble(nombre)
                if not self.cerca_de(rect):
                    texto += " · " + t("acercate")
                imagen = self.fuente_chica.render(texto, True, estilo.TINTA)
                caja = imagen.get_rect(midbottom=(rect.centerx, rect.y - 8))
                caja.clamp_ip(sala.inflate(-8, -8))
                pygame.draw.rect(p, estilo.CONTORNO, caja.inflate(12, 6), border_radius=4)
                pygame.draw.rect(p, estilo.CASILLA, caja.inflate(8, 2), border_radius=3)
                p.blit(imagen, caja)

    def texto_mueble(self, nombre):
        if nombre in ("puerta_inv", "puerta_hab"):
            return t("ir_invernadero" if nombre == "puerta_inv" else "ir_habitable")
        if not nombre.startswith("maceta"):
            return t("mueble_" + nombre)
        mq = self.macetas[int(nombre[len("maceta"):])]
        if mq is None:
            return t("mueble_maceta_vacia")
        return t("cultivo_" + mq.cultivo)

    def _dibujar_maceta(self, i, r):
        """Hueco del invernadero de la base: vacío (tierra marcada) o con su
        cubeta y la planta, las gotas de agua que tiene y las del riego."""
        p = self.pantalla
        mq = self.macetas[i]
        if mq is None:
            pygame.draw.ellipse(p, (170, 196, 168), r.inflate(-8, -20).move(0, 10))
            pygame.draw.ellipse(p, (130, 160, 128), r.inflate(-8, -20).move(0, 10), 2)
            mas = self.fuente.render("+", True, (120, 150, 118))
            p.blit(mas, mas.get_rect(center=(r.centerx, r.centery + 6)))
            return
        x, y = r.x + (r.w - TILE) // 2, r.bottom - TILE
        self._dibujar_cubeta(mq, x, y)
        for k in range(mq.entrada):                     # agua que le queda
            pygame.draw.rect(p, COLOR_RECURSO["agua"], (r.x + 2, r.bottom - 8 - k * 7, 5, 5))
        if mq.salida:                                   # listo para cosechar
            pygame.draw.circle(p, COLOR_LUZ_ON, (r.right - 5, r.y + 5), 4)
        if ("maceta", i) in self._riegos:
            self.dibujar_gotas(self._riegos[("maceta", i)], x, y)

    def _dibujar_cama(self, r):
        p = self.pantalla
        estilo.sombra(p, r, desplazar=(3, 4), radio=6)
        pygame.draw.rect(p, estilo.MARCO, r, border_radius=6)
        colchon = r.inflate(-8, -8)
        pygame.draw.rect(p, estilo.PANEL_LUZ, colchon, border_radius=4)
        almohada = pygame.Rect(colchon.x + 4, colchon.y + 6, 24, colchon.h - 12)
        pygame.draw.rect(p, estilo.CASILLA, almohada, border_radius=5)
        pygame.draw.rect(p, estilo.CASILLA_SOMBRA, almohada, 1, border_radius=5)
        cobija = pygame.Rect(colchon.x + 36, colchon.y, colchon.w - 36, colchon.h)
        pygame.draw.rect(p, COLOR_COBIJA, cobija, border_radius=4)
        pygame.draw.line(p, estilo.PANEL_LUZ, (cobija.x + 4, cobija.y + 6), (cobija.x + 4, cobija.bottom - 6), 2)
        pygame.draw.rect(p, estilo.CONTORNO, r, 2, border_radius=6)

    def _dibujar_almacen_mueble(self, r):
        p = self.pantalla
        estilo.sombra(p, r, desplazar=(3, 4), radio=6)
        pygame.draw.rect(p, (204, 211, 221), r, border_radius=5)
        ancho = r.w // 3
        for i in range(3):                                     # tres puertas de casillero
            puerta = pygame.Rect(r.x + 4 + i * ancho, r.y + 4, ancho - 6, r.h - 8)
            pygame.draw.rect(p, estilo.PANEL, puerta, border_radius=3)
            pygame.draw.rect(p, estilo.CASILLA_SOMBRA, puerta, 1, border_radius=3)
            pygame.draw.line(p, estilo.CONTORNO, (puerta.right - 6, puerta.centery - 6), (puerta.right - 6, puerta.centery + 6), 2)
        usadas = sum(1 for c in self.casillas_almacen() if c)
        if usadas:                                             # una franja dice que hay cosas guardadas
            pygame.draw.rect(p, estilo.ACENTO, (r.x + 6, r.bottom - 7, (r.w - 12) * usadas // ALMACEN_CASILLAS, 3))
        pygame.draw.rect(p, estilo.CONTORNO, r, 2, border_radius=5)

    def _dibujar_panel_sistemas(self, r):
        """Pantalla en la pared de arriba: una barrita por color de cable (alta si
        su circuito tiene energía) y una luz de la antena."""
        p = self.pantalla
        pygame.draw.rect(p, estilo.FONDO_BARRA, r, border_radius=4)
        por_color, _, _, _ = self.resumen_sistemas()
        for i, color in enumerate(CABLE_COLORES):
            datos_color = por_color[color]
            alto = 24 if datos_color["con"] else (8 if datos_color["redes"] else 3)
            barra = pygame.Rect(r.x + 14 + i * 24, r.bottom - 8 - alto, 14, alto)
            pygame.draw.rect(p, COLOR_CABLE_DE[color], barra, border_radius=2)
        x = r.x + 92
        for i in range(3):
            pygame.draw.line(p, (120, 140, 160), (x, r.y + 10 + i * 8), (x + 40, r.y + 10 + i * 8), 2)
        pygame.draw.circle(p, COLOR_LUZ_ON if self.contacto else (110, 120, 132), (r.right - 14, r.y + 12), 5)
        pygame.draw.rect(p, estilo.CONTORNO, r, 2, border_radius=4)

    def _dibujar_terminal(self, r):
        p = self.pantalla
        estilo.sombra(p, r, desplazar=(3, 4), radio=6)
        pygame.draw.rect(p, (210, 216, 225), r, border_radius=5)
        pantalla_chica = pygame.Rect(r.x + 8, r.y + 8, r.w - 16, 30)
        pygame.draw.rect(p, estilo.ACENTO, pantalla_chica, border_radius=3)
        for i in range(3):
            pygame.draw.line(p, estilo.PANEL_LUZ, (pantalla_chica.x + 5, pantalla_chica.y + 7 + i * 7),
                             (pantalla_chica.x + 18 + i * 8, pantalla_chica.y + 7 + i * 7), 2)
        teclado = pygame.Rect(r.x + 8, r.y + 46, r.w - 16, 14)
        pygame.draw.rect(p, estilo.CASILLA, teclado, border_radius=2)
        for i in range(1, 5):
            pygame.draw.line(p, estilo.CASILLA_SOMBRA, (teclado.x + i * teclado.w // 5, teclado.y + 2),
                             (teclado.x + i * teclado.w // 5, teclado.bottom - 3))
        pygame.draw.rect(p, estilo.CONTORNO, r, 2, border_radius=5)

    def _dibujar_rack(self, r):
        """Rack de cables en la pared: un cable de cada color (con su patrón) y una
        luz arriba: verde si ese circuito tiene energía, roja si no tiene."""
        p = self.pantalla
        pygame.draw.rect(p, (200, 207, 217), r, border_radius=4)
        por_color, _, _, _ = self.resumen_sistemas()
        for i, color in enumerate(CABLE_COLORES):
            x = r.x + 9 + i * 11
            pygame.draw.line(p, COLOR_CABLE_BORDE_DE[color], (x, r.y + 18), (x, r.bottom - 6), 6)
            pygame.draw.line(p, COLOR_CABLE_DE[color], (x, r.y + 18), (x, r.bottom - 6), 4)
            for y in range(r.y + 26, r.bottom - 8, 12):
                if PATRON_CABLE[color] == "rayas":
                    pygame.draw.line(p, COLOR_CABLE_BORDE_DE[color], (x - 2, y), (x + 2, y), 2)
                elif PATRON_CABLE[color] == "puntos":
                    pygame.draw.circle(p, COLOR_CABLE_BORDE_DE[color], (x, y), 1)
            luz = COLOR_LUZ_ON if por_color[color]["con"] else COLOR_LUZ_OFF
            pygame.draw.circle(p, luz, (x, r.y + 9), 4)
            pygame.draw.circle(p, COLOR_TALADRO_BORDE, (x, r.y + 9), 4, 1)
        pygame.draw.rect(p, estilo.CONTORNO, r, 2, border_radius=4)

    def dibujar_menu_base(self):
        """Almacén, panel de sistemas o terminal: mismos paneles blancos que el
        inventario, con el juego oscurecido detrás."""
        if self.menu_base is None or not self.menu_visible:
            return
        p = self.pantalla
        tinta, suave = estilo.TINTA, estilo.TINTA_SUAVE
        self._velo.fill((0, 0, 0, int(MENU_ATENUAR * self._menu_t)))
        p.blit(self._velo, (0, 0))
        r = self.rect_menu_base()
        estilo.panel(p, r)
        titulos = {"almacen": t("almacen_titulo", usadas=sum(1 for c in self.casillas_almacen() if c),
                                total=ALMACEN_CASILLAS),
                   "sistemas": t("sistemas_titulo"), "terminal": t("terminal_titulo")}
        if self.menu_base == "cofre":
            titulos["cofre"] = self.titulo_cofre()
        p.blit(self.fuente.render(titulos[self.menu_base], True, tinta), (r.x + 20, r.y + 16))
        cerrar = self.fuente_chica.render(t("cerrar_ayuda"), True, suave)
        p.blit(cerrar, cerrar.get_rect(topright=(r.right - 20, r.y + 19)))
        estilo.separador(p, r.x + 14, r.right - 14, r.y + 44)
        raton = pygame.mouse.get_pos()
        if self.menu_base in ("almacen", "cofre"):
            p.blit(self.fuente_chica.render(t("almacen_mochila"), True, suave), (r.x + 20, r.y + 54))
            caja0 = self.rect_almacen_base(0)
            p.blit(self.fuente_chica.render(t("cofre_sacar" if self.menu_base == "cofre" else "almacen_sacar"),
                                            True, suave), (caja0.x, r.y + 54))
            for i, contenido in enumerate(self.inventario.casillas()):
                caja = self.rect_mochila_base(i)
                estilo.casilla(p, caja, mouse=caja.collidepoint(raton) and contenido is not None)
                if contenido:
                    self._dibujar_en_casilla(caja, *contenido)
            for i, contenido in enumerate(self.contenedor_abierto()[0]):
                caja = self.rect_almacen_base(i)
                estilo.casilla(p, caja, mouse=caja.collidepoint(raton) and contenido is not None)
                if contenido:
                    self._dibujar_en_casilla(caja, *contenido)
            x_linea = caja0.x - 16
            pygame.draw.line(p, estilo.BISEL, (x_linea, r.y + 56), (x_linea, r.bottom - 20))
        elif self.menu_base == "sistemas":
            self._dibujar_sistemas(r)
        else:
            p.blit(self.fuente.render(self._info_partida or t("terminal_no_hay"), True, tinta), (r.x + 30, r.y + 70))
            for boton, clave in zip(self.botones_terminal(), ("terminal_guardar", "terminal_cargar")):
                encima = boton.collidepoint(raton)
                pygame.draw.rect(p, estilo.CASILLA_ACTIVA if encima else estilo.CASILLA, boton, border_radius=6)
                pygame.draw.rect(p, estilo.ACENTO if encima else estilo.CONTORNO, boton, 2, border_radius=6)
                texto = self.fuente.render(t(clave), True, tinta)
                p.blit(texto, texto.get_rect(center=boton.center))
            p.blit(self.fuente_chica.render(t("terminal_atajos"), True, suave), (r.x + 30, r.bottom - 40))

    def _dibujar_en_casilla(self, caja, recurso, cantidad):
        icono = self.iconos_recurso_chico[recurso]
        self.pantalla.blit(icono, icono.get_rect(center=(caja.centerx, caja.centery - 5)))
        numero = self.fuente_chica.render(str(cantidad), True, estilo.TINTA)
        self.pantalla.blit(numero, numero.get_rect(bottomright=(caja.right - 5, caja.bottom - 3)))

    def _dibujar_sistemas(self, r):
        """Panel de sistemas: un renglón por color de cable (muestra con patrón,
        estado con luz y palabra) y abajo el resumen de la base. Solo lectura."""
        p = self.pantalla
        tinta, suave = estilo.TINTA, estilo.TINTA_SUAVE
        por_color, encendidas, apagadas, paneles = self.resumen_sistemas()
        y = r.y + 56
        p.blit(self.fuente_chica.render(t("sistemas_circuitos"), True, suave), (r.x + 24, y))
        y += 26
        for color in CABLE_COLORES:
            datos_color = por_color[color]
            self._muestra_color((r.x + 36, y + 10), color, 9)
            p.blit(self.fuente.render(t("color_" + color).capitalize(), True, tinta), (r.x + 54, y + 1))
            if datos_color["redes"] == 0:
                estado, luz = t("sistemas_sin_cable"), None
            elif datos_color["con"] == datos_color["redes"]:
                estado, luz = t("sistemas_con_energia"), COLOR_LUZ_ON
            elif datos_color["con"] == 0:
                estado, luz = t("sistemas_sin_energia"), COLOR_LUZ_OFF
            else:
                estado, luz = t("sistemas_parcial", p=datos_color["con"], n=datos_color["redes"]), COLOR_AVISO
            detalle = t("sistemas_circuito", cables=datos_color["cables"], maquinas=len(datos_color["maquinas"]))
            p.blit(self.fuente_chica.render(detalle, True, suave), (r.x + 160, y + 4))
            if luz:
                pygame.draw.circle(p, luz, (r.x + 382, y + 10), 6)
                pygame.draw.circle(p, COLOR_TALADRO_BORDE, (r.x + 382, y + 10), 6, 1)
            p.blit(self.fuente_chica.render(estado, True, tinta), (r.x + 396, y + 4))
            y += 36
        estilo.separador(p, r.x + 20, r.right - 20, y + 2)
        y += 14
        lineas = [t("sistemas_paneles", n=paneles),
                  t("sistemas_maquinas", on=encendidas, off=apagadas),
                  t("sistemas_produccion", o=self.producido["oxigeno"], a=self.producido["agua"],
                    c=self.producido["comida"]),
                  t("sistemas_dosis", n=f"{self.astronauta.dosis_msv:.0f}"),
                  t("antena_info_on") if self.contacto else t("sistemas_antena_no")]
        if self.polvo and self.polvo.tapa_paneles:
            lineas.append(t("sistemas_polvo"))
        for linea in lineas:
            p.blit(self.fuente.render(linea, True, tinta), (r.x + 24, y))
            y += 28
