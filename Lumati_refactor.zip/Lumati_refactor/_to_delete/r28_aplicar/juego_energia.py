"""Cables y energía en el juego: tender cables y piezas (negro, +, T, L), paneles
solares, tanque de agua, baterías, qué máquinas tienen energía y la física de los cables
flexibles (solo adorno).
"""

import math

import pygame

from energia import encontrar_redes, red_de, tiene_cable_vecino, toca_celdas, vecinos
from maquinas import Maquina
from textos import t
from config import (AGUA_MAX, BATERIA_CARGA, BATERIA_MAX, CABLE, CABLE_ACOPLE, CABLE_COLORES,
                    CABLE_FISICA, CABLE_FRENO, CABLE_GROSOR, CABLE_HOLGURA, CABLE_MAX,
                    CABLE_PIEZAS, CABLE_PISAR, CABLE_PUNTOS, CABLE_RESORTE, CABLE_SACUDIDA,
                    COLOR_CABLE_BORDE_DE, COLOR_CABLE_BRILLO_DE, COLOR_CABLE_DE, COLOR_TALADRO,
                    COLUMNAS, CON_ENERGIA, DIRECCION, FILAS, GENERADOR, GIRO, LADOS_FORMA,
                    LUZ_MINIMA_PANEL, NOCHE_APAGA_PANELES, OPCIONES_CABLE, OPUESTO, PATRON_CABLE,
                    ROCA, SUELO, TILE)


class EnergiaMixin:
    """Cables y energía en el juego: tender cables y piezas (negro, +, T, L), paneles
    solares, tanque de agua, baterías, qué máquinas tienen energía y la física de los cables
    flexibles (solo adorno)."""

    def usar_cable(self, fila, col):
        """Pone un cable en el suelo o lo quita si ya hay uno. Sobre una roca
        no se puede. Los índices ya vienen envueltos, así que funciona en los
        bordes."""
        tipo = self.mapa[fila][col]
        opcion = self.color_cable
        color = self.color_visual(opcion)
        pieza = (CABLE_PIEZAS[opcion], self.giro_cable) if opcion in CABLE_PIEZAS else None
        actual = (self.colores_cable.get((fila, col)), self.piezas_cable.get((fila, col)))
        if tipo == ROCA:
            self.mensaje = t("hay_roca")
        elif tipo not in (SUELO, CABLE):
            self.mensaje = t("solo_suelo")      # no se pisa una máquina, la base o un bloque
        elif tipo == CABLE and actual != (color, pieza):
            # Clic en un cable distinto (otro color, otra pieza u otro giro): se cambia
            # por lo elegido (no cuesta nada).
            self._poner_pieza(fila, col, color, pieza)
            self.sacudir_vecinos(fila, col)
            self._energia_sucia = True
            self.mensaje = t("cable_pintado", color=t("color_" + opcion))
        elif tipo == CABLE:                     # mismo color: se quita y vuelve al inventario
            self.mapa[fila][col] = SUELO
            self.colores_cable.pop((fila, col), None)
            self.piezas_cable.pop((fila, col), None)
            self._nodos_cable.pop((fila, col), None)
            self.sacudir_vecinos(fila, col)
            self.devolver_objeto("cable")
            self._energia_sucia = True
            redes = len(encontrar_redes(self.mapa, CABLE, self.colores_cable, self.puede_unir))
            self.mensaje = t("cable_quitado", n=redes)
        elif self.tiene_objeto("cable"):
            self.gastar_objeto("cable")
            self.mapa[fila][col] = CABLE
            self._poner_pieza(fila, col, color, pieza)
            self.sacudir_vecinos(fila, col)
            self._energia_sucia = True
            tam = len(red_de(self.mapa, CABLE, fila, col, self.colores_cable, self.puede_unir))
            self.mensaje = t("cable_puesto", n=tam, color=t("color_" + opcion))

    def cambiar_color_cable(self, paso=1):
        """Tecla C o rueda del mouse: siguiente (o anterior) color o pieza de cable."""
        i = OPCIONES_CABLE.index(self.color_cable)
        self.color_cable = OPCIONES_CABLE[(i + paso) % len(OPCIONES_CABLE)]
        clave = "color_elegido_pieza" if self.color_cable in CABLE_PIEZAS else "color_elegido"
        self.mensaje = t(clave, color=t("color_" + self.color_cable))

    def girar_pieza(self):
        """Tecla R con un conector o cable negro elegido: lo gira 90 grados."""
        self.giro_cable = (self.giro_cable + 1) % 4
        self.mensaje = t("pieza_girada", lados=" ".join(t("lado_" + l) for l in
                                                          self.lados_de_pieza((CABLE_PIEZAS[self.color_cable],
                                                                               self.giro_cable))))

    @staticmethod
    def color_visual(opcion):
        """Color con que se dibuja/guarda una opción: los conectores son "conector"."""
        if opcion in CABLE_COLORES or opcion == "negro":
            return opcion
        return "conector"

    def _poner_pieza(self, fila, col, color, pieza):
        self.colores_cable[(fila, col)] = color
        if pieza:
            self.piezas_cable[(fila, col)] = pieza
        else:
            self.piezas_cable.pop((fila, col), None)

    @staticmethod
    def lados_de_pieza(pieza):
        forma, giro = pieza
        lados = LADOS_FORMA[forma]
        for _ in range(giro % 4):
            lados = tuple(GIRO[l] for l in lados)
        return lados

    def lados_cable(self, f, c):
        """Lados por los que se une el cable en (f, c): todos, o los de su pieza."""
        pieza = self.piezas_cable.get((f, c))
        return ("arr", "der", "aba", "izq") if pieza is None else self.lados_de_pieza(pieza)

    @staticmethod
    def direccion_entre(a, b):
        """Lado de `a` por el que se llega a su vecino `b` (con la vuelta del mapa)."""
        df = (b[0] - a[0]) % FILAS
        dc = (b[1] - a[1]) % COLUMNAS
        if df == 1:
            return "aba"
        if df == FILAS - 1:
            return "arr"
        return "der" if dc == 1 else "izq"

    def puede_unir(self, a, b):
        """True si los cables vecinos a y b se unen: cada uno tiene abierto el lado
        que mira al otro, y son del mismo color salvo que uno sea pieza neutra
        (conector o cable negro), que une cualquier color."""
        d = self.direccion_entre(a, b)
        if d not in self.lados_cable(*a) or OPUESTO[d] not in self.lados_cable(*b):
            return False
        if a in self.piezas_cable or b in self.piezas_cable:
            return True
        return self.color_de(*a) == self.color_de(*b)

    def color_de(self, f, c):
        """Color del cable en (f, c); los cables viejos sin color cuentan como el primero."""
        return self.colores_cable.get((f, c), CABLE_COLORES[0])

    def usar_generador(self, fila, col):
        """Con la herramienta Panel solar: clic en suelo libre pone un panel;
        clic sobre un panel lo quita (igual que el cable). No se pone sobre
        rocas, cables o máquinas, ni encima del astronauta."""
        tipo = self.mapa[fila][col]
        if tipo == GENERADOR:
            self.mapa[fila][col] = SUELO
            self.devolver_objeto("generador")
            self._energia_sucia = True
            self.mensaje = t("generador_quitado")
            return
        if tipo != SUELO:
            self.mensaje = t("solo_suelo")
            return
        if not self.tiene_objeto("generador"):
            return
        self.mapa[fila][col] = GENERADOR
        if self.jugador.choca(self.mapa, self.jugador.x, self.jugador.y):
            self.mapa[fila][col] = SUELO          # deshacer: estorba el astronauta
            self.mensaje = t("generador_no_cabe")
            return
        self.gastar_objeto("generador")
        self._energia_sucia = True
        con_cable = tiene_cable_vecino(self.mapa, CABLE, fila, col)
        self.mensaje = t("generador_puesto" if con_cable else "generador_sin_cable")

    def usar_tanque_agua(self, fila, col):
        """Clic en el tanque de agua: si llevas agua, la guarda; si no, te da."""
        guardada = self.tanques_agua[(fila, col)]
        llevas = self.inventario["agua"]
        if llevas and guardada < AGUA_MAX:
            n = min(llevas, AGUA_MAX - guardada)
            self.inventario["agua"] -= n
            self.tanques_agua[(fila, col)] += n
            self.mensaje = t("agua_guardada", n=n, total=guardada + n, max=AGUA_MAX)
        elif guardada:
            n = min(guardada, self.inventario.espacio("agua"))
            if n:
                self.inventario.agregar("agua", n)
                self.tanques_agua[(fila, col)] -= n
                self.mensaje = t("agua_sacada", n=n, total=guardada - n, max=AGUA_MAX)
            else:
                self.mensaje = self._mensaje_lleno("agua")
        else:
            self.mensaje = t("tanque_agua_info", total=guardada, max=AGUA_MAX)

    def mover_agua(self):
        """Tanques de agua: reciben el agua lista de los purificadores pegados y
        llenan a los electrolizadores e invernaderos pegados (sin energía)."""
        for (f, c), agua in list(self.tanques_agua.items()):
            for v in vecinos(f, c, FILAS, COLUMNAS):
                mq = self.maquinas.get(v)
                if not isinstance(mq, Maquina):
                    continue
                if mq.recurso_salida == "agua" and mq.salida and agua < AGUA_MAX:
                    n = mq.retirar(AGUA_MAX - agua)
                    agua += n
                elif mq.recurso_entrada == "agua" and agua:
                    n = mq.depositar(agua)
                    agua -= n
            self.tanques_agua[(f, c)] = agua

    def paneles_activos(self):
        """False si los paneles no rinden: tormenta de polvo (Marte) o de noche."""
        if self.polvo and self.polvo.tapa_paneles:
            return False
        if NOCHE_APAGA_PANELES and self.clima.reloj.luz < LUZ_MINIMA_PANEL:
            return False
        return True

    def _clave_actual(self):
        """Lo que, si cambia, obliga a recalcular la energía sin tocar cables."""
        return self.paneles_activos(), frozenset(b for b, q in self.baterias.items() if q > 0)

    def recalcular_energia(self):
        """Vuelve a calcular qué cables tienen energía. Una red tiene energía si
        toca un panel solar activo o una batería con carga. Es un relleno de toda
        la red, así que solo se hace cuando algo cambia (no en cada cuadro).
        También decide si cada batería se carga, da energía o está vacía."""
        activos = self.paneles_activos()
        energizados = set()
        self._estado_bateria = {b: "vacia" for b in self.baterias}
        for red in encontrar_redes(self.mapa, CABLE, self.colores_cable, self.puede_unir):
            vecinas = {v for f, c in red for v in vecinos(f, c, FILAS, COLUMNAS)}
            panel = activos and any(self.mapa[f][c] == GENERADOR for f, c in vecinas)
            bats = [v for v in vecinas if v in self.baterias]
            cargada = any(self.baterias[b] > 0 for b in bats)
            if panel or cargada:
                energizados |= red
            for b in bats:
                if panel:
                    self._estado_bateria[b] = "carga"
                elif self.baterias[b] > 0 and self._estado_bateria[b] != "carga":
                    self._estado_bateria[b] = "descarga"
        self._energizados = energizados
        self._clave_energia = self._clave_actual()
        self._energia_sucia = False

    def actualizar_baterias(self, dt, avisar=True):
        """Carga o descarga las baterías y avisa cuando los paneles dejan de rendir."""
        activos = self.paneles_activos()
        if avisar and not activos and self._paneles_previo and not (self.polvo and self.polvo.tapa_paneles):
            self.mensaje = t("noche_paneles")
        self._paneles_previo = activos
        if not self.baterias:
            return
        if self._energia_sucia or self._clave_actual() != self._clave_energia:
            self.recalcular_energia()
        for b, carga in self.baterias.items():
            estado = self._estado_bateria.get(b, "vacia")
            if estado == "carga":
                self.baterias[b] = min(BATERIA_MAX, carga + BATERIA_CARGA * dt)
            elif estado == "descarga":
                self.baterias[b] = max(0.0, carga - dt)

    def _texto_bateria(self, fila, col):
        if self._energia_sucia or self._clave_actual() != self._clave_energia:
            self.recalcular_energia()
        p = round(100 * self.baterias.get((fila, col), 0.0) / BATERIA_MAX)
        estado = self._estado_bateria.get((fila, col), "vacia")
        return t("bateria_info", p=p, estado=t("bateria_" + estado))

    def tiene_energia(self, fila, col):
        """True si la máquina en (fila, col) recibe energía: toca un cable cuya
        red toca un panel solar. Este es el único lugar donde se decide.

        SIMPLIFICACIONES de la versión fácil (el documento de diseño las deja
        para la completa): el panel siempre rinde (no hay noche ni polvo) y no
        hay límite de capacidad: un panel alimenta toda su red."""
        if self._energia_sucia or self._clave_actual() != self._clave_energia:
            self.recalcular_energia()
        return toca_celdas(self._energizados, fila, col, FILAS, COLUMNAS)

    # -- cables flexibles (solo adorno: no cambian la red de energía) ----------
    def _vecinos_cable(self, f, c):
        """Los cuadros vecinos (arriba, abajo, izquierda, derecha) que son cable DEL MISMO
        color, con módulo (la onda solo viaja por el mismo cable)."""
        color = self.color_de(f, c)
        return [((f + df) % FILAS, (c + dc) % COLUMNAS) for df, dc in ((-1, 0), (1, 0), (0, -1), (0, 1))
                if self.mapa[(f + df) % FILAS][(c + dc) % COLUMNAS] == CABLE
                and self.color_de((f + df) % FILAS, (c + dc) % COLUMNAS) == color]

    def empujar_cable(self, f, c, vx, vy):
        """Suma velocidad al nodo del cable en (f, c) (lo despierta si estaba quieto)."""
        if self.mapa[f][c] != CABLE:
            return
        nodo = self._nodos_cable.setdefault((f, c), [0.0, 0.0, 0.0, 0.0])
        nodo[2] += vx
        nodo[3] += vy

    def sacudir_vecinos(self, fila, col):
        """Al poner o quitar un cable, los cables pegados reciben un empujón hacia
        afuera (y el nuevo, uno chiquito): se ve cómo se acomodan."""
        for df, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            self.empujar_cable((fila + df) % FILAS, (col + dc) % COLUMNAS,
                               dc * CABLE_SACUDIDA, df * CABLE_SACUDIDA)
        self.empujar_cable(fila, col, CABLE_SACUDIDA * 0.4, -CABLE_SACUDIDA * 0.3)

    def pisar_cable(self, dir_x, dir_y, dt):
        """Si el astronauta camina sobre un cable, lo empuja en la dirección del paso."""
        cx, cy = self.jugador.centro
        f, c = int(cy // TILE) % FILAS, int(cx // TILE) % COLUMNAS
        self.empujar_cable(f, c, dir_x * CABLE_PISAR * dt, dir_y * CABLE_PISAR * dt)

    def actualizar_cables(self, dt):
        """Resorte amortiguado de cada nodo que se mueve: regresa a su lugar, se
        frena y jala un poco a sus vecinos (así la onda recorre el cable). Los
        nodos que ya se asentaron se borran: un cable quieto no cuesta nada."""
        if not CABLE_FISICA or not self._nodos_cable:
            return
        nodos = self._nodos_cable
        # Los vecinos de un nodo que se mueve se despiertan para que les llegue la onda.
        for (f, c), (dx, dy, _, _) in list(nodos.items()):
            if abs(dx) + abs(dy) > 0.5:
                for v in self._vecinos_cable(f, c):
                    nodos.setdefault(v, [0.0, 0.0, 0.0, 0.0])
        previo = {k: (n[0], n[1]) for k, n in nodos.items()}
        for (f, c), nodo in list(nodos.items()):
            if self.mapa[f][c] != CABLE:            # lo quitaron
                del nodos[(f, c)]
                continue
            vecinos_ = self._vecinos_cable(f, c)
            ax = -CABLE_RESORTE * nodo[0] - CABLE_FRENO * nodo[2]
            ay = -CABLE_RESORTE * nodo[1] - CABLE_FRENO * nodo[3]
            for v in vecinos_:
                vx_, vy_ = previo.get(v, (0.0, 0.0))
                ax += CABLE_ACOPLE * (vx_ - nodo[0]) / len(vecinos_)
                ay += CABLE_ACOPLE * (vy_ - nodo[1]) / len(vecinos_)
            nodo[2] += ax * dt                       # Euler semi-implícito: estable con dt chico
            nodo[3] += ay * dt
            nodo[0] = max(-CABLE_MAX, min(CABLE_MAX, nodo[0] + nodo[2] * dt))
            nodo[1] = max(-CABLE_MAX, min(CABLE_MAX, nodo[1] + nodo[3] * dt))
            if abs(nodo[0]) + abs(nodo[1]) < 0.05 and abs(nodo[2]) + abs(nodo[3]) < 0.5:
                del nodos[(f, c)]                    # ya se asentó

    def _punto_nodo(self, f, c, x, y):
        """Dónde se dibuja el nodo del cable (f, c) cuyo centro en pantalla es (x, y):
        un poco corrido por la holgura (una onda lenta y fija según el cuadro, así
        el cable no se ve tieso) más lo que lo mueva el resorte."""
        hx = math.sin(f * 1.3 + c * 0.9) * CABLE_HOLGURA
        hy = math.sin(f * 0.8 - c * 1.6 + 1.0) * CABLE_HOLGURA
        dx, dy = self._nodos_cable.get((f, c), (0.0, 0.0, 0.0, 0.0))[:2]
        return (x + hx + dx, y + hy + dy)

    def dibujar_cables(self, cuadros):
        """Dibuja los cables visibles como curvas: de cada nodo sale medio tramo
        hacia cada vecino conectado (cable del MISMO color, panel o máquina). Los
        dos medios tramos de una unión se calculan con la misma curva (desde cada
        lado), así se juntan sin corte y funciona igual al cruzar el borde del
        mapa. Primero todos los contornos, luego el color, el patrón y el brillo."""
        conecta = {GENERADOR} | CON_ENERGIA
        trazos = []
        centros = []                                            # conectores: su caja va encima
        for f, c, x, y in cuadros:
            color = self.color_de(f, c)
            pieza = self.piezas_cable.get((f, c))
            lados = self.lados_cable(f, c)
            a = self._punto_nodo(f, c, x + TILE / 2, y + TILE / 2)   # nodo de este cable
            if pieza and pieza[0] != "negro":
                centros.append(a)
            for lado in lados:
                df, dc = DIRECCION[lado]
                fv, cv = (f + df) % FILAS, (c + dc) % COLUMNAS
                tipo = self.mapa[fv][cv]
                es_cable = tipo == CABLE and self.puede_unir((f, c), (fv, cv))
                if not es_cable and tipo not in conecta:
                    if pieza:                                   # la pieza muestra su forma aunque esté suelta
                        p1 = (a[0] + dc * TILE / 4, a[1] + df * TILE / 4)
                        trazos.append((a, p1, (a[0] + dc * TILE * 0.42, a[1] + df * TILE * 0.42), False, color))
                    continue
                # La curva sale del nodo a lo largo del cable (tangente pareja en el nodo)...
                p1 = (a[0] + dc * TILE / 4, a[1] + df * TILE / 4)
                if es_cable:
                    # ...y llega a la mitad del camino al nodo vecino. El vecino dibuja la otra
                    # mitad igual, así que la unión queda lisa.
                    b = self._punto_nodo(fv, cv, x + TILE / 2 + dc * TILE, y + TILE / 2 + df * TILE)
                    trazos.append((a, p1, ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2), False, color))
                else:                                           # hacia una máquina: hasta el borde del cuadro
                    b = (x + TILE / 2 + dc * TILE / 2, y + TILE / 2 + df * TILE / 2)
                    trazos.append((a, p1, b, True, color))
            trazos.append((a, a, a, False, color))              # nudito en el nodo (también si está suelto)
        pantalla = self.pantalla
        g = CABLE_GROSOR
        curvas = []
        for p0, p1, p2, enchufe, color in trazos:
            puntos = []
            for i in range(CABLE_PUNTOS + 1):
                t_ = i / CABLE_PUNTOS
                u = 1 - t_
                puntos.append((u * u * p0[0] + 2 * u * t_ * p1[0] + t_ * t_ * p2[0],
                               u * u * p0[1] + 2 * u * t_ * p1[1] + t_ * t_ * p2[1]))
            curvas.append((puntos, enchufe, color))
        for puntos, enchufe, color in curvas:                  # contorno
            borde = COLOR_CABLE_BORDE_DE[color]
            if len(set(puntos)) > 1:
                pygame.draw.lines(pantalla, borde, False, puntos, g + 3)
            pygame.draw.circle(pantalla, borde, puntos[0], (g + 3) // 2)
            if enchufe:                                        # enchufe pegado a la máquina
                pygame.draw.circle(pantalla, borde, puntos[-1], g // 2 + 3)
        for puntos, enchufe, color in curvas:                  # color del cable
            relleno = COLOR_CABLE_DE[color]
            if len(set(puntos)) > 1:
                pygame.draw.lines(pantalla, relleno, False, puntos, g)
            pygame.draw.circle(pantalla, relleno, puntos[0], g // 2)
            for p in puntos[1:-1]:                             # tapa las muescas de las uniones
                pygame.draw.circle(pantalla, relleno, p, g // 2 - 1)
            if enchufe:
                pygame.draw.circle(pantalla, COLOR_TALADRO, puntos[-1], g // 2 + 1)
        for puntos, _, color in curvas:                        # patrón: rayas (azul) o puntos (amarillo)
            self._patron_cable(puntos, color)
        for puntos, _, color in curvas:                        # brillo fino
            if len(set(puntos)) > 1 and PATRON_CABLE[color] == "liso":
                pygame.draw.lines(pantalla, COLOR_CABLE_BRILLO_DE[color], False,
                                  [(px - 1, py - 1) for px, py in puntos], 2)
        for cx, cy in centros:                                 # caja de cada conector
            caja = pygame.Rect(0, 0, 14, 14)
            caja.center = (round(cx), round(cy))
            pygame.draw.rect(pantalla, COLOR_CABLE_DE["conector"], caja, border_radius=3)
            pygame.draw.rect(pantalla, COLOR_CABLE_BORDE_DE["conector"], caja, 2, border_radius=3)
            pygame.draw.circle(pantalla, COLOR_CABLE_BORDE_DE["conector"], caja.center, 2)

    def _patron_cable(self, puntos, color):
        """Marca el patrón de un color de cable sobre su curva, para que se distinga
        sin depender del color: rayitas cruzadas (azul) o puntos (amarillo)."""
        patron = PATRON_CABLE[color]
        if patron == "liso" or len(puntos) < 3:
            return
        borde = COLOR_CABLE_BORDE_DE[color]
        medio = len(puntos) // 2
        p, antes, despues = puntos[medio], puntos[medio - 1], puntos[medio + 1]
        if patron == "puntos":
            pygame.draw.circle(self.pantalla, borde, (round(p[0]), round(p[1])), 2)
            return
        tx, ty = despues[0] - antes[0], despues[1] - antes[1]      # tangente de la curva
        largo = math.hypot(tx, ty)
        if largo < 0.5:
            return
        nx, ny = -ty / largo, tx / largo                           # normal: la raya cruza el cable
        r = CABLE_GROSOR / 2 - 0.5
        pygame.draw.line(self.pantalla, borde, (p[0] - nx * r, p[1] - ny * r), (p[0] + nx * r, p[1] + ny * r), 2)
