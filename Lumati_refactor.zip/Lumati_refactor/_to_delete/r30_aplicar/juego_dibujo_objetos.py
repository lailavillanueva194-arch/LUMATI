"""Dibujo de cada objeto del mapa: cables, tanque de agua,
electrolizador, batería, taladro, panel solar, etiquetas, Fabricador, antena, piso
picado y caminos, bloques, máquinas y plantas.
"""

import math
import random

import pygame

import estilo
from energia import tiene_cable_vecino
from maquinas import ALMACEN_MAX, ENTRADA_MAX, PRODUCIENDO, SALIDA_MAX, Tanque
from config import (AGUA_MAX, ARTE_CULTIVOS, BATERIA_MAX, CABLE, CABLE_GROSOR,
                    COLOR_ANTENA, COLOR_BLOQUE, COLOR_BLOQUE_CLARO, COLOR_CABLE_DE,
                    COLOR_CELDA_SOLAR, COLOR_FABRICADOR, COLOR_HIDROGENO, COLOR_HOJA,
                    COLOR_LUZ_OFF, COLOR_LUZ_ON, COLOR_MAQUINA, COLOR_PANEL_SOLAR, COLOR_RECURSO,
                    COLOR_REMOLINO, COLOR_SALIDA, COLOR_TALADRO_BORDE, COLOR_TALADRO_NIVEL,
                    COLOR_VELO_POLVO, COLUMNAS, CON_ENERGIA, ELECTROLIZADOR, ESCALA_ARTE, FILAS,
                    GENERADOR, INVERNADERO, MAQUINAS, MARTE, PICADO, PURIFICADOR, RIEGO_SEGUNDOS,
                    SUELO_PLANTAS, TALADRO_PIXEL, TANQUE, TILE, VIBRA_TALADRO)


class DibujoObjetosMixin:
    """Dibujo de cada objeto del mapa: cables, tanque de agua,
    electrolizador, batería, taladro, panel solar, etiquetas, Fabricador, antena, piso
    picado y caminos, bloques, máquinas y plantas."""

    def dibujar_cable(self, f, c, x, y):
        """Un cuadrito en el centro del cuadro (x, y) y un brazo hacia cada
        vecino que también sea cable (vecinos con módulo, como en el borde)."""
        # Con colores ya no se usan las piezas PNG de cable (no se pueden teñir).
        color = self.color_de(f, c)
        relleno = COLOR_CABLE_DE[color]

        def conecta(df, dc):
            fv, cv = (f + df) % FILAS, (c + dc) % COLUMNAS
            tipo = self.mapa[fv][cv]
            return (tipo == CABLE and self.color_de(fv, cv) == color) or tipo in ({GENERADOR} | CON_ENERGIA)
        cx, cy = x + TILE // 2, y + TILE // 2
        g = CABLE_GROSOR
        mitad = TILE // 2
        pygame.draw.rect(self.pantalla, relleno, (cx - g // 2, cy - g // 2, g, g))
        for df, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            if not conecta(df, dc):
                continue
            if dc:     # brazo horizontal
                rect = pygame.Rect(min(cx, cx + dc * mitad), cy - g // 2, mitad, g)
            else:      # brazo vertical
                rect = pygame.Rect(cx - g // 2, min(cy, cy + df * mitad), g, mitad)
            pygame.draw.rect(self.pantalla, relleno, rect)

    def _escalado(self, nombre, cuadro, lado):
        """Sprite de las diseñadoras a `lado` píxeles (guardado para no escalar cada vez)."""
        clave = (nombre, cuadro, lado)
        if clave not in self._img_cache:
            self._img_cache[clave] = pygame.transform.scale(self.sprites[nombre][cuadro], (lado, lado))
        return self._img_cache[clave]

    def dibujar_tanque_agua(self, f, c, x, y):
        """Tanque de agua: cilindro claro con ventana; el agua sube según lo guardado."""
        p = self.pantalla
        nivel = self.tanques_agua.get((f, c), 0) / AGUA_MAX
        cuerpo = pygame.Rect(x + 9, y + 5, TILE - 18, TILE - 10)
        pygame.draw.rect(p, (214, 224, 234), cuerpo, border_radius=9)
        ventana = cuerpo.inflate(-10, -12)
        pygame.draw.rect(p, (40, 56, 72), ventana, border_radius=4)
        alto = int(ventana.h * nivel)
        if alto:
            agua = pygame.Rect(ventana.x, ventana.bottom - alto, ventana.w, alto)
            pygame.draw.rect(p, COLOR_SALIDA["agua"], agua, border_radius=4)
            pygame.draw.line(p, (210, 240, 255), (agua.x + 2, agua.y + 1), (agua.right - 3, agua.y + 1), 2)
        pygame.draw.rect(p, COLOR_TALADRO_BORDE, cuerpo, 2, border_radius=9)
        pygame.draw.line(p, COLOR_TALADRO_BORDE, (cuerpo.x + 3, cuerpo.y + 5), (cuerpo.right - 4, cuerpo.y + 5), 1)
        # gotita arriba: es de agua (forma, no solo color)
        gx, gy = cuerpo.centerx, cuerpo.y - 1
        pygame.draw.circle(p, COLOR_SALIDA["agua"], (gx, gy + 3), 3)
        pygame.draw.polygon(p, COLOR_SALIDA["agua"], [(gx - 3, gy + 2), (gx + 3, gy + 2), (gx, gy - 4)])

    def _dibujar_caja_electrolizador(self, maquina, x, y, produciendo):
        """Electrolizador como caja: ventana con agua (según lo que tiene dentro),
        dos electrodos, burbujas que suben mientras trabaja y dos salidas arriba
        (O2 celeste a la izquierda, H2 blanca a la derecha)."""
        p = self.pantalla
        caja = pygame.Rect(x + 5, y + 9, TILE - 10, TILE - 14)
        pygame.draw.rect(p, (196, 204, 214), caja, border_radius=3)
        pygame.draw.rect(p, COLOR_TALADRO_BORDE, caja, 2, border_radius=3)
        for dx, color in ((10, COLOR_SALIDA["oxigeno"]), (TILE - 20, COLOR_HIDROGENO)):   # salidas de gas
            tubo = pygame.Rect(x + dx, y + 3, 7, 8)
            pygame.draw.rect(p, color, tubo)
            pygame.draw.rect(p, COLOR_TALADRO_BORDE, tubo, 1)
        ventana = pygame.Rect(caja.x + 9, caja.y + 5, caja.w - 18, caja.h - 12)
        pygame.draw.rect(p, (34, 48, 64), ventana)
        alto = int(ventana.h * min(1.0, maquina.entrada / ENTRADA_MAX))
        if alto:
            pygame.draw.rect(p, COLOR_SALIDA["agua"], (ventana.x, ventana.bottom - alto, ventana.w, alto))
        for ex in (ventana.x + 4, ventana.right - 5):            # electrodos
            pygame.draw.line(p, (90, 96, 108), (ex, ventana.y + 2), (ex, ventana.bottom - 2), 2)
        if produciendo:                                          # burbujas que suben
            for k in range(4):
                fase = (self._tiempo * 0.9 + k * 0.25) % 1.0
                bx = ventana.x + 6 + (k % 2) * (ventana.w - 12)
                by = ventana.bottom - 3 - fase * (ventana.h - 6)
                pygame.draw.circle(p, (235, 248, 255), (int(bx), int(by)), 2)
        pygame.draw.rect(p, COLOR_TALADRO_BORDE, ventana, 1)

    def dibujar_bateria(self, f, c, x, y):
        """Batería (panel de control): la aguja marca la carga, abajo una barra
        amarilla y la luz verde mientras guarda o da energía."""
        pantalla = self.pantalla
        carga = self.baterias.get((f, c), 0.0) / BATERIA_MAX
        if "bateria" in self.sprites:
            cuadro = 0 if carga > 0.66 else (1 if carga > 0.33 else 2)
            pantalla.blit(self._escalado("bateria", cuadro, TILE), (x, y))
        else:
            cuerpo = pygame.Rect(x + 8, y + 6, TILE - 16, TILE - 12)
            pygame.draw.rect(pantalla, (236, 238, 242), cuerpo, border_radius=4)
            pygame.draw.rect(pantalla, COLOR_TALADRO_BORDE, cuerpo, 2, border_radius=4)
        barra = pygame.Rect(x + 8, y + TILE - 8, TILE - 16, 5)
        pygame.draw.rect(pantalla, (40, 44, 52), barra)
        pygame.draw.rect(pantalla, (240, 210, 80), (barra.x, barra.y, int(barra.w * carga), barra.h))
        pygame.draw.rect(pantalla, COLOR_TALADRO_BORDE, barra, 1)
        activa = self._estado_bateria.get((f, c)) in ("carga", "descarga")
        luz = COLOR_LUZ_ON if activa else COLOR_LUZ_OFF
        pygame.draw.circle(pantalla, luz, (x + TILE - 10, y + 9), 4)
        pygame.draw.circle(pantalla, COLOR_TALADRO_BORDE, (x + TILE - 10, y + 9), 4, 1)

    def dibujar_taladro(self, f, c, x, y):
        """Taladro provisional (los PNG vendrán después). Se ve: el color según
        el nivel, tantos puntitos arriba como nivel, la broca, una raya de
        progreso, 3 casillas de almacén (cada una del color de lo que sacó) y
        una luz: verde si está produciendo, roja si no."""
        pantalla = self.pantalla
        taladro = self.taladros[(f, c)]
        cuerpo = pygame.Rect(x + 4, y + 4, TILE - 8, TILE - 8)
        produce = taladro.estado(self.tiene_energia(f, c)) == PRODUCIENDO
        if "taladro_niveles" in self.sprites:
            # Dibujo de las diseñadoras (uno por nivel), a tamaño nativo. Mientras
            # trabaja, tiembla un poco.
            dx = dy = 0
            if produce:
                dx = round(math.sin(self._tiempo * 47 + f * 3 + c) * VIBRA_TALADRO)
                dy = round(math.sin(self._tiempo * 61 + c * 5 + f) * VIBRA_TALADRO * 0.6)
            img = self.imagen_taladro(taladro.nivel)
            pantalla.blit(img, img.get_rect(midbottom=(x + TILE // 2 + dx, y + TILE - 1 + dy)))
        elif "taladro" in self.sprites:
            pantalla.blit(self.sprites["taladro"][0], (x, y))
        else:
            pygame.draw.rect(pantalla, COLOR_TALADRO_NIVEL[taladro.nivel], cuerpo)
            pygame.draw.rect(pantalla, COLOR_TALADRO_BORDE, cuerpo, 2)
            pygame.draw.polygon(pantalla, COLOR_TALADRO_BORDE,          # broca
                                [(x + 9, y + 20), (x + 23, y + 20), (x + 16, y + 37)])
        if "taladro_niveles" not in self.sprites:
            for i in range(taladro.nivel):                  # nivel (el dibujo ya lo muestra)
                pygame.draw.rect(pantalla, COLOR_TALADRO_BORDE, (x + 9 + i * 7, y + 9, 5, 5))
        # Indicadores sobre una base oscura, para que se lean encima del dibujo grande.
        pygame.draw.rect(pantalla, (24, 28, 36), (x + 25, y + 29, 3 * 7 + 3, 12), border_radius=3)
        for i in range(ALMACEN_MAX):                        # almacén
            casilla = (x + 27 + i * 7, y + 31, 6, 8)
            if i < taladro.cantidad:
                pygame.draw.rect(pantalla, COLOR_RECURSO[taladro.almacen[i]], casilla)
            pygame.draw.rect(pantalla, (150, 158, 170), casilla, 1)
        if taladro.estado(self.tiene_energia(f, c)) == PRODUCIENDO:     # progreso
            ancho = int((TILE - 14) * taladro.progreso / taladro.tiempo_unidad)
            pygame.draw.rect(pantalla, (24, 28, 36), (x + 6, y + TILE - 10, TILE - 12, 5), border_radius=2)
            pygame.draw.rect(pantalla, COLOR_LUZ_ON, (x + 7, y + TILE - 9, ancho, 3))
        produciendo = taladro.estado(self.tiene_energia(f, c)) == PRODUCIENDO
        luz = COLOR_LUZ_ON if produciendo else COLOR_LUZ_OFF
        pygame.draw.circle(pantalla, luz, (x + TILE - 12, y + 13), 5)
        pygame.draw.circle(pantalla, COLOR_TALADRO_BORDE, (x + TILE - 12, y + 13), 5, 1)

    def dibujar_generador(self, f, c, x, y):
        """Panel solar provisional (los PNG vendrán después): marco gris, una
        rejilla de 2x3 celdas y una luz: verde si toca un cable, roja si no."""
        pantalla = self.pantalla
        marco = pygame.Rect(x + 4, y + 4, TILE - 8, TILE - 8)
        if "panel_solar_mapa" in self.sprites:
            # El panel sigue al Sol: inclinado en la mañana, plano a mediodía y de noche,
            # inclinado al otro lado en la tarde.
            hora = self.clima.reloj.hora if hasattr(self.clima.reloj, "hora") else 12
            cuadro = 0 if 6 <= hora < 11 else (1 if 14 <= hora < 19 else 2)
            if cuadro not in self._panel_cache:
                self._panel_cache[cuadro] = pygame.transform.scale(
                    self.sprites["panel_solar_mapa"][cuadro], (TILE, TILE))
            pantalla.blit(self._panel_cache[cuadro], (x, y))
        elif "panel_solar" in self.sprites:
            pantalla.blit(self.sprites["panel_solar"][0], (x, y))
        else:
            pygame.draw.rect(pantalla, COLOR_PANEL_SOLAR, marco)
            pygame.draw.rect(pantalla, COLOR_TALADRO_BORDE, marco, 2)
            for fila in range(2):
                for col in range(3):
                    celda = (x + 9 + col * 10, y + 15 + fila * 11, 8, 9)
                    pygame.draw.rect(pantalla, COLOR_CELDA_SOLAR, celda)
                    pygame.draw.rect(pantalla, COLOR_TALADRO_BORDE, celda, 1)
        if self._paneles_sucios > 0.02:                  # Marte: polvo sobre el panel (adorno)
            if self._panel_polvo is None:
                self._panel_polvo = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
                azar = random.Random(3)
                pygame.draw.rect(self._panel_polvo, (*COLOR_VELO_POLVO, 120), (6, 8, TILE - 12, TILE - 16),
                                 border_radius=3)
                for _ in range(26):
                    px, py = azar.randint(7, TILE - 9), azar.randint(9, TILE - 11)
                    pygame.draw.circle(self._panel_polvo, (*COLOR_REMOLINO, 200), (px, py), azar.randint(1, 3))
            self._panel_polvo.set_alpha(int(230 * self._paneles_sucios))
            pantalla.blit(self._panel_polvo, (x, y))
        conectado = tiene_cable_vecino(self.mapa, CABLE, f, c)
        if not self.paneles_activos():                   # de noche o tapado por el polvo
            conectado = False
        luz = COLOR_LUZ_ON if conectado else COLOR_LUZ_OFF
        pygame.draw.circle(pantalla, luz, (x + TILE - 12, y + 10), 4)
        pygame.draw.circle(pantalla, COLOR_TALADRO_BORDE, (x + TILE - 12, y + 10), 4, 1)

    def imagen_taladro(self, nivel):
        """El dibujo del taladro de ese nivel, recortado a la figura y agrandado
        TALADRO_PIXEL veces (se hace una vez). Los 3 niveles usan el mismo recorte
        para que no cambie de lugar al mejorarlo."""
        clave = ("taladro_grande", nivel)
        if clave not in self._img_cache:
            cuadros = self.sprites["taladro_niveles"]          # ya vienen x3 (ESCALA_ARTE)
            caja = cuadros[0].get_bounding_rect()
            for cuadro in cuadros[1:]:
                caja = caja.union(cuadro.get_bounding_rect())
            e = ESCALA_ARTE                                    # recorte en píxeles enteros del dibujo
            x0, y0 = caja.x // e * e, caja.y // e * e
            x1, y1 = -(-caja.right // e) * e, -(-caja.bottom // e) * e
            recorte = cuadros[nivel - 1].subsurface((x0, y0, x1 - x0, y1 - y0))
            tam = (round((x1 - x0) // e * TALADRO_PIXEL), round((y1 - y0) // e * TALADRO_PIXEL))
            self._img_cache[clave] = pygame.transform.scale(recorte, tam)
        return self._img_cache[clave]

    def dibujar_fabricador(self, x, y):
        """El Fabricador (máquina de crafteo), dibujado por código: una caja
        blanca de estación con una pantallita del acento frío y una boca de
        salida abajo. Arte provisional, sin PNG."""
        p = self.pantalla
        cuerpo = pygame.Rect(x + 4, y + 6, TILE - 8, TILE - 10)
        pygame.draw.rect(p, COLOR_FABRICADOR, cuerpo, border_radius=5)
        pygame.draw.rect(p, estilo.CONTORNO, cuerpo, 2, border_radius=5)
        pantalla_chica = pygame.Rect(cuerpo.x + 6, cuerpo.y + 5, cuerpo.w - 12, 11)
        pygame.draw.rect(p, estilo.ACENTO, pantalla_chica, border_radius=2)
        pygame.draw.line(p, estilo.PANEL_LUZ, (pantalla_chica.x + 3, pantalla_chica.y + 3),
                         (pantalla_chica.x + 12, pantalla_chica.y + 3), 2)
        boca = pygame.Rect(cuerpo.centerx - 9, cuerpo.bottom - 13, 18, 9)
        pygame.draw.rect(p, estilo.FONDO_BARRA, boca, border_radius=2)
        for i in range(3):                                   # rejilla de ventilación
            pygame.draw.line(p, estilo.MARCO, (cuerpo.x + 6, cuerpo.y + 21 + i * 4),
                             (cuerpo.x + 12, cuerpo.y + 21 + i * 4), 1)

    def dibujar_antena(self, f, c, x, y):
        """Antena de comunicación, dibujada por código: base blanca, mástil y un
        plato que mira al cielo, más la luz verde/roja. Con energía, un anillo
        suave sale del plato (despacio, sin parpadear)."""
        p = self.pantalla
        encendida = self.tiene_energia(f, c)
        base = pygame.Rect(x + 12, y + TILE - 14, TILE - 24, 9)
        pygame.draw.rect(p, COLOR_ANTENA, base, border_radius=3)
        pygame.draw.rect(p, estilo.CONTORNO, base, 2, border_radius=3)
        cx = x + TILE // 2
        pygame.draw.line(p, estilo.CONTORNO, (cx, base.top), (cx, y + 18), 4)
        pygame.draw.line(p, COLOR_ANTENA, (cx, base.top), (cx, y + 18), 2)
        plato = pygame.Rect(cx - 15, y + 5, 30, 18)
        pygame.draw.ellipse(p, COLOR_ANTENA, plato)
        pygame.draw.ellipse(p, estilo.CONTORNO, plato, 2)
        pygame.draw.line(p, estilo.CONTORNO, (cx, plato.centery), (cx + 6, plato.top - 2), 2)
        pygame.draw.circle(p, estilo.ACENTO, (cx + 6, plato.top - 2), 3)
        if encendida:                          # ondas: crecen despacio (periodo de 1.6 s)
            r = 10 + int(10 * estilo.pulso())
            pygame.draw.circle(p, estilo.ACENTO, (cx + 6, plato.top - 2), r, 1)
        luz = COLOR_LUZ_ON if encendida else COLOR_LUZ_OFF
        pygame.draw.circle(p, luz, (x + TILE - 11, y + TILE - 10), 4)
        pygame.draw.circle(p, COLOR_TALADRO_BORDE, (x + TILE - 11, y + TILE - 10), 4, 1)

    def dibujar_terreno(self, tipo, x, y, f=0, c=0):
        """Suelo picado (tierra removida con marcas) o camino (piedras dispersas)."""
        pantalla = self.pantalla
        marte = self.destino == MARTE
        if tipo == PICADO:
            capa = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
            capa.fill((60, 30, 20, 70) if marte else (20, 20, 26, 70))
            pantalla.blit(capa, (x, y))
            oscuro = (90, 50, 36) if marte else (70, 70, 78)
            for i in range(3):                         # surcos del pico
                yy = y + 10 + i * 12
                pygame.draw.line(pantalla, oscuro, (x + 8 + i * 3, yy), (x + TILE - 12 + i * 2, yy + 3), 3)
            pygame.draw.rect(pantalla, oscuro, (x + 2, y + 2, TILE - 4, TILE - 4), 2, border_radius=4)
        else:
            pantalla.blit(self._piedras_camino(f, c, marte), (x, y))

    def _piedras_camino(self, f, c, marte):
        """Camino de piedras planas dispersas. Cada cuadro tiene su propio
        acomodo (siempre el mismo) y se dibuja una sola vez (caché)."""
        if not hasattr(self, "_cache_piedras"):
            self._cache_piedras = {}
        clave = (f, c, marte)
        if clave not in self._cache_piedras:
            azar = random.Random(f * 977 + c * 131 + 7)
            capa = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
            # Fondo del camino: tierra apisonada un poco más oscura que el suelo (sin borde: los cuadros se unen).
            # Semitransparente: se ve la textura del suelo debajo y combina con él.
            fondo = (96, 54, 38, 85) if marte else (70, 70, 78, 85)
            borde = (120, 74, 54, 140) if marte else (96, 96, 104, 140)
            pygame.draw.rect(capa, fondo, (0, 0, TILE, TILE))
            for _ in range(10):                              # granitos para que no sea plano
                capa.set_at((azar.randrange(TILE), azar.randrange(TILE)), borde)
            tonos = ([(196, 140, 108), (172, 116, 88), (214, 162, 128)] if marte else
                     [(176, 176, 182), (150, 150, 158), (198, 198, 204)])
            sombra = (90, 50, 36, 110) if marte else (40, 40, 48, 110)
            for _ in range(azar.randint(4, 6)):
                w, h = azar.randint(9, 15), azar.randint(7, 11)
                px, py = azar.randint(2, TILE - w - 2), azar.randint(2, TILE - h - 3)
                pygame.draw.ellipse(capa, sombra, (px + 1, py + 2, w, h))            # sombra
                tono = azar.choice(tonos)
                pygame.draw.ellipse(capa, tono, (px, py, w, h))
                claro = tuple(min(255, v + 22) for v in tono)
                pygame.draw.ellipse(capa, claro, (px + 2, py + 1, max(3, w // 2), max(2, h // 3)))
            self._cache_piedras[clave] = capa
        return self._cache_piedras[clave]

    def dibujar_bloque(self, x, y):
        """Bloque de regolito: un ladrillo gris con el borde de arriba claro."""
        if "bloque_regolito" in self.sprites:
            self.pantalla.blit(self.sprites["bloque_regolito"][0], (x, y))
            return
        cuerpo = pygame.Rect(x + 3, y + 3, TILE - 6, TILE - 6)
        pygame.draw.rect(self.pantalla, COLOR_BLOQUE, cuerpo)
        pygame.draw.line(self.pantalla, COLOR_BLOQUE_CLARO, cuerpo.topleft, cuerpo.topright, 3)
        pygame.draw.line(self.pantalla, COLOR_BLOQUE_CLARO, cuerpo.topleft, cuerpo.bottomleft, 3)
        pygame.draw.line(self.pantalla, COLOR_TALADRO_BORDE, (x + 3, y + TILE // 2), (x + TILE - 4, y + TILE // 2), 1)
        pygame.draw.rect(self.pantalla, COLOR_TALADRO_BORDE, cuerpo, 2)

    def dibujar_gotas(self, queda, x, y):
        """Gotas de la regadera (dibujo de las diseñadoras): caen sobre el
        invernadero y se desvanecen. Solo adorno."""
        if "gotas" not in self.sprites:
            return
        if not hasattr(self, "_gotas_img"):
            self._gotas_img = pygame.transform.scale(self.sprites["gotas"][0], (TILE, TILE))
        avance = 1.0 - queda / RIEGO_SEGUNDOS          # 0 al empezar, 1 al terminar
        img = self._gotas_img.copy()
        img.set_alpha(int(255 * (1.0 - avance)))
        self.pantalla.blit(img, (x, y - TILE // 3 + int(avance * TILE // 3)))

    def dibujar_maquina(self, f, c, x, y):
        """Purificador, electrolizador, invernadero o tanque (color plano hasta
        que lleguen los PNG). Se ve: a la izquierda las casillas de ingrediente,
        a la derecha lo producido, una raya de progreso y una luz verde/roja.
        El tanque muestra cuánto hidrógeno tiene (4 estados)."""
        pantalla = self.pantalla
        tipo = self.mapa[f][c]
        maquina = self.maquinas[(f, c)]
        cuerpo = pygame.Rect(x + 4, y + 4, TILE - 8, TILE - 8)
        if isinstance(maquina, Tanque):
            if "tanque" in self.sprites:
                pantalla.blit(self.sprites["tanque"][maquina.estado_llenado], (x, y))
                return
            cilindro = pygame.Rect(x + 12, y + 4, TILE - 24, TILE - 8)
            pygame.draw.rect(pantalla, COLOR_MAQUINA[TANQUE], cilindro, border_radius=8)
            alto = int((cilindro.h - 6) * maquina.estado_llenado / 3)
            if alto:
                pygame.draw.rect(pantalla, COLOR_HIDROGENO,
                                 (cilindro.x + 3, cilindro.bottom - 3 - alto, cilindro.w - 6, alto),
                                 border_radius=5)
            pygame.draw.rect(pantalla, COLOR_TALADRO_BORDE, cilindro, 2, border_radius=8)
            return
        nombre = MAQUINAS[tipo]
        if tipo == INVERNADERO and "cubeta" in self.sprites:
            self._dibujar_cubeta(maquina, x, y)
        elif tipo == ELECTROLIZADOR:              # caja con agua (dibujo nuevo, ronda 12)
            self._dibujar_caja_electrolizador(maquina, x, y, self.estado_maquina(f, c) == PRODUCIENDO)
        elif nombre in self.sprites:
            pantalla.blit(self.sprites[nombre][0], (x, y))
        else:
            pygame.draw.rect(pantalla, COLOR_MAQUINA[tipo], cuerpo, border_radius=4)
            pygame.draw.rect(pantalla, COLOR_TALADRO_BORDE, cuerpo, 2, border_radius=4)
            centro = (x + 22, y + 22)
            if tipo == PURIFICADOR:                 # una gota
                pygame.draw.circle(pantalla, COLOR_SALIDA["agua"], (centro[0], centro[1] + 3), 6)
                pygame.draw.polygon(pantalla, COLOR_SALIDA["agua"],
                                    [(centro[0] - 6, centro[1] + 2), (centro[0] + 6, centro[1] + 2),
                                     (centro[0], centro[1] - 9)])
            elif tipo == ELECTROLIZADOR:            # dos burbujas: oxígeno e hidrógeno
                pygame.draw.circle(pantalla, COLOR_SALIDA["oxigeno"], (centro[0] - 5, centro[1]), 6)
                pygame.draw.circle(pantalla, COLOR_HIDROGENO, (centro[0] + 6, centro[1] - 4), 4)
            elif not self.plantas:                  # invernadero sin PNG de plantas: tres hojas
                for dx, dy in ((-7, 2), (0, -5), (7, 2)):
                    pygame.draw.ellipse(pantalla, COLOR_HOJA, (centro[0] + dx - 4, centro[1] + dy - 6, 8, 12))
        if tipo == INVERNADERO and "cubeta" not in self.sprites:
            self.dibujar_planta(maquina, x, y)
        color_entrada = COLOR_RECURSO[maquina.recurso_entrada]
        color_salida = COLOR_SALIDA[maquina.recurso_salida]
        for i in range(ENTRADA_MAX):
            casilla = (x + 7, y + TILE - 15 - i * 7, 5, 5)
            if i < maquina.entrada:
                pygame.draw.rect(pantalla, color_entrada, casilla)
            pygame.draw.rect(pantalla, COLOR_TALADRO_BORDE, casilla, 1)
        for i in range(SALIDA_MAX):
            casilla = (x + TILE - 12, y + TILE - 15 - i * 7, 5, 5)
            if i < maquina.salida:
                pygame.draw.rect(pantalla, color_salida, casilla)
            pygame.draw.rect(pantalla, COLOR_TALADRO_BORDE, casilla, 1)
        produciendo = self.estado_maquina(f, c) == PRODUCIENDO
        if produciendo:
            ancho = int((TILE - 14) * maquina.progreso / maquina.tiempo_unidad)
            pygame.draw.rect(pantalla, COLOR_LUZ_ON, (x + 7, y + TILE - 8, ancho, 3))
        luz = COLOR_LUZ_ON if produciendo else COLOR_LUZ_OFF
        pygame.draw.circle(pantalla, luz, (x + TILE - 11, y + 11), 4)
        pygame.draw.circle(pantalla, COLOR_TALADRO_BORDE, (x + TILE - 11, y + 11), 4, 1)

    def _dibujar_cubeta(self, maquina, x, y):
        """Maceta de las diseñadoras en el cuadro (x, y): la planta sale de la
        tierra y el frente de la cubeta se vuelve a dibujar encima para tapar
        la base del tallo. Sin el PNG, solo la planta."""
        if "cubeta" not in self.sprites:
            self.dibujar_planta(maquina, x, y)
            return
        con_tierra = bool(maquina.entrada or maquina.progreso > 0 or maquina.salida)
        lado = 36
        maceta = self._escalado("cubeta", 1 if con_tierra else 0, lado)
        caja = maceta.get_rect(midbottom=(x + TILE // 2, y + TILE - 2))
        self.pantalla.blit(maceta, caja)
        self.dibujar_planta(maquina, x, y, base=caja.y + lado * 12 // 32)
        frente = lado * 13 // 32
        self.pantalla.blit(maceta, (caja.x, caja.y + frente), (0, frente, lado, lado - frente))

    def dibujar_planta(self, maquina, x, y, base=None):
        """Planta del invernadero: con comida lista se ve el fruto; mientras
        crece, la etapa según el progreso (4 etapas); sin agua, la tierra vacía."""
        etapas, fruto = ARTE_CULTIVOS[maquina.cultivo]
        if maquina.salida:
            numero = fruto
        elif maquina.progreso > 0 or maquina.entrada:
            parte = maquina.progreso / maquina.tiempo_unidad
            numero = etapas[min(len(etapas) - 1, int(parte * len(etapas)))]
        else:
            return
        if numero in self.plantas:
            imagen = self.plantas[numero]
            abajo = base if base is not None else y + TILE - SUELO_PLANTAS
            self.pantalla.blit(imagen, imagen.get_rect(midbottom=(x + TILE // 2, abajo)))
