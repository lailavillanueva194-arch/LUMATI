"""Eventos de Marte dentro del juego (ronda 20): conecta eventos_marte.py con
la tormenta de polvo, la cadena solar, la radiación, la temperatura y el mapa (cráteres,
remolinos, sismos).
"""

import math

import pygame

import eventos_marte
from clima import CALMA, LLAMARADA, PARTICULAS, POLVO_EN_CALMA
from eventos_marte import CONFIG as CONFIG_MARTE
from textos import t
from config import (ALTO, ANCHO, BASE, CAMINO, CHIP_EVENTO_SEGUNDOS, COLOR_REMOLINO, COLUMNAS, CRAFTEO, ESCENA_MAPA, FILAS, MAPA_ALTO, MAPA_ANCHO,
                    NAVE, PANEL_POLVO_BAJA, PANEL_POLVO_SUBE, PICADO, REMOLINO_VEL, SACUDIDA_ACTIVA, SACUDIDA_HZ, SUELO, TILE)
from mapa import distancia_corta
from jugador import pos_pantalla


class MarteMixin:
    """Eventos de Marte dentro del juego (ronda 20): conecta eventos_marte.py con
    la tormenta de polvo, la cadena solar, la radiación, la temperatura y el mapa (cráteres,
    remolinos, sismos)."""

    # -- eventos de Marte (ronda 20) -------------------------------------------
    def factor_cultivo(self):
        """1.0 normal; menos con una tormenta de polvo activa (menos luz directa).
        SUPUESTO DEL JUEGO: también afecta al cuarto de cultivo de la base."""
        if self.polvo and self.polvo.tapa_paneles:
            return CONFIG_MARTE["polvo_" + self.polvo.tipo]["cultivo"]
        return 1.0

    def avisar_evento(self, texto, icono, mensaje=None):
        """Aviso corto con ícono bajo el reloj (y un mensaje abajo, si se da)."""
        self._chip = [texto, icono, CHIP_EVENTO_SEGUNDOS]
        if mensaje:
            self.mensaje = mensaje

    def actualizar_eventos_marte(self, dt, cambios_clima, avisar=True):
        """Marte: avanza los eventos y conecta sus efectos con lo que ya existe
        (tormenta de polvo, cadena solar, radiación, temperatura y mapa)."""
        ev = self.eventos_marte
        # Fases nuevas de la cadena solar. iniciar_tormenta() (tecla T o un evento SEP)
        # entra a la llamarada sin pasar por actualizar(): eso se detecta aquí.
        fases = list(cambios_clima) or ([self.clima.fase] if self.clima.fase != self._fase_clima else [])
        self._fase_clima = self.clima.fase
        for fase in fases:                  # la cadena solar de clima.py, con efectos de Marte
            if fase == LLAMARADA and avisar:
                self.mostrar_dato("marte_sep_frecuencia")
            elif fase == PARTICULAS and avisar:
                self.mensaje = t("sep_refugio")
            elif fase == CALMA:             # pasó la CME: caída Forbush de la radiación cósmica
                ev.iniciar_forbush()
                if avisar:
                    self.avisar_evento(t("ev_forbush"), "radiacion", t("ev_forbush_msg"))
                    self.mostrar_dato("marte_forbush")
        de_dia = self.clima.reloj.luz >= eventos_marte.ESCALA["luz_de_dia"]
        for aviso in ev.actualizar(dt, de_dia=de_dia, hay_tormenta=self.polvo.fase != POLVO_EN_CALMA,
                                   polvo_libre=self.polvo.fase == POLVO_EN_CALMA,
                                   clima_libre=self.clima.fase == CALMA):
            tipo = aviso[0]
            if tipo == "temporada" and avisar:
                self.avisar_evento(t("ev_temporada", n=aviso[1]), "polvo", t("ev_temporada_msg"))
            elif tipo == "polvo":
                self.iniciar_tormenta_polvo(aviso[1], avisar)
            elif tipo == "sep":
                self.clima.iniciar_tormenta()
            elif tipo == "remolino" and avisar:
                self.crear_remolino()
            elif tipo == "sismo":
                self.sismo(aviso[1], avisar)
            elif tipo == "impacto":
                self.impacto(avisar)
        # Temperatura: con polvo, días más fríos y noches menos frías (se acerca despacio).
        meta = 0.0
        if self.polvo.tapa_paneles:
            meta = CONFIG_MARTE["polvo_" + self.polvo.tipo]["amortiguar_temp"]
        reloj = self.clima.reloj
        paso = 0.05 * dt
        reloj.amortiguar = min(meta, reloj.amortiguar + paso) if reloj.amortiguar < meta \
            else max(meta, reloj.amortiguar - paso)

    def iniciar_tormenta_polvo(self, tipo, avisar=True):
        """Tormenta de polvo "regional" (la de siempre) o "global" (más larga y
        fuerte). Devuelve False si ya hay una."""
        cfg = CONFIG_MARTE["polvo_" + tipo]
        if not self.polvo.iniciar(tipo, cfg["aviso"], cfg["duracion"]):
            return False
        if avisar:
            if tipo == "global":
                self.mensaje = t("polvo_crece")
            self.mostrar_dato(cfg["dato_aviso"], repetir=tipo == "global")
        return True

    def crear_remolino(self):
        """Un remolino de polvo entra por un lado de la pantalla y la cruza (solo
        adorno: SUPUESTO DEL JUEGO, no hace daño). Solo se ve afuera."""
        if self.escena != ESCENA_MAPA or len(self.remolinos) >= CONFIG_MARTE["remolino"]["max_a_la_vez"]:
            return False
        azar = self.eventos_marte.azar()
        lado = azar.choice((-1, 1))
        vel = azar.uniform(*REMOLINO_VEL)
        x = (self._cam[0] + lado * (ANCHO / 2 + 50)) % MAPA_ANCHO
        y = (self._cam[1] + azar.uniform(-ALTO * 0.05, ALTO * 0.28)) % MAPA_ALTO   # a la vista, no bajo los paneles
        vida = (ANCHO + 100) / vel
        self.remolinos.append({"x": x, "y": y, "vx": -lado * vel, "vy": azar.uniform(-12, 12),
                               "vida": vida, "total": vida, "soplo": 0.0, "giro": azar.uniform(0, 6)})
        self.avisar_evento(t("ev_remolino"), "remolino", t("ev_remolino_msg"))
        self.mostrar_dato(CONFIG_MARTE["remolino"]["dato"])
        return True

    def sismo(self, magnitud, avisar=True):
        """Sismo: sacudida suave de la cámara y un aviso con la magnitud. Sin daño
        (SUPUESTO DEL JUEGO; los sismos de Marte son pequeños)."""
        s = CONFIG_MARTE["sismo"]
        total = s["duracion_base"] + s["duracion_por_magnitud"] * magnitud
        if avisar:
            self._sacudida = [total, total, s["pixeles_por_magnitud"] * magnitud]
            m = f"{magnitud:.1f}"
            self.avisar_evento(t("ev_sismo", m=m), "sismo", t("ev_sismo_msg", m=m))
            self.mostrar_dato(s["dato"])

    def lugar_crater(self):
        """Centro (fila, col) de un cráter nuevo en suelo libre, cerca del
        astronauta y a la vista; None si no hay lugar. Nunca rompe nada: los
        (2r+1)x(2r+1) cuadros tienen que ser suelo, picado o camino, sin montaña
        ni otro cráter, y lejos de los pies del astronauta."""
        cfg = CONFIG_MARTE["impacto"]
        r = cfg["radio_crater"]
        d_min, d_max = cfg["distancia"]
        pf = int(self.jugador.centro[1] // TILE) % FILAS
        pc = int(self.jugador.centro[0] // TILE) % COLUMNAS

        def libre(f0, c0):
            m = r + 1                        # margen: el dibujo de la nave y la base sobresale
            if any(self.mapa[(f0 + i) % FILAS][(c0 + j) % COLUMNAS] in (NAVE, BASE, CRAFTEO)
                   for i in range(-m, m + 1) for j in range(-m, m + 1)):
                return False
            return all(self.mapa[(f0 + i) % FILAS][(c0 + j) % COLUMNAS] in (SUELO, PICADO, CAMINO)
                       and not self.alturas[(f0 + i) % FILAS][(c0 + j) % COLUMNAS]
                       and ((f0 + i) % FILAS, (c0 + j) % COLUMNAS) not in self._crater_de
                       for i in range(-r, r + 1) for j in range(-r, r + 1))

        opciones = []
        for df in range(-1, 3):              # a la vista: ni bajo los paneles de arriba ni bajo el dato de abajo
            for dc in range(-d_max, d_max + 1):
                if max(abs(df), abs(dc)) >= d_min and libre((pf + df) % FILAS, (pc + dc) % COLUMNAS):
                    opciones.append(((pf + df) % FILAS, (pc + dc) % COLUMNAS))
        if not opciones:                     # plan B: cualquier lugar libre del mapa, lejos del astronauta
            opciones = [(f, c) for f in range(FILAS) for c in range(COLUMNAS)
                        if max(abs(distancia_corta(f, pf, FILAS)), abs(distancia_corta(c, pc, COLUMNAS))) >= d_min
                        and libre(f, c)]
        return self.eventos_marte.azar().choice(opciones) if opciones else None

    def poner_crater(self, f0, c0):
        """Marca el cráter en el mapa (solo dibujo y botín: el suelo sigue igual)."""
        r = CONFIG_MARTE["impacto"]["radio_crater"]
        k = len(self.crateres)
        self.crateres.append((f0, c0))
        for i in range(-r, r + 1):
            for j in range(-r, r + 1):
                self._crater_de[((f0 + i) % FILAS, (c0 + j) % COLUMNAS)] = (k, i + r, j + r)
        self._mini = None                    # que el minimapa lo muestre ya

    def impacto(self, avisar=True):
        """Impacto de meteorito: cráter nuevo en suelo libre (sin romper
        construcciones), sismo asociado y hielo expuesto para los taladros."""
        lugar = self.lugar_crater()
        if lugar is None:
            return False
        self.poner_crater(*lugar)
        cfg = CONFIG_MARTE["impacto"]
        if avisar:
            x, y = (lugar[1] + 0.5) * TILE, (lugar[0] + 0.5) * TILE
            self.particulas.emitir(x, y, self.colores_polvo(), cantidad=40, velocidad=160, vida=1.4,
                                   tam=10, subir=30)
            m = f"{cfg['magnitud_sismo']:.1f}"
            total = CONFIG_MARTE["sismo"]["duracion_base"] + CONFIG_MARTE["sismo"]["duracion_por_magnitud"] * 4
            self._sacudida = [total, total, CONFIG_MARTE["sismo"]["pixeles_por_magnitud"] * cfg["magnitud_sismo"]]
            self.avisar_evento(t("ev_impacto"), "impacto", t("ev_impacto_msg", m=m))
            self.mostrar_dato(cfg["dato"], repetir=True)
        return True

    def hielo_de_crater(self, taladro, fila, col):
        """Un taladro dentro de un cráter saca hielo con más probabilidad
        (hielo expuesto por el impacto). Devuelve True si está en un cráter."""
        if (fila, col) not in self._crater_de:
            return False
        taladro.extra = {"hielo": CONFIG_MARTE["impacto"]["bonus_hielo"]}
        return True

    def actualizar_eventos_visuales(self, dt):
        """Solo adorno: remolinos que cruzan, sacudida, aviso corto y polvo sobre
        los paneles."""
        for rm in self.remolinos:
            rm["x"] = (rm["x"] + rm["vx"] * dt) % MAPA_ANCHO
            rm["y"] = (rm["y"] + rm["vy"] * dt) % MAPA_ALTO
            rm["vida"] -= dt
            rm["soplo"] -= dt
            if rm["soplo"] <= 0 and self.escena == ESCENA_MAPA:      # levanta polvo al pasar
                rm["soplo"] = 0.09
                self.particulas.emitir(rm["x"], rm["y"], self.colores_polvo(), cantidad=2, velocidad=40,
                                       vida=0.8, tam=7, subir=14)
        self.remolinos = [rm for rm in self.remolinos if rm["vida"] > 0]
        if self._sacudida:
            self._sacudida[0] -= dt
            if self._sacudida[0] <= 0:
                self._sacudida = None
        if self._chip:
            self._chip[2] -= dt
            if self._chip[2] <= 0:
                self._chip = None
        if self.polvo.tapa_paneles:
            self._paneles_sucios = min(1.0, self._paneles_sucios + PANEL_POLVO_SUBE * dt)
        else:
            self._paneles_sucios = max(0.0, self._paneles_sucios - PANEL_POLVO_BAJA * dt)

    def desplazamiento_sacudida(self):
        """(dx, dy) en píxeles de la sacudida del sismo: suave, lenta y que se
        apaga sola (nada de parpadeos). (0, 0) si no hay sismo."""
        if not self._sacudida or not SACUDIDA_ACTIVA:
            return 0, 0
        queda, total, amplitud = self._sacudida
        fuerza = amplitud * (queda / total)
        fase = (total - queda) * SACUDIDA_HZ * 2 * math.pi
        return int(round(math.sin(fase) * fuerza)), int(round(math.sin(fase * 0.7 + 1.0) * fuerza * 0.5))

    def dibujar_remolinos(self, cam_x, cam_y):
        """Remolinos de polvo: un embudo de óvalos que gira despacio y se desvanece
        al entrar y al salir."""
        for rm in self.remolinos:
            x = pos_pantalla(rm["x"], cam_x, MAPA_ANCHO, ANCHO / 2)
            y = pos_pantalla(rm["y"], cam_y, MAPA_ALTO, ALTO / 2)
            if not -120 < x < ANCHO + 120 or not -120 < y < ALTO + 120:
                continue
            transcurrido = rm["total"] - rm["vida"]
            alfa = min(1.0, transcurrido / 1.0, rm["vida"] / 1.0)
            img = pygame.Surface((100, 130), pygame.SRCALPHA)
            pygame.draw.ellipse(img, (60, 26, 16, int(70 * alfa)), (26, 116, 48, 12))   # sombra en el suelo
            giro = rm["giro"] + self._tiempo * 3.0
            for k in range(9):
                w = 10 + k * 8.5
                h = 7 + k * 2
                cx = 50 + math.sin(giro + k * 0.8) * (2 + k * 1.0)
                cy = 120 - k * 12
                caja = (cx - w / 2, cy - h / 2, w, h)
                pygame.draw.ellipse(img, (*COLOR_REMOLINO, int((190 - k * 12) * alfa)), caja)
                pygame.draw.ellipse(img, (120, 64, 40, int((110 - k * 8) * alfa)), caja, 2)
            self.pantalla.blit(img, (x - 50, y - 120))

