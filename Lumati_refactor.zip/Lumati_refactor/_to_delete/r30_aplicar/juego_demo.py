"""Partida de demostración en el juego (ronda 28): abrirla desde el menú
principal, mostrar los objetos como ilimitados (signo de infinito) y dibujar los
letreros del suelo de cada zona. Cómo se arma la demo está en demo.py.
"""

import os

import pygame

import demo
import estilo
from textos import t
from arte import ajustar_texto
from config import ALTO, ANCHO, TILE

# Color de la franja de cada zona: verde (básicos), ámbar (medios), teja (difíciles).
COLOR_ZONA = {"basicos": (70, 160, 105), "medios": (214, 150, 40), "dificiles": (196, 80, 64)}
NOTA_ANCHO = 4 * TILE + 24             # ancho máximo de la explicación de un circuito (px)
NOTA_CERCA, NOTA_LEJOS = 5.0, 7.0   # cuadros: nota entera / ya no se ve (ronda 30)
ZONA_CERCA, ZONA_LEJOS = 9.0, 12.0  # el cartel de la zona se ve desde más lejos
LUZ_ESPERA = {True: (60, 190, 90), False: (210, 70, 60)}   # punto: debe funcionar / roto a propósito


def infinito(alto, color):
    """Signo de infinito dibujado (la letra de pygame no lo trae): dos aros que se
    tocan, dibujados 4 veces más grandes y achicados con suavizado (se leen bien chicos)."""
    k = 4
    r = alto * 0.42 * k                                  # radio de cada aro
    grueso = max(2, round(alto * 0.2)) * k
    grande = pygame.Surface((round(4 * r + grueso), round(2 * r + grueso)), pygame.SRCALPHA)
    cy = grande.get_height() / 2
    for cx in (grueso / 2 + r, grueso / 2 + 3 * r):
        pygame.draw.circle(grande, color, (cx, cy), r + grueso / 2, grueso)
    return pygame.transform.smoothscale(grande, (max(1, grande.get_width() // k), max(1, grande.get_height() // k)))


class DemoMixin:
    """Partida de demostración: abrirla, cantidades infinitas y letreros del suelo."""

    # ---- abrir la demo desde el menú principal -------------------------------------
    def abrir_demo(self, destino):
        """Carga partidas/demo_<destino>.json. Si no existe, la arma con demo.py y
        la guarda (así el archivo siempre está). Los 3 slots no se tocan."""
        ruta = demo.ruta(destino)
        if not os.path.exists(ruta):
            try:
                demo.construir(self, destino)
                demo.guardar(self, destino)
            except OSError:
                self.mensaje = t("partida_error_guardar")
        if self.cargar_partida(ruta):
            self.mensaje = t("demo_bienvenida")
            self.cerrar_opciones()
            return True
        return False

    # ---- cantidades: en la demo se ven como infinito ------------------------------
    def render_cantidad(self, fuente, plantilla, n, color):
        """Imagen de una cantidad ("x{n}" o "{n}"). En la demo, el número se cambia
        por el signo de infinito."""
        if not self.es_demo:
            return fuente.render(plantilla.format(n=n), True, color)
        antes = fuente.render(plantilla.format(n=""), True, color) if plantilla.format(n="") else None
        signo = infinito(max(8, fuente.get_height() - 4), color)
        ancho = (antes.get_width() + 1 if antes else 0) + signo.get_width()
        img = pygame.Surface((ancho, fuente.get_height()), pygame.SRCALPHA)
        if antes:
            img.blit(antes, (0, 0))
        img.blit(signo, signo.get_rect(midright=(ancho, fuente.get_height() // 2)))
        return img

    def texto_cantidad(self, n):
        """La cantidad para un texto: el número, o "ilimitado" en la demo."""
        return t("demo_ilimitado") if self.es_demo else n

    # ---- letreros del suelo --------------------------------------------------------
    def dibujar_letreros(self, xs, ys):
        """Los letreros pintados en el suelo (solo la demo los tiene): el cartel de
        cada zona y la explicación de cada circuito."""
        p = self.pantalla
        for f, c, clave, tipo, zona, espera in self.letreros:
            x, y = xs[c % len(xs)], ys[f % len(ys)]
            if not (-6 * TILE < x < ANCHO and -TILE < y < ALTO):
                continue
            color = COLOR_ZONA.get(zona, estilo.ACENTO)
            # Ronda 30: más chicos, y solo cerca (con un fundido suave según la distancia):
            # el cartel de la zona desde lejos, la nota de cada circuito al acercarse.
            if tipo == "zona":
                alfa = self.cercania(f + 0.5, c + 2, ZONA_CERCA, ZONA_LEJOS)
            else:
                alfa = self.cercania(f + 0.5, c + NOTA_ANCHO / TILE / 2, NOTA_CERCA, NOTA_LEJOS)
            if alfa <= 0.02:
                continue
            fuente = self.fuente if tipo == "zona" else self.fuente_mini
            lineas = [t(clave)] if tipo == "zona" else ajustar_texto(t(clave), fuente, NOTA_ANCHO)[:2]
            alto = len(lineas) * fuente.get_linesize() + (10 if tipo == "zona" else 7)
            ancho = max(fuente.size(l)[0] for l in lineas) + (28 if tipo == "zona" else 22) + (12 if espera is not None else 0)
            placa = pygame.Surface((ancho, alto), pygame.SRCALPHA)
            pygame.draw.rect(placa, (*estilo.PANEL, 215), placa.get_rect(), border_radius=5)
            pygame.draw.rect(placa, estilo.CONTORNO, placa.get_rect(), 1, border_radius=5)
            pygame.draw.rect(placa, color, (1, 1, 6, alto - 2), border_top_left_radius=4, border_bottom_left_radius=4)
            ty = 4 if tipo == "zona" else 3
            for linea in lineas:
                placa.blit(fuente.render(linea, True, estilo.TINTA), (14, ty + (1 if tipo == "zona" else 0)))
                ty += fuente.get_linesize()
            if espera is not None:                   # punto: verde = funciona, rojo = roto a propósito
                pygame.draw.circle(placa, estilo.CONTORNO, (ancho - 7, 7), 5)
                pygame.draw.circle(placa, LUZ_ESPERA[espera], (ancho - 7, 7), 3)
                if not espera:                       # además de color, forma: una rayita (roto)
                    pygame.draw.line(placa, estilo.CREMA, (ancho - 9, 7), (ancho - 5, 7), 1)
            placa.set_alpha(int(255 * alfa))
            p.blit(placa, (x + 4, y + 4))
