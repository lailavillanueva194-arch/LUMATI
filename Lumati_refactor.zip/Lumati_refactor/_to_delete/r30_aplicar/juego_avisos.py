"""Mensajes limpios (ronda 30): todo lo que se escribe encima del juego, más chico
y discreto.

- Mensajes (toasts): una línea con fondo oscuro semitransparente encima del acceso
  rápido; entran y salen con un fundido suave; como mucho 2 apilados; si un mensaje se
  repite, no se acumula (se renueva el que ya estaba).
- Datos reales NASA y mensajes de la Tierra: tarjeta compacta abajo a la derecha, 2
  líneas y la fuente en letra chica. Con el mouse encima se ve completo; un clic la
  cierra; se cierra sola. Entre un dato y el siguiente hay un descanso: los que llegan
  mientras tanto esperan en una fila corta.
- Avisos de tormenta y eventos: barras delgadas arriba al centro con ícono y cuenta
  regresiva. El detalle (dato DONKI, fecha del ejemplo, aviso de que no es oficial)
  va a la tarjeta de datos o se ve al pasar el mouse por la barra.
- Máquinas: un ícono chico encima (rayo tachado = sin energía, gota o recurso = le
  falta, palomita = listo, tanque = falta tanque); el texto solo con el mouse encima.
- Rótulos de Base, Fabricador y Nave: solo cerca del astronauta o con el mouse encima.

Nada parpadea: los fundidos duran décimas de segundo y van en un solo sentido.
"""

import math

import pygame

import datos
import estilo
from clima import CALMA, CME_EN_CAMINO, LLAMARADA, PARTICULAS, POLVO_EN_AVISO, POLVO_EN_CALMA
from maquinas import (LLENO, PRODUCIENDO, SIN_ENERGIA, SIN_ENTRADA, SIN_TANQUE, TANQUE_LLENO, Tanque)
from textos import t
from config import (ALTO, ANCHO, BASE_POS, COLOR_AVISO, COLOR_MORADO, CRAFTEO_POS, DATO_POR_FASE,
                    DATO_POR_FASE_MARTE, DATO_SEGUNDOS, ESTRUCTURA_LADO, INVENTARIO_RECT, MAPA_ALTO,
                    MAPA_ANCHO, MARTE, MENSAJE_ABAJO, MENSAJE_SEGUNDOS, NAVE_LADO, NAVE_POS, TILE,
                    VITALES_RECT)
from arte import ajustar_texto, icono_evento
from mapa import distancia_corta

# ---- medidas y colores (BALANCE visual: ajústalos aquí) ---------------------------
TOAST_MAX = 2                     # mensajes a la vez
TOAST_ALTO = 26
TOAST_SEP = 4
TOAST_ANCHO_MAX = 600             # px; uno más largo usa letra más chica (y al final se corta)
TOAST_ENTRA = 0.2                 # segundos del fundido de entrada
TOAST_SALE = 0.5                  # y de salida
FONDO_OSCURO = (18, 22, 30)
ALFA_FONDO = 200                  # 0 a 255: qué tan opaco es el fondo de los avisos
TINTA_CLARA = (244, 246, 250)     # texto sobre el fondo oscuro (contraste alto)
TINTA_CLARA_SUAVE = (186, 194, 206)
BARRA_ALTO = 28
BARRA_ANCHO_MAX = 520
DATO_ANCHO = 320                  # tarjeta de datos, abajo a la derecha
DATO_LINEAS = 2
DATO_ENFRIAMIENTO = 12.0          # segundos de descanso entre un dato y el siguiente
DATO_COLA_MAX = 4
DATO_ENTRA, DATO_SALE = 0.3, 0.6
ROTULO_CERCA, ROTULO_LEJOS = 3.5, 5.0      # cuadros: rótulo entero / ya no se ve
COLOR_LISTO = (70, 200, 110)
COLOR_PROBLEMA = (232, 92, 72)
COLOR_FALTA = (236, 176, 60)


def _caja_oscura(ancho, alto, radio=8):
    caja = pygame.Surface((ancho, alto), pygame.SRCALPHA)
    pygame.draw.rect(caja, (*FONDO_OSCURO, ALFA_FONDO), caja.get_rect(), border_radius=radio)
    pygame.draw.rect(caja, (255, 255, 255, 40), caja.get_rect(), 1, border_radius=radio)
    return caja


def _cortar(texto, fuente, ancho):
    """El texto en una línea de `ancho` px como mucho (con "..." si no cabe)."""
    if fuente.size(texto)[0] <= ancho:
        return texto
    while texto and fuente.size(texto + "...")[0] > ancho:
        texto = texto[:-1]
    return texto.rstrip() + "..."


def icono_estado(tipo, lado=18, recurso_img=None):
    """Ícono redondo de estado de una máquina: fondo oscuro, aro de color y figura
    clara (la figura dice lo mismo que el color, para quien no distingue colores)."""
    img = pygame.Surface((lado, lado), pygame.SRCALPHA)
    c = lado / 2
    aro = {"sin_energia": COLOR_PROBLEMA, "listo": COLOR_LISTO, "falta": COLOR_FALTA,
           "sin_tanque": COLOR_FALTA}[tipo]
    pygame.draw.circle(img, (*FONDO_OSCURO, 235), (c, c), c)
    pygame.draw.circle(img, aro, (c, c), c, 2)
    blanco = TINTA_CLARA
    s = lado / 18
    if tipo == "sin_energia":                          # rayo tachado
        pygame.draw.polygon(img, blanco, [(10 * s, 3 * s), (5 * s, 10 * s), (8.5 * s, 10 * s),
                                          (7 * s, 15 * s), (13 * s, 7.5 * s), (9.5 * s, 7.5 * s), (11 * s, 3 * s)])
        pygame.draw.line(img, aro, (4 * s, 4 * s), (14 * s, 14 * s), max(2, round(2 * s)))
    elif tipo == "listo":                              # palomita
        pygame.draw.lines(img, blanco, False, [(5 * s, 9.5 * s), (8 * s, 12.5 * s), (13.5 * s, 6 * s)],
                          max(2, round(2 * s)))
    elif tipo == "falta" and recurso_img is not None:  # el recurso que le falta (gota, hielo...)
        chico = pygame.transform.smoothscale(recurso_img, (round(11 * s), round(11 * s)))
        img.blit(chico, chico.get_rect(center=(c, c)))
    elif tipo == "falta":                              # gota
        pygame.draw.circle(img, (120, 200, 235), (c, 10.5 * s), 3.5 * s)
        pygame.draw.polygon(img, (120, 200, 235), [(c, 3.5 * s), (c - 3.4 * s, 10 * s), (c + 3.4 * s, 10 * s)])
    else:                                              # sin tanque: un tanque (cápsula) con signo "!"
        pygame.draw.rect(img, blanco, (5 * s, 3.5 * s, 8 * s, 11 * s), border_radius=round(3.5 * s))
        pygame.draw.line(img, FONDO_OSCURO, (c, 6 * s), (c, 10 * s), max(2, round(1.6 * s)))
        pygame.draw.circle(img, FONDO_OSCURO, (c, 12.3 * s), max(1, round(1 * s)))
    return img


class AvisosMixin:
    """Mensajes (toasts), barras de aviso, tarjeta de datos, íconos de estado de las
    máquinas y rótulos que aparecen al acercarse."""

    # ======================================================================== toasts
    def agregar_toast(self, texto):
        """Un mensaje nuevo abajo. Si ya estaba (repetido), se renueva sin parpadear."""
        toasts = self.__dict__.setdefault("_toasts", [])
        for k, toast in enumerate(toasts):
            if toast[0] == texto:
                toasts.pop(k)
                toast[1] = MENSAJE_SEGUNDOS + TOAST_SALE        # vida otra vez completa
                toasts.append(toast)
                return
        toasts.append([texto, MENSAJE_SEGUNDOS + TOAST_SALE, 0.0, None])   # [texto, vida, edad, imagen]
        del toasts[:-TOAST_MAX]                                   # como mucho 2 a la vez

    def limpiar_toasts(self):
        self.__dict__.setdefault("_toasts", []).clear()

    def actualizar_avisos(self, dt):
        """Edad y vida de los mensajes, tarjeta de datos (y su fila) y avisos."""
        toasts = self.__dict__.setdefault("_toasts", [])
        for toast in toasts:
            toast[1] -= dt
            toast[2] += dt
        toasts[:] = [x for x in toasts if x[1] > 0]
        self.actualizar_datos(dt)

    def _imagen_toast(self, texto):
        fuente = self.fuente_chica
        if fuente.size(texto)[0] > TOAST_ANCHO_MAX - 28:
            fuente = self.fuente_mini
        linea = _cortar(texto, fuente, TOAST_ANCHO_MAX - 28)
        letras = fuente.render(linea, True, TINTA_CLARA)
        caja = _caja_oscura(letras.get_width() + 28, TOAST_ALTO)
        pygame.draw.rect(caja, (*estilo.ACENTO, 230), (6, 7, 3, TOAST_ALTO - 14), border_radius=1)
        caja.blit(letras, letras.get_rect(midleft=(15, TOAST_ALTO // 2 + 1)))
        return caja

    def rects_toasts(self):
        """[(rect, toast)] de los mensajes visibles, el más nuevo abajo."""
        lista = []
        y = MENSAJE_ABAJO - 8                # un poco arriba: así no toca la tarjeta de datos (abajo a la derecha)
        for toast in reversed(self.__dict__.get("_toasts", [])):
            if toast[3] is None or toast[3][0] != (toast[0], id(self.fuente_chica)):
                toast[3] = ((toast[0], id(self.fuente_chica)), self._imagen_toast(toast[0]))
            img = toast[3][1]
            rect = img.get_rect(midbottom=(ANCHO // 2, y))
            lista.append((rect, toast))
            y = rect.top - TOAST_SEP
        return lista

    def dibujar_toasts(self):
        for rect, toast in self.rects_toasts():
            alfa = min(1.0, toast[2] / TOAST_ENTRA) * min(1.0, toast[1] / TOAST_SALE)
            img = toast[3][1]
            img.set_alpha(int(255 * max(0.0, alfa)))
            self.pantalla.blit(img, rect)

    # ======================================================================== datos
    def actualizar_datos(self, dt):
        """La tarjeta de datos: se cierra sola, deja un descanso y saca el siguiente de
        la fila. Además, al empezar cada fase de una tormenta solar, su dato real."""
        d = self.__dict__
        d.setdefault("_datos_cola", [])
        d["_dato_enfriar"] = max(0.0, d.get("_dato_enfriar", 0.0) - dt)
        if self.dato:
            self.dato[1] -= dt
            if self.dato[1] <= 0:
                self.cerrar_dato()
        fase = self.clima.fase
        if fase != d.get("_fase_aviso", CALMA):
            if fase != CALMA:
                self.poner_dato(self.dato_de_fase(), urgente=True)
            d["_fase_aviso"] = fase
        if self.dato is None and self._dato_enfriar <= 0 and self._datos_cola:
            id_dato, origen = self._datos_cola.pop(0)
            self.dato = [id_dato, DATO_SEGUNDOS] + ([origen] if origen else [])

    def dato_de_fase(self):
        """Id del dato real que explica la fase actual de la tormenta solar."""
        id_dato = (DATO_POR_FASE_MARTE if self.destino == MARTE else DATO_POR_FASE)[self.clima.fase]
        if self.destino == MARTE and id_dato == "marte_cme_viaje" and self.clima.evento["id"] != "cme_2017_01_03":
            id_dato = "cme_escala"          # el viaje a Marte solo se conoce de la CME de 2017
        return id_dato

    def poner_dato(self, id_dato, origen=None, urgente=False):
        """Muestra un dato ahora si se puede; si no, lo deja en la fila (sin repetir).
        urgente=True (el de una tormenta): sale ya, en lugar del que hubiera."""
        d = self.__dict__
        cola = d.setdefault("_datos_cola", [])
        nuevo = [id_dato, DATO_SEGUNDOS] + ([origen] if origen else [])
        if urgente or (self.dato is None and d.get("_dato_enfriar", 0.0) <= 0):
            self.dato = nuevo
            return
        if (self.dato and self.dato[0] == id_dato) or any(i == id_dato for i, _ in cola):
            return
        cola.append((id_dato, origen))
        del cola[:-DATO_COLA_MAX]

    def cerrar_dato(self):
        """Cierra la tarjeta (sola o con clic) y empieza el descanso."""
        self.dato = None
        self._dato_enfriar = DATO_ENFRIAMIENTO

    def _lineas_dato(self, ancho, completo):
        """(encabezado, líneas del texto, fuente) de la tarjeta de datos."""
        id_dato = self.dato[0]
        de_la_tierra = len(self.dato) > 2 and self.dato[2] == "tierra"
        encabezado = t("mensaje_tierra") if de_la_tierra else datos.ETIQUETA[datos._idioma(None)]
        lineas = ajustar_texto(datos.obtener(id_dato), self.fuente_chica, ancho)
        if not completo and len(lineas) > DATO_LINEAS:
            lineas = lineas[:DATO_LINEAS]
            lineas[-1] = _cortar(lineas[-1] + " ...", self.fuente_chica, ancho)
        return encabezado, lineas, de_la_tierra

    def rect_dato(self, completo=None):
        """Rectángulo de la tarjeta de datos (abajo a la derecha), o None."""
        if not self.dato:
            return None
        if completo is None:
            completo = self._dato_bajo_mouse()
        _, lineas, _ = self._lineas_dato(DATO_ANCHO - 28, completo)
        alto = 10 + self.fuente_mini.get_linesize() + 2 + len(lineas) * self.fuente_chica.get_linesize() \
            + self.fuente_mini.get_linesize() + 10
        return pygame.Rect(ANCHO - 8 - DATO_ANCHO, ALTO - 8 - alto, DATO_ANCHO, alto)

    def _dato_bajo_mouse(self):
        corto = self.rect_dato(completo=False) if self.dato else None
        return bool(corto and corto.collidepoint(pygame.mouse.get_pos()))

    def dato_bajo(self, pos):
        r = self.rect_dato()
        return bool(r and r.collidepoint(pos))

    def dibujar_tarjeta_dato(self):
        if not self.dato:
            return
        completo = self._dato_bajo_mouse()
        rect = self.rect_dato(completo)
        encabezado, lineas, de_la_tierra = self._lineas_dato(DATO_ANCHO - 28, completo)
        pasado = DATO_SEGUNDOS - self.dato[1]
        alfa = 1.0 if completo else min(1.0, max(0.0, pasado / DATO_ENTRA)) * min(1.0, max(0.0, self.dato[1] / DATO_SALE))
        caja = _caja_oscura(rect.w, rect.h)
        color = estilo.ACENTO if de_la_tierra else (236, 176, 60)
        pygame.draw.rect(caja, color, (0, 0, 4, rect.h), border_top_left_radius=8, border_bottom_left_radius=8)
        y = 9
        caja.blit(self.fuente_mini.render(encabezado, True, color if de_la_tierra else (246, 200, 110)), (14, y))
        x_cierre = rect.w - 14                                   # "x" para cerrar (dibujada)
        pygame.draw.line(caja, TINTA_CLARA_SUAVE, (x_cierre - 4, y + 2), (x_cierre + 2, y + 8), 2)
        pygame.draw.line(caja, TINTA_CLARA_SUAVE, (x_cierre + 2, y + 2), (x_cierre - 4, y + 8), 2)
        y += self.fuente_mini.get_linesize() + 2
        for linea in lineas:
            caja.blit(self.fuente_chica.render(linea, True, TINTA_CLARA), (14, y))
            y += self.fuente_chica.get_linesize()
        fuente_txt = t("fuente_dato", nombre=datos.fuente(self.dato[0])[0])
        caja.blit(self.fuente_mini.render(_cortar(fuente_txt, self.fuente_mini, rect.w - 28), True,
                                          TINTA_CLARA_SUAVE), (14, y + 1))
        caja.set_alpha(int(255 * alfa))
        self.pantalla.blit(caja, rect)

    # ======================================================================== barras de aviso
    def barras_aviso(self):
        """[(clave, ícono, texto, color, detalle)] de los avisos de arriba al centro:
        tormenta solar, tormenta de polvo (Marte), evento corto (Marte) y la cima."""
        barras = []
        c = self.clima
        if c.fase != CALMA:
            segundos = math.ceil(c.segundos_restantes)
            if c.fase == LLAMARADA:
                titulo = t("clima_alerta", etiqueta=c.evento["etiqueta"])
            elif c.fase == CME_EN_CAMINO:
                titulo = t("clima_cme", s=segundos)
            else:
                titulo = t("clima_particulas")
            detalle = [t("clima_ejemplo", fecha=c.evento["fecha"]), t("clima_no_oficial")]
            barras.append(("clima", "radiacion", titulo, COLOR_MORADO if c.fase == PARTICULAS else COLOR_AVISO,
                           detalle))
        if self.polvo and self.polvo.fase != POLVO_EN_CALMA:
            clave = "polvo_aviso" if self.polvo.fase == POLVO_EN_AVISO else "polvo_activa"
            if self.polvo.tipo == "global":
                clave += "_global"
            barras.append(("polvo", "polvo", t(clave, s=math.ceil(self.polvo.segundos_restantes)),
                           COLOR_AVISO, None))
        if self._chip:
            barras.append(("chip", self._chip[1], self._chip[0], COLOR_AVISO, None))
        if self._cielo > 0.3:
            barras.append(("cima", None, t("cima_vista"), estilo.ACENTO, None))
        return barras

    def rects_barras(self):
        """[(rect, barra)] de las barras de aviso, una debajo de otra."""
        lista = []
        centro = (INVENTARIO_RECT[0] + INVENTARIO_RECT[2] + VITALES_RECT[0]) // 2
        y = 8
        for barra in self.barras_aviso():
            texto = _cortar(barra[2], self.fuente_chica, BARRA_ANCHO_MAX - 60)
            ancho = min(BARRA_ANCHO_MAX, self.fuente_chica.size(texto)[0] + (52 if barra[1] else 26))
            rect = pygame.Rect(0, y, ancho, BARRA_ALTO)
            rect.centerx = centro
            lista.append((rect, barra, texto))
            y = rect.bottom + 4
        return lista

    def dibujar_barras(self):
        raton = pygame.mouse.get_pos()
        detalle = None
        for rect, (clave, icono, _, color, mas), texto in self.rects_barras():
            caja = _caja_oscura(rect.w, rect.h)
            pygame.draw.rect(caja, color, (0, 0, 5, rect.h), border_top_left_radius=8, border_bottom_left_radius=8)
            x = 12
            if icono:
                if icono not in self._iconos_evento:
                    self._iconos_evento[icono] = icono_evento(icono)
                pygame.draw.circle(caja, (232, 226, 214), (x + 10, rect.h // 2), 11)   # ícono sobre fondo claro
                caja.blit(self._iconos_evento[icono], self._iconos_evento[icono].get_rect(center=(x + 10, rect.h // 2)))
                x += 26
            caja.blit(self.fuente_chica.render(texto, True, TINTA_CLARA),
                      (x, (rect.h - self.fuente_chica.get_height()) // 2 + 1))
            self.pantalla.blit(caja, rect)
            if mas and rect.collidepoint(raton):
                detalle = (rect, mas)
        if detalle:                                         # el detalle, solo con el mouse encima
            rect, mas = detalle
            lineas = [l for texto in mas for l in ajustar_texto(texto, self.fuente_mini, BARRA_ANCHO_MAX - 24)]
            caja = pygame.Rect(0, rect.bottom + 4, BARRA_ANCHO_MAX,
                               14 + len(lineas) * self.fuente_mini.get_linesize())
            caja.centerx = rect.centerx
            self.pantalla.blit(_caja_oscura(caja.w, caja.h), caja)
            y = caja.y + 7
            for linea in lineas:
                self.pantalla.blit(self.fuente_mini.render(linea, True, TINTA_CLARA), (caja.x + 12, y))
                y += self.fuente_mini.get_linesize()

    # ======================================================================== máquinas
    def estado_icono(self, f, c):
        """(tipo de ícono, texto completo, imagen de recurso o None) del estado de un
        taladro o máquina, o None si está trabajando bien."""
        if (f, c) in self.taladros:
            taladro = self.taladros[(f, c)]
            estado = taladro.estado(self.tiene_energia(f, c))
            if estado == LLENO:
                return "listo", t("almacen_lleno"), None
            if estado == SIN_ENERGIA:
                return "sin_energia", t("sin_energia"), None
            return None
        maquina = self.maquinas.get((f, c))
        if maquina is None:
            return None
        if isinstance(maquina, Tanque):
            return ("listo", t("tanque_lleno"), None) if maquina.lleno else None
        estado = self.estado_maquina(f, c)
        if estado == PRODUCIENDO:
            return None
        texto = self._texto_estado(f, c)
        if estado == SIN_ENERGIA:
            return "sin_energia", texto, None
        if estado in (LLENO, TANQUE_LLENO):
            return "listo", texto, None
        if estado == SIN_ENTRADA:
            return "falta", texto, self.iconos_recurso_chico.get(maquina.recurso_entrada)
        if estado == SIN_TANQUE:
            return "sin_tanque", texto, None
        return None

    def _alto_extra(self, f, c):
        """Cuánto sobresale hacia arriba el dibujo (el taladro grande)."""
        if (f, c) in self.taladros and "taladro_niveles" in self.sprites:
            return max(0, self.imagen_taladro(self.taladros[(f, c)].nivel).get_height() - TILE + 1)
        return 0

    def rects_iconos_estado(self, xs, ys):
        """[(rect, (f, c), estado)] de los íconos visibles sobre taladros y máquinas."""
        lista = []
        cache = self.__dict__.setdefault("_iconos_estado", {})
        for (f, c) in list(self.taladros) + list(self.maquinas):
            x, y = xs[c], ys[f]
            if not (-TILE < x < ANCHO and -TILE < y < ALTO):
                continue
            estado = self.estado_icono(f, c)
            if estado is None:
                continue
            clave = (estado[0], id(estado[2]))
            if clave not in cache:
                cache[clave] = icono_estado(estado[0], recurso_img=estado[2])
            img = cache[clave]
            # En la esquina de arriba a la derecha de su propio dibujo (no sobre el vecino de arriba).
            rect = img.get_rect(center=(x + TILE - 9, y - self._alto_extra(f, c) + 9))
            lista.append((rect, (f, c), estado, img))
        return lista

    def dibujar_iconos_estado(self, xs, ys):
        """Íconos chicos de estado y, con el mouse encima de una máquina, su texto."""
        raton = pygame.mouse.get_pos()
        sobre = self.cuadro_bajo_mouse(raton)
        texto = None
        for rect, fc, estado, img in self.rects_iconos_estado(xs, ys):
            self.pantalla.blit(img, rect)
            if fc == sobre or rect.collidepoint(raton):
                texto = (rect, estado[1])
        if texto:                                           # solo uno a la vez: nunca se enciman
            rect, linea = texto
            self._pastilla(linea, (rect.centerx, rect.top - 3), self.fuente_chica)

    def _pastilla(self, texto, midbottom, fuente, alfa=1.0):
        """Texto chico en una pastilla oscura (rótulos y textos al pasar el mouse)."""
        letras = fuente.render(texto, True, TINTA_CLARA)
        caja = _caja_oscura(letras.get_width() + 14, letras.get_height() + 6, radio=6)
        caja.blit(letras, (7, 4))
        rect = caja.get_rect(midbottom=midbottom)
        rect.clamp_ip(pygame.Rect(0, 0, ANCHO, ALTO))
        if alfa < 1.0:
            caja.set_alpha(int(255 * alfa))
        self.pantalla.blit(caja, rect)
        return rect

    # ======================================================================== rótulos
    def cercania(self, fila, col, cerca=ROTULO_CERCA, lejos=ROTULO_LEJOS):
        """1 si el astronauta está a `cerca` cuadros o menos del punto (fila, col),
        0 a `lejos` o más, y en medio un fundido suave."""
        jx, jy = self.jugador.centro
        d = math.hypot(distancia_corta(col * TILE, jx, MAPA_ANCHO), distancia_corta(fila * TILE, jy, MAPA_ALTO)) / TILE
        return max(0.0, min(1.0, (lejos - d) / (lejos - cerca)))

    def dibujar_rotulos(self):
        """Base (con "clic: entrar"), Fabricador y Nave: solo cerca o con el mouse encima."""
        raton = pygame.mouse.get_pos()
        cam_x, cam_y = self.camara
        rotulos = (("base", BASE_POS, ESTRUCTURA_LADO, t("base") + " · " + t("base_entrar")),
                   ("crafteo", CRAFTEO_POS, 1, t("crafteo")),
                   ("nave", NAVE_POS, NAVE_LADO, t("nave")))
        for nombre, (f0, c0), lado, texto in rotulos:
            x = distancia_corta(c0 * TILE, cam_x, MAPA_ANCHO) + ANCHO / 2
            y = distancia_corta(f0 * TILE, cam_y, MAPA_ALTO) + ALTO / 2
            zona = (self.rect_nave() if nombre == "nave" and self.nave_grande
                    else pygame.Rect(x, y, lado * TILE, lado * TILE))
            alfa = self.cercania(f0 + lado / 2, c0 + lado / 2)
            if zona.collidepoint(raton):
                alfa = 1.0
            if alfa <= 0.02 or not (-zona.w < zona.x < ANCHO and -zona.h < zona.y < ALTO):
                continue
            # Base y Fabricador lo llevan arriba (abajo suele estar el astronauta); la
            # nave, abajo (su dibujo sobresale mucho hacia arriba).
            abajo = y + lado * TILE + 18 if nombre == "nave" else y - 4
            self._pastilla(texto, (x + lado * TILE / 2, abajo), self.fuente_mini, alfa)
