"""Cinemáticas: carga los PNG de una carpeta, los ordena y los reproduce como
animación a pantalla completa. Solo dibuja: no tiene reglas del juego.

- Final (al salir de Marte): assets/cinematica/ (orden de abajo).
- Luna -> Marte (ronda 31): assets/cinematica_luna_marte/lm01.png ... lm70.png
  (orden por número; ver CINE_LM_* en config.py). Algunos cuadros duran más
  (`duraciones`): así la nave se queda un momento en la Luna y en Marte.

Orden de los cuadros: por prefijo de letra y luego por número. Los prefijos
cuentan la historia en este orden (ORDEN_PREFIJOS):
  i  la nave en Marte y despegando (el suelo naranja queda abajo),
  s  la nave subiendo al espacio y viajando entre las estrellas,
  y  la llegada a la Tierra (el suelo verde aparece abajo),
  z  la nave en la Tierra, rodeada de flores de colores que cambian.
"y.png" sin número cuenta como el 1. Hay números que faltan (s13, s24...) y
muchos cuadros repetidos a propósito: así una imagen dura más tiempo.

Accesibilidad: va a pocos cuadros por segundo, con fundidos suaves al empezar
y al terminar; nada parpadea rápido.
"""

import bisect
import itertools
import os
import re

import pygame

ORDEN_PREFIJOS = ("i", "s", "y", "z")
_NOMBRE = re.compile(r"([a-z]+)(\d*)\.png$")


def clave_orden(nombre, orden=ORDEN_PREFIJOS):
    """(lugar del prefijo, número) para ordenar "s12.png" después de "s9.png"."""
    m = _NOMBRE.match(nombre.lower())
    if not m:
        return (len(orden) + 1, 0, nombre)
    prefijo, numero = m.group(1), int(m.group(2) or 1)
    lugar = orden.index(prefijo) if prefijo in orden else len(orden)
    return (lugar, numero, nombre)


def nombres_en_orden(carpeta, orden=ORDEN_PREFIJOS):
    """Los .png de la carpeta en el orden de la historia ([] si no existe)."""
    if not os.path.isdir(carpeta):
        return []
    return sorted((n for n in os.listdir(carpeta) if _NOMBRE.match(n.lower())),
                  key=lambda n: clave_orden(n, orden))


def cargar(carpeta, orden=ORDEN_PREFIJOS):
    """Lista de imágenes en orden. Un PNG que no se puede leer se salta; si no
    hay ninguno devuelve [] (el juego sigue con el final de siempre)."""
    return [img for _, img in cargar_con_nombres(carpeta, orden)]


def cargar_con_nombres(carpeta, orden=ORDEN_PREFIJOS):
    """[(nombre, imagen)] en orden, saltando los PNG que no se pueden leer."""
    cuadros = []
    for nombre in nombres_en_orden(carpeta, orden):
        try:
            cuadros.append((nombre, pygame.image.load(os.path.join(carpeta, nombre)).convert_alpha()))
        except (pygame.error, FileNotFoundError):
            continue
    return cuadros


def duraciones(nombres, fps, sostener):
    """Segundos de cada cuadro: 1/fps, salvo los de `sostener` ({número: segundos})."""
    lista = []
    for nombre in nombres:
        m = _NOMBRE.match(nombre.lower())
        numero = int(m.group(2) or 1) if m else 0
        lista.append(sostener.get(numero, 1.0 / fps))
    return lista


class Cinematica:
    """Reproduce los cuadros a `fps`, escalados a pantalla completa con píxeles
    parejos (un múltiplo entero, sin suavizado) y centrados sobre negro."""

    def __init__(self, cuadros, tam, fps, fundido, duraciones=None):
        """duraciones: segundos de cada cuadro (None: todos 1/fps, como siempre)."""
        self.cuadros = cuadros
        self.duraciones = duraciones
        self._fines = list(itertools.accumulate(duraciones)) if duraciones else None
        self.ancho, self.alto = tam
        self.fps = fps
        self.fundido = fundido
        self.t = 0.0
        # Las imágenes repetidas se escalan una sola vez (se comparan por sus píxeles).
        self._escaladas = {}
        self._clave = []
        for c in cuadros:
            clave = pygame.image.tobytes(c, "RGBA") + bytes(str(c.get_size()), "ascii")
            if clave not in self._escaladas:
                w, h = c.get_size()
                escala = max(1, min(self.ancho // w, self.alto // h))
                self._escaladas[clave] = pygame.transform.scale(c, (w * escala, h * escala))
            self._clave.append(clave)
        self._velo = pygame.Surface(tam, pygame.SRCALPHA)

    @property
    def duracion(self):
        if self._fines:
            return self._fines[-1]
        return len(self.cuadros) / self.fps

    @property
    def terminada(self):
        return self.t >= self.duracion

    @property
    def indice(self):
        """Número del cuadro que se ve ahora."""
        if self._fines:
            return min(len(self.cuadros) - 1, bisect.bisect_right(self._fines, self.t))
        return min(len(self.cuadros) - 1, int(self.t * self.fps))

    def actualizar(self, dt):
        """Avanza dt segundos. Devuelve True cuando ya terminó."""
        self.t += dt
        return self.terminada

    def saltar(self):
        self.t = self.duracion

    def dibujar(self, pantalla, aviso=None):
        """Cuadro actual centrado, el fundido (negro al empezar y al terminar) y,
        si se da, un aviso abajo ("Espacio: saltar")."""
        pantalla.fill((0, 0, 0))
        img = self._escaladas[self._clave[self.indice]]
        pantalla.blit(img, img.get_rect(center=(self.ancho // 2, self.alto // 2)))
        if self.fundido > 0:
            visible = min(1.0, self.t / self.fundido, max(0.0, self.duracion - self.t) / self.fundido)
            if visible < 1.0:
                self._velo.fill((0, 0, 0, int(255 * (1.0 - visible))))
                pantalla.blit(self._velo, (0, 0))
        if aviso is not None:
            pantalla.blit(aviso, aviso.get_rect(bottomright=(self.ancho - 12, self.alto - 8)))
