"""La clase Juego: une todas las partes (mixins), crea la partida y tiene el bucle principal.
"""

import random

import pygame

import clima as modulo_clima
import estilo
import eventos_marte
import fondo_menu
import partidas
from clima import CALMA, Clima, TEMP_DIA_MARTE, TEMP_NOCHE_MARTE, TormentaPolvo
from eventos_marte import CONFIG as CONFIG_MARTE
from maquinas import RECURSOS
from supervivencia import BARRAS, DOSIS, NORMAL, OXIGENO, Supervivencia
from textos import t
from config import (ICONO_OBJETO, AGUA_INICIAL, ALTO, ANCHO, ANTENA_PRIMERO, ARTE_RECURSO, CABLE_COLORES,
                    CARPETA, COLINAS, COLOR_BARRA, COLOR_RECURSO, COLOR_VINETA_OXIGENO,
                    COLOR_VINETA_RADIACION, COLUMNAS, DESTINO_INICIAL, DT_MAX, ESCENA_MAPA, FILAS,
                    FPS, ICONOS_OBJETO, INVENTARIO_RECT, JUGADOR_TAM, LUNA, MACETAS_BASE,
                    MANO_RECT, MAPA_ALTO, MAPA_ANCHO, MARTE, MENU_RECT, NAVE_ESCALA, OBJETOS,
                    OBJETOS_INICIALES, POLVO_RECT, RAPIDA_INICIAL, RAPIDA_RECT, RELOJ_RECT,
                    SEMILLA_BOTIN, SPRITES, TEXTURA_VARIANTES, TILE, VITALES_RECT)
from arte import (cargar_astronauta, cargar_plantas, cargar_sprites, cargar_trozos_suelo,
                  color_marte, icono_ajustado, icono_de_sprite, piezas_de_cable,
                  sortear_variantes_suelo)
from mapa import colocar_estructuras, generar_alturas, generar_mapa
from jugador import Jugador, calcular_camara
from juego_hud import HudMixin
from juego_herramientas import HerramientasMixin
from juego_energia import EnergiaMixin
from juego_entrada import EntradaMixin
from juego_mundo import MundoMixin
from juego_marte import MarteMixin
from juego_dibujo_mundo import DibujoMundoMixin
from juego_dibujo_objetos import DibujoObjetosMixin
from juego_inventario import InventarioMixin
from juego_base import BaseMixin
from juego_guardado import GuardadoMixin
from juego_menus import MenusMixin
from juego_slots import SlotsMixin
from juego_mano import ManoMixin
from juego_cinematica import CinematicaMixin
from juego_companero import CompaneroMixin, cargar_companero
from juego_demo import DemoMixin
from juego_pantalla import PantallaMixin, crear_ventana
from juego_avisos import AvisosMixin
from companero import Companero


class Juego(HudMixin, HerramientasMixin, EnergiaMixin, EntradaMixin, MundoMixin, MarteMixin,
            DibujoMundoMixin, DibujoObjetosMixin, InventarioMixin, BaseMixin, GuardadoMixin, SlotsMixin, ManoMixin, CinematicaMixin, CompaneroMixin,
            DemoMixin, PantallaMixin, AvisosMixin, MenusMixin):
    """El juego completo. Cada mixin (clase de la que hereda) trae un tema; los
    métodos y atributos se llaman igual que cuando todo estaba en main.py."""

    def __init__(self, destino=DESTINO_INICIAL, inicio=False, completa=False):
        """inicio=True: empieza en el menú principal (así lo abre main()). Sin él,
        empieza jugando (como antes; lo usan las pruebas y "python main.py marte").
        completa=True: arranca en pantalla completa (python main.py --completa)."""
        pygame.init()
        pygame.display.set_caption("Lumati")
        # Ronda 29: ventana escalada por SDL (pantalla completa con F11; ver juego_pantalla.py).
        # Se sigue dibujando a ANCHO x ALTO; el mouse llega ya en coordenadas del juego.
        self.pantalla = crear_ventana(False)
        self.pantalla_completa = False
        self.reloj = pygame.time.Clock()

        self.destino = destino                             # LUNA o MARTE
        self._suelos = {LUNA: cargar_trozos_suelo()}       # el de Marte se genera al llegar
        self.trozos_suelo = self._suelos[LUNA]
        self.sprites_astronauta = cargar_astronauta()      # None si falta el PNG
        self.sprites = cargar_sprites()                    # solo los PNG que existen
        self.piezas_cable = piezas_de_cable(self.sprites)
        # La nave se dibuja más grande que el resto del arte (NAVE_ESCALA en vez de x3).
        # El sprite ya viene x3 en bloques de 3x3 px: reescalarlo a otro entero es exacto.
        if "nave" in self.sprites:
            (nave_ancho, nave_alto), _ = SPRITES["nave"]
            self.nave_grande = pygame.transform.scale(self.sprites["nave"][0],
                                                      (nave_ancho * NAVE_ESCALA, nave_alto * NAVE_ESCALA))
        else:
            self.nave_grande = None
        self.plantas = cargar_plantas()
        # Íconos de los objetos: el PNG de las diseñadoras si existe; si no, uno de color.
        self.iconos_objeto = {o: (icono_de_sprite(self.sprites[ICONOS_OBJETO[o]][0])
                                  if ICONOS_OBJETO.get(o) in self.sprites
                                  else self._icono_respaldo(o))
                              for o in OBJETOS}
        self.sprites_companero = cargar_companero()        # robot compañero (ronda 27); None si faltan los PNG
        if self.sprites_companero:                          # su ícono: el dibujo de frente
            self.iconos_objeto["companero"] = icono_ajustado(self.sprites_companero["frente"][0], ICONO_OBJETO)
        azar = random.Random(5)                            # estrellas del final (siempre iguales)
        self._estrellas = [(azar.randrange(ANCHO), azar.randrange(ALTO), azar.choice((1, 1, 2)))
                           for _ in range(140)]
        self.variantes_suelo = sortear_variantes_suelo(
            len(self.trozos_suelo) if self.trozos_suelo else TEXTURA_VARIANTES)
        self.fuente = pygame.font.Font(None, 24)
        self.fuente_chica = pygame.font.Font(None, 20)
        self.fuente_mini = pygame.font.Font(None, 16)
        self.fuente_grande = pygame.font.Font(None, 44)
        self.fuente_titulo = pygame.font.Font(None, 96)    # "Lumati" en el menú de opciones
        self.fuente_tarjeta = pygame.font.Font(None, 30)   # texto de las tarjetas del menú
        self.rect_mano = pygame.Rect(MANO_RECT)                 # "en la mano", abajo a la izquierda
        self.rect_rapida = pygame.Rect(RAPIDA_RECT)             # acceso rápido, abajo al centro
        self.rect_inventario = pygame.Rect(INVENTARIO_RECT)     # la etiqueta de la esquina
        self.rect_menu = pygame.Rect(MENU_RECT)                 # el menú de las 21 casillas (tecla E)
        self.rect_vitales = pygame.Rect(VITALES_RECT)
        self.rect_reloj = pygame.Rect(RELOJ_RECT)
        self.rect_polvo = pygame.Rect(POLVO_RECT)
        self._velo = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)   # velo de la noche, se reutiliza
        self._banner_cache = (None, None)       # (clave, (rect, líneas))
        # Pulido visual (estilo.py): íconos hechos una sola vez, partículas y vinetas.
        self.iconos_vitales = {b: estilo.icono_barra(b, COLOR_BARRA[b]) for b in BARRAS}
        self.iconos_recurso = {r: estilo.icono_recurso(r, c, 3) for r, c in COLOR_RECURSO.items()}
        self.iconos_recurso_chico = {r: estilo.icono_recurso(r, c, 2) for r, c in COLOR_RECURSO.items()}
        if "recursos_taladro" in self.sprites:     # dibujos de las diseñadoras para los recursos
            for recurso, cuadro in ARTE_RECURSO.items():
                imagen = self.sprites["recursos_taladro"][cuadro]
                self.iconos_recurso[recurso] = icono_ajustado(imagen, self.iconos_recurso[recurso].get_width())
                self.iconos_recurso_chico[recurso] = icono_ajustado(imagen, self.iconos_recurso_chico[recurso].get_width())
        self.particulas = estilo.Particulas()
        self._vineta_radiacion = estilo.vineta((ANCHO, ALTO), COLOR_VINETA_RADIACION)
        self._vineta_oxigeno = estilo.vineta((ANCHO, ALTO), COLOR_VINETA_OXIGENO)
        self._iconos_evento = {}               # íconos de los avisos de Marte (se hacen al usarse)
        # Ronda 22: fondo del menú de opciones con dos astronautas (el dibujo de las diseñadoras).
        flotando = []
        if self.sprites_astronauta:
            cuadros = self.sprites_astronauta[0]
            flotando = [cuadros["abajo"][0], cuadros["derecha"][0]]
        self._fondo_menu = fondo_menu.FondoEspacial((ANCHO, ALTO), flotando)
        self._resalte = {}                     # "página:botón" -> 0 a 1 (tarjeta bajo el mouse)
        # Menú de opciones (ronda 21). Mientras está abierto el juego está en pausa.
        self.opciones = None                   # None o la página del menú abierta (ver abrir_opciones)
        self.en_inicio = False                 # True: el menú abierto es el principal (no la pausa)
        self._confirmar = None                 # pregunta abierta: ("sobrescribir", ruta) o ("salir",)
        self.guia_seccion = 0
        self._lista_partidas = None            # lista de ranuras (se relee al cambiar algo)
        self._slots = None                     # los 3 slots con sus estadísticas (ronda 25)
        self._iconos_slot = {}                 # íconos chicos de las estadísticas de los slots
        self._iconos_mano = {}                 # íconos del objeto en la mano (ronda 26)
        self._cuadros_cine = None              # cuadros de la cinemática final (se cargan al usarse)
        self.quiere_salir = False              # "Guardar y salir" o "Salir sin guardar": run() termina
        try:                                   # la primera vez, copia los guardados viejos a ranuras
            partidas.migrar(CARPETA)
            partidas.ordenar_slots(CARPETA)    # solo 3 slots: las de más van a partidas/_extra/
        except OSError:
            pass
        self._panel_polvo = None               # capa de polvo sobre un panel solar (Marte)
        self._sombra_astronauta = pygame.Surface((34, 12), pygame.SRCALPHA)
        pygame.draw.ellipse(self._sombra_astronauta, estilo.SOMBRA, self._sombra_astronauta.get_rect())
        self.nueva_partida()
        if inicio:
            self.abrir_inicio()                # el juego empieza en el menú principal
        if completa:
            self.alternar_pantalla_completa(True)

    def nueva_partida(self, destino=None):
        """Estado de una partida: mapa, taladros, máquinas, inventario,
        astronauta y clima. No toca la ventana ni el idioma. Con `destino`
        (LUNA o MARTE) cambia de mundo; sin él, se queda en el mismo."""
        if destino:
            self.destino = destino
        if self.destino not in self._suelos:               # el piso de Marte se hace la primera vez
            self._suelos[self.destino] = cargar_trozos_suelo(color_marte)
        self.trozos_suelo = self._suelos[self.destino]
        self.mapa = generar_mapa()
        self.alturas = generar_alturas()     # montañas: se caminan, no se construye encima
        self._montanas = {}                  # (colina, marte) -> imagen de la montaña
        self._colina_de = {}                 # (fila, col) -> (colina, fila dentro, col dentro)
        for k, (f0, c0, radio) in enumerate(COLINAS):
            for df in range(-radio, radio + 1):
                for dc in range(-radio, radio + 1):
                    self._colina_de[((f0 + df) % FILAS, (c0 + dc) % COLUMNAS)] = (k, df + radio, dc + radio)
        self._cielo = 0.0                    # 0 a 1: vista del espacio desde una cima
        self.minimapa_visible = True
        self._mini = None                    # superficie del minimapa (se rehace cada MINIMAPA_CADA)
        self._mini_t = 0.0
        self._cometas = []                   # [x, y, vx, vy, vida, vida_total]
        self._cometa_t = 2.0
        self._en_cima = False
        colocar_estructuras(self.mapa)
        self._azar_botin = random.Random(SEMILLA_BOTIN)   # lo que sacan los taladros
        self.taladros = {}               # (fila, columna) -> Taladro
        self.maquinas = {}               # (fila, columna) -> Maquina o Tanque (cadena del agua)
        self.escena_final = None         # None jugando; 0..ESCENAS_FINAL tras despegar
        self.cinematica = None           # cinemática en curso (final de Marte, Luna -> Marte o demostración) o None
        self._cine_fin = None            # qué pasa al terminar la cinemática (None: las estadísticas del final)
        self.producido = {"oxigeno": 0, "agua": 0, "comida": 0}   # para la comparación final
        self.dato = None                 # [id de datos.py, segundos que le quedan en pantalla]
        self._sembrados = 0              # invernaderos puestos: decide el siguiente cultivo
        self.macetas = [None] * MACETAS_BASE   # cuarto de cultivos de la base: Maquina o None
        self.cuarto = "habitable"        # dentro de la base: "habitable" o "invernadero"
        self._datos_vistos = set()       # cada dato emergente sale una sola vez por partida
        self._energizados = set()        # cables cuya red toca un panel solar (o una batería con carga)
        self.baterias = {}               # (fila, col) -> segundos de energía guardados
        self.tanques_agua = {}           # (fila, col) -> unidades de agua guardadas
        self._estado_bateria = {}        # (fila, col) -> "carga", "descarga" o "vacia"
        self._clave_energia = None       # (paneles activos, baterías con carga) del último cálculo
        self._paneles_previo = True
        self._img_cache = {}             # sprites escalados al cuadro (batería, taladro, cubeta)
        self._nodos_cable = {}           # (fila, col) -> [dx, dy, vx, vy]: cables que se balancean (adorno)
        self.colores_cable = {}          # (fila, col) -> "verde", "azul" o "amarillo" (cada color, su circuito)
        self.antenas = set()             # (fila, col) de cada antena puesta
        self.contacto = False            # alguna antena tiene energía ahora
        self.contacto_hecho = False      # hubo contacto alguna vez (sale en el final)
        self._tierra_t = ANTENA_PRIMERO  # segundos hasta el siguiente mensaje de la Tierra
        self._msg_tierra = 0             # qué dato toca mandar (se recorren en orden)
        self.color_cable = CABLE_COLORES[0]   # color o pieza con que se tiende el siguiente cable (C o rueda)
        self.giro_cable = 0              # giro de la pieza (R): 0 a 3, de 90 en 90 grados
        self.piezas_cable = {}           # (fila, col) -> (forma, giro) de los conectores y cables negros
        self._energia_sucia = True       # hay que recalcular (se cambió un cable o panel)
        self.jugador = Jugador(MAPA_ANCHO / 2 - JUGADOR_TAM / 2,
                               MAPA_ALTO / 2 - JUGADOR_TAM / 2)
        self.companero = Companero()     # el robot compañero (ronda 27): inactivo hasta ponerlo
        self._comp_lugar = None          # (escena, cuarto) donde estaba: si cambia, aparece junto a ti
        self.camara = calcular_camara(self.jugador)
        self.astronauta = Supervivencia()     # oxígeno, energía, comida, radiación
        self.polvo = None                     # tormentas de polvo: solo en Marte
        self.eventos_marte = None             # eventos de Marte (ronda 20): solo en Marte
        if self.destino == MARTE:
            # Las tormentas solares y de polvo de Marte ya no se disparan solas: las
            # programa eventos_marte.py con frecuencias basadas en datos reales.
            sep = CONFIG_MARTE["sep"]
            ejemplos = [e for i in eventos_marte.IDS_SEP_MARTE for e in modulo_clima.EVENTOS if e["id"] == i]
            self.clima = Clima(eventos=ejemplos, automatico=False,
                               duracion_particulas=sep["duracion_particulas"])
            self.polvo = TormentaPolvo(automatico=False)
            self.eventos_marte = eventos_marte.EventosMarte()
            self.clima.reloj.temp_dia = TEMP_DIA_MARTE
            self.clima.reloj.temp_noche = TEMP_NOCHE_MARTE
        else:
            self.clima = Clima()              # tormentas solares (la Luna, como siempre)
        self.crateres = []                    # Marte: (fila, col) del centro de cada cráter de impacto
        self._crater_de = {}                  # (fila, col) -> (cráter, fila dentro, col dentro)
        self._img_crater = {}                 # cráter -> imagen
        self.remolinos = []                   # remolinos de polvo que cruzan (solo adorno)
        self._sacudida = None                 # [segundos que quedan, total, amplitud en px]
        self._chip = None                     # aviso corto con ícono: [texto, ícono, segundos]
        self._paneles_sucios = 0.0            # 0 a 1: polvo que se ve sobre los paneles (adorno)
        self._fase_clima = CALMA              # para notar cuándo empieza la cadena solar en Marte
        self._nivel_previo = {OXIGENO: NORMAL, DOSIS: NORMAL}
        # Pulido visual: nada de esto es parte de las reglas.
        self._cam = [float(v) for v in self.camara]       # cámara con decimales (para suavizarla)
        self._barra_vista = {b: self.astronauta.fraccion(b) for b in BARRAS}   # lo que muestran las barras
        self._panel_cache = {}                # panel solar escalado al cuadro, por posición
        self._riegos = {}                     # (fila, col) -> segundos que quedan de gotas
        self._vinetas = {"radiacion": 0.0, "oxigeno": 0.0}                     # 0 = no se ve, 1 = toda
        self._polvo_velo = 0.0                # qué tanto se ve el velo de la tormenta de polvo
        self._polvo_t = 0.0                   # tiempo hasta el siguiente soplo de polvo al caminar
        self._menu_t = 0.0                    # 0 a 1: el menú aparece suave
        self._tiempo = 0.0                    # segundos de partida (mueve las rachas de polvo)
        self.particulas.vaciar()

        self.escena = ESCENA_MAPA        # ESCENA_MAPA afuera; ESCENA_BASE dentro de la base
        self.pos_base = [0.0, 0.0]       # dentro de la base: esquina de la caja del astronauta (pantalla)
        self._fuera_pos = None           # dónde estaba afuera al entrar
        self.menu_base = None            # dentro: None, "almacen", "sistemas" o "terminal"
        self._fundido = None             # al dormir: [fase, 0..1]; fase "bajando" o "subiendo"
        self._info_partida = None        # texto de la partida guardada (para la terminal)
        self.almacen = {r: 0 for r in RECURSOS}   # almacén de la base: {recurso: cantidad}
        self.es_demo = False             # partida de demostración (ronda 28): fabricar y colocar no gastan
        self.letreros = []               # letreros pintados en el suelo (solo la demo): [fila, col, clave, tipo, zona, espera]
        self.objetos = {o: OBJETOS_INICIALES.get(o, 0) for o in OBJETOS}   # objetos fabricados que lleva
        self.inventario.agregar("agua", AGUA_INICIAL)     # la regadera empieza con agua
        self.en_mano = "taladro"         # objeto que coloca un clic en el mapa (None = nada)
        self.rapida = list(RAPIDA_INICIAL)   # acceso rápido: objeto de cada casilla (None = vacía)
        self.mensaje = t("marte_bienvenida") if self.destino == MARTE else ""
        self.ranura_actual = None        # ranura de partidas/ donde guarda F5 (None = una nueva)
        if self.destino == MARTE:
            self.mostrar_dato("marte_gcr")    # la radiación de fondo de Marte (Curiosity)
        self.inventario_abierto = False  # el menú de las 21 casillas (tecla E)
        self.crafteo_abierto = False     # el menú del Fabricador (clic en él)
        self.casilla_elegida = None      # casilla (0 a 20) elegida con un clic en el menú

    def rescatar_astronauta(self):
        """Tras morir sin oxígeno: vuelve al inicio con todo lleno. Se conservan
        el inventario, los taladros y la radiación acumulada. Devuelve False si
        no hay rescate (murió por radiación)."""
        if not self.astronauta.rescatar():
            return False
        self._nivel_previo = {OXIGENO: NORMAL, DOSIS: self.astronauta.nivel_aviso(DOSIS)}
        inicio = (MAPA_ANCHO / 2 - JUGADOR_TAM / 2, MAPA_ALTO / 2 - JUGADOR_TAM / 2)
        # Si en el inicio se construyó algo, busca el cuadro libre más cercano.
        for radio in range(0, 6):
            for df in range(-radio, radio + 1):
                for dc in range(-radio, radio + 1):
                    x = (inicio[0] + dc * TILE) % MAPA_ANCHO
                    y = (inicio[1] + df * TILE) % MAPA_ALTO
                    if not self.jugador.choca(self.mapa, x, y):
                        self.jugador.x, self.jugador.y = x, y
                        self.camara = calcular_camara(self.jugador)
                        self._cam = [float(v) for v in self.camara]
                        return True
        return True

    # -- bucle principal ---------------------------------------------------
    def run(self):
        corriendo = True
        while corriendo:
            dt = min(self.reloj.tick(FPS) / 1000, DT_MAX)
            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    corriendo = False
                elif evento.type == pygame.KEYDOWN:
                    self.tecla(evento.key)       # Esc abre o cierra el menú de opciones (ronda 21)
                elif evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:
                    self.clic(evento.pos)
                elif evento.type == pygame.MOUSEWHEEL:
                    self.rueda(evento.y)
            self.actualizar(dt)
            self.dibujar()
            if self.quiere_salir:                # "Guardar y salir" o "Salir sin guardar"
                corriendo = False
        pygame.quit()
