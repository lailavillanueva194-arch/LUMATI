"""Datos de supervivencia del jugador: oxígeno, energía, comida y radiación
(las 4 barras del panel) y el inventario que lleva encima. Lógica pura: no usa
pygame, no dibuja y no sabe de colores ni de dónde está el jugador. main.py le
dice, en cada cuadro, si está en la base, en qué zona de radiación y cuánto lo
protege el regolito.

Dificultad fácil: el oxígeno baja lento y no se pierde ningún objeto. Todos
los valores de balance están aquí arriba para ajustarlos.
"""

from maquinas import RECURSOS, casillas, casillas_ocupadas, espacio, faltante

# --------------------------------------------------------------------------
# Balance (por segundo de juego)
# --------------------------------------------------------------------------
OXIGENO_MAX = 100.0
ENERGIA_MAX = 100.0
COMIDA_MAX = 100.0
DOSIS_MAX = 100.0               # al llegar aquí la radiación mata (permanente)

CONSUMO_OXIGENO = 0.15          # afuera dura unos 11 minutos
FACTOR_BASE_OXIGENO = 0.25      # dentro de la base se gasta una cuarta parte
CONSUMO_ENERGIA = 0.10          # energía del traje, afuera
RECARGA_ENERGIA_BASE = 1.0      # en la base se recarga
CONSUMO_COMIDA = 0.05
FACTOR_HAMBRE_ENERGIA = 2.0     # con la comida en 0, la energía baja el doble
TASA_DOSIS = 0.02               # dosis normal; luego se multiplica por zona y tormenta
GRACIA_SIN_OXIGENO = 10.0       # segundos con el oxígeno en 0 antes de morir

# SIMPLIFICACIÓN: 100 unidades de dosis equivalen al límite de carrera de
# 600 mSv que cita la guía (para la pantalla final "tu misión contra la real").
DOSIS_A_MSV = 6.0

# Avisos: fracción de la barra. Para la dosis cuenta lo que YA se acumuló.
UMBRAL_BAJO = 0.25
UMBRAL_CRITICO = 0.10

# Nombres de las barras y niveles de aviso
OXIGENO, ENERGIA, COMIDA, DOSIS = "oxigeno", "energia", "comida", "dosis"
BARRAS = (OXIGENO, ENERGIA, COMIDA, DOSIS)
NORMAL, BAJO, CRITICO = "normal", "bajo", "critico"
MAXIMOS = {OXIGENO: OXIGENO_MAX, ENERGIA: ENERGIA_MAX, COMIDA: COMIDA_MAX, DOSIS: DOSIS_MAX}


class Inventario(dict):
    """Lo que lleva el astronauta: {recurso: cantidad}. Sigue siendo un diccionario
    (inventario["hierro"] funciona), pero con las reglas en un solo lugar:
    límite de lo que cabe (CASILLAS de PILA_MAX y el máximo de hielo en las
    manos, ver maquinas.py) y pago de costos. Empieza vacío, con todos los
    recursos en 0. Las casillas se calculan de estas cantidades."""

    def __init__(self):
        super().__init__({r: 0 for r in RECURSOS})

    def espacio(self, recurso):
        """Cuántas unidades más de ese recurso caben (0 si ya no hay lugar)."""
        return espacio(self, recurso)

    def casillas(self):
        """Las CASILLAS (21) de la mochila: (recurso, cantidad) o None."""
        return casillas(self)

    @property
    def casillas_usadas(self):
        return casillas_ocupadas(self)

    def agregar(self, recurso, cantidad):
        """Guarda hasta `cantidad` unidades y devuelve cuántas entraron de
        verdad (lo que cabe en las casillas; el hielo no pasa del máximo de las
        manos). 0 si no cabe nada."""
        if recurso not in self:
            raise ValueError(f"recurso desconocido: '{recurso}'")
        if cantidad <= 0:
            return 0
        entran = int(min(cantidad, self.espacio(recurso)))
        self[recurso] += entran
        return entran

    def faltante(self, costo):
        """{recurso: cuánto falta} para pagar el costo; vacío si alcanza."""
        return faltante(self, costo)

    def pagar(self, costo):
        """Descuenta el costo completo, o no toca nada y devuelve False si no
        alcanza (nunca cobra a medias)."""
        if self.faltante(costo):
            return False
        for recurso, cantidad in costo.items():
            self[recurso] -= cantidad
        return True


def _segundos_hasta(cantidad, tasa):
    """Segundos que tarda en agotarse `cantidad` a `tasa` por segundo. Una tasa
    de 0 (o negativa) nunca la agota: así poner una constante en 0 no truena."""
    return cantidad / tasa if tasa > 0 else float("inf")


class Supervivencia:
    """Estado vital del jugador. Empieza con todo lleno y sin radiación."""

    def __init__(self):
        self.oxigeno = OXIGENO_MAX
        self.energia = ENERGIA_MAX
        self.comida = COMIDA_MAX
        self.inventario = Inventario()  # lo que lleva encima
        self.dosis = 0.0                # PERMANENTE: nunca baja
        self.segundos_sin_oxigeno = 0.0
        self.causa_muerte = None        # None, OXIGENO o DOSIS

    # ---- consulta -------------------------------------------------------
    @property
    def vivo(self):
        return self.causa_muerte is None

    @property
    def dosis_msv(self):
        """Dosis acumulada en milisieverts (equivalencia de juego)."""
        return self.dosis * DOSIS_A_MSV

    def valor(self, barra):
        return getattr(self, barra)

    def fraccion(self, barra):
        """Qué tan llena está la barra, de 0.0 a 1.0 (para dibujarla)."""
        return self.valor(barra) / MAXIMOS[barra]

    def nivel_aviso(self, barra):
        """NORMAL, BAJO o CRITICO. En oxígeno, energía y comida avisa cuando
        quedan pocos; en la dosis avisa cuando ya se acumuló mucha."""
        f = self.fraccion(barra)
        peligro = f if barra == DOSIS else 1.0 - f      # cuánto falta para lo malo
        restante = 1.0 - peligro                        # fracción que queda hasta el límite
        if restante <= UMBRAL_CRITICO:
            return CRITICO
        if restante <= UMBRAL_BAJO:
            return BAJO
        return NORMAL

    def rescatar(self):
        """Revive a quien murió por falta de oxígeno, con aire, energía y comida
        llenos. La dosis NO se toca (es permanente). Si la causa fue la
        radiación no hay rescate: devuelve False."""
        if self.causa_muerte != OXIGENO:
            return False
        self.oxigeno = OXIGENO_MAX
        self.energia = ENERGIA_MAX
        self.comida = COMIDA_MAX
        self.segundos_sin_oxigeno = 0.0
        self.causa_muerte = None
        return True

    # ---- recursos que entran ---------------------------------------------
    def agregar(self, barra, cantidad):
        """Sube oxígeno, energía o comida. Devuelve cuánto entró de verdad
        (no pasa del máximo). La dosis no se puede reducir: es permanente."""
        if barra == DOSIS or barra not in MAXIMOS:
            raise ValueError(f"no se puede agregar a '{barra}'")
        if cantidad <= 0 or not self.vivo:
            return 0.0
        antes = self.valor(barra)
        setattr(self, barra, min(MAXIMOS[barra], antes + cantidad))
        return self.valor(barra) - antes

    # ---- paso del tiempo --------------------------------------------------
    def actualizar(self, dt, en_base=False, zona=1.0, blindaje=0.0, mult_tormenta=1.0, factor_oxigeno=1.0):
        """Avanza dt segundos.

        en_base: dentro de la base gasta menos oxígeno y recarga energía.
        zona: multiplicador de radiación del lugar (1.0 normal, 0 sin radiación).
        blindaje: 0.0 a 1.0, cuánto frenan los bloques de regolito.
        mult_tormenta: Clima.multiplicador_radiacion (1.0 si no hay tormenta).
        factor_oxigeno: multiplica el gasto de oxígeno afuera (ronda 33: tanque del
        traje; 1.0 = como siempre).
        Un dt grande da el mismo resultado que muchos pasos chicos.
        """
        if dt <= 0 or not self.vivo:
            return
        consumo = CONSUMO_OXIGENO * (FACTOR_BASE_OXIGENO if en_base else factor_oxigeno)
        blindaje = min(1.0, max(0.0, blindaje))
        tasa_dosis = TASA_DOSIS * zona * mult_tormenta * (1.0 - blindaje)

        # Cuánto falta para cada muerte. Si ocurre dentro de este dt, todo se
        # detiene en ese momento (así un dt grande = muchos pasos chicos).
        if self.oxigeno > 0:
            self.segundos_sin_oxigeno = 0.0     # con aire se reinicia la gracia
        hasta_aire = _segundos_hasta(self.oxigeno, consumo)
        hasta_muerte_oxigeno = hasta_aire + (GRACIA_SIN_OXIGENO - self.segundos_sin_oxigeno)
        hasta_muerte_dosis = _segundos_hasta(DOSIS_MAX - self.dosis, tasa_dosis)
        dt_real = min(dt, hasta_muerte_oxigeno, hasta_muerte_dosis)

        # Oxígeno
        if dt_real < hasta_aire:
            self.oxigeno -= consumo * dt_real
        else:
            self.oxigeno = 0.0
            self.segundos_sin_oxigeno += dt_real - hasta_aire   # solo lo que pasó sin aire
        self._comida_y_energia(dt_real, en_base)
        self.dosis = min(DOSIS_MAX, self.dosis + tasa_dosis * dt_real)

        # Si alcanza a ocurrir más de una muerte en este dt, cuenta la primera.
        if hasta_muerte_oxigeno <= hasta_muerte_dosis and dt >= hasta_muerte_oxigeno:
            self.causa_muerte = OXIGENO
        elif dt >= hasta_muerte_dosis:
            self.dosis = DOSIS_MAX
            self.causa_muerte = DOSIS

    def _comida_y_energia(self, dt, en_base):
        # Primer tramo: aún hay comida. Segundo tramo: comida en 0 (hambre).
        con_comida = min(dt, _segundos_hasta(self.comida, CONSUMO_COMIDA))
        con_hambre = dt - con_comida
        self.comida = max(0.0, self.comida - CONSUMO_COMIDA * dt)
        if en_base:
            self.energia = min(ENERGIA_MAX, self.energia + RECARGA_ENERGIA_BASE * dt)
        else:
            gasto = CONSUMO_ENERGIA * (con_comida + FACTOR_HAMBRE_ENERGIA * con_hambre)
            self.energia = max(0.0, self.energia - gasto)
