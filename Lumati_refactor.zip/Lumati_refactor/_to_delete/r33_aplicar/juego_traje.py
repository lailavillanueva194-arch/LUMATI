"""Mejoras del traje (ronda 33): blindaje contra la radiación y tanque de oxígeno.

Dos líneas de 3 niveles cada una que se compran en el Fabricador (pestaña "Traje")
y se aplican al instante: no se colocan en el mapa ni ocupan el inventario.

- Blindaje del traje: frena una parte de la dosis (TRAJE_BLINDAJE) que se suma al
  blindaje del lugar (base y bloques), sin pasar de BLINDAJE_MAX. Durante una
  tormenta solar cuenta solo TRAJE_EN_TORMENTA de eso: ayuda, pero hay que refugiarse.
- Tanque de oxígeno: afuera el oxígeno dura más (TRAJE_OXIGENO). Se implementa como
  menor gasto por segundo, así la barra sigue siendo de 0 a 100 %.

Con nivel 0 en las dos (partidas nuevas y viejas) todo es exactamente como antes.
SIMPLIFICACIÓN (también en la guía): en la realidad la radiación se frena con
materiales densos o con agua, y el oxígeno dura más con tanques más grandes; aquí
son solo niveles con números de juego (no son datos de la NASA).
"""

import pygame

import estilo
from textos import t
from config import (BLINDAJE_MAX, TRAJE_BLINDAJE, TRAJE_COSTOS, TRAJE_EN_TORMENTA, TRAJE_NIVEL_MAX,
                    TRAJE_OXIGENO)

LINEAS_TRAJE = ("blindaje", "oxigeno")
ROMANO = {0: "0", 1: "I", 2: "II", 3: "III"}


def icono_traje(linea, lado=32):
    """Ícono dibujado: escudo (blindaje) o tanque con burbuja (oxígeno)."""
    img = pygame.Surface((lado, lado), pygame.SRCALPHA)
    s = lado / 32
    tinta = (40, 46, 58)
    if linea == "blindaje":
        puntos = [(16 * s, 3 * s), (27 * s, 7 * s), (26 * s, 17 * s), (16 * s, 29 * s), (6 * s, 17 * s), (5 * s, 7 * s)]
        pygame.draw.polygon(img, (150, 70, 210), puntos)
        pygame.draw.polygon(img, tinta, puntos, max(2, round(2 * s)))
        pygame.draw.polygon(img, (215, 180, 245), [(16 * s, 8 * s), (22 * s, 10 * s), (21 * s, 16 * s), (16 * s, 23 * s)])
    else:
        cuerpo = pygame.Rect(round(10 * s), round(7 * s), round(12 * s), round(22 * s))
        pygame.draw.rect(img, (110, 205, 245), cuerpo, border_radius=round(6 * s))
        pygame.draw.rect(img, tinta, cuerpo, max(2, round(2 * s)), border_radius=round(6 * s))
        pygame.draw.rect(img, tinta, (round(13 * s), round(3 * s), round(6 * s), round(5 * s)), border_radius=1)
        pygame.draw.circle(img, (235, 250, 255), (round(16 * s), round(17 * s)), round(3.5 * s))
        pygame.draw.circle(img, tinta, (round(16 * s), round(17 * s)), round(3.5 * s), 1)
    return img


class TrajeMixin:
    """Niveles del traje: comprarlos, su efecto en la radiación y el oxígeno, y su dibujo."""

    # ---- efecto ----------------------------------------------------------------
    def blindaje_traje(self):
        """Fracción de la dosis que frena el traje ahora (menos en una tormenta solar)."""
        b = TRAJE_BLINDAJE[self.traje["blindaje"]]
        if b and self.clima.en_peligro:
            b *= TRAJE_EN_TORMENTA
        return b

    def blindaje_total(self):
        """(en_base, blindaje): el del lugar (base y bloques, como antes) más el del
        traje, sin pasar de BLINDAJE_MAX. Con el traje en nivel 0 es igual que antes."""
        en_base, blindaje = self.proteccion()
        extra = self.blindaje_traje()
        return en_base, (min(BLINDAJE_MAX, blindaje + extra) if extra else blindaje)

    def factor_oxigeno(self):
        """Multiplica el gasto de oxígeno afuera: 1 / (1 + más duración)."""
        return 1.0 / (1.0 + TRAJE_OXIGENO[self.traje["oxigeno"]])

    # ---- comprar -------------------------------------------------------------------
    def costo_traje(self, linea):
        """Costo del siguiente nivel, o None si ya está al máximo."""
        nivel = self.traje[linea]
        return None if nivel >= TRAJE_NIVEL_MAX else TRAJE_COSTOS[linea][nivel + 1]

    def mejorar_traje(self, linea):
        """Compra el siguiente nivel (en la demo, gratis). Devuelve True si mejoró."""
        costo = self.costo_traje(linea)
        nombre = t("traje_" + linea)
        if costo is None:
            self.mensaje = t("traje_max", nombre=nombre)
            return False
        if not self.es_demo:
            falta = self.inventario.faltante(costo)
            if falta:
                self.mensaje = t("traje_faltan", nombre=nombre, n=ROMANO[self.traje[linea] + 1],
                                 lista=self._lista(falta))
                return False
            self.inventario.pagar(costo)
        self.traje[linea] += 1
        self.mensaje = t("traje_mejorado", nombre=nombre, n=ROMANO[self.traje[linea]],
                         efecto=self.efecto_traje(linea, self.traje[linea]))
        return True

    @staticmethod
    def efecto_traje(linea, nivel):
        """Texto corto del efecto de un nivel ("-35 % de radiación afuera")."""
        if nivel <= 0:
            return t("traje_sin_mejora")
        if linea == "blindaje":
            return t("traje_efecto_blindaje", p=round(TRAJE_BLINDAJE[nivel] * 100))
        return t("traje_efecto_oxigeno", p=round(TRAJE_OXIGENO[nivel] * 100))

    # ---- dibujo --------------------------------------------------------------------
    def insignia_traje(self, pos, linea, chica=True):
        """Insignia con el nivel en números romanos (solo si hay mejora)."""
        nivel = self.traje[linea]
        if nivel <= 0:
            return None
        fuente = self.fuente_mini
        letras = fuente.render(ROMANO[nivel], True, (255, 255, 255))
        caja = pygame.Rect(0, 0, letras.get_width() + 6, 12 if chica else 16)
        caja.topleft = pos
        pygame.draw.rect(self.pantalla, (150, 70, 210) if linea == "blindaje" else estilo.ACENTO, caja, border_radius=3)
        pygame.draw.rect(self.pantalla, estilo.CONTORNO, caja, 1, border_radius=3)
        self.pantalla.blit(letras, letras.get_rect(center=(caja.centerx, caja.centery + 1)))
        return caja

    def dibujar_pagina_traje(self):
        """Pestaña "Traje" del Fabricador: una fila grande por mejora con su ícono,
        el nivel (3 casillas y número romano), el efecto de ahora y del siguiente
        nivel, lo que cuesta y palomita o X. Clic en la fila: comprar el siguiente."""
        p = self.pantalla
        tinta, suave = estilo.TINTA, estilo.TINTA_SUAVE
        raton = pygame.mouse.get_pos()
        for i, linea in enumerate(LINEAS_TRAJE):
            fila = self.rect_fila_traje(i)
            nivel = self.traje[linea]
            costo = self.costo_traje(linea)
            alcanza = costo is not None and (self.es_demo or not self.inventario.faltante(costo))
            if fila.collidepoint(raton) and costo is not None:
                pygame.draw.rect(p, estilo.CASILLA_ACTIVA, fila, border_radius=6)
                pygame.draw.rect(p, estilo.ACENTO, fila, 2, border_radius=6)
            caja = pygame.Rect(fila.x + 4, fila.y + 8, 60, 60)
            estilo.casilla(p, caja)
            icono = self.iconos_traje[linea]
            p.blit(icono, icono.get_rect(center=caja.center))
            x = caja.right + 14
            p.blit(self.fuente.render(t("traje_" + linea), True, tinta), (x, fila.y + 8))
            for k in range(TRAJE_NIVEL_MAX):                 # 3 casillas de nivel (llenas = compradas)
                marca = pygame.Rect(x + k * 18, fila.y + 34, 14, 10)
                pygame.draw.rect(p, estilo.ACENTO if k < nivel else estilo.CASILLA, marca, border_radius=2)
                pygame.draw.rect(p, estilo.CONTORNO, marca, 1, border_radius=2)
            p.blit(self.fuente_chica.render(t("traje_nivel", n=ROMANO[nivel]), True, tinta), (x + 60, fila.y + 31))
            p.blit(self.fuente_chica.render(t("traje_ahora", efecto=self.efecto_traje(linea, nivel)), True, suave),
                   (x, fila.y + 52))
            siguiente = (t("traje_siguiente", efecto=self.efecto_traje(linea, nivel + 1)) if costo is not None
                         else t("traje_max_corto"))
            p.blit(self.fuente_chica.render(siguiente, True, suave), (x, fila.y + 71))
            if linea == "blindaje":                          # en tormentas cuenta la mitad: refúgiate igual
                nota = self.fuente_mini.render(t("traje_nota_tormenta"), True, suave)
                p.blit(nota, (x, fila.y + 89))
            xc = fila.x + 380                                # costo del siguiente nivel
            if costo is not None:
                for recurso, pide in costo.items():
                    ok = self.es_demo or self.inventario[recurso] >= pide
                    p.blit(self.iconos_recurso_chico[recurso], (xc, fila.y + 30))
                    texto = self.fuente_chica.render(t("demo_gratis") if self.es_demo else f"{pide}/{self.inventario[recurso]}",
                                                     True, tinta if ok else estilo.FALTA)
                    p.blit(texto, (xc + 28, fila.y + 36))
                    xc += 28 + texto.get_width() + 14
                    if self.es_demo:
                        break
            cx, cy = fila.right - 18, fila.y + 40            # palomita o X, dibujadas
            if costo is None:
                pygame.draw.circle(p, estilo.ACENTO, (cx, cy), 9)
                pygame.draw.lines(p, (255, 255, 255), False, [(cx - 5, cy), (cx - 1, cy + 4), (cx + 5, cy - 4)], 2)
            elif alcanza:
                pygame.draw.lines(p, estilo.OK, False, [(cx - 6, cy), (cx - 2, cy + 5), (cx + 6, cy - 5)], 3)
            else:
                pygame.draw.line(p, estilo.FALTA, (cx - 5, cy - 5), (cx + 5, cy + 5), 3)
                pygame.draw.line(p, estilo.FALTA, (cx - 5, cy + 5), (cx + 5, cy - 5), 3)
