# Lumati_pulido: qué cambió respecto a ~/Lumati

Copia pulida hecha con IA (Claude Fable 5.2) el 14 nov 2026. La carpeta original
`~/Lumati` no se tocó. Se corre igual: `python main.py`.

Las reglas del juego son las mismas: con la misma partida simulada (6000 pasos),
el original y esta copia dan exactamente los mismos números (oxígeno, dosis,
inventario, producción, reloj). Lo único nuevo en reglas es Marte, que está aparte.

## Qué cambió, por archivo

**estilo.py (nuevo, ~400 líneas).** Todo lo visual de la interfaz en un solo lugar:
- Paleta única (sección "Paleta"): cambiar un color ahí cambia toda la interfaz.
- `panel()`, `casilla()`, `barra()`, `separador()`: paneles tipo madera con marco.
- Íconos dibujados por código (pixel art propio, con letras): 4 barras vitales,
  6 recursos, pico / regadera / taladro básico.
- `Particulas`: cuadritos de polvo y chispas (máximo 160, solo adorno).
- `vineta()`: borde de pantalla teñido.

**main.py.**
- Inventario (tecla E): dos paneles de madera. Arriba las 21 casillas con íconos
  de recurso; abajo el retrato del astronauta, "En la mano" (pico, regadera,
  taladro básico) y los datos de la misión, o el detalle de la casilla bajo el mouse.
- HUD: barras vitales con ícono y relleno que se mueve suave; reloj, avisos,
  mensajes, etiquetas de máquinas y barra de herramientas con el mismo estilo.
- "Crafteo": panel de receta abajo a la izquierda al elegir algo que cuesta
  (herramientas 4 a 8): qué pide, cuánto tienes, palomita o X.
- Barra crítica: antes parpadeaba cada 0.25 s; ahora pulsa despacio (accesibilidad).
- Viñetas en los bordes: morada mientras llega la radiación de una tormenta solar
  (menos si hay blindaje), azul oscuro con oxígeno bajo. Entran y salen despacio.
- Sombras suaves bajo máquinas, bloques y astronauta.
- Partículas: polvo al caminar, soplo al poner o quitar algo, chispas al recoger.
- Cámara con un pequeño retraso (`CAMARA_SUAVE = 12`; ponlo en 0 y queda pegada
  como antes). Respeta el mapa que da la vuelta.
- Pantalla de muerte y comparación final en panel de madera.
- Constantes nuevas arriba, en "Pulido visual". Se quitaron 7 constantes de color
  que ya no se usaban (`COLOR_PANEL`, `COLOR_CASILLA...`, `COLOR_FONDO_BARRA`).
- Métodos nuevos: `actualizar_pulido`, `seguir_con_camara`, `polvo_al_caminar`,
  `_usar_con_efecto`, `rect_receta`, `dibujar_receta`, `dibujar_vinetas`,
  `dibujar_polvo`, `dibujar_aviso_polvo`, `actualizar_polvo`, `colores_polvo`.
  Ningún método que ya existía cambió de nombre.

**clima.py.** `Reloj` acepta temperaturas distintas (la Luna usa las de siempre).
Clase nueva `TormentaPolvo` y constantes de Marte. `Clima` no cambió.

**textos.py.** 24 claves nuevas en español e inglés (inventario, receta, Marte).

**Sin cambios:** maquinas.py, supervivencia.py, energia.py, suelo.py, datos.py,
requirements.txt y todos los PNG de assets/.

## Lo que NO se tocó
- Mecánicas, costos, tiempos y demás valores de balance.
- Controles (1 a 8, E, M, X, T, N, R, L, Esc siguen igual).
- Los sprites de los diseñadores. Están limpios (pocos colores, sin píxeles
  semitransparentes), así que no se retocó ninguno y no hizo falta guardar copias.
- Los dibujos provisionales de máquinas, base y cables: siguen esperando sus PNG.

## Ojo: pico y regadera
El código original no tiene pico ni regadera como herramientas (su comentario
dice "Ya no hay pico") y la barra son las 8 construcciones. Para no cambiar
controles, pico, regadera y taladro básico se muestran en el inventario como
"En la mano", pero **el pico y la regadera no hacen nada todavía**. El taladro
básico sí es la herramienta 2, que ya era gratis.

## Marte
- Empezar en Marte: `python main.py marte`.
- O desde el juego: en la pantalla final ("Tu misión contra la real") pulsa **M**.
  Desde Marte, M regresa a la Luna.
- Qué tiene: suelo color óxido (los mismos cráteres de suelo.py, teñidos),
  temperaturas propias (20 a -90 °C, valores del juego) y tormentas de polvo:
  aviso de 8 s, luego 20 s con los paneles tapados y todas las máquinas sin
  energía. **P** dispara una (modo demo).
- Simplificación (está en el comentario de `TormentaPolvo`): el polvo apaga los
  paneles del todo; en la realidad baja su rendimiento poco a poco.
- No se hizo MOXIE ni nada más único de Marte. Las tormentas solares y todo lo
  demás son iguales a la Luna. La pantalla final sigue comparando con MOXIE.
- Por defecto se juega en la Luna; Marte no afecta a la Luna.

## Qué quedó sin probar
Todo se probó sin ventana (pantalla falsa), con capturas revisadas: inicio,
construcciones, receta, inventario, tormenta solar, noche, inglés, barras
críticas, muerte y rescate, final, vuelta completa al mapa, y Marte.
Falta probar en la Mac con ventana real:
- Teclado y mouse de verdad (pasar el mouse por casillas y barra, clics).
- Cómo se siente la cámara suave y si el polvo al caminar se ve bien a 60 FPS.
- Rendimiento real (sin ventana: unos 1.5 ms por cuadro).

## Para la presentación
Declarar que el pulido visual (estilo.py y los cambios de dibujo) y la versión
mínima de Marte se hicieron con Claude Fable 5.2.

---

## Ronda 2 (14 nov, noche)

Pedido de Oliver: sin barra de herramientas (es supervivencia, no creativo), una
máquina de crafteo, menús en blanco "de médico" y cables que no se vean tiesos.
Respaldo de la versión anterior completa: `Proyectos/Lumati_pulido_v1`.

### Qué cambió para el jugador
- **Ya no hay barra de abajo ni teclas 1 a 8.** Junto a la nave está el
  **Fabricador** (cuadro fijo en `CRAFTEO_POS = (14, 17)`). Clic en él abre su menú:
  una fila por objeto con su costo (ícono + `pide/tienes`, en rojo y con X lo que
  falta). Clic en una fila lo fabrica y va al inventario.
- **En la mano:** en el inventario (E), abajo, están los 8 objetos fabricados con
  cuántos tienes. Clic en uno lo pone en la mano; otro clic lo guarda. Abajo a la
  izquierda un recuadro chico dice qué llevas y cuántos quedan (clic: abre el
  inventario). Clic en el mapa coloca lo de la mano y gasta una unidad.
- **Quitar devuelve el objeto, no los recursos:** X sobre un taladro o una máquina,
  o clic con cable/panel/bloque en la mano sobre uno igual, lo regresa al
  inventario de objetos. (Un taladro mejorado vuelve como taladro básico, igual
  que antes se perdía la mejora.)
- **Con qué empiezas:** 1 taladro básico (en la mano), 1 panel solar y 5 cables:
  justo para el primer circuito. `OBJETOS_INICIALES` en main.py.
- **Costos:** los mismos de `maquinas.COSTO_CONSTRUIR`. Cable, taladro y panel
  solar ya eran gratis y siguen gratis (pero hay que ir al Fabricador); el cable
  sale en tramos de 5 (`FABRICA_CANTIDAD`). Para ponerles costo: `COSTO_FABRICAR`.
- **Menús blancos:** inventario, Fabricador, barras, reloj, avisos, datos, muerte y
  final usan la paleta nueva de `estilo.py`: blanco clínico, grises claros, texto
  gris casi negro y una franja fina cian (`ACENTO`) arriba de cada panel. Las barras
  vitales tienen fondo oscuro para que sus colores resalten.
- **Cables flexibles:** cada cable se dibuja como curva con holgura (una onda lenta
  fija según el cuadro). El centro de cada cable es un resorte amortiguado: se mueve
  cuando el astronauta camina encima o cuando pones/quitas un cable vecino, la onda
  pasa a los vecinos y en unos segundos se asienta. La red de energía NO cambió
  (un cable por cuadro, mismo relleno). `CABLE_FISICA = False` vuelve a los cables
  rectos de antes. Los cables se dibujan todos juntos después del piso.

### Archivos
- `main.py`: objetos y Fabricador (`OBJETOS`, `COSTO_FABRICAR`, `fabricar`,
  `elegir_en_mano`, `dibujar_crafteo`, `dibujar_mano`, `dibujar_fabricador`),
  sección de objetos en el inventario, cables con física (`actualizar_cables`,
  `dibujar_cables`, `_punto_nodo`, `pisar_cable`, `sacudir_vecinos`), docstring de
  controles. Se quitaron la barra, la receta abajo a la izquierda, las teclas 1-8 y
  los íconos decorativos de pico y regadera (no hacían nada).
- `estilo.py`: paleta blanca + `ACENTO`, `MARCO`, `BISEL`, `OK`; los nombres
  viejos (`MADERA`, `MADERA_OSCURA`) quedan como alias.
- `textos.py`: textos nuevos en español e inglés (Fabricador, en la mano, etc.).

### Probado (sin ventana)
- Partida completa por el camino nuevo, en la Luna y en Marte: primer circuito con
  lo inicial, fabricar, elegir en el inventario, colocar, mejorar taladro,
  purificador → electrolizador → tanque lleno → despegue → final.
- Quitar devuelve objetos; rescate conserva los objetos; inglés; cables rectos.
- Los cables se asientan solos (~6 s) y cruzan el borde del mapa sin cortes.
- Dibujo: ~2 ms por cuadro con cables moviéndose.

### Falta probar en la Mac
- Mouse y teclado reales; cómo se siente el balanceo de los cables a 60 FPS.
- `dibujar_cable` (la versión vieja con PNG de piezas) solo se usa si
  `CABLE_FISICA = False`: si las diseñadoras entregan PNG de cable, decidir cuál se queda.

## Ronda 3: acceso rápido (5 casillas)

- `main.py`: 5 casillas abajo al centro (`RAPIDA_*`, `dibujar_rapida`, `usar_rapida`, `asignar_rapida`).
  Teclas 1 a 5 o clic en la casilla: llevar ese objeto a la mano (otra vez: guardarlo).
  Asignar: en el inventario (E), mouse sobre un objeto y tecla 1 a 5; si ya estaba en otra casilla, se intercambian.
  Al empezar: taladro, cable y panel solar. Lo que fabricas por primera vez entra solo a la primera casilla libre.
  Los mensajes ahora salen encima del acceso rápido.
- `textos.py`: textos nuevos `rapida_vacia`, `rapida_asignada` y ayuda del inventario (es/en).

## Ronda 4: cables de colores, antena, base por dentro y guardado

Respaldo del estado anterior: `Proyectos/Lumati_pulido_v2`.

**Cables menos elásticos** (`main.py`, constantes `CABLE_*`, valores viejos anotados al lado):
holgura 5 → 2.5 px, resorte 60 → 150, freno 4 → 16, desplazamiento máximo 10 → 5 px.
Se mueven poco y se asientan en ~0.5 s. `CABLE_FISICA = False` sigue regresando a cables rectos.

**Colores de cable: verde, azul y amarillo** (`main.py`, `energia.py`).
- Cada color es su propio circuito: cables de distinto color NO se conectan entre sí.
  Máquinas, antenas y paneles se conectan a cables de cualquier color (un panel puede
  alimentar varios colores; una máquina que toca dos colores recibe energía si alguno la tiene).
- El color se guarda por cuadro en `colores_cable` (aparte del mapa). `energia.py` solo
  recibió un parámetro opcional `colores`; sin él funciona como antes.
- Elegir color: tecla **C** o **rueda del mouse** (con el cable en la mano). Se ve en
  "En la mano" y en la casilla rápida del cable.
- Con cable en la mano: clic en un cable de **otro** color lo pinta (gratis); del **mismo**
  color, lo quita y vuelve al inventario.
- Accesibilidad: además del color, patrón: verde liso, azul con rayas, amarillo con puntos.
- Sin rojo (luces de apagado) ni azul oscuro (poco oxígeno).
- Con `CABLE_FISICA = False` ya no se usan las piezas PNG de cable (no se pueden teñir).

**Antena de comunicación** (`main.py`, tipo de cuadro `ANTENA`).
- Se fabrica en el Fabricador. Costo provisional `COSTO_ANTENA = {"hierro": 4, "metal": 2}`
  (ajústalo ahí). Se coloca desde la mano como las máquinas y se quita con X.
- Necesita energía por cable. Encendida: cartel "Tierra: en contacto" bajo el reloj y cada
  `ANTENA_CADA` (40 s) un "Mensaje de la Tierra" con un dato real de `datos.py` y su fuente.
- No cambia cómo se gana (despegar). El final agrega "Contacto con la Tierra por antena: sí/no".
- El inventario muestra ahora los objetos en 2 filas de 5 (son 9).

**Base por dentro** (`main.py`, `ESCENA_BASE`, `SALA_RECT`).
- Clic en la base (al alcance) para entrar. La sala se ve desde arriba, en blanco de
  estación, y se camina con WASD. Dentro: oxígeno y radiación como en el piso de la base.
- Muebles (clic estando cerca):
  - **Cama**: dormir solo de 18:00 a 06:00. La pantalla se oscurece suave, el mundo avanza
    hasta las 06:00 en pasos de 0.5 s (taladros, máquinas, tormentas y barras siguen) y aclara.
  - **Almacén**: 12 casillas de 20 (`ALMACEN_CASILLAS`, `ALMACEN_PILA`). Clic en la mochila
    guarda esa casilla; clic en el almacén la saca.
  - **Panel de sistemas** (y el **rack de cables**): por color, cables, máquinas conectadas
    y si tiene energía; paneles, máquinas encendidas/apagadas, producción, dosis, antena.
  - **Terminal**: Guardar / Cargar partida.
  - **Puerta**: caminar hacia ella (o clic) para salir; el astronauta aparece abajo de la base.

**Guardar partida** (`main.py`, `estado_a_dict`, `aplicar_dict`).
- Archivo `partida_lumati.json` junto a `main.py`. **F5** guarda y **F9** carga (también la terminal).
- Guarda mapa, colores, taladros, máquinas, antenas, inventario, almacén, objetos, acceso rápido,
  barras, dosis, reloj, tormenta solar, tormenta de polvo, destino y si estabas dentro de la base.
- Se escribe en un archivo temporal y luego se renombra. Si no hay partida o está dañada, avisa
  y la partida actual no cambia.

**Textos nuevos** en `textos.py` (es/en). "Colocaste: {nombre}" reemplaza "{nombre} construido".

## Ronda 5: regadera

- `main.py`: objeto "regadera" (herramienta de mano, empieza con 1, casilla rápida 4; no se fabrica ni se coloca). El agua entra al invernadero solo con la regadera en la mano; cosechar sigue con cualquier cosa. Ícono propio. `FABRICABLES` = objetos del Fabricador.
- `textos.py`: textos de la regadera (es/en).

## Ronda 6: pico

- `main.py`: tipos PICADO y CAMINO (se caminan). Pico (herramienta de mano, casilla 1): suelo -> picado -> camino -> suelo. El taladro solo va en suelo picado; al quitarlo queda picado. Dibujo propio de ambos terrenos (Luna y Marte).
- `textos.py`: textos del pico (es/en).

## Ronda 7: arte nuevo de Piskel (Descargas, 14 nov)

- `assets/`: panel_solar_mapa.png (3 posiciones), icono_regadera.png, gotas.png, icono_o2.png (fondo quitado; originales en Descargas sin tocar).
- `main.py`: panel solar del mapa con el dibujo nuevo (cambia de posición según la hora), íconos de regadera y electrolizador, gotas al regar, menú de objetos en 2 filas de 6.
- Sin usar (no tocar terreno, piedras, base ni cables): roca-oscura, rocas-suelo-lunar, prueba-franjas. Pendientes de decidir: cubeta, panel-control, personaje-colores.

## Ronda 8: batería, taladros y cubeta (arte de Piskel)

- `assets/`: bateria.png (panel-control, 3 cuadros), taladro_niveles.png (personaje-colores, nivel 1-3), cubeta.png (vacía / con tierra). Fondos quitados.
- `main.py`: objeto Batería (BATERIA=16, costo COSTO_BATERIA): se carga con un panel activo en su red y da energía cuando los paneles no rinden. NUEVO: de noche los paneles no dan energía (`NOCHE_APAGA_PANELES`, False = como antes). Taladros con dibujo por nivel que tiemblan al trabajar. Invernadero en cubeta con la planta saliendo de la tierra. Guardado incluye baterías.
- `textos.py`: textos de la batería y aviso de noche (es/en).

## Ronda 9: invernadero en la base y nopal

- `main.py`: 6 huecos de maceta dentro de la base (fila al centro, sólidos). Con Invernadero en la mano: poner maceta; clic sin regar: cambiar cultivo; regadera: regar; con fruto: cosechar. Siempre con energía (la de la base). Se guardan en la partida. Cubeta como función `_dibujar_cubeta`.
- `maquinas.py`: cultivo nopal.
- `assets/plantas/sprite_12-16.png`: nopal PROVISIONAL hecho por código (el plantas.zip de Descargas no trae nopal).
- `textos.py`: textos del invernadero de la base (es/en).

## Ronda 10: cuarto de cultivos aparte

- `main.py`: la base tiene 2 cuartos (`self.cuarto`): módulo habitable y invernadero. Puerta lateral en la pared izquierda del habitable; en el invernadero, regreso por la pared derecha. Las macetas salieron del habitable: ahora son 12 (2 filas de 6) en el invernadero, piso verde. La salida al exterior sigue abajo en el habitable.
- `textos.py`: rótulos de los cuartos (es/en).

## Ronda 11: conectores y cable negro

- `energia.py`: parámetro opcional `une(a, b)` para decidir si dos cables vecinos se unen.
- `main.py`: con el cable en la mano, C/rueda recorre verde, azul, amarillo, negro y conectores +, T, L; R gira la pieza. Negro (troncal): une cualquier color, solo en su dirección (horizontal o vertical). Conectores: neutros, unen cualquier color por los lados de su forma. `piezas_cable` se guarda en la partida. Cuestan 1 cable.
- `textos.py`: nombres de piezas y giro (es/en).

## Ronda 12: electrolizador en caja y tanque de agua

- `main.py`: electrolizador dibujado como caja con ventana de agua, electrodos, burbujas al trabajar y salidas O2/H2 (ícono igual). Nuevo objeto Tanque de agua (TANQUE_AGUA=17, máx. AGUA_MAX=20, costo COSTO_TANQUE_AGUA): recibe agua de un purificador pegado y llena solo al electrolizador o invernadero pegados (pasivo, sin energía). Clic: guardar o sacar agua. Se guarda en la partida. Inventario de objetos en 2 filas de 7.
- `textos.py`: textos del tanque de agua (es/en).

## Ronda 13: inicio

- `main.py`: se empieza con 1 maceta (Invernadero) y 3 de agua (`AGUA_INICIAL`) para la regadera.

## Ronda 14: materiales de los taladros y piedra

- `assets/recursos_taladro.png` (de hierro.piskel): íconos de cristal, hierro y regolito en inventario, Fabricador y almacén (`ARTE_RECURSO`). `assets/bloque_regolito.png` (de minerales.piskel): el bloque de regolito en el mapa y su ícono. Las pinzas (tit.piskel) ya eran el ícono del cable.

## Ronda 15: relieve y vista del espacio

- `main.py`: 4 colinas de adorno (`COLINAS`, 3 alturas; se camina y construye encima). La cima tiene un montón de piedras con banderita. Parado en la cima, aparece suave el espacio negro con estrellas que brillan y unos cuantos cometas (`COMETAS_MAX`=2). Al bajar, se va.
- `textos.py`: aviso de la cima (es/en).

## Ronda 16: montañas y vista lateral desde la cima

- `main.py`: las colinas ahora son montañas (imagen por colina hecha por código: anillos más claros hacia la cima, sombra, crestas y piedras), con banderita en la cima. En la montaña no se construye. Parado en la cima, la vista cambia a una escena de lado: espacio negro con estrellas, unos cuantos cometas, la Tierra (Luna) o Fobos y Deimos (Marte), cordilleras y el astronauta en la punta. Caminar te baja.
- `textos.py`: textos de la montaña (es/en).

## Ronda 17

- `main.py`: montañas más raras: 2 en vez de 4 (`COLINAS`).

## Ronda 18: minimapa

- `main.py`: minimapa arriba a la derecha (todo el mapa, 3 px por cuadro, centrado en el astronauta, da la vuelta). Muestra base, nave, Fabricador, máquinas, cables de color, montañas y cimas. TAB lo muestra u oculta. Se redibuja cada 0.3 s.
- `textos.py`: rótulo del minimapa (es/en).
- Minimapa movido arriba a la izquierda, bajo la etiqueta del inventario.

## Ronda 19

- `main.py`: montañas hechas con capas semitransparentes (luz hacia la cima, sombra y curvas de nivel) encima de la textura del suelo, para que combinen con él.

## Ronda 20: eventos de Marte

Solo en Marte (la Luna no cambia: se comprobó que dibuja los mismos píxeles que antes).

- `eventos_marte.py` (nuevo, sin pygame): ficha `EventoMarte` (nombre, categoría polvo/radiación/suelo, frecuencia relativa, duración, aviso previo, efectos, dato) y el programador `EventosMarte`. Todos los números están en `ESCALA` y `CONFIG`, cada uno marcado "DATO NASA (fuente)" o "SUPUESTO DEL JUEGO". Las escalas de tiempo son supuestos: 1 año marciano = 180 s de juego; para las partículas solares, 1 sol = 3 s.
- Eventos, de más a menos frecuentes: sismos y remolinos de polvo (constantes; remolinos solo de día y menos con tormenta), tormenta de polvo regional (1 por año, en la temporada de polvo), tormenta global (cada 3 a 4 años, aviso más largo, 60 s, velo más espeso), partículas solares SEP (irregulares; actividad solar "baja" por defecto), impacto de meteorito (muy raro).
- `clima.py`: la tormenta de polvo que ya había es la regional; `TormentaPolvo` ahora tiene tipo (regional/global) y modo no automático. `Clima` acepta ejemplos, modo no automático y duración de partículas (Marte las usa; la Luna no pasa nada y queda igual). `Reloj.amortiguar`: con polvo, días más fríos y noches menos frías.
- `main.py`: efectos conectados. Polvo: paneles tapados (como antes), cultivo más lento (60 % regional, 35 % global; también las macetas de la base), temperatura amortiguada y polvo dibujado sobre los paneles. SEP: la cadena solar de siempre con ejemplos de DONKI que llegan a Marte (CME de 645 km/s del 2017), partículas el doble de largas, mensaje de refugio en la base y caída Forbush (radiación de fondo al 85 % un rato). Sismo: sacudida suave de cámara (`SACUDIDA_ACTIVA` = False la quita) y aviso con magnitud, sin daño. Impacto: cráter de 3x3 en suelo libre y a la vista (nunca encima de construcciones, montañas, base, nave ni Fabricador), sismo M4.0 y un taladro dentro del cráter saca más hielo. Remolino: embudo de polvo que cruza la pantalla, sin daño. Avisos cortos con ícono bajo el reloj. Cada evento muestra su dato real con fuente.
- Teclas del modo demo (solo Marte): P regional, G global, T partículas solares (SEP), V remolino, K sismo, I impacto.
- Partida guardada: tipo de tormenta, relojes de los eventos, cráteres y temperatura. Las partidas viejas cargan (campos nuevos con `d.get`).
- `maquinas.py`: `Taladro.extra` (pesos extra del botín; vacío = igual que antes).
- `datos.py`: 12 datos de Marte del encargo (NASA/JPL, Curiosity, InSight, MRO, DONKI), marcados `verificado=False` y `solo_marte` (la antena no los manda en la Luna).
- `textos.py`: textos nuevos (es/en).

## Ronda 21: taladros grandes, menú de opciones, guía y partidas

- `assets/taladro_niveles.png`: el borde blanco que quedó del recorte del fondo ahora es un contorno fino gris oscuro (donde era de 2 px se quitó la capa de afuera). El diseño de adentro no cambió. El original está en `assets/_originales/taladro_niveles.png`.
- `main.py`: taladros más grandes (`TALADRO_PIXEL` = 1.75: la figura mide ~60x56 en vez de ~34). Se dibujan después del piso de todos los cuadros para que lo que sobresale no lo tape el vecino. Almacén y progreso sobre una base oscura para que se lean; la etiqueta ("Sin energía", "Almacén lleno") sube.
- `main.py`: menú de opciones con Esc (ya no cierra el juego). El juego se pausa de verdad (reloj, barras, máquinas y eventos). Botones: Continuar, Guía del juego, Partidas, Guardar y salir, Salir sin guardar (con confirmación). Con otro menú abierto, Esc solo lo cierra; en la guía o las partidas, Esc vuelve. L cambia el idioma también dentro del menú.
- Guía del juego: 8 temas (Objetivo, Controles, Energía, Recursos, Agua y aire, Comida, Base, Peligros), con textos cortos sacados de lo que hace el código. Clic o flechas para cambiar de tema.
- `partidas.py` (nuevo, sin pygame): partidas en ranuras `partidas/ranura_NNN.json` (el estado de siempre + "meta" con nombre, destino, día, hora y fecha real). La primera vez que se abre el juego copia `partida_lumati.json`, `partida_marte_avanzada.json` y `partida_lumati_respaldo.json` a ranuras, sin borrarlos ni cambiarlos (`partidas/.migrado` evita repetirlo). Ya no se escribe `partida_lumati.json`.
- Lista de partidas: clic para cargar, "Guardar en ranura nueva", "Sobrescribir" con confirmación, páginas de 6 (flechas, rueda o < >). F5 guarda en la ranura actual (o una nueva); F9 carga la más reciente. La terminal de la base guarda igual y "Ver partidas" abre la lista.
- `textos.py`: textos del menú, partidas y guía (es/en). `.gitignore`: `partidas/`.

## Ronda 22: menú de opciones decorado

- `fondo_menu.py` (nuevo, solo dibujo): fondo del menú con espacio (degradado casi negro), estrellas que cambian de brillo despacio (periodos de 4 a 10 s, sin parpadeos), 3 planetas hechos por código (uno con anillo, uno rojizo tipo Marte y la Tierra) que se mecen un poco, 2 astronautas flotando y girando suave (el dibujo de las diseñadoras, `assets/astronauta.png`) y meteoros con cola de vez en cuando (máximo 2 a la vez). Nada pasa por encima de las tarjetas.
- `main.py`: cada opción es una tarjeta flotante aparte (ícono en un círculo a la izquierda, franja del acento, sombra), con un leve flotar escalonado. Al pasar el mouse crece, se corre un poco y su borde se pinta del acento (todo suave). "Salir sin guardar" va en rojo discreto; "Guardar y salir" se ve apagada cuando no se puede guardar. Título "Lumati" grande arriba.
- La guía y las partidas usan el mismo fondo, más oscuro, con sus paneles blancos de siempre.
- El menú tiene su propio reloj: la decoración se mueve, pero el juego sigue en pausa. Todo lo de antes funciona igual (Esc, guía, partidas, confirmaciones, F5/F9).

## Ronda 23: menú principal (inicio) y menú de pausa nuevo

- Al abrir el juego aparece el menú principal, con el fondo decorado de la ronda 22 y las tarjetas flotantes bajo el título "Lumati": Continuar (carga la partida guardada más reciente; apagada si no hay), Nueva partida (tarjetas Luna o Marte, y Volver), Partidas (solo para cargar), Guía del juego y Salir. Debajo del título dice cuál es la última partida. Esc no hace nada en esta pantalla; en sus subpáginas, vuelve.
- `python main.py marte` sigue empezando directo una partida nueva en Marte, sin pasar por el menú principal (lo más simple). `Juego()` sin `inicio=True` también empieza jugando (lo usan las pruebas).
- Menú de pausa nuevo (Esc jugando): un panel compacto blanco sobre el juego oscurecido, sin decoración. Botones: Continuar, Guía del juego, Partidas (guardar y cargar), Guardar, Menú principal y Salir del juego. Estos dos últimos preguntan: Guardar / No guardar / Cancelar (si no se puede guardar, por ejemplo muerto, "Guardar" se ve apagado). La pausa sigue siendo real.
- La guía y la lista de partidas son las mismas en los dos menús: desde el inicio con el fondo decorado (y la lista solo carga); desde la pausa con el juego oscurecido (y se puede guardar en una ranura nueva o sobrescribir).
- Final del juego: además de R (jugar otra vez) y M (siguiente misión), I vuelve al menú principal.
- `fondo_menu.py`: íconos nuevos (nueva partida, Luna, Marte, volver). `textos.py`: textos del inicio y la pausa (es/en).


## Refactor: main.py dividido en archivos

Copia nueva (`Lumati_refactor`); `Lumati_pulido` no se tocó. Sin cambios de lógica, nombres, controles,
textos, balance ni formato de guardado: cada método y función se copió tal cual (se comprobó que los 246
métodos y las 25 funciones/clases tienen exactamente el mismo código). La clase `Juego` ahora hereda de
"mixins" (clases por tema), así que `self.algo` se llama igual que antes. Las dependencias van en una sola
dirección (config -> arte -> mapa -> jugador -> mixins -> juego -> main): no hay importaciones circulares.

Antes: `main.py` tenía 5860 líneas. Ahora:

| Archivo | Líneas | Qué tiene |
|---|---|---|
| `main.py` | 117 | Arranque: docstring con todos los controles, `main()` (menú principal, o Marte directo con `python main.py marte`). Re-exporta los nombres de siempre (`main.TILE`, `main.Juego`...). |
| `config.py` | 507 | Todas las constantes: tamaños, colores, balance, sprites, rectángulos de la interfaz y de los menús. Solo valores. |
| `arte.py` | 311 | Carga del arte (texturas del suelo, astronauta, sprites, plantas) e íconos; cortar texto en líneas. |
| `mapa.py` | 150 | Generar el mapa, estructuras fijas, montañas (alturas y dibujo), cráteres y distancia en un mapa que da la vuelta. |
| `jugador.py` | 107 | El astronauta en el mapa (movimiento, choques, animación) y la cámara. |
| `juego.py` | 288 | La clase `Juego`: hereda de los mixins, `__init__`, `nueva_partida`, rescate y el bucle `run()`. |
| `juego_hud.py` | 547 | HudMixin: mensajes, avisos, barras, reloj, mano, acceso rápido, resaltado, viñetas, datos reales y el final. |
| `juego_herramientas.py` | 482 | HerramientasMixin: mouse, usar herramientas, objetos, acceso rápido, Fabricador, pico, taladros, construir, máquinas, nave. |
| `juego_energia.py` | 432 | EnergiaMixin: cables y piezas, paneles, tanque de agua, baterías, energía y física de los cables. |
| `juego_entrada.py` | 191 | EntradaMixin: clic, rueda, teclado (con teclas demo) y reiniciar. |
| `juego_mundo.py` | 204 | MundoMixin: actualizar cada cuadro y avanzar el mundo (reloj, tormentas, barras, máquinas, antena). |
| `juego_marte.py` | 279 | MarteMixin: eventos de Marte dentro del juego (polvo, SEP, sismos, remolinos, cráteres). |
| `juego_dibujo_mundo.py` | 431 | DibujoMundoMixin: dibujar el mapa, minimapa, montañas y cielo, astronauta, base, nave y cohete. |
| `juego_dibujo_objetos.py` | 480 | DibujoObjetosMixin: dibujo de cada objeto del mapa (cables, máquinas, taladros, paneles, plantas...). |
| `juego_inventario.py` | 308 | InventarioMixin: inventario (E) y menú del Fabricador. |
| `juego_base.py` | 671 | BaseMixin: la base por dentro (cuartos, muebles, macetas, dormir, almacén, menús de la base) y su dibujo. |
| `juego_guardado.py` | 245 | GuardadoMixin: estado a diccionario y de vuelta; guardar y cargar en ranuras. |
| `juego_menus.py` | 520 | MenusMixin: menú principal, pausa, guía, lista de partidas y confirmaciones. |
| **Total** | **6270** | (más líneas que antes por los docstrings y los imports de cada archivo) |

Sin cambios: `clima.py`, `datos.py`, `energia.py`, `estilo.py`, `eventos_marte.py`, `fondo_menu.py`, `maquinas.py`, `partidas.py`, `suelo.py`, `supervivencia.py`, `textos.py`.

Comprobado: mismo estado guardado y mismos píxeles que `Lumati_pulido` en 47 casos (inicio, nueva partida
con construcción, Marte con cada evento, base y cuarto de cultivos, pausa, guía, partidas, partida avanzada
de Marte, cima, final, muerte y rescate) y el mismo rendimiento.

Código que parece no usarse (se dejó, no se borró): en el `main.py` original, los imports `json`, `Reloj`,
`celdas_con_energia` y `BOTIN` (siguen en `main.py`), el método `guardar_y_salir` (sin uso desde la ronda 23)
y las constantes `COLOR_CABLE_BORDE`, `COLOR_CABLE_BRILLO`, `OPCIONES_RECT` y `PARTIDA` (esta última solo la
usan las pruebas). En otros archivos: `estilo.MADERA`, `estilo.MADERA_OSCURA`, `estilo.icono_equipo`,
`eventos_marte.SIN_FIN`, `eventos_marte.fichas` (solo pruebas), `maquinas.NIVEL_REQUERIDO`, `maquinas.A_MANO`,
`maquinas.NECESITA_NIVEL`, `maquinas.generar_recursos` y varias constantes y `generar_variante` de `suelo.py`.

## Slots de partidas (ronda 25)

- La pantalla de Partidas ahora son 3 slots fijos (Slot 1, 2 y 3), cada uno una tarjeta grande lado a lado: desde el menú principal sobre el fondo decorado, desde la pausa sobre el juego oscurecido. Cada tarjeta ocupada muestra nombre, destino con su planeta (Luna gris / Marte rojizo), día y hora del juego, fecha real del guardado y estadísticas sacadas del propio guardado: oxígeno, agua y comida producidos, dosis (mSv), hidrógeno del tanque más lleno (x/6 con barrita), taladros, máquinas, paneles, baterías, macetas sembradas y contacto con la Tierra. Un slot vacío muestra "Slot libre" con un + grande.
- Acciones: Cargar; Guardar aquí (solo desde la pausa; en un slot ocupado pide confirmar); Borrar (con confirmación: el archivo no se elimina, se mueve a `partidas/_borradas/` con la fecha en el nombre).
- El Slot N es el archivo `partidas/ranura_00N.json`: las 3 partidas que ya había quedaron como Slot 1, 2 y 3 sin moverlas. Al abrir el juego, una ranura de más (4, 5...) pasa a un slot libre o, si no hay, a `partidas/_extra/` (no se pierde).
- F5 guarda en el slot actual; si no hay, en el primero libre; si los 3 están llenos, avisa que se elija uno en Partidas (lo mismo con "Guardar" de la pausa, "Guardar y salir", "Volver al menú principal" y la terminal). F9 y "Continuar" cargan el más reciente.
- Archivos: `juego_slots.py` nuevo (206 líneas, SlotsMixin: tarjetas, estadísticas y acciones); `partidas.py` (slots, ordenar, borrar a _borradas, estadísticas); `juego_menus.py` (443 líneas: se quitó la lista vieja con páginas); `juego_guardado.py` (F5 con slots); `juego_entrada.py` (la rueda ya no cambia páginas); `config.py` (medidas de las tarjetas; se quitó `PARTIDAS_POR_PAGINA`); `textos.py` (es/en, y la guía menciona los 3 slots).
- Comprobado con el guion de equivalencia: todo lo demás es idéntico a antes (estado y píxeles); solo cambian la pantalla de Partidas y las páginas Controles y Base de la guía (su texto ahora habla de los slots).

## Mano y cinemática (ronda 26)

- Objeto en la mano: lo que está elegido "en la mano" (barra de acceso rápido) se dibuja chiquito (18 px) en el guante del astronauta, en el mapa y dentro de la base, según hacia dónde mira: a los lados, en la mano de ese lado (volteado al mirar a la izquierda); de frente, en su mano derecha; de espaldas, detrás del cuerpo. Se mueve con la animación al caminar y queda a la altura de las manos (no tapa el visor). El cable muestra además su color y patrón. Con la mano vacía no se dibuja nada. `juego_mano.py` (ManoMixin); las posiciones de los guantes (medidas en el PNG de las diseñadoras) están en `config.py` (`MANO_POS`, `MANO_EMPUJE`, `MANO_LADO`).
- Cinemática final: al despegar desde Marte se reproduce la animación de `assets/cinematica/` (89 PNG de 120x120 copiados de Descargas/cinematica, sin tocar los originales) a 10 cuadros por segundo (unos 9 s), escalada x5 con píxeles parejos, centrada sobre negro, con fundidos suaves al empezar y al terminar; luego, la pantalla final con las estadísticas. Espacio, Enter o un clic la saltan; Esc la pausa. Si faltan los PNG, el final es el de siempre. La Luna no cambia.
- Orden de la cinemática: por prefijo y luego por número: `i` (la nave en Marte y despegando), `s` (subiendo al espacio y viajando entre estrellas), `y` (llegando a la Tierra) y `z` (en la Tierra, entre flores de colores). Hay 14 imágenes distintas: las repetidas hacen que una escena dure más.
- Archivos: `cinematica.py` (cargar, ordenar y reproducir; solo dibujo), `juego_cinematica.py` (CinematicaMixin), `juego_mano.py` (ManoMixin), cambios chicos en `juego.py`, `juego_herramientas.py` (usar_nave, avanzar_final), `juego_mundo.py`, `juego_hud.py`, `juego_dibujo_mundo.py` (dibujar_astronauta), `config.py` y `textos.py` ("Espacio: saltar").
- Comprobado con el guion de equivalencia: el estado del juego es idéntico; sin el dibujo de la mano, también los píxeles.

## Compañero: Laylu (ronda 27)

- Laylu, una compañera robot, se fabrica en el Fabricador (costo provisional, por balancear: 6 hierro, 3 metal y 4 regolito; `COSTO_COMPANERO` en `config.py`). Con Laylu en la mano, clic en suelo libre: se activa ahí y te sigue a corta distancia (unos 56 px) con su animación de caminar en la dirección correcta (4 direcciones x 4 cuadros, a 8 cuadros por segundo). Esquiva obstáculos sencillos (si choca, prueba por el otro eje), respeta el borde del mapa (sigue al otro lado) y, si se atora más de 1.2 s sin acercarse o se queda a más de 6 casillas, aparece junto a ti. Entra contigo a la base y al cuarto de cultivos (sin meterse en los muebles) y sale contigo. Solo puede haber una Laylu a la vez; X sobre Laylu la regresa al inventario, solo si su cofre está vacío.
- Cofre de Laylu: lleva un cofrecito café dibujado en la cabeza. Clic en Laylu estando cerca abre "Cofre de Laylu", un menú de casillas como el almacén de la base: 8 casillas de hasta 20 recursos cada una (el almacén de la base tiene 12 x 20). Se usa igual: clic en la mochila guarda, clic en el cofre saca. Se guarda en la partida (activa o no, posición, dirección y contenido); las partidas y slots viejos, que no lo tienen, cargan igual.
- Antena más cara: ahora cuesta 8 hierro, 5 metal y 2 cristal (antes 4 hierro y 2 metal).
- El Fabricador tiene 12 recetas: la altura de cada fila se ajusta sola para que quepan (44 px en lugar de 48). El inventario tiene ahora 14 objetos, justo lo que cabe en sus 2 filas de 7.
- Dibujos: `assets/companero/laylu_{frente,espaldas,izquierda,derecha}_{1..4}.png`, copiados de Descargas/compañero_png sin tocar los originales; se renombraron así: `wallie_X_N.png` -> `laylu_X_N.png` (mismo X y N; por ejemplo `wallie_frente_1.png` -> `laylu_frente_1.png`, ... `wallie_derecha_4.png` -> `laylu_derecha_4.png`). Si faltan, el juego no carga a Laylu (no truena).
- Archivos: `companero.py` nuevo (lógica: seguir, atorarse, cofre, guardar/cargar), `juego_companero.py` nuevo (CompaneroMixin: poner, guardar, seguir en cada escena, dibujar y el cofre); cambios chicos en `config.py` (costos y constantes `COMPANERO_*`, `COFRE_*`), `juego.py`, `juego_herramientas.py`, `juego_entrada.py` (clic y X sobre Laylu), `juego_mundo.py`, `juego_dibujo_mundo.py`, `juego_base.py` (menú del cofre), `juego_guardado.py`, `juego_inventario.py` (filas del Fabricador) y `textos.py` (es/en, y la guía, página Base).
- Comprobado con el guion de equivalencia (contra la ronda 26, sin contar las claves nuevas del guardado): el estado es idéntico en los 47 casos; solo cambian los píxeles del inventario, el Fabricador y la página Base de la guía.

## Partida de demostración y Laylu más separada (ronda 28)

- Menú principal: nueva tarjeta "Demostración" (entre Nueva partida y Partidas; las 6 tarjetas van un poco más juntas para caber). Abre una página con "Demostración en la Luna" y "Demostración en Marte". Cargan `partidas/demo_luna.json` y `partidas/demo_marte.json`: guardados normales armados con el propio código del juego (`demo.py`: pone cables, paneles, taladros y máquinas como el jugador, planta y riega las macetas, activa a Laylu). Los 3 slots no se tocan y la demo no sale en Partidas. Si un archivo de demo falta, el menú lo vuelve a armar solo; también `python3 demo.py` los rehace.
- Materiales ilimitados: bandera `"demo": true` en el guardado (solo en la demo). Con ella fabricar no gasta recursos, colocar no gasta unidades, mejorar un taladro es gratis, los objetos se ven con el signo de infinito (dibujado por código: la letra no lo trae) y el Fabricador dice "Gratis (demostración)". Mochila, almacén y cofre de Laylu con recursos. El juego normal no cambia (su guardado no lleva la bandera ni los letreros).
- Letreros pintados en el suelo (es/en), con el cartel de cada zona y una nota debajo de cada circuito; la nota lleva un punto verde si debe funcionar y rojo si está roto a propósito. Dónde está cada zona (fila, columna; la base está en 14,14):
  - BÁSICOS, filas 19-24, columnas 2-14 (el astronauta aparece en medio, fila 22, columna 8, con Laylu al lado): panel + cable verde + taladro; panel + cable + purificador con hielo; cable cortado a propósito (sin energía); purificador pegado al panel sin cable (sin energía).
  - MEDIOS, filas 10-16, columnas 20-31 (a la derecha, arriba de la nave): verde y azul juntos sin mezclarse (el azul sin energía); conector + que une verde con azul; batería llena (de noche sigue dando energía); purificador > tanque de agua > electrolizador > tanque de hidrógeno.
  - DIFÍCILES, filas 0-9, columnas 12-24 (arriba de la base): cable negro troncal entre verde y azul (el amarillo que lo toca por abajo no recibe); conector L girado para bajar; dos redes con panel y batería y la antena encendida (contacto con la Tierra); la misma L mal girada (sin energía).
  - Ninguna toca las montañas. Empieza de día (08:00), sin tormenta; macetas del cuarto de cultivos en 7 etapas distintas (sin regar, varias de crecimiento y con fruto).
- Laylu va más separada: se detiene a 2.5 cuadros (`COMPANERO_DISTANCIA`) y no vuelve a caminar hasta que te alejas más de 3 (`COMPANERO_ARRANCA`), así no da pasitos con cada movimiento. Dentro de la base usa el 60 % (`COMPANERO_FACTOR_BASE`: ~1.5 a 1.8 cuadros, cabe en la sala). Al reaparecer junto a ti lo hace a unos 2 cuadros. El teletransporte no cambia (a más de 6 cuadros o atorada 1.2 s).
- Archivos: nuevos `demo.py` (cómo se arma la demo, zonas y lo que debe hacer cada circuito) y `juego_demo.py` (DemoMixin: abrir la demo, infinito, letreros); `partidas/demo_luna.json` y `partidas/demo_marte.json`. Cambios chicos en `juego.py`, `juego_herramientas.py` (gastar_objeto, fabricar y mejorar en la demo), `juego_energia.py`, `juego_base.py`, `juego_companero.py`, `juego_guardado.py` (claves "demo" y "letreros"), `juego_dibujo_mundo.py` (letreros), `juego_hud.py` e `juego_inventario.py` (infinito), `juego_menus.py` y `fondo_menu.py` (tarjeta y página Demostración, ícono de rayo), `companero.py` (distancia con histéresis), `config.py` y `textos.py` (es/en).
- Comprobado con el guion de equivalencia (contra la ronda 27): estado idéntico en los 47 casos; solo cambian los píxeles del menú principal (la tarjeta nueva).

## Pantalla completa (ronda 29)

- El juego sigue dibujando a 960x640; la ventana se crea con `pygame.SCALED` y SDL agranda la imagen a la pantalla manteniendo la proporción (barras negras si sobra), con píxeles nítidos (`SDL_RENDER_SCALE_QUALITY=0`, sin suavizado). SDL entrega el mouse ya convertido a coordenadas del juego, así que clics en tarjetas, mapa, inventario y slots no cambian. En ventana se ve igual que antes.
- Teclas: F11 en cualquier momento; en la Mac también Cmd+F y Ctrl+Cmd+F (en muchos teclados de Mac F11 es fn+F11). Con el menú principal o la pausa abiertos, también F. Botón "Pantalla completa (F11)" arriba a la derecha del menú principal y opción "Pantalla completa: sí/no" en la pausa.
- `python main.py --completa` (o `pantalla_completa`) arranca ya en pantalla completa; se combina con `marte` (`python main.py marte --completa`).
- Si el sistema no deja cambiar: primero se intenta `toggle_fullscreen`, luego volver a crear la ventana con la bandera; si nada funciona, avisa ("No se pudo cambiar a pantalla completa...") y sigue en ventana, sin tronar.
- No se recuerda la preferencia (se eligió no crear un archivo de ajustes: cada vez arranca en ventana, salvo con `--completa`).
- Archivos: `juego_pantalla.py` nuevo (PantallaMixin); cambios chicos en `juego.py` (crear la ventana, argumento completa), `juego_entrada.py` (F11 / Cmd+F), `juego_menus.py` (F, botón y opción de la pausa), `config.py` (`PAUSA_BOTONES`, `PAUSA_RECT` más alto, `BOTON_PANTALLA`), `main.py` (argumento y ayuda) y `textos.py` (es/en; la guía, página Controles, menciona F11).
- Comprobado con el guion de equivalencia (contra la ronda 28, con los mismos slots): estado idéntico en los 47 casos; solo cambian los píxeles del menú principal (botón), la pausa (7 botones), la pregunta sobre la pausa y la página Controles de la guía.

## Mensajes limpios (ronda 30)

- Mensajes (`juego_avisos.py`, nuevo): una línea chica con fondo oscuro semitransparente (texto claro, buen contraste) encima del acceso rápido, en vez del panel blanco grande. Entran y salen con un fundido suave (0.2 s y 0.5 s, sin parpadeos); como mucho 2 a la vez, apilados (el nuevo abajo); si un mensaje se repite no se acumula, se renueva. Un mensaje muy largo usa letra más chica y, si aun así no cabe, se corta con "...". No tapan al astronauta (ni en el mapa ni dentro de la base).
- Datos reales NASA y mensajes de la Tierra: tarjeta compacta abajo a la derecha (320 px): encabezado chico ("Dato real NASA" o "Mensaje de la Tierra"), el texto en 2 líneas y la fuente en letra chica. Con el mouse encima se ve completo; un clic la cierra; se cierra sola a los 8 s. Después hay un descanso de 12 s (`DATO_ENFRIAMIENTO`): los datos que llegan mientras tanto esperan en una fila corta (sin repetirse) y la antena espera para mandar el siguiente mensaje de la Tierra. Por eso, en una partida con antena, los mensajes de la Tierra llegan un poco más espaciados (es lo único que cambia del estado del juego: el contador `msg_tierra`).
- Tormentas y eventos: barras delgadas (28 px) arriba al centro con ícono y cuenta regresiva: tormenta solar, tormenta de polvo, eventos cortos de Marte (sismo, remolino, impacto...) y "Desde la cima". El dato DONKI de cada fase de la tormenta solar sale en la tarjeta de datos; la fecha del ejemplo histórico y el aviso de que no es un pronóstico oficial se ven al pasar el mouse por la barra.
- Máquinas y taladros: en vez de etiquetas de texto, un ícono redondo chico en la esquina de arriba a la derecha de su dibujo, con figura y color: rayo tachado (rojo) = sin energía; gota o el recurso que falta (ámbar) = le falta; palomita (verde) = listo para recoger o tanque lleno; cápsula con "!" (ámbar) = le falta un tanque. El texto completo sale solo con el mouse encima de la máquina, uno a la vez: ya no se enciman las etiquetas de máquinas vecinas.
- Rótulos "Base · clic: entrar", "Fabricador" y "Nave": pastillas chicas que solo se ven cerca (a 3.5 cuadros o menos, con fundido hasta 5) o con el mouse encima.
- Notas de la demo: letra más chica y solo se ven cerca de su circuito (fundido entre 5 y 7 cuadros); el cartel de cada zona, desde más lejos. El punto de "debe funcionar / roto" lleva además una rayita cuando está roto (no solo el color).
- Se quitaron las funciones de dibujo viejas que ya no se usan (`_banner`, `dibujar_banner`, `dibujar_dato`, `dibujar_aviso_polvo`, `rect_chip`, `dibujar_chip`, `_etiqueta`, `dibujar_etiqueta_taladro`, `dibujar_etiqueta_maquina`).
- Archivos: `juego_avisos.py` nuevo (AvisosMixin); cambios en `juego_hud.py`, `juego_dibujo_mundo.py`, `juego_dibujo_objetos.py`, `juego_marte.py`, `juego_mundo.py`, `juego_herramientas.py` (mostrar_dato usa la fila), `juego_entrada.py` (clic en la tarjeta), `juego_menus.py`, `juego_demo.py`, `juego.py` y `config.py` (`DATO_SEGUNDOS` 9 -> 8).
- Comprobado con el guion de equivalencia (contra la ronda 29): mismos mensajes en los 47 casos; el estado solo cambia en `msg_tierra` en los casos con antena (por el descanso entre datos). Rendimiento igual.

## Cinemática Luna-Marte (ronda 31)

- Cuadros: `assets/cinematica_luna_marte/lm01.png` ... `lm70.png`, copiados de Descargas/luna-marte sin tocar los originales. Orden por el número del nombre: `00.png` -> lm01 (la nave en la Luna), `01.png` -> lm02 (despega: la Luna queda abajo), `03.png` -> lm03 (en el espacio), `04 s4 copia.png` ... `68 s4 copia.png` -> lm04 ... lm68 (el viaje: dos cuadros de la nave de lado que se alternan), `s5.png` -> lm69 (llega a Marte: el suelo naranja aparece abajo) y `s6.png` -> lm70 (la nave en Marte). `s4.png` no se usó: es idéntico a los cuadros "s4" del viaje. El zip `luna-marte.zip` trae los mismos 7 cuadros distintos (sprite_0..6, la exportación de Piskel): no falta ninguno.
- Duración: el viaje va a 10 cuadros por segundo; la Luna (1.2 s), el despegue y el espacio (0.7 s cada uno), la llegada (0.9 s) y la nave en Marte (2 s) duran más (`CINE_LM_SOSTENER` en `config.py`): unos 12 s en total. Mismo escalado nítido (x4, centrado sobre negro) y mismos fundidos que la final de Marte.
- Cuándo sale: en la pantalla de resultados de la Luna, al elegir la siguiente misión (tecla M). Al terminar (o al saltarla con Espacio, Enter o clic) empieza la partida en Marte como antes; Esc la pausa. Va ahí y no al despegar de la Luna porque termina con la nave en Marte: antes de ver los resultados de la Luna no tendría sentido. El despegue de la Luna sigue con sus imágenes de siempre. Si faltan los PNG, M va directo a Marte.
- Para enseñarlas al jurado: F7 (o "Ver cinemáticas (F7)" en la pausa) reproduce Luna -> Marte y luego la final de Marte, sin jugar; Espacio salta a la siguiente; al terminar se vuelve al juego tal como estaba (la partida no cambia: mismo guardado antes y después). Si faltan todas, avisa.
- `cinematica.py` acepta duraciones por cuadro (la final de Marte sigue igual, a 10 por segundo); `juego_cinematica.py` decide qué pasa al terminar cada una. La cinemática se dibuja aparte del mapa (con la pausa encima si se abre).
- Archivos: `cinematica.py`, `juego_cinematica.py`, `juego.py`, `juego_entrada.py` (M, F7, saltar), `juego_menus.py` (botón de la pausa), `juego_dibujo_mundo.py`, `config.py` (`CINE_LM_*`, pausa con 8 botones), `textos.py` (es/en, guía: Controles), `main.py` (ayuda) y `assets/cinematica_luna_marte/` (70 PNG).
- Comprobado con el guion de equivalencia (contra la ronda 30): estado y mensajes idénticos en los 47 casos; solo cambian los píxeles de la pausa (un botón más) y de la página Controles de la guía.

## Batería de Laylu (ronda 32)

- Laylu tiene batería propia (0 a 100 %). Se gasta más caminando que quieta: llena dura unos 4.5 minutos de juego siguiéndote y unos 30 minutos quieta (`COMPANERO_GASTO_CAMINANDO`, `COMPANERO_GASTO_QUIETA` en `config.py`, BALANCE provisional).
- Recarga sola, despacio: dentro de la base (se llena en ~1.5 min, `COMPANERO_RECARGA_BASE`) o a 1 cuadro (también en diagonal) de una batería del circuito que tenga carga (~2 min, `COMPANERO_RECARGA_BATERIA`). Esa batería le da la energía: pierde 0.5 s de su carga por cada segundo de recarga (`COMPANERO_BATERIA_COSTO`), así una recarga completa de Laylu cuesta 60 s de una batería de 90. Se eligió así por simple y coherente: es lo mismo que gasta una máquina conectada.
- Pila para Laylu: objeto nuevo del Fabricador (2 hierro + 3 regolito, BALANCE provisional). Con la pila en la mano, clic en Laylu (de cerca): batería al 100 % y se gasta la pila. La usada no vuelve (lo más simple: no hay "pila vacía"). En la demo es gratis, como todo.
- Sin carga: se queda quieta donde está, con su pila marcada con una X; no te sigue, no aparece junto a ti y no entra contigo a la base (se queda en su lugar hasta que le pongas una pila o, si se quedó dentro de la base, hasta que se recargue). Su cofre se puede abrir si estás cerca. Avisos cortos (mensajes limpios) al 20 % y al 0 %.
- Indicador: una pila chica sobre Laylu (encima de su cofre) con el relleno de la carga y, además del color, una forma: "!" con poca carga, X sin carga y un rayito mientras se recarga. En el HUD, discreto encima de "En la mano": "Laylu", la pila y el %; solo con Laylu activa.
- Se guarda en la partida: la batería y dónde está Laylu (`"bateria"` y `"lugar"` dentro de `"companero"`). Partidas viejas: 100 % y con el astronauta.
- Inventario: 15 objetos, ahora en 2 filas de 8 casillas un poco más chicas (mismo ancho que antes, así el panel de la derecha no cambia); una línea del detalle que no cabe se parte en dos (antes "Clic: a la mano · 1-5: atajo" se salía del panel). El Fabricador tiene 13 recetas (filas de 41 px).
- Arreglo: con la pila en la mano, un clic en la montaña decía "En la montaña no se puede construir"; ahora dice que la pila es para Laylu.
- Guía (página Base) y textos es/en.
- Archivos: `companero.py` (batería, guardar/cargar), `juego_companero.py` (gasto, recarga, pila, lugar, dibujo de la pila e indicador del HUD, ícono de la pila), `juego_entrada.py`, `juego_herramientas.py`, `juego_guardado.py`, `juego_hud.py`, `juego_inventario.py`, `juego.py`, `demo.py`, `config.py` y `textos.py`.
- Comprobado con el guion de equivalencia (contra la ronda 31, sin contar las claves nuevas): estado y mensajes idénticos en los 47 casos; solo cambian los píxeles del inventario, el Fabricador y la página Base de la guía.

## Mejoras del traje (ronda 33)

- Dos mejoras del traje con 3 niveles cada una, en el Fabricador (pestañas "Objetos | Traje" junto al título). Se aplican al instante: no se colocan en el mapa ni ocupan el inventario. Clic en la fila: compra el siguiente nivel (gasta recursos; no pasa del III).
  - Blindaje del traje (radiación): frena -20 % / -35 % / -50 % de la dosis afuera. Se suma al blindaje del lugar (base 80 %, bloques de regolito) sin pasar de `BLINDAJE_MAX` (95 %). En una tormenta solar cuenta la mitad (`TRAJE_EN_TORMENTA`): el nivel III frena 25 %, así que refugiarse en la base (80 %) sigue siendo necesario.
  - Tanque de oxígeno: afuera el oxígeno dura +25 % / +50 % / +100 % (de ~11 a ~14, ~17 y ~22 minutos). Se eligió bajar el gasto por segundo en vez de agrandar la barra: la barra sigue de 0 a 100 % y se lee igual (es como un tanque más grande). Dentro de la base el gasto no cambia.
  - Costos (BALANCE provisional, `TRAJE_COSTOS` en `config.py`): blindaje I 6 regolito + 3 hierro, II 6 hierro + 2 metal, III 4 metal + 2 cristal; tanque I 4 hierro + 2 hielo, II 6 hierro + 2 metal, III 3 metal + 2 cristal.
- Indicadores: el nivel en números romanos (I, II, III) sobre los íconos de oxígeno y radiación del panel de barras, y un escudo y un tanque con su nivel en el retrato del inventario. El blindaje que muestra el reloj ("Afuera · blindaje 35 %") ya incluye el del traje. Mensaje limpio al mejorar ("Traje mejorado: Tanque de oxígeno II (el oxígeno dura +50 % afuera)").
- Guardado: clave `"traje"` solo si hay alguna mejora; las partidas viejas (y las nuevas sin mejoras) quedan en nivel 0, que se comporta exactamente como antes. En la demo las mejoras son gratis.
- Guía (página Peligros), con una frase marcada como simplificación: en la realidad se usan materiales densos o agua como escudo y tanques de mayor capacidad (no se inventaron datos de la NASA).
- Archivos: `juego_traje.py` nuevo (TrajeMixin: efecto, compra, página del Fabricador, insignias e íconos dibujados); cambios en `supervivencia.py` (`factor_oxigeno` en `actualizar`, 1.0 = como antes), `juego_mundo.py`, `juego_hud.py`, `juego_inventario.py` (pestañas y retrato), `juego_guardado.py`, `juego.py`, `config.py` (`TRAJE_*`) y `textos.py` (es/en).
- Comprobado con el guion de equivalencia (contra la ronda 32): estado y mensajes idénticos en los 47 casos; solo cambian los píxeles del Fabricador (las pestañas) y de la página Peligros de la guía.

## Ronda 34

- Se quitó la tecla F7. Las cinemáticas se ven desde la pausa: "Ver cinemáticas".

## Ronda 35: Luna → Marte directo

- Corrección de Oliver: al despegar desde la Luna con un tanque de hidrógeno lleno se reproduce de inmediato la cinemática Luna → Marte y, al terminar (o al saltarla con Espacio, Enter o clic), empieza directo la partida en Marte. Ya no pasa por las imágenes fijas del final de la Luna ni por su pantalla de resultados, y no hace falta pulsar M. Esc la pausa (sin dejar guardar a medio viaje).
- Al llegar a Marte, un mensaje corto con lo logrado en la Luna: "En la Luna produjiste X de oxígeno, Y de agua y Z de comida" (y "hiciste contacto con la Tierra" si la antena llegó a funcionar). Junto con el aviso de bienvenida de Marte, en mensajes limpios.
- Sin los PNG de la cinemática: directo a Marte con el mensaje "Rumbo a Marte" y el resumen.
- La final de Marte queda igual: su cinemática, las estadísticas y M para volver a la Luna. "Ver cinemáticas" de la pausa sigue igual (las dos seguidas y vuelve al juego sin cambiar la partida).
- Guía (Objetivo), docstrings de `main.py` y `juego_cinematica.py` actualizados al flujo nuevo.
- Archivos: `juego_herramientas.py` (usar_nave), `juego_cinematica.py` (`ir_a_marte`), `main.py`, `textos.py` (es/en).
- Comprobado: guion de equivalencia (contra la ronda 34) con el mismo estado y mensajes en los 47 casos; solo cambian los píxeles de la página Objetivo de la guía. Las pruebas viejas que esperaban los resultados de la Luna al despegar (rondas 26 y 31) fallan justo en eso, que es lo que se cambió.
