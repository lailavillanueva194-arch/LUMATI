"""Dibujo del mundo: el mapa cuadro por cuadro, cráteres, minimapa,
montañas y vista desde la cima, el astronauta, la base, la nave y el cohete.
"""

import math
import random

import pygame

import estilo
from eventos_marte import CONFIG as CONFIG_MARTE
from textos import t
from config import (ALTO, ALTURA_MAX, ANCHO, ANTENA, ASTRONAUTA_FPS, BASE, BASE_POS, BATERIA,
                    BLOQUE, CABLE, CABLE_FISICA, CAMINO, CIELO_VELOCIDAD, COLINAS,
                    COLOR_BASE_BORDE, COLOR_BASE_PISO, COLOR_CABLE_DE, COLOR_CRATER_FONDO,
                    COLOR_FONDO, COLOR_FUEGO, COLOR_HIELO_CRATER, COLOR_JUGADOR, COLOR_NAVE,
                    COLOR_NAVE_DETALLE, COLOR_ROCA, COLOR_ROCA_BORDE, COLOR_SALIDA, COLOR_SUELO_A,
                    COLOR_SUELO_B, COLOR_TEXTO, COLUMNAS, COMETAS_MAX, COMETA_CADA, CON_SOMBRA,
                    CRAFTEO, CRAFTEO_POS, ELECTROLIZADOR, ESCENA_BASE, ESCENA_MAPA,
                    ESTRUCTURA_LADO, FILAS, GENERADOR, INVERNADERO, JUGADOR_TAM, MAPA_ALTO,
                    MAPA_ANCHO, MAQUINAS, MARTE, MINIMAPA_CADA, MINIMAPA_ESCALA, MINIMAPA_RECT,
                    NAVE, NAVE_LADO, NAVE_POS, PICADO, PURIFICADOR, ROCA, SPRITES, SUELO, TALADRO,
                    TANQUE, TANQUE_AGUA, TEXTURA_CUADROS, TILE)
from mapa import dibujar_crater, dibujar_montana
from jugador import pos_pantalla


class DibujoMundoMixin:
    """Dibujo del mundo: el mapa cuadro por cuadro, cráteres, minimapa,
    montañas y vista desde la cima, el astronauta, la base, la nave y el cohete."""

    # -- dibujo ------------------------------------------------------------
    def dibujar(self):
        if self.en_inicio and self.opciones is not None:   # menú principal: no se ve el juego
            self.dibujar_opciones()
            pygame.display.flip()
            return
        if self.escena == ESCENA_BASE:
            self.dibujar_interior()
            self.dibujar_interfaz()
            return
        pantalla = self.pantalla
        pantalla.fill(COLOR_FONDO)
        camara_real = self.camara
        dx, dy = self.desplazamiento_sacudida()          # Marte: el sismo mueve la vista un poco
        self.camara = ((camara_real[0] + dx) % MAPA_ANCHO, (camara_real[1] + dy) % MAPA_ALTO)
        cam_x, cam_y = self.camara

        # Posición en pantalla de cada columna y fila (distancia corta).
        xs = [pos_pantalla(c * TILE, cam_x, MAPA_ANCHO, ANCHO / 2)
              for c in range(COLUMNAS)]
        ys = [pos_pantalla(f * TILE, cam_y, MAPA_ALTO, ALTO / 2)
              for f in range(FILAS)]
        cables = []                          # cables visibles (con física se dibujan después del piso)
        taladros_vis = []                    # taladros visibles: van encima del piso de sus vecinos
        for f in range(FILAS):
            if not -TILE < ys[f] < ALTO:      # fuera de la pantalla: saltar
                continue
            for c in range(COLUMNAS):
                if not -TILE < xs[c] < ANCHO:
                    continue
                tipo = self.mapa[f][c]
                if tipo == ROCA and "roca" not in self.sprites:
                    rect = (xs[c], ys[f], TILE, TILE)           # respaldo: cuadro plano
                    pygame.draw.rect(pantalla, COLOR_ROCA, rect)
                    pygame.draw.rect(pantalla, COLOR_ROCA_BORDE, rect, 2)
                else:
                    # El piso va siempre debajo: el sprite de la roca es transparente.
                    if self.trozos_suelo:
                        n = TEXTURA_CUADROS
                        v = self.variantes_suelo[f // n][c // n]
                        pantalla.blit(self.trozos_suelo[v][f % n][c % n], (xs[c], ys[f]))
                    else:
                        color = COLOR_SUELO_A if (f + c) % 2 == 0 else COLOR_SUELO_B
                        pygame.draw.rect(pantalla, color, (xs[c], ys[f], TILE, TILE))
                    if self.alturas[f][c]:
                        self.dibujar_relieve(f, c, xs[c], ys[f])
                    if (f, c) in self._crater_de:
                        self.dibujar_crater_cuadro(f, c, xs[c], ys[f])
                    if tipo in (PICADO, CAMINO, TALADRO):
                        self.dibujar_terreno(PICADO if tipo == TALADRO else tipo, xs[c], ys[f], f, c)
                    if tipo in CON_SOMBRA:      # sombra suave: despega la máquina del piso
                        estilo.sombra(pantalla, pygame.Rect(xs[c] + 5, ys[f] + 6, TILE - 10, TILE - 10))
                    if tipo == ROCA:
                        pantalla.blit(self.sprites["roca"][0], (xs[c], ys[f]))
                    if tipo == CABLE:
                        if CABLE_FISICA:
                            cables.append((f, c, xs[c], ys[f]))     # se dibujan todos juntos al final
                        else:
                            self.dibujar_cable(f, c, xs[c], ys[f])
                    elif tipo == TALADRO:
                        taladros_vis.append((f, c, xs[c], ys[f]))     # se dibujan al final (son grandes)
                    elif tipo == GENERADOR:
                        self.dibujar_generador(f, c, xs[c], ys[f])
                    elif tipo == BLOQUE:
                        self.dibujar_bloque(xs[c], ys[f])
                    elif tipo in MAQUINAS:
                        self.dibujar_maquina(f, c, xs[c], ys[f])
                        if (f, c) in self._riegos:
                            self.dibujar_gotas(self._riegos[(f, c)], xs[c], ys[f])
                    elif tipo == CRAFTEO:
                        self.dibujar_fabricador(xs[c], ys[f])
                    elif tipo == ANTENA:
                        self.dibujar_antena(f, c, xs[c], ys[f])
                    elif tipo == BATERIA:
                        self.dibujar_bateria(f, c, xs[c], ys[f])
                    elif tipo == TANQUE_AGUA:
                        self.dibujar_tanque_agua(f, c, xs[c], ys[f])
        if cables:
            self.dibujar_cables(cables)
        for f, c, x, y in sorted(taladros_vis, key=lambda v: v[3]):
            self.dibujar_taladro(f, c, x, y)
        self.dibujar_estructuras()          # base y nave (2x2), encima del piso

        # La noche oscurece el mundo, pero no las etiquetas de los taladros, el
        # astronauta ni la interfaz, que se dibujan después.
        self.dibujar_noche()

        # Las etiquetas van después del bucle: son más anchas que un cuadro y
        # los cuadros siguientes las taparían.
        for (f, c) in self.taladros:
            self.dibujar_etiqueta_taladro(f, c, xs[c], ys[f])
        for (f, c) in self.maquinas:
            self.dibujar_etiqueta_maquina(f, c, xs[c], ys[f])
        f, c = CRAFTEO_POS                   # nombre del Fabricador, debajo de él
        if -TILE < xs[c] < ANCHO and -TILE < ys[f] < ALTO:
            texto = self.fuente_mini.render(t("crafteo"), True, COLOR_TEXTO)
            self.pantalla.blit(texto, texto.get_rect(midtop=(xs[c] + TILE // 2, ys[f] + TILE + 1)))

        self.particulas.dibujar(pantalla, lambda x, y: (pos_pantalla(x, cam_x, MAPA_ANCHO, ANCHO / 2),
                                                        pos_pantalla(y, cam_y, MAPA_ALTO, ALTO / 2)))
        self.dibujar_astronauta()
        if self.remolinos:
            self.dibujar_remolinos(cam_x, cam_y)
        if self._cielo > 0.01:               # desde la cima: vista de lado con el espacio
            self.dibujar_cielo()
        self.dibujar_polvo()                 # Marte: velo y rachas de la tormenta de polvo
        self.camara = camara_real            # sin sacudida para el mouse y la interfaz
        if not self.menu_visible and self.opciones is None:   # con un menú abierto no se marca ningún cuadro
            self.dibujar_resaltado()
        self.dibujar_interfaz()

    def dibujar_crater_cuadro(self, f, c, x, y):
        """El pedazo del cráter de impacto que cae en este cuadro."""
        k, fi, ci = self._crater_de[(f, c)]
        if k not in self._img_crater:
            self._img_crater[k] = dibujar_crater(CONFIG_MARTE["impacto"]["radio_crater"], 70 + k)
        self.pantalla.blit(self._img_crater[k], (x, y), (ci * TILE, fi * TILE, TILE, TILE))

    def color_minimapa(self, f, c):
        """Color de un cuadro en el minimapa."""
        tipo = self.mapa[f][c]
        marte = self.destino == MARTE
        if tipo == CABLE:
            return COLOR_CABLE_DE[self.color_de(f, c)]
        if (f, c) in self._crater_de and tipo in (SUELO, PICADO, CAMINO):
            return COLOR_HIELO_CRATER if self._crater_de[(f, c)][1:] == (1, 1) else COLOR_CRATER_FONDO
        colores = {GENERADOR: (240, 210, 80), BATERIA: (240, 210, 80), TALADRO: (210, 214, 222),
                   BASE: (236, 240, 246), NAVE: (255, 255, 255), CRAFTEO: estilo.ACENTO,
                   ANTENA: (255, 255, 255), TANQUE_AGUA: COLOR_SALIDA["agua"], BLOQUE: (150, 150, 156),
                   PURIFICADOR: COLOR_SALIDA["agua"], ELECTROLIZADOR: (190, 200, 214),
                   TANQUE: (230, 230, 240), INVERNADERO: (90, 190, 90), ROCA: (60, 60, 66)}
        if tipo in colores:
            return colores[tipo]
        h = self.alturas[f][c]
        if h == ALTURA_MAX:
            return estilo.ACENTO                                       # cima
        if h:
            return (196, 130, 96) if marte else (150, 150, 158)        # montaña
        if tipo == CAMINO:
            return (110, 70, 52) if marte else (74, 74, 80)
        return (136, 72, 52) if marte else (100, 100, 106)

    def dibujar_minimapa(self):
        """Minimapa arriba a la derecha: el mapa completo centrado en el astronauta
        (punto blanco). Se redibuja cada MINIMAPA_CADA segundos, no en cada cuadro."""
        p = self.pantalla
        e = MINIMAPA_ESCALA
        if self._mini is None or self._tiempo - self._mini_t >= MINIMAPA_CADA:
            self._mini_t = self._tiempo
            self._mini = pygame.Surface((COLUMNAS * e, FILAS * e))
            for f in range(FILAS):
                for c in range(COLUMNAS):
                    self._mini.fill(self.color_minimapa(f, c), (c * e, f * e, e, e))
        marco = pygame.Rect(MINIMAPA_RECT)
        estilo.panel(p, marco)
        p.blit(self.fuente_mini.render(t("minimapa"), True, estilo.TINTA_SUAVE), (marco.x + 8, marco.y + 6))
        area = pygame.Rect(marco.x + 6, marco.y + 20, COLUMNAS * e, FILAS * e)
        # Centrar en el astronauta: se pega el mapa 4 veces con desplazamiento (da la vuelta).
        pf = self.jugador.centro[1] / TILE
        pc = self.jugador.centro[0] / TILE
        ox = int((COLUMNAS / 2 - pc) * e) % area.w
        oy = int((FILAS / 2 - pf) * e) % area.h
        anterior = p.get_clip()
        p.set_clip(area)
        for dx in (ox - area.w, ox):
            for dy in (oy - area.h, oy):
                p.blit(self._mini, (area.x + dx, area.y + dy))
        p.set_clip(anterior)
        pygame.draw.rect(p, estilo.CONTORNO, area, 1)
        centro = area.center
        pygame.draw.circle(p, (20, 24, 30), centro, 4)              # el astronauta
        pygame.draw.circle(p, (255, 255, 255), centro, 3)

    def dibujar_relieve(self, f, c, x, y):
        """El pedazo de montaña que cae en este cuadro (la montaña completa se dibuja
        una vez y aquí se recorta). En la cima, piedras con banderita."""
        datos = self._colina_de.get((f, c))
        if datos is None:
            return
        k, fi, ci = datos
        marte = self.destino == MARTE
        if (k, marte) not in self._montanas:
            self._montanas[(k, marte)] = dibujar_montana(COLINAS[k][2], 50 + k, marte)
        self.pantalla.blit(self._montanas[(k, marte)], (x, y), (ci * TILE, fi * TILE, TILE, TILE))
        if self.alturas[f][c] == ALTURA_MAX and self.mapa[f][c] in (SUELO, PICADO, CAMINO):
            p = self.pantalla
            cx, cy = x + TILE // 2 - 4, y + TILE // 2 + 2
            pygame.draw.line(p, (50, 50, 58), (cx, cy), (cx, cy - 20), 2)              # banderita en la cima
            pygame.draw.polygon(p, estilo.ACENTO, [(cx, cy - 20), (cx + 11, cy - 16), (cx, cy - 12)])

    def actualizar_cielo(self, dt):
        """Sube la vista del cielo al pararse en una cima; mueve estrellas y cometas."""
        f = int(self.jugador.centro[1] // TILE) % FILAS
        c = int(self.jugador.centro[0] // TILE) % COLUMNAS
        en_cima = (self.escena == ESCENA_MAPA and self.astronauta.vivo and self.escena_final is None
                   and self.alturas[f][c] == ALTURA_MAX)
        if en_cima and not self._en_cima:
            self.mensaje = t("cima")
        self._en_cima = en_cima
        meta = 1.0 if en_cima else 0.0
        paso = CIELO_VELOCIDAD * dt
        self._cielo = min(meta, self._cielo + paso) if self._cielo < meta else max(meta, self._cielo - paso)
        for cometa in self._cometas:
            cometa[0] += cometa[2] * dt
            cometa[1] += cometa[3] * dt
            cometa[4] -= dt
        self._cometas = [k for k in self._cometas if k[4] > 0]
        if self._cielo > 0.5:
            self._cometa_t -= dt
            if self._cometa_t <= 0 and len(self._cometas) < COMETAS_MAX:
                self._cometa_t = random.uniform(*COMETA_CADA)
                x, y = random.uniform(-80, ANCHO * 0.6), random.uniform(-40, ALTO * 0.35)
                v = random.uniform(260, 380)
                ang = random.uniform(0.35, 0.65)
                vida = random.uniform(1.6, 2.4)
                self._cometas.append([x, y, v * math.cos(ang), v * math.sin(ang), vida, vida])

    def _panorama_montanas(self):
        """Siluetas de la vista lateral (se calculan una vez por destino): tres
        cordilleras, de la más lejana (oscura) a la cercana, y la cima al centro."""
        clave = self.destino
        if getattr(self, "_panorama", (None,))[0] == clave:
            return self._panorama[1]
        azar = random.Random(7)
        capas = []
        for nivel, (base, alto, picos) in enumerate(((ALTO * 0.62, 90, 9), (ALTO * 0.72, 70, 7), (ALTO * 0.84, 50, 6))):
            puntos = [(0, ALTO)]
            for k in range(picos + 1):
                x = k * ANCHO / picos
                puntos.append((x, base - azar.uniform(0.3, 1.0) * alto))
                if k < picos:
                    puntos.append((x + ANCHO / picos / 2, base - azar.uniform(0.0, 0.3) * alto))
            puntos.append((ANCHO, ALTO))
            capas.append(puntos)
        # la montaña donde está parado el astronauta, al frente y al centro
        cima = (ANCHO / 2, ALTO * 0.56)
        frente = [(ANCHO * 0.12, ALTO), (ANCHO * 0.30, ALTO * 0.80), (ANCHO * 0.40, ALTO * 0.66),
                  (ANCHO * 0.46, ALTO * 0.60), cima, (ANCHO * 0.55, ALTO * 0.61), (ANCHO * 0.62, ALTO * 0.70),
                  (ANCHO * 0.74, ALTO * 0.82), (ANCHO * 0.90, ALTO)]
        self._panorama = (clave, (capas, frente, cima))
        return self._panorama[1]

    def dibujar_cielo(self):
        """Vista desde la cima (de lado): espacio negro con estrellas que brillan
        suave (sin parpadeos rápidos), unos cuantos cometas, la Tierra en el cielo
        (o las lunas de Marte), cordilleras al fondo y el astronauta en la punta."""
        if not hasattr(self, "_velo_cielo"):
            self._velo_cielo = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
        v = self._velo_cielo
        a = self._cielo
        alfa = int(255 * a)
        v.fill((3, 4, 12, alfa))
        for i, (x, y, r) in enumerate(self._estrellas):
            if y > ALTO * 0.75:
                continue
            brillo = 0.6 + 0.4 * math.sin(self._tiempo * (0.8 + (i % 5) * 0.25) + i)
            c = int(255 * brillo)
            pygame.draw.circle(v, (c, c, min(255, c + 20), alfa), (x, y), r)
            if r > 1 and brillo > 0.85:                     # destello en cruz en las más brillantes
                pygame.draw.line(v, (c, c, c, int(160 * a)), (x - 4, y), (x + 4, y))
                pygame.draw.line(v, (c, c, c, int(160 * a)), (x, y - 4), (x, y + 4))
        if self.destino == MARTE:                            # Fobos y Deimos, chiquitos
            pygame.draw.circle(v, (150, 130, 120, alfa), (int(ANCHO * 0.26), int(ALTO * 0.22)), 7)
            pygame.draw.circle(v, (170, 150, 140, alfa), (int(ANCHO * 0.40), int(ALTO * 0.14)), 4)
        else:                                                # la Tierra vista desde la Luna
            tierra = (int(ANCHO * 0.24), int(ALTO * 0.24))
            pygame.draw.circle(v, (40, 90, 170, alfa), tierra, 26)
            pygame.draw.circle(v, (70, 150, 90, alfa), (tierra[0] - 8, tierra[1] - 4), 9)
            pygame.draw.circle(v, (60, 140, 80, alfa), (tierra[0] + 9, tierra[1] + 8), 6)
            pygame.draw.arc(v, (230, 240, 255, alfa), (tierra[0] - 26, tierra[1] - 26, 52, 52), 1.0, 2.6, 3)
        for x, y, vx, vy, vida, total in self._cometas:
            fuerza = min(1.0, vida / total * 2) * a
            for k in range(14):                                     # cola que se desvanece
                q = k / 14
                px, py = x - vx * 0.2 * q, y - vy * 0.2 * q
                pygame.draw.circle(v, (200, 230, 255, int(220 * fuerza * (1 - q))), (int(px), int(py)),
                                   max(1, int(3 * (1 - q))))
            pygame.draw.circle(v, (255, 255, 255, int(255 * fuerza)), (int(x), int(y)), 3)
        capas, frente, cima = self._panorama_montanas()
        if self.destino == MARTE:
            colores = [(60, 30, 22), (90, 46, 32), (120, 62, 42)]
            frente_color, luz = (150, 80, 54), (190, 112, 80)
        else:
            colores = [(34, 34, 40), (54, 54, 62), (76, 76, 84)]
            frente_color, luz = (104, 104, 112), (150, 150, 158)
        for puntos, color in zip(capas, colores):
            pygame.draw.polygon(v, (*color, alfa), puntos)
        pygame.draw.polygon(v, (*frente_color, alfa), frente)
        pygame.draw.lines(v, (*luz, alfa), False, frente[1:6], 3)     # borde iluminado del lado izquierdo
        self.pantalla.blit(v, (0, 0))
        if a > 0.6 and self.sprites_astronauta:              # el astronauta parado en la punta
            imagen = self.sprites_astronauta[0]["abajo"][0]
            figura = imagen.get_bounding_rect()
            self.pantalla.blit(imagen, (cima[0] - figura.centerx, cima[1] - figura.bottom + 4))
        texto = self.fuente_chica.render(t("cima_vista"), True, (220, 226, 240))
        texto.set_alpha(alfa)
        self.pantalla.blit(texto, texto.get_rect(midbottom=(ANCHO // 2, ALTO - 96)))

    def dibujar_astronauta(self):
        """Dibuja al astronauta con el cuadro que toca (quieto o caminando). Los
        pies van en el borde de abajo de la caja de colisión y el dibujo queda
        centrado en ella. Sin PNG, un cuadrito amarillo del tamaño de la caja."""
        j = self.jugador
        if self.escena == ESCENA_BASE:          # dentro de la base: coordenadas de la sala
            x, y = int(self.pos_base[0]), int(self.pos_base[1])
        else:
            cam_x, cam_y = self.camara
            x = pos_pantalla(j.x, cam_x, MAPA_ANCHO, ANCHO / 2)
            y = pos_pantalla(j.y, cam_y, MAPA_ALTO, ALTO / 2)
        sombra = self._sombra_astronauta       # sombra ovalada en los pies
        self.pantalla.blit(sombra, sombra.get_rect(center=(x + JUGADOR_TAM // 2, y + JUGADOR_TAM - 1)))
        if not self.sprites_astronauta:
            pygame.draw.rect(self.pantalla, COLOR_JUGADOR, (x, y, JUGADOR_TAM, JUGADOR_TAM))
            return
        cuadros, pie = self.sprites_astronauta
        lista = cuadros[j.direccion]
        imagen = lista[int(j.t_anim * ASTRONAUTA_FPS) % len(lista)] if j.camina else lista[0]
        self.pantalla.blit(imagen, (x + JUGADOR_TAM // 2 - imagen.get_width() // 2,
                                    y + JUGADOR_TAM - pie))

    def rect_nave(self):
        """Rectángulo en pantalla de la nave tal como se dibuja. Es más grande que
        sus cuadros: va centrada y apoyada en el borde de abajo, así que sobresale
        por arriba y por los lados. Sin PNG es solo su zona de NAVE_LADO x NAVE_LADO."""
        f0, c0 = NAVE_POS
        cam_x, cam_y = self.camara
        lado = NAVE_LADO * TILE
        x = pos_pantalla(c0 * TILE, cam_x, MAPA_ANCHO, ANCHO / 2)
        y = pos_pantalla(f0 * TILE, cam_y, MAPA_ALTO, ALTO / 2)
        ancho, alto = self.nave_grande.get_size() if self.nave_grande else (lado, lado)
        return pygame.Rect(round(x + (lado - ancho) / 2), round(y + lado - alto), ancho, alto)

    def dibujar_estructuras(self):
        """Base (2x2 cuadros) y nave (NAVE_LADO x NAVE_LADO). Se dibujan desde su
        esquina, que puede estar un poco fuera de la pantalla."""
        cam_x, cam_y = self.camara
        for (f0, c0), nombre, cuadros in ((BASE_POS, "base", ESTRUCTURA_LADO), (NAVE_POS, "nave", NAVE_LADO)):
            lado = cuadros * TILE
            x = pos_pantalla(c0 * TILE, cam_x, MAPA_ANCHO, ANCHO / 2)
            y = pos_pantalla(f0 * TILE, cam_y, MAPA_ALTO, ALTO / 2)
            # La nave sobresale: se descarta con su rectángulo dibujado, no con sus cuadros.
            caja = self.rect_nave() if nombre == "nave" else pygame.Rect(x, y, lado, lado)
            if not (-caja.width < caja.x < ANCHO and -caja.height < caja.y < ALTO):
                continue
            if nombre == "nave" and self.nave_grande:
                self.pantalla.blit(self.nave_grande, caja)
            elif nombre in self.sprites:
                imagen = self.sprites[nombre][0]
                # Centrada y apoyada en el borde de abajo de su zona (la base mide justo 2x2).
                self.pantalla.blit(imagen, (x + (lado - imagen.get_width()) // 2,
                                            y + lado - imagen.get_height()))
            elif nombre == "base":
                piso = pygame.Rect(x + 3, y + 3, lado - 6, lado - 6)
                pygame.draw.rect(self.pantalla, COLOR_BASE_PISO, piso, border_radius=10)
                pygame.draw.rect(self.pantalla, COLOR_BASE_BORDE, piso, 3, border_radius=10)
                pygame.draw.rect(self.pantalla, COLOR_BASE_BORDE, piso.inflate(-24, -24), 1, border_radius=6)
            else:
                self._dibujar_cohete(x + lado // 2, y + 6, lado / (2 * TILE))
            texto = self.fuente_chica.render(t(nombre), True, COLOR_TEXTO)
            if nombre == "nave" and self.nave_grande:
                # el nombre va debajo: encima del dibujo de la nave no se leería
                self.pantalla.blit(texto, texto.get_rect(midtop=(x + lado // 2, y + lado + 2)))
            else:
                self.pantalla.blit(texto, texto.get_rect(midbottom=(x + lado // 2, y + lado - 4)))
                if nombre == "base":
                    pista = self.fuente_mini.render(t("base_entrar"), True, COLOR_TEXTO)
                    self.pantalla.blit(pista, pista.get_rect(midtop=(x + lado // 2, y + lado + 1)))

    def _dibujar_cohete(self, cx, arriba, escala, fuego=False):
        """Cohete de las escenas del final. Con assets/nave.png dibuja ese sprite
        (agrandado a un múltiplo entero de píxeles, sin deformarlo); si falta,
        una silueta genérica sin logos. cx = centro, arriba = punta."""
        e = escala
        if "nave" in self.sprites:
            (ancho, alto), _ = SPRITES["nave"]
            k = max(1, round(3 * e))                 # píxeles de pantalla por píxel del dibujo
            imagen = pygame.transform.scale(self.sprites["nave"][0], (ancho * k, alto * k))
            caja = imagen.get_rect(midtop=(cx, arriba))
            if fuego:
                llama = [(caja.centerx - 5 * k, caja.bottom - k), (caja.centerx + 5 * k, caja.bottom - k),
                         (caja.centerx, caja.bottom + 12 * k)]
                pygame.draw.polygon(self.pantalla, COLOR_FUEGO, llama)
            self.pantalla.blit(imagen, caja)
            return
        cuerpo = pygame.Rect(0, 0, int(26 * e), int(54 * e))
        cuerpo.midtop = (cx, arriba + int(18 * e))
        punta = [(cuerpo.left, cuerpo.top), (cuerpo.right, cuerpo.top), (cx, arriba)]
        aleta_i = [(cuerpo.left, cuerpo.bottom - int(18 * e)), (cuerpo.left, cuerpo.bottom),
                   (cuerpo.left - int(12 * e), cuerpo.bottom + int(6 * e))]
        aleta_d = [(cuerpo.right, cuerpo.bottom - int(18 * e)), (cuerpo.right, cuerpo.bottom),
                   (cuerpo.right + int(12 * e), cuerpo.bottom + int(6 * e))]
        if fuego:
            llama = [(cuerpo.left + 4, cuerpo.bottom), (cuerpo.right - 4, cuerpo.bottom),
                     (cx, cuerpo.bottom + int(34 * e))]
            pygame.draw.polygon(self.pantalla, COLOR_FUEGO, llama)
        for forma in (punta, aleta_i, aleta_d):
            pygame.draw.polygon(self.pantalla, COLOR_NAVE_DETALLE, forma)
        pygame.draw.rect(self.pantalla, COLOR_NAVE, cuerpo)
        pygame.draw.rect(self.pantalla, COLOR_NAVE_DETALLE, cuerpo, 2)
        pygame.draw.circle(self.pantalla, COLOR_NAVE_DETALLE, (cx, cuerpo.top + int(14 * e)), max(3, int(6 * e)), 2)
