"""El astronauta en el mapa (movimiento, choques, animación) y la cámara que lo sigue.
"""

from config import COLUMNAS, EPS, FILAS, JUGADOR_TAM, MAPA_ALTO, MAPA_ANCHO, SOLIDOS, TILE
from mapa import distancia_corta


# --------------------------------------------------------------------------
# Jugador
# --------------------------------------------------------------------------
class Jugador:
    def __init__(self, x, y):
        # (x, y) es la esquina superior izquierda de la caja de colisión.
        self.x = float(x)
        self.y = float(y)
        self.direccion = "abajo"        # hacia dónde mira: izquierda, derecha, arriba o abajo
        self.camina = False
        self.t_anim = 0.0               # segundos caminando seguidos (mueve la animación)

    def animar(self, dir_x, dir_y, dt):
        """Pone la dirección y avanza la animación según lo que el jugador PIDE
        (las teclas), no según cuánto se movió: contra una pared sigue mirando
        hacia ella. En diagonal gana la dirección horizontal. Al soltar las
        teclas conserva la dirección y vuelve al cuadro de quieto."""
        if dir_x or dir_y:
            if abs(dir_x) >= abs(dir_y):
                self.direccion = "derecha" if dir_x > 0 else "izquierda"
            else:
                self.direccion = "abajo" if dir_y > 0 else "arriba"
            self.camina = True
            self.t_anim += dt
        else:
            self.camina = False
            self.t_anim = 0.0

    @property
    def centro(self):
        return (self.x + JUGADOR_TAM / 2, self.y + JUGADOR_TAM / 2)

    def choca(self, mapa, x, y):
        """True si la caja del jugador colocada en (x, y) toca un cuadro sólido.

        Revisamos solo los cuadros que la caja cubre: desde el que contiene su
        esquina superior izquierda hasta el que contiene la inferior derecha.
        Los índices se envuelven con módulo: una caja que cruza el borde
        revisa también los cuadros del lado opuesto.
        """
        col_ini = int(x // TILE)
        col_fin = int((x + JUGADOR_TAM - EPS) // TILE)
        fila_ini = int(y // TILE)
        fila_fin = int((y + JUGADOR_TAM - EPS) // TILE)
        for f in range(fila_ini, fila_fin + 1):
            for c in range(col_ini, col_fin + 1):
                if mapa[f % FILAS][c % COLUMNAS] in SOLIDOS:
                    return True
        return False

    def mover(self, dx, dy, mapa):
        """Mueve primero en X y luego en Y, cada eje por separado.

        Si se moviera en diagonal de golpe y chocara, el jugador se quedaría
        pegado a la pared. Al separar los ejes, si la pared bloquea X todavía
        puede deslizarse en Y (y al revés).
        Al chocar, se pega al borde del cuadro sólido en vez de quedarse a
        medio píxel.
        """
        nx = self.x + dx
        if self.choca(mapa, nx, self.y):
            if dx > 0:   # chocó con algo a la derecha: pegar a su borde izquierdo
                nx = int((nx + JUGADOR_TAM) // TILE) * TILE - JUGADOR_TAM
            else:        # chocó a la izquierda: pegar al borde derecho del cuadro
                nx = (int(nx // TILE) + 1) * TILE
        self.x = nx

        ny = self.y + dy
        if self.choca(mapa, self.x, ny):
            if dy > 0:
                ny = int((ny + JUGADOR_TAM) // TILE) * TILE - JUGADOR_TAM
            else:
                ny = (int(ny // TILE) + 1) * TILE
        self.y = ny

        # Dar la vuelta al mapa: si se pasó del borde, reaparece del otro lado.
        self.x %= MAPA_ANCHO
        self.y %= MAPA_ALTO


# --------------------------------------------------------------------------
# Cámara
# --------------------------------------------------------------------------
def calcular_camara(jugador):
    """Punto del mundo que está en el centro de la pantalla: el jugador.

    Como el mapa da la vuelta, ya no hay que frenar la cámara en los bordes.
    """
    cx, cy = jugador.centro
    return int(cx), int(cy)


def pos_pantalla(mundo, centro, tam_mapa, mitad_ventana):
    """Posición en pantalla de una coordenada del mundo (eje x o y).

    Se mide la distancia corta al centro de la vista y se suma la mitad de la
    ventana. Así cada cosa cae del lado correcto aunque cruce el borde del
    mapa. Funciona porque la ventana es menor que el mapa.
    """
    return int(mitad_ventana + distancia_corta(mundo, centro, tam_mapa))
