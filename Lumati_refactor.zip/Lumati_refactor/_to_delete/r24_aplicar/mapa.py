"""El mapa y el terreno: generar el mapa, estructuras fijas (base, nave, Fabricador),
alturas de las montañas y su dibujo, cráteres de impacto y la distancia en un mapa que da
la vuelta.
"""

import math
import random

import pygame

from config import (ALTURA_MAX, BASE, BASE_POS, COLINAS, COLOR_CRATER_BORDE, COLOR_CRATER_FONDO,
                    COLOR_HIELO_CRATER, COLUMNAS, CRAFTEO, CRAFTEO_POS, DENSIDAD_ROCAS,
                    ESTRUCTURA_LADO, FILAS, NAVE, NAVE_LADO, NAVE_POS, ROCA, SEMILLA, SUELO, TILE)


# --------------------------------------------------------------------------
# Mapa (toroidal: al salir por un lado se entra por el opuesto)
# --------------------------------------------------------------------------
def distancia_corta(a, b, tam):
    """Diferencia a - b por el camino más corto en un mundo que da la vuelta.

    Ejemplo con tam=32: a=1, b=31 da 2 (cruzando el borde), no -30.
    """
    return (a - b + tam / 2) % tam - tam / 2


def celdas_estructura(pos, lado=ESTRUCTURA_LADO):
    """Los cuadros (fila, col) que ocupa una estructura cuadrada de lado x lado
    (la base: 2x2; la nave: NAVE_LADO) con su esquina de arriba a la izquierda en pos."""
    f0, c0 = pos
    return [((f0 + df) % FILAS, (c0 + dc) % COLUMNAS)
            for df in range(lado) for dc in range(lado)]


def colocar_estructuras(mapa):
    """Pone la base, la nave y el Fabricador (fijos) en la zona de inicio."""
    for pos, tipo, lado in ((BASE_POS, BASE, ESTRUCTURA_LADO), (NAVE_POS, NAVE, NAVE_LADO),
                            (CRAFTEO_POS, CRAFTEO, 1)):
        for f, c in celdas_estructura(pos, lado):
            mapa[f][c] = tipo


def generar_alturas():
    """Dónde hay montaña: {0 = llano, 1 = ladera, ALTURA_MAX = cima (el centro)}."""
    alturas = [[0] * COLUMNAS for _ in range(FILAS)]
    for f0, c0, radio in COLINAS:
        for f in range(FILAS):
            for c in range(COLUMNAS):
                d = math.hypot(distancia_corta(f, f0, FILAS), distancia_corta(c, c0, COLUMNAS))
                if d <= radio + 0.6:
                    alturas[f][c] = max(alturas[f][c], ALTURA_MAX if d < 0.5 else 1)
    return alturas


def dibujar_montana(radio_cuadros, semilla, marte):
    """Montaña vista desde arriba (con luz desde arriba a la izquierda): anillos
    irregulares cada vez más claros hacia la cima, sombra abajo a la derecha y
    crestas de roca. Se dibuja una sola vez por colina."""
    azar = random.Random(semilla)
    lado = (2 * radio_cuadros + 1) * TILE
    s = pygame.Surface((lado, lado), pygame.SRCALPHA)
    cx = cy = lado / 2
    R = radio_cuadros * TILE * 0.92
    fases = [azar.uniform(0, 6.3) for _ in range(3)]

    def anillo(r, dx=0.0, dy=0.0):
        puntos = []
        for k in range(48):
            a = k / 48 * 2 * math.pi
            ruido = (0.10 * math.sin(3 * a + fases[0]) + 0.06 * math.sin(5 * a + fases[1])
                     + 0.04 * math.sin(9 * a + fases[2]))
            puntos.append((cx + dx + math.cos(a) * r * (1 + ruido), cy + dy + math.sin(a) * r * (1 + ruido)))
        return puntos

    # Capas semitransparentes encima del suelo: la textura del piso se sigue viendo y
    # la montaña combina con él (luz blanca hacia la cima, sombra negra abajo).
    sombra = (60, 20, 10, 70) if marte else (0, 0, 8, 70)
    contorno = (40, 14, 6, 70) if marte else (0, 0, 10, 60)
    capas = [(0, 0, 0, 30), (255, 255, 255, 8), (255, 255, 255, 18), (255, 255, 255, 30),
             (255, 255, 255, 42), (255, 255, 255, 56)]
    pygame.draw.polygon(s, sombra, anillo(R * 0.98, TILE * 0.22, TILE * 0.30))          # sombra
    n = len(capas)
    for k, capa in enumerate(capas):                                                 # base -> cima
        r = R * (1 - k / (n + 0.6))
        desplazo = -k * 2.2                                                          # la cima hacia la luz
        puntos = anillo(r, desplazo, desplazo)
        pygame.draw.polygon(s, capa, puntos)
        pygame.draw.polygon(s, contorno if k == 0 else (0, 0, 0, 22), puntos, 2 if k == 0 else 1)
    for _ in range(4):                                                               # crestas de roca
        a = azar.uniform(0, 2 * math.pi)
        r1, r2 = 0.25 * R, azar.uniform(0.5, 0.7) * R
        x1, y1 = cx - 8 + math.cos(a) * r1, cy - 8 + math.sin(a) * r1
        x2, y2 = cx + math.cos(a + 0.25) * r2, cy + math.sin(a + 0.25) * r2
        pygame.draw.line(s, (0, 0, 0, 45), (x1, y1), (x2, y2), 2)
        pygame.draw.line(s, (255, 255, 255, 40), (x1 - 1, y1 - 1), (x2 - 1, y2 - 1), 1)
    for _ in range(14):                                                              # piedras sueltas
        a, d = azar.uniform(0, 2 * math.pi), azar.uniform(0.2, 0.85) * R
        px, py = cx + math.cos(a) * d, cy + math.sin(a) * d
        r = azar.randint(2, 4)
        pygame.draw.circle(s, (0, 0, 0, 70), (int(px + 1), int(py + 1)), r)
        pygame.draw.circle(s, (255, 255, 255, 50), (int(px), int(py)), r - 1)
    return s


def dibujar_crater(radio_cuadros, semilla):
    """Imagen de un cráter de impacto de (2r+1) x (2r+1) cuadros: borde claro
    levantado, fondo oscuro con sombra, rayos de escombros y hielo expuesto
    (manchas blancas). Se dibuja una vez y el mapa la recorta por cuadro."""
    lado = (2 * radio_cuadros + 1) * TILE
    img = pygame.Surface((lado, lado), pygame.SRCALPHA)
    azar = random.Random(semilla)
    c = lado / 2
    for i in range(14):                                     # rayos de escombros
        ang = i / 14 * 2 * math.pi + azar.uniform(-0.15, 0.15)
        largo = azar.uniform(0.32, 0.49) * lado
        x2, y2 = c + math.cos(ang) * largo, c + math.sin(ang) * largo
        pygame.draw.line(img, (*COLOR_CRATER_BORDE, 70), (c, c), (x2, y2), 3)
    r = lado * 0.36
    pygame.draw.ellipse(img, (*COLOR_CRATER_BORDE, 200), (c - r, c - r * 0.9, 2 * r, 1.8 * r))
    r2 = r * 0.8
    pygame.draw.ellipse(img, (*COLOR_CRATER_FONDO, 230), (c - r2, c - r2 * 0.88, 2 * r2, 1.76 * r2))
    sombra = pygame.Surface((lado, lado), pygame.SRCALPHA)  # sombra dentro, del lado de arriba
    pygame.draw.ellipse(sombra, (40, 18, 12, 120), (c - r2, c - r2 * 0.88, 2 * r2, 1.2 * r2))
    img.blit(sombra, (0, 0))
    for _ in range(9):                                      # hielo expuesto
        hx = c + azar.uniform(-0.55, 0.55) * r2
        hy = c + azar.uniform(-0.25, 0.6) * r2
        tam = azar.randint(3, 7)
        pygame.draw.ellipse(img, (*COLOR_HIELO_CRATER, 235), (hx - tam, hy - tam * 0.6, 2 * tam, 1.2 * tam))
    pygame.draw.ellipse(img, (90, 46, 32, 160), (c - r, c - r * 0.9, 2 * r, 1.8 * r), 2)
    return img


def generar_mapa(semilla=SEMILLA):
    """Devuelve una lista de filas; mapa[fila][columna] es el tipo de cuadro.

    Ya no hay pared en el borde: el mapa da la vuelta.
    """
    azar = random.Random(semilla)
    mapa = [[SUELO] * COLUMNAS for _ in range(FILAS)]
    for f in range(FILAS):
        for c in range(COLUMNAS):
            if azar.random() < DENSIDAD_ROCAS:
                mapa[f][c] = ROCA
    # Zona de inicio despejada: 5x5 cuadros en el centro del mapa.
    cf, cc = FILAS // 2, COLUMNAS // 2
    for f in range(cf - 2, cf + 3):
        for c in range(cc - 2, cc + 3):
            mapa[f][c] = SUELO
    return mapa
