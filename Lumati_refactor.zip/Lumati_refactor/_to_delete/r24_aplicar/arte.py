"""Carga del arte y ayudas de dibujo: texturas del suelo, astronauta, sprites, plantas,
íconos, piezas de cable y cortar texto en líneas.
"""

import os
import random

import pygame

import suelo
from config import (ARTE_CULTIVOS, ASTRONAUTA_BANDA_CASCO, ASTRONAUTA_CUADROS, ASTRONAUTA_ESCALA,
                    ASTRONAUTA_LADO, ASTRONAUTA_PNG, CARPETA, CARPETA_PLANTAS, COLOR_CRATER_BORDE,
                    COLOR_CRATER_FONDO, COLOR_REMOLINO, COLUMNAS, ESCALA_ARTE, ESCALA_PLANTAS,
                    FILAS, GIRO_IZQUIERDA, ICONO_BARRA, LIENZO_PLANTAS, PIEZAS_CABLE, PLANTA_MAX,
                    SEMILLA_SUELO, SPRITES, SUELO_PROCEDURAL, SUELO_VARIANTES, TEXTURA_CUADROS,
                    TEXTURA_SUELO, TEXTURA_VARIANTES, TILE)


def color_marte(color):
    """El mismo gris del piso lunar, pasado a tono óxido para Marte: más rojo,
    menos verde y mucho menos azul. Así Marte reutiliza los cráteres de suelo.py."""
    r, g, b = color[:3]
    return (min(255, int(r * 1.5) + 12), int(g * 0.82), int(b * 0.58))


def _variantes_generadas(tinte=None):
    """Variantes del piso hechas por suelo.py, como imágenes de LADO x LADO px.
    `tinte` es una función que cambia cada color (para Marte); None lo deja igual."""
    pixeles, _ = suelo.generar_variantes(SEMILLA_SUELO, SUELO_VARIANTES)
    imagenes = []
    for matriz in pixeles:
        imagen = pygame.Surface((suelo.LADO, suelo.LADO)).convert()
        for y, fila in enumerate(matriz):
            for x, color in enumerate(fila):
                imagen.set_at((x, y), tinte(color) if tinte else color)
        imagenes.append(imagen)
    return imagenes


def _variantes_del_png():
    """Variantes del piso de la tira PNG de los diseñadores (TEXTURA_VARIANTES
    imágenes cuadradas una al lado de otra), o None si falta o no sirve."""
    try:
        tira = pygame.image.load(TEXTURA_SUELO).convert_alpha()
    except (pygame.error, FileNotFoundError):
        print(f"Aviso: no se pudo cargar {TEXTURA_SUELO}; uso colores planos.")
        return None
    v = TEXTURA_VARIANTES
    if tira.get_width() % v:
        print(f"Aviso: {TEXTURA_SUELO} no mide un múltiplo de {v} de ancho; uso colores planos.")
        return None
    lado = tira.get_width() // v          # lado de cada variante en píxeles del PNG
    return [tira.subsurface((i * lado, 0, lado, tira.get_height())) for i in range(v)]


def cargar_trozos_suelo(tinte=None):
    """Trozos de suelo [variante][fila][columna], ya escalados a TILE x TILE.
    Con `tinte` (ver color_marte) el piso generado sale de otro color.

    Orden de respaldo: piso generado (suelo.py), luego el PNG de los
    diseñadores, luego None: el juego sigue con colores planos en vez de tronar."""
    imagenes = None
    if SUELO_PROCEDURAL:
        try:
            imagenes = _variantes_generadas(tinte)
        except Exception as error:                 # el generador no debería fallar; por si acaso
            print(f"Aviso: no se pudo generar el piso ({error}); pruebo con el PNG.")
    if imagenes is None:
        imagenes = _variantes_del_png()
        if imagenes and tinte:                         # el PNG también se tiñe, píxel por píxel
            tenidas = []
            for imagen in imagenes:
                copia = imagen.copy()
                for y in range(copia.get_height()):
                    for x in range(copia.get_width()):
                        copia.set_at((x, y), tinte(copia.get_at((x, y))))
                tenidas.append(copia)
            imagenes = tenidas
    if imagenes is None:
        return None
    n = TEXTURA_CUADROS
    variantes = []
    for imagen in imagenes:
        # scale (sin suavizado) mantiene los píxeles nítidos al agrandar.
        imagen = pygame.transform.scale(imagen, (n * TILE, n * TILE))
        variantes.append([[imagen.subsurface((c * TILE, f * TILE, TILE, TILE))
                           for c in range(n)] for f in range(n)])
    return variantes


def centrar_casco(cuadro):
    """Devuelve una copia del cuadro con el casco centrado en el lienzo.

    En el PNG de la diseñadora los cuadros no están alineados entre sí (unos
    quedan 4 px a la derecha y otros 4 a la izquierda): sin corregirlo, el
    astronauta vibra al caminar. Se centra por las primeras filas de la figura
    (el casco), no por toda la figura, porque brazos y piernas cambian de un
    cuadro a otro. El desplazamiento nunca saca píxeles del lienzo."""
    lado = cuadro.get_width()
    caja = cuadro.get_bounding_rect()
    if caja.width == 0:                 # cuadro vacío
        return cuadro.copy()
    banda = range(caja.top, caja.top + ASTRONAUTA_BANDA_CASCO)
    xs = [x for y in banda for x in range(lado) if cuadro.get_at((x, y))[3] > 0]
    desplazamiento = round(lado / 2 - (min(xs) + max(xs) + 1) / 2)
    desplazamiento = max(-caja.left, min(lado - caja.right, desplazamiento))   # sin recortar
    centrado = pygame.Surface(cuadro.get_size(), pygame.SRCALPHA)
    centrado.blit(cuadro, (desplazamiento, 0))
    return centrado


def cargar_astronauta():
    """(cuadros, pie) del astronauta, o None si el PNG falta o no sirve.

    cuadros[dirección] es la lista de imágenes ya centradas y escaladas (sin
    suavizado, para que los píxeles queden nítidos). pie es la distancia en
    pantalla desde la parte de arriba del dibujo hasta los pies."""
    try:
        tira = pygame.image.load(ASTRONAUTA_PNG).convert_alpha()
    except (pygame.error, FileNotFoundError):
        print(f"Aviso: no se pudo cargar {ASTRONAUTA_PNG}; el astronauta será un cuadro amarillo.")
        return None
    lado = ASTRONAUTA_LADO
    n = tira.get_width() // lado
    usados = [i for lista in ASTRONAUTA_CUADROS.values() for i in lista]
    if tira.get_height() != lado or tira.get_width() % lado or max(usados) >= n:
        print(f"Aviso: {ASTRONAUTA_PNG} no tiene el formato esperado (cuadros de "
              f"{lado}x{lado}); el astronauta será un cuadro amarillo.")
        return None
    centrados = {}
    for i in sorted(set(usados)):
        cuadro = pygame.Surface((lado, lado), pygame.SRCALPHA)
        cuadro.blit(tira, (0, 0), (i * lado, 0, lado, lado))
        centrados[i] = centrar_casco(cuadro)
    pie = max(c.get_bounding_rect().bottom for c in centrados.values())    # fila más baja usada
    tam = (lado * ASTRONAUTA_ESCALA, lado * ASTRONAUTA_ESCALA)
    cuadros = {d: [pygame.transform.scale(centrados[i], tam) for i in lista]
               for d, lista in ASTRONAUTA_CUADROS.items()}
    return cuadros, pie * ASTRONAUTA_ESCALA


def cargar_sprites():
    """{nombre: [cuadros ya agrandados]} con los PNG de SPRITES que existen en
    assets/. Si uno falta o no mide lo esperado, no está en el diccionario y el
    juego lo dibuja con color plano (avisa en la terminal solo si mide mal)."""
    sprites = {}
    for nombre, ((ancho, alto), n) in SPRITES.items():
        ruta = os.path.join(CARPETA, "assets", nombre + ".png")
        if not os.path.exists(ruta):
            continue
        try:
            tira = pygame.image.load(ruta).convert_alpha()
        except pygame.error as error:
            print(f"Aviso: no se pudo cargar {ruta} ({error}); uso color plano.")
            continue
        if tira.get_size() != (ancho * n, alto):
            print(f"Aviso: {ruta} mide {tira.get_size()} y se esperaba {(ancho * n, alto)}; "
                  "uso color plano.")
            continue
        tam = (ancho * ESCALA_ARTE, alto * ESCALA_ARTE)
        sprites[nombre] = [pygame.transform.scale(tira.subsurface((i * ancho, 0, ancho, alto)), tam)
                           for i in range(n)]
    return sprites


def cargar_plantas():
    """{número: imagen} con los sprite_NN.png de assets/plantas, ya recortados a
    la planta y agrandados. Los que falten no están (el invernadero se dibuja con
    sus hojas de color)."""
    plantas = {}
    numeros = {n for etapas, fruto in ARTE_CULTIVOS.values() for n in (*etapas, fruto)}
    for n in sorted(numeros):
        ruta = os.path.join(CARPETA_PLANTAS, f"sprite_{n:02d}.png")
        if not os.path.exists(ruta):
            continue
        try:
            imagen = pygame.image.load(ruta).convert_alpha()
        except pygame.error as error:
            print(f"Aviso: no se pudo cargar {ruta} ({error}).")
            continue
        if imagen.get_width() != imagen.get_height():
            print(f"Aviso: {ruta} no es cuadrada; no se usa.")
            continue
        # Volver a 1 píxel por píxel del dibujo (sin suavizado), recortar lo
        # transparente y agrandar con un factor entero.
        lado = LIENZO_PLANTAS
        nativo = pygame.transform.scale(imagen, (lado, lado))
        caja = nativo.get_bounding_rect()
        if caja.width == 0:
            continue
        planta = nativo.subsurface(caja).copy()
        factor = min(ESCALA_PLANTAS, PLANTA_MAX[0] / caja.width, PLANTA_MAX[1] / caja.height)
        plantas[n] = pygame.transform.scale(planta, (round(caja.width * factor),
                                                     round(caja.height * factor)))
    return plantas


def icono_ajustado(imagen, lado):
    """Sprite ya agrandado x ESCALA_ARTE -> ícono de `lado` píxeles: vuelve al dibujo
    original, recorta lo transparente y lo agranda (entero si se puede) para caber."""
    w, h = imagen.get_width() // ESCALA_ARTE, imagen.get_height() // ESCALA_ARTE
    nativo = pygame.transform.scale(imagen, (w, h))
    caja = nativo.get_bounding_rect()
    if caja.width == 0:
        return pygame.Surface((lado, lado), pygame.SRCALPHA)
    nativo = nativo.subsurface(caja).copy()
    mayor = max(caja.width, caja.height)
    factor = lado // mayor
    if factor >= 1:
        dibujo = pygame.transform.scale(nativo, (caja.width * factor, caja.height * factor))
    else:
        k = lado / mayor
        dibujo = pygame.transform.scale(nativo, (max(1, int(caja.width * k)), max(1, int(caja.height * k))))
    icono = pygame.Surface((lado, lado), pygame.SRCALPHA)
    icono.blit(dibujo, dibujo.get_rect(center=(lado // 2, lado // 2)))
    return icono


def icono_de_sprite(imagen):
    """Ícono de la barra a partir de un sprite ya agrandado x ESCALA_ARTE: vuelve a
    1 píxel por píxel del dibujo, recorta lo transparente y lo agranda con el
    mayor factor entero que quepa en ICONO_BARRA (píxeles parejos, sin deformar)."""
    w, h = imagen.get_width() // ESCALA_ARTE, imagen.get_height() // ESCALA_ARTE
    nativo = pygame.transform.scale(imagen, (w, h))
    caja = nativo.get_bounding_rect()
    if caja.width == 0:
        return nativo
    nativo = nativo.subsurface(caja).copy()
    factor = max(1, ICONO_BARRA // max(caja.width, caja.height))
    return pygame.transform.scale(nativo, (caja.width * factor, caja.height * factor))


def piezas_de_cable(sprites):
    """{lados conectados: imagen} con cada pieza de cable girada en sus 4
    posiciones. Solo las piezas cuyo PNG existe."""
    piezas = {}
    for nombre, lados in PIEZAS_CABLE.items():
        if nombre not in sprites:
            continue
        imagen = sprites[nombre][0]
        for vueltas in range(4):
            piezas.setdefault(frozenset(lados), pygame.transform.rotate(imagen, 90 * vueltas))
            lados = {GIRO_IZQUIERDA[l] for l in lados}
    return piezas


def sortear_variantes_suelo(cantidad=TEXTURA_VARIANTES):
    """Matriz con la variante de cada bloque de TEXTURA_CUADROS x TEXTURA_CUADROS
    cuadros. Como 32 es múltiplo de 4, los bloques encajan también al dar la
    vuelta al mapa. Semilla fija: el piso es el mismo en cada partida.

    Un bloque nunca repite la variante de su vecino de arriba ni de la izquierda
    (ni el de abajo o la derecha al dar la vuelta): dos bloques idénticos juntos
    se ven como un patrón repetido. Si no queda otra opción, se permite."""
    azar = random.Random(SEMILLA_SUELO)
    n = TEXTURA_CUADROS
    filas, columnas = FILAS // n, COLUMNAS // n
    bloques = [[None] * columnas for _ in range(filas)]
    for f in range(filas):
        for c in range(columnas):
            vecinas = {bloques[f - 1][c] if f else None, bloques[f][c - 1] if c else None}
            if f == filas - 1:
                vecinas.add(bloques[0][c])          # la última fila toca la primera
            if c == columnas - 1:
                vecinas.add(bloques[f][0])          # la última columna toca la primera
            opciones = [v for v in range(cantidad) if v not in vecinas]
            bloques[f][c] = azar.choice(opciones or list(range(cantidad)))
    return bloques


def icono_evento(nombre, lado=20):
    """Ícono chico hecho por código para los avisos de Marte (sin texto)."""
    img = pygame.Surface((lado, lado), pygame.SRCALPHA)
    tinta = (60, 36, 28)
    if nombre == "sismo":                                   # línea de sismógrafo
        puntos = [(1, 10), (5, 10), (7, 4), (9, 16), (11, 2), (13, 18), (15, 8), (17, 10), (19, 10)]
        pygame.draw.lines(img, tinta, False, [(x * lado / 20, y * lado / 20) for x, y in puntos], 2)
    elif nombre == "remolino":                              # embudo de polvo
        for k in range(5):
            w = 4 + k * 3.2
            pygame.draw.ellipse(img, COLOR_REMOLINO, (lado / 2 - w / 2 + (k % 2) * 1.5, 15 - k * 3.2, w, 4))
            pygame.draw.ellipse(img, tinta, (lado / 2 - w / 2 + (k % 2) * 1.5, 15 - k * 3.2, w, 4), 1)
    elif nombre == "impacto":                               # cráter con una roca que cae
        pygame.draw.ellipse(img, COLOR_CRATER_BORDE, (2, 10, 16, 8))
        pygame.draw.ellipse(img, COLOR_CRATER_FONDO, (5, 12, 10, 5))
        pygame.draw.line(img, tinta, (16, 1), (11, 9), 2)
        pygame.draw.circle(img, tinta, (11, 9), 2)
    elif nombre == "radiacion":                             # trébol simple
        pygame.draw.circle(img, (175, 95, 225), (lado // 2, lado // 2), lado // 2 - 1)
        pygame.draw.circle(img, (255, 255, 255), (lado // 2, lado // 2), 3)
    else:                                                   # polvo: rachas de viento
        for k, y in enumerate((5, 10, 15)):
            pygame.draw.line(img, COLOR_REMOLINO, (2 + k * 2, y), (18 - k, y), 3)
            pygame.draw.line(img, tinta, (2 + k * 2, y + 1), (18 - k, y + 1), 1)
    return img


def ajustar_texto(texto, fuente, ancho_max):
    """Parte un texto largo en líneas que quepan en ancho_max píxeles, sin
    cortar palabras. Una palabra más ancha que el máximo queda sola en su línea."""
    lineas, actual = [], ""
    for palabra in texto.split():
        prueba = f"{actual} {palabra}".strip()
        if not actual or fuente.size(prueba)[0] <= ancho_max:
            actual = prueba
        else:
            lineas.append(actual)
            actual = palabra
    if actual:
        lineas.append(actual)
    return lineas
