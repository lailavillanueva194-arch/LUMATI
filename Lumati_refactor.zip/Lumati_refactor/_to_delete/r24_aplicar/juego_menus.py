"""Menú principal (inicio), menú de pausa, guía del juego, lista de partidas y
las preguntas de confirmación.
"""

import math

import pygame

import estilo
import fondo_menu
import partidas
from textos import cambiar_idioma, t
from config import (ALTO, ANCHO, CARPETA, COLOR_AVISO, COLOR_TEXTO_CIELO, CONFIRMAR_ANCHO_3,
                    CONFIRMAR_RECT, GUIA_SECCIONES, INICIO_BOTONES, LUNA, MARTE, MENU_ATENUAR,
                    NUEVA_BOTONES, OPCIONES_GRANDE, PARTIDAS_POR_PAGINA, PAUSA_BOTONES, PAUSA_RECT,
                    TARJETA_ALTO, TARJETA_ANCHO, TARJETA_ARRIBA, TARJETA_FLOTA,
                    TARJETA_RESALTE_VEL, TARJETA_SEP)
from arte import ajustar_texto


class MenusMixin:
    """Menú principal (inicio), menú de pausa, guía del juego, lista de partidas y
    las preguntas de confirmación."""

    # -- menú principal (inicio) y menú de opciones (pausa) ---------------------
    # Ronda 23: un solo sistema de páginas en self.opciones.
    #   Inicio (self.en_inicio = True), con el fondo decorado y tarjetas flotantes:
    #       "inicio" (Continuar, Nueva partida, Partidas, Guía, Salir) y "nueva" (Luna o Marte).
    #   Pausa (Esc jugando): "menu", un panel sencillo sobre el juego oscurecido.
    #   En los dos: "guia" y "partidas" (cada uno con su fondo).
    # Mientras hay una página abierta, el juego está en pausa (actualizar no lo avanza).
    def abrir_opciones(self, pagina="menu"):
        """Abre una página del menú. Si no se está en el inicio, es la pausa."""
        self.opciones = pagina
        self._confirmar = None
        self._lista_partidas = None
        self.pagina_partidas = 0
        self._mensaje_t = 0.0                # el aviso que había se borra: en el menú solo salen los suyos

    def abrir_inicio(self, pagina="inicio"):
        """Menú principal (pantalla de inicio). El juego que había se queda quieto
        en memoria; "Continuar" carga la partida guardada más reciente."""
        self.en_inicio = True
        self.inventario_abierto = self.crafteo_abierto = False
        self.menu_base = None
        self.abrir_opciones(pagina)

    def cerrar_opciones(self):
        """Cierra el menú y vuelve a jugar."""
        self.opciones = None
        self._confirmar = None
        self.en_inicio = False

    def pagina_principal(self):
        """A dónde vuelve Esc o "Volver" desde la guía o las partidas."""
        return "inicio" if self.en_inicio else "menu"

    def lista_partidas(self):
        if self._lista_partidas is None:
            try:
                self._lista_partidas = partidas.listar(CARPETA)
            except OSError:
                self._lista_partidas = []
        return self._lista_partidas

    def hay_partida(self):
        """True si hay al menos una partida guardada que se puede cargar."""
        return any(not r["danada"] for r in self.lista_partidas())

    def cambiar_pagina_partidas(self, paso):
        paginas = max(1, -(-len(self.lista_partidas()) // PARTIDAS_POR_PAGINA))
        self.pagina_partidas = max(0, min(paginas - 1, self.pagina_partidas + paso))

    def empezar(self, destino):
        """Nueva partida desde el inicio (Luna o Marte)."""
        self.nueva_partida(destino)
        self.cerrar_opciones()

    def cargar_desde_menu(self, ruta=None):
        """Carga una partida (o la más reciente) y, si se pudo, se pone a jugar."""
        if self.cargar_partida(ruta):
            self.cerrar_opciones()
            return True
        return False

    def tecla_opciones(self, tecla):
        """Teclas con un menú abierto: Esc vuelve (o cierra la pausa), L cambia el
        idioma, las flechas cambian de tema en la guía o de página en las partidas."""
        if tecla == pygame.K_l:
            cambiar_idioma()
            return
        if self._confirmar:                  # pregunta abierta: Esc o N cancelan; Enter o S, la primera opción
            if tecla in (pygame.K_ESCAPE, pygame.K_n):
                self._confirmar = None
            elif tecla in (pygame.K_RETURN, pygame.K_s):
                opcion, _, activo = self.opciones_confirmar()[0]
                if activo:
                    self.responder(opcion)
            return
        if tecla == pygame.K_ESCAPE:
            if self.opciones == "menu":
                self.cerrar_opciones()       # la pausa se cierra
            elif self.opciones != "inicio":
                self.opciones = self.pagina_principal()   # en el inicio, Esc no hace nada
            return
        if self.opciones == "guia" and tecla in (pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT):
            paso = -1 if tecla in (pygame.K_UP, pygame.K_LEFT) else 1
            self.guia_seccion = (self.guia_seccion + paso) % len(GUIA_SECCIONES)
        elif self.opciones == "partidas" and tecla in (pygame.K_LEFT, pygame.K_RIGHT):
            self.cambiar_pagina_partidas(-1 if tecla == pygame.K_LEFT else 1)

    def opciones_confirmar(self):
        """[(opción, texto, activa)] de la pregunta abierta."""
        if self._confirmar[0] == "sobrescribir":
            return [("si", t("confirmar_si"), True), ("no", t("confirmar_no"), True)]
        return [("guardar", t("conf_guardar"), self.puede_guardar()),
                ("sin_guardar", t("conf_sin_guardar"), True),
                ("cancelar", t("conf_cancelar"), True)]

    def responder(self, opcion):
        """Respuesta a la pregunta abierta. Volver al inicio o salir: "guardar"
        guarda primero (si no se puede guardar, no se va), "sin_guardar" se va."""
        pregunta, self._confirmar = self._confirmar, None
        if not pregunta or opcion in ("no", "cancelar"):
            return
        if pregunta[0] == "sobrescribir":
            self.guardar_partida(pregunta[1])
            return
        if opcion == "guardar" and not self.guardar_partida():
            return
        if pregunta[0] == "inicio":
            self.abrir_inicio()
        elif pregunta[0] == "salir":
            self.quiere_salir = True

    def guardar_y_salir(self):
        if self.guardar_partida():
            self.quiere_salir = True

    def boton_activo(self, nombre):
        if self.opciones == "inicio" and nombre == "continuar":
            return self.hay_partida()
        if self.opciones == "menu" and nombre == "guardar":
            return self.puede_guardar()
        return True

    def accion(self, nombre):
        """Lo que hace cada botón de "inicio", "nueva" o "menu"."""
        pagina = self.opciones
        if pagina == "inicio":
            if nombre == "continuar":
                self.cargar_desde_menu()
            elif nombre == "nueva":
                self.opciones = "nueva"
            elif nombre in ("partidas", "guia"):
                self.abrir_opciones(nombre)
            elif nombre == "salir":
                self.quiere_salir = True     # en el inicio no hay nada sin guardar
        elif pagina == "nueva":
            if nombre in (LUNA, MARTE):
                self.empezar(nombre)
            else:
                self.opciones = "inicio"
        elif pagina == "menu":
            if nombre == "continuar":
                self.cerrar_opciones()
            elif nombre in ("guia", "partidas"):
                self.abrir_opciones(nombre)
            elif nombre == "guardar":
                self.guardar_partida()
            elif nombre in ("inicio", "salir"):
                self._confirmar = (nombre,)  # pregunta si guardar antes

    # rectángulos de cada parte del menú
    def rect_opciones(self):
        """Panel de la pausa."""
        r = pygame.Rect(PAUSA_RECT)
        r.center = (ANCHO // 2, ALTO // 2)
        return r

    def botones_opciones(self):
        """{nombre: rect} de los botones de la página abierta. En el inicio son
        tarjetas que flotan (escalonadas); en la pausa, botones fijos del panel."""
        if self.opciones == "menu":
            r = self.rect_opciones()
            return {nombre: pygame.Rect(r.x + 32, r.y + 84 + i * 54, r.w - 64, 44)
                    for i, nombre in enumerate(PAUSA_BOTONES)}
        if self.opciones not in ("inicio", "nueva"):
            return {}
        nombres = INICIO_BOTONES if self.opciones == "inicio" else NUEVA_BOTONES
        alto = TARJETA_ALTO if self.opciones == "inicio" else TARJETA_ALTO + 16
        arriba = TARJETA_ARRIBA if self.opciones == "inicio" else TARJETA_ARRIBA + 24
        t_menu = self._fondo_menu.t
        botones = {}
        for i, nombre in enumerate(nombres):
            dy = round(TARJETA_FLOTA * math.sin(t_menu * 1.3 + i * 0.8))
            r = pygame.Rect(0, 0, TARJETA_ANCHO, alto)
            r.midtop = (ANCHO // 2, arriba + i * (alto + TARJETA_SEP) + dy)
            botones[nombre] = r
        return botones

    def actualizar_menu(self, dt):
        """Con un menú abierto: mueve el fondo del inicio y el resalte de las
        tarjetas (solo adorno; el juego sigue en pausa)."""
        if self.en_inicio:
            self._fondo_menu.actualizar(dt)
        raton = pygame.mouse.get_pos()
        botones = self.botones_opciones() if self.opciones in ("inicio", "nueva") and not self._confirmar else {}
        paso = TARJETA_RESALTE_VEL * dt
        claves = set(self._resalte) | {f"{self.opciones}:{n}" for n in botones}
        for clave in claves:
            pagina, nombre = clave.split(":")
            encima = (pagina == self.opciones and nombre in botones and self.boton_activo(nombre)
                      and botones[nombre].collidepoint(raton))
            meta = 1.0 if encima else 0.0
            actual = self._resalte.get(clave, 0.0)
            self._resalte[clave] = min(meta, actual + paso) if actual < meta else max(meta, actual - paso)

    def rect_grande(self):
        r = pygame.Rect(OPCIONES_GRANDE)
        r.center = (ANCHO // 2, ALTO // 2)
        return r

    def boton_volver(self):
        r = self.rect_grande()
        return pygame.Rect(r.right - 170, r.bottom - 62, 150, 44)

    def pestanas_guia(self):
        r = self.rect_grande()
        return [pygame.Rect(r.x + 18, r.y + 62 + i * 52, 184, 44) for i in range(len(GUIA_SECCIONES))]

    def area_guia(self):
        r = self.rect_grande()
        return pygame.Rect(r.x + 222, r.y + 62, r.w - 222 - 22, r.h - 62 - 74)

    def filas_partidas(self):
        """[(rect de la fila, rect del botón Sobrescribir, ranura)] de esta página."""
        r = self.rect_grande()
        lista = self.lista_partidas()
        inicio = self.pagina_partidas * PARTIDAS_POR_PAGINA
        filas = []
        for i, ranura in enumerate(lista[inicio:inicio + PARTIDAS_POR_PAGINA]):
            fila = pygame.Rect(r.x + 20, r.y + 84 + i * 66, r.w - 40, 58)
            boton = pygame.Rect(fila.right - 150, fila.y + 9, 140, 40)
            filas.append((fila, boton, ranura))
        return filas

    def botones_partidas(self):
        r = self.rect_grande()
        return {"nueva": pygame.Rect(r.x + 20, r.bottom - 62, 270, 44),
                "anterior": pygame.Rect(r.centerx - 70, r.bottom - 62, 44, 44),
                "siguiente": pygame.Rect(r.centerx + 26, r.bottom - 62, 44, 44)}

    def botones_confirmar(self):
        """(panel, rect de cada opción...). Con 2 opciones: (panel, sí, no)."""
        opciones = self.opciones_confirmar()
        r = pygame.Rect(CONFIRMAR_RECT)
        if len(opciones) > 2:
            r.w = CONFIRMAR_ANCHO_3
        r.center = (ANCHO // 2, ALTO // 2)
        if len(opciones) == 2:
            return (r, pygame.Rect(r.x + 60, r.bottom - 64, 150, 44),
                    pygame.Rect(r.right - 210, r.bottom - 64, 150, 44))
        ancho = (r.w - 44 - 2 * 14) // 3
        return (r, *[pygame.Rect(r.x + 22 + i * (ancho + 14), r.bottom - 64, ancho, 44) for i in range(3)])

    def clic_opciones(self, pos):
        if self._confirmar:
            _, *rects = self.botones_confirmar()
            for (opcion, _, activo), rect in zip(self.opciones_confirmar(), rects):
                if activo and rect.collidepoint(pos):
                    self.responder(opcion)
                    return
            return
        if self.opciones in ("inicio", "nueva", "menu"):
            for nombre, boton in self.botones_opciones().items():
                if boton.collidepoint(pos) and self.boton_activo(nombre):
                    self.accion(nombre)
                    return
            return
        if self.boton_volver().collidepoint(pos):
            self.opciones = self.pagina_principal()
            return
        if self.opciones == "guia":
            for i, pestana in enumerate(self.pestanas_guia()):
                if pestana.collidepoint(pos):
                    self.guia_seccion = i
            return
        botones = self.botones_partidas()
        if not self.en_inicio and botones["nueva"].collidepoint(pos):   # en el inicio solo se carga
            if self.puede_guardar():
                self.guardar_partida(partidas.ruta_nueva(CARPETA))
            else:
                self.mensaje = t("partida_no_ahora")
            return
        if botones["anterior"].collidepoint(pos):
            self.cambiar_pagina_partidas(-1)
            return
        if botones["siguiente"].collidepoint(pos):
            self.cambiar_pagina_partidas(1)
            return
        for fila, boton, ranura in self.filas_partidas():
            if not self.en_inicio and boton.collidepoint(pos):
                if self.puede_guardar():
                    self._confirmar = ("sobrescribir", ranura["ruta"], ranura["nombre"])
                else:
                    self.mensaje = t("partida_no_ahora")
                return
            if fila.collidepoint(pos) and not ranura["danada"]:
                self.cargar_desde_menu(ranura["ruta"])
                return

    # dibujo del menú
    def _boton(self, rect, texto, activo=True, elegido=False, borde=None):
        """Botón del estilo de la terminal: gris claro, borde del acento con el mouse encima."""
        p = self.pantalla
        encima = activo and rect.collidepoint(pygame.mouse.get_pos())
        fondo = estilo.CASILLA_ACTIVA if (encima or elegido) else estilo.CASILLA
        pygame.draw.rect(p, fondo, rect, border_radius=6)
        color = estilo.ACENTO if (encima or elegido) else (borde or estilo.CONTORNO)
        pygame.draw.rect(p, color, rect, 3 if elegido else 2, border_radius=6)
        imagen = self.fuente.render(texto, True, estilo.TINTA if activo else estilo.TINTA_SUAVE)
        p.blit(imagen, imagen.get_rect(center=rect.center))

    def lineas_guia(self, seccion, fuente, ancho):
        """Líneas ya cortadas de una sección de la guía: [(texto, sangría)]. Las
        líneas que empiezan con "- " llevan sangría al continuar."""
        lineas = []
        for parrafo in t("guia_" + seccion).split("\n"):
            vineta = parrafo.startswith("- ")
            texto = ("• " + parrafo[2:]) if vineta else parrafo
            partes = ajustar_texto(texto, fuente, ancho - (14 if vineta else 0))
            for k, parte in enumerate(partes):
                lineas.append((parte, 14 if vineta and k else 0))
            lineas.append(None)              # espacio entre párrafos
        return lineas[:-1]

    def fuente_guia(self, seccion):
        """La fuente más grande con la que la sección cabe en su área (la normal o la chica)."""
        area = self.area_guia()
        for fuente in (self.fuente, self.fuente_chica):
            if self.alto_guia(seccion, fuente) <= area.h - 40:
                return fuente
        return self.fuente_chica

    def alto_guia(self, seccion, fuente):
        lineas = self.lineas_guia(seccion, fuente, self.area_guia().w)
        return sum(fuente.get_linesize() if l else 6 for l in lineas)

    def _titulo_lumati(self, y=50):
        """Título "Lumati" grande con sombra y una línea del acento. Devuelve su caja."""
        p = self.pantalla
        sombra = self.fuente_titulo.render("Lumati", True, (12, 14, 24))
        titulo = self.fuente_titulo.render("Lumati", True, estilo.CREMA)
        p.blit(sombra, sombra.get_rect(midtop=(ANCHO // 2 + 3, y + 4)))
        caja = p.blit(titulo, titulo.get_rect(midtop=(ANCHO // 2, y)))
        pygame.draw.line(p, estilo.ACENTO, (caja.x + 10, caja.bottom + 4), (caja.right - 10, caja.bottom + 4), 3)
        return caja

    def _dibujar_tarjetas(self):
        """Tarjetas flotantes del inicio ("inicio" o "nueva")."""
        p = self.pantalla
        for nombre, boton in self.botones_opciones().items():
            activo = self.boton_activo(nombre)
            resalte = self._resalte.get(f"{self.opciones}:{nombre}", 0.0)
            boton = boton.move(round(6 * resalte), 0)            # se corre un poco al pasar el mouse
            color = estilo.TINTA if activo else estilo.TINTA_SUAVE
            if self.opciones == "inicio":
                texto = self.fuente_tarjeta.render(t("ini_" + nombre), True, color)
            else:                                                 # Luna / Marte: nombre y una línea más
                nombre_img = self.fuente_tarjeta.render(t("nueva_" + nombre), True, color)
                detalle = self.fuente_chica.render(t(f"nueva_{nombre}_desc"), True, estilo.TINTA_SUAVE)
                texto = pygame.Surface((max(nombre_img.get_width(), detalle.get_width()),
                                        nombre_img.get_height() + detalle.get_height() + 2), pygame.SRCALPHA)
                texto.blit(nombre_img, (0, 0))
                texto.blit(detalle, (0, nombre_img.get_height() + 2))
            icono = {"continuar": "continuar", "nueva": "nueva", "partidas": "partidas", "guia": "guia",
                     "salir": "salir", "luna": "luna", "marte": "marte", "volver": "volver"}[nombre]
            fondo_menu.tarjeta(p, boton, texto, icono, resalte, aviso=nombre == "salir", activo=activo)

    def dibujar_opciones(self):
        """Menú principal (fondo decorado) o menú de opciones de la pausa (panel
        sencillo sobre el juego oscurecido). La guía y las partidas son las mismas."""
        if self.opciones is None:
            return
        p = self.pantalla
        tinta, suave = estilo.TINTA, estilo.TINTA_SUAVE
        if self.en_inicio:                   # espacio, planetas, astronautas y meteoros
            self._fondo_menu.dibujar(p, discreto=self.opciones in ("guia", "partidas"))
        else:                                # pausa: el juego oscurecido, sin decoración
            self._velo.fill((0, 0, 0, MENU_ATENUAR + 40))
            p.blit(self._velo, (0, 0))
        if self.opciones == "inicio":
            caja = self._titulo_lumati()
            sub = self.fuente.render(t("ini_sub"), True, COLOR_TEXTO_CIELO)
            p.blit(sub, sub.get_rect(midtop=(ANCHO // 2, caja.bottom + 16)))
            ultima = next((r for r in self.lista_partidas() if not r["danada"]), None)
            linea = (t("ini_ultima", nombre=ultima["nombre"], lugar=t("lugar_" + ultima["destino"]),
                       dia=ultima["dia"]) if ultima else t("ini_sin_partidas"))
            linea = ajustar_texto(linea, self.fuente_chica, TARJETA_ANCHO + 160)[0]
            img = self.fuente_chica.render(linea, True, (150, 158, 174))
            p.blit(img, img.get_rect(midtop=(ANCHO // 2, caja.bottom + 40)))
            self._dibujar_tarjetas()
            ayuda = self.fuente_chica.render(t("ini_ayuda"), True, COLOR_TEXTO_CIELO)
            p.blit(ayuda, ayuda.get_rect(midbottom=(ANCHO // 2, ALTO - 48)))
        elif self.opciones == "nueva":
            caja = self._titulo_lumati()
            sub = self.fuente.render(t("nueva_titulo"), True, COLOR_TEXTO_CIELO)
            p.blit(sub, sub.get_rect(midtop=(ANCHO // 2, caja.bottom + 16)))
            self._dibujar_tarjetas()
            ayuda = self.fuente_chica.render(t("opc_esc_volver"), True, COLOR_TEXTO_CIELO)
            p.blit(ayuda, ayuda.get_rect(midbottom=(ANCHO // 2, ALTO - 48)))
        elif self.opciones == "menu":        # pausa: un panel compacto
            r = self.rect_opciones()
            estilo.panel(p, r)
            p.blit(self.fuente_grande.render(t("pausa_titulo"), True, tinta), (r.x + 22, r.y + 14))
            estilo.separador(p, r.x + 14, r.right - 14, r.y + 50)
            ranura = (t("opc_ranura", nombre=self.nombre_ranura(self.ranura_actual)) if self.ranura_actual
                      else t("opc_sin_ranura"))
            linea = ajustar_texto(ranura, self.fuente_chica, r.w - 44)[0]
            p.blit(self.fuente_chica.render(linea, True, suave), (r.x + 22, r.y + 58))
            for nombre, boton in self.botones_opciones().items():
                self._boton(boton, t("pausa_" + nombre), self.boton_activo(nombre),
                            borde=fondo_menu.COLOR_AVISO_SALIR if nombre == "salir" else None)
            ayuda = self.fuente_chica.render(t("opc_esc_juego"), True, suave)
            p.blit(ayuda, ayuda.get_rect(midbottom=(r.centerx, r.bottom - 12)))
        else:
            r = self.rect_grande()
            estilo.panel(p, r)
            titulo = t("guia_titulo" if self.opciones == "guia" else "partidas_titulo")
            p.blit(self.fuente_grande.render(titulo, True, tinta), (r.x + 22, r.y + 12))
            ayuda = self.fuente_chica.render(t("guia_ayuda" if self.opciones == "guia" else "partidas_ayuda"),
                                             True, suave)
            p.blit(ayuda, ayuda.get_rect(topright=(r.right - 22, r.y + 24)))
            estilo.separador(p, r.x + 14, r.right - 14, r.y + 52)
            if self.opciones == "guia":
                self._dibujar_guia(r)
            else:
                self._dibujar_partidas(r)
            self._boton(self.boton_volver(), t("opc_volver"))
            esc = self.fuente_chica.render(t("opc_esc_volver"), True, suave)
            p.blit(esc, esc.get_rect(midright=(self.boton_volver().x - 16, self.boton_volver().centery)))
        if self.mensaje:                     # lo que acaba de pasar en el menú (guardado, error...)
            aviso = self.fuente.render(self.mensaje, True, tinta)
            caja = aviso.get_rect(midbottom=(ANCHO // 2, ALTO - 12)).inflate(28, 16)
            estilo.panel(p, caja, borde=estilo.ACENTO)
            p.blit(aviso, aviso.get_rect(center=caja.center))
        if self._confirmar:
            self._dibujar_confirmar()

    def _dibujar_guia(self, r):
        p = self.pantalla
        for i, (pestana, seccion) in enumerate(zip(self.pestanas_guia(), GUIA_SECCIONES)):
            self._boton(pestana, t(f"guia_{seccion}_t"), elegido=i == self.guia_seccion)
        pygame.draw.line(p, estilo.BISEL, (r.x + 212, r.y + 62), (r.x + 212, r.bottom - 74))
        seccion = GUIA_SECCIONES[self.guia_seccion]
        area = self.area_guia()
        p.blit(self.fuente.render(t(f"guia_{seccion}_t"), True, estilo.ACENTO), (area.x, area.y))
        fuente = self.fuente_guia(seccion)
        y = area.y + 34
        for linea in self.lineas_guia(seccion, fuente, area.w):
            if linea is None:
                y += 6
                continue
            texto, sangria = linea
            p.blit(fuente.render(texto, True, estilo.TINTA), (area.x + sangria, y))
            y += fuente.get_linesize()

    def _dibujar_partidas(self, r):
        """Lista de partidas. Desde el inicio solo se cargan (no hay partida que
        guardar); desde la pausa también se guarda en una nueva o se sobrescribe."""
        p = self.pantalla
        filas = self.filas_partidas()
        if not filas:
            vacia = self.fuente.render(t("partidas_vacia"), True, estilo.TINTA_SUAVE)
            p.blit(vacia, (r.x + 30, r.y + 100))
        raton = pygame.mouse.get_pos()
        for fila, boton, ranura in filas:
            actual = ranura["ruta"] == self.ranura_actual and not self.en_inicio
            sobre_boton = boton.collidepoint(raton) and not self.en_inicio
            encima = fila.collidepoint(raton) and not sobre_boton and not ranura["danada"]
            estilo.casilla(p, fila, activa=actual, mouse=encima)
            nombre = ranura["nombre"] + (f"  ({t('partidas_actual')})" if actual else "")
            p.blit(self.fuente.render(nombre, True, estilo.TINTA), (fila.x + 14, fila.y + 9))
            if ranura["danada"]:
                detalle = t("partidas_danada")
            else:
                detalle = t("partidas_linea", lugar=t("lugar_" + ranura["destino"]), dia=ranura["dia"],
                            hora=ranura["hora"], fecha=ranura["guardado"])
            detalle = ajustar_texto(detalle, self.fuente_chica, fila.w - 190)[0]
            p.blit(self.fuente_chica.render(detalle, True, estilo.TINTA_SUAVE), (fila.x + 14, fila.y + 34))
            if not self.en_inicio:
                self._boton(boton, t("partidas_sobrescribir"), self.puede_guardar())
        botones = self.botones_partidas()
        if not self.en_inicio:
            self._boton(botones["nueva"], t("partidas_nueva"), self.puede_guardar())
        paginas = max(1, -(-len(self.lista_partidas()) // PARTIDAS_POR_PAGINA))
        if paginas > 1:
            self._boton(botones["anterior"], "<", self.pagina_partidas > 0)
            self._boton(botones["siguiente"], ">", self.pagina_partidas < paginas - 1)
            n = self.fuente_chica.render(f"{self.pagina_partidas + 1}/{paginas}", True, estilo.TINTA_SUAVE)
            p.blit(n, n.get_rect(center=(r.centerx - 4, botones["anterior"].bottom + 10)))

    def _dibujar_confirmar(self):
        p = self.pantalla
        r, *rects = self.botones_confirmar()
        self._velo.fill((0, 0, 0, 90))
        p.blit(self._velo, (0, 0))
        estilo.panel(p, r, borde=COLOR_AVISO)
        tipo = self._confirmar[0]
        if tipo == "sobrescribir":
            pregunta = t("confirmar_sobrescribir", nombre=self._confirmar[2])
        else:
            pregunta = t("confirmar_inicio" if tipo == "inicio" else "confirmar_salir_juego")
        y = r.y + 22
        for linea in ajustar_texto(pregunta, self.fuente, r.w - 44):
            p.blit(self.fuente.render(linea, True, estilo.TINTA), (r.x + 22, y))
            y += self.fuente.get_linesize()
        for (opcion, texto, activo), rect in zip(self.opciones_confirmar(), rects):
            self._boton(rect, texto, activo)
