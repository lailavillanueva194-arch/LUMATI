"""Partidas guardadas en ranuras (ronda 21). Lógica pura: no usa pygame.

Cada ranura es un archivo partidas/ranura_001.json junto a main.py. Adentro va
el mismo estado de siempre (Juego.estado_a_dict) y además una clave "meta" con
lo que se muestra en la lista: nombre, destino, día, hora del juego y la fecha
real en que se guardó. Como "meta" es solo una clave más, un archivo de ranura
también se puede cargar como una partida vieja y al revés.

Ronda 25: la pantalla de Partidas usa 3 slots fijos (ver "Slots" abajo):
cargar, guardar aquí, borrar (mueve el archivo a partidas/_borradas/) y las
estadísticas de cada partida.

Migración: la primera vez que se abre el juego, los .json viejos que estén
junto a main.py (partida_lumati.json y compañía) se COPIAN a ranuras. Los
originales no se tocan. Un archivo partidas/.migrado evita que se repita.
"""

import json
import os
import re
from datetime import datetime

import clima
from maquinas import TANQUE_MAX
from supervivencia import DOSIS_A_MSV

CARPETA = "partidas"
PREFIJO = "ranura_"
MARCA_MIGRADO = ".migrado"
# Guardados viejos que se copian a ranuras la primera vez (en este orden).
VIEJOS = ("partida_lumati.json", "partida_marte_avanzada.json", "partida_lumati_respaldo.json")
FORMATO_FECHA = "%Y-%m-%d %H:%M"


def carpeta(base):
    """Ruta de la carpeta de partidas (junto a main.py). La crea si no existe."""
    ruta = os.path.join(base, CARPETA)
    os.makedirs(ruta, exist_ok=True)
    return ruta


def _numero(nombre_archivo):
    m = re.fullmatch(PREFIJO + r"(\d+)\.json", nombre_archivo)
    return int(m.group(1)) if m else None


def ruta_nueva(base):
    """Ruta de una ranura nueva (el número siguiente al más alto que hay)."""
    dir_ = carpeta(base)
    numeros = [n for n in (_numero(a) for a in os.listdir(dir_)) if n is not None]
    siguiente = max(numeros, default=0) + 1
    return os.path.join(dir_, f"{PREFIJO}{siguiente:03d}.json")


def dia_y_hora(estado):
    """(día, 'HH:MM') del juego, a partir del reloj guardado."""
    reloj = clima.Reloj()
    reloj.segundos = float(estado["reloj"]["segundos"]) % clima.DURACION_CICLO
    reloj.ciclos = int(estado["reloj"]["ciclos"])
    return reloj.dia, reloj.hora_texto


def hacer_meta(estado, nombre, fecha=None):
    """Lo que la lista muestra de una partida."""
    dia, hora = dia_y_hora(estado)
    return {"nombre": nombre, "destino": estado["destino"], "dia": dia, "hora": hora,
            "guardado": (fecha or datetime.now()).strftime(FORMATO_FECHA)}


def escribir(ruta, estado, nombre, fecha=None):
    """Guarda `estado` con su meta en `ruta`. Primero escribe un temporal y lo
    renombra: si algo falla a medias, la ranura anterior no se pierde."""
    datos = dict(estado)
    datos["meta"] = hacer_meta(estado, nombre, fecha)
    temporal = ruta + ".tmp"
    with open(temporal, "w", encoding="utf-8") as archivo:
        json.dump(datos, archivo)
    os.replace(temporal, ruta)
    return datos["meta"]


def leer(ruta):
    """El diccionario guardado (lanza OSError o ValueError si no se puede)."""
    with open(ruta, encoding="utf-8") as archivo:
        return json.load(archivo)


def listar(base):
    """Lista de ranuras, la más reciente primero. Cada una es un diccionario con
    ruta, numero y la meta (nombre, destino, dia, hora, guardado). Una ranura que
    no se puede leer sale con danada=True (y no se puede cargar)."""
    dir_ = carpeta(base)
    lista = []
    for archivo in os.listdir(dir_):
        numero = _numero(archivo)
        if numero is None:
            continue
        ruta = os.path.join(dir_, archivo)
        try:
            d = leer(ruta)
            meta = d.get("meta") or hacer_meta(d, f"{PREFIJO}{numero:03d}",
                                                datetime.fromtimestamp(os.path.getmtime(ruta)))
            lista.append({"ruta": ruta, "numero": numero, "danada": False, **meta})
        except (OSError, ValueError, KeyError, TypeError):
            lista.append({"ruta": ruta, "numero": numero, "danada": True, "nombre": archivo,
                          "destino": "", "dia": 0, "hora": "", "guardado": ""})
    # Más reciente primero; a igual fecha, la de número más alto.
    lista.sort(key=lambda r: (r["guardado"], r["numero"]), reverse=True)
    return lista


def mas_reciente(base):
    """Ruta de la ranura guardada más reciente que se puede cargar, o None."""
    for r in listar(base):
        if not r["danada"]:
            return r["ruta"]
    return None


def migrar(base, viejos=VIEJOS):
    """Copia los guardados viejos de junto a main.py a ranuras, una sola vez.
    No borra ni cambia los originales. Devuelve cuántos copió."""
    dir_ = carpeta(base)
    marca = os.path.join(dir_, MARCA_MIGRADO)
    if os.path.exists(marca):
        return 0
    copiados = 0
    for nombre in viejos:
        origen = os.path.join(base, nombre)
        if not os.path.exists(origen):
            continue
        try:
            estado = leer(origen)
            fecha = datetime.fromtimestamp(os.path.getmtime(origen))
            escribir(ruta_nueva(base), estado, os.path.splitext(nombre)[0], fecha)
            copiados += 1
        except (OSError, ValueError, KeyError, TypeError):
            continue                    # un archivo dañado no se copia (el original se queda igual)
    with open(marca, "w", encoding="utf-8") as archivo:
        archivo.write("Los guardados viejos ya se copiaron a ranuras.\n")
    return copiados


# --------------------------------------------------------------------------
# Slots (ronda 25): 3 ranuras fijas. El Slot N es el archivo ranura_00N.json, así
# las partidas que ya existían quedan como Slot 1, 2 y 3 sin moverlas.
# --------------------------------------------------------------------------
SLOTS = 3
CARPETA_EXTRA = "_extra"            # ranuras de más (4, 5...): se guardan aquí, no se pierden
CARPETA_BORRADAS = "_borradas"      # "Borrar" mueve el archivo aquí (no se elimina de verdad)


def ruta_slot(base, n):
    """Ruta del Slot n (1 a SLOTS)."""
    return os.path.join(carpeta(base), f"{PREFIJO}{n:03d}.json")


def numero_slot(ruta):
    """Número de slot (1 a SLOTS) de una ruta, o None si no es un slot."""
    if not ruta:
        return None
    n = _numero(os.path.basename(ruta))
    return n if n is not None and 1 <= n <= SLOTS else None


def primer_libre(base):
    """El primer slot sin partida, o None si los 3 están ocupados."""
    for n in range(1, SLOTS + 1):
        if not os.path.exists(ruta_slot(base, n)):
            return n
    return None


def _mover_sin_pisar(origen, carpeta_destino, nombre):
    """Mueve un archivo a otra carpeta sin pisar ninguno que ya esté ahí."""
    os.makedirs(carpeta_destino, exist_ok=True)
    raiz, ext = os.path.splitext(nombre)
    destino = os.path.join(carpeta_destino, nombre)
    k = 2
    while os.path.exists(destino):
        destino = os.path.join(carpeta_destino, f"{raiz}_{k}{ext}")
        k += 1
    os.replace(origen, destino)
    return destino


def ordenar_slots(base):
    """Deja solo los 3 slots en partidas/. Una ranura de más (número 4 o mayor)
    pasa a un slot libre si hay; si no, se mueve a partidas/_extra/ (no se
    pierde). Devuelve [(origen, destino)]."""
    dir_ = carpeta(base)
    movidos = []
    numeros = sorted(n for n in (_numero(a) for a in os.listdir(dir_)) if n is not None and n > SLOTS)
    for n in numeros:
        origen = os.path.join(dir_, f"{PREFIJO}{n:03d}.json")
        libre = primer_libre(base)
        if libre is not None:
            destino = ruta_slot(base, libre)
            os.replace(origen, destino)
        else:
            destino = _mover_sin_pisar(origen, os.path.join(dir_, CARPETA_EXTRA), os.path.basename(origen))
        movidos.append((origen, destino))
    return movidos


def borrar_slot(base, n, fecha=None):
    """"Borra" el Slot n: mueve su archivo a partidas/_borradas/ con la fecha en el
    nombre. Devuelve la ruta nueva, o None si el slot ya estaba libre."""
    origen = ruta_slot(base, n)
    if not os.path.exists(origen):
        return None
    sello = (fecha or datetime.now()).strftime("%Y%m%d-%H%M%S")
    return _mover_sin_pisar(origen, os.path.join(carpeta(base), CARPETA_BORRADAS),
                            f"{PREFIJO}{n:03d}_{sello}.json")


def estadisticas(estado, tipo_panel):
    """Números de una partida guardada, sacados del propio guardado (no inventa
    nada): lo producido, la dosis, el hidrógeno del tanque más lleno y cuántas
    cosas construyó. tipo_panel es el número del panel solar en el mapa
    (GENERADOR en config.py)."""
    producido = estado.get("producido", {})
    maquinas_mapa = estado.get("maquinas", [])
    hidrogeno = max((int(m.get("hidrogeno", 0)) for _, _, m in maquinas_mapa if m.get("clase") == "tanque"),
                    default=0)
    return {
        "oxigeno": int(producido.get("oxigeno", 0)),
        "agua": int(producido.get("agua", 0)),
        "comida": int(producido.get("comida", 0)),
        "dosis_msv": float(estado.get("astronauta", {}).get("dosis", 0.0)) * DOSIS_A_MSV,
        "hidrogeno": hidrogeno,
        "hidrogeno_max": TANQUE_MAX,
        "taladros": len(estado.get("taladros", [])),
        "maquinas": len(maquinas_mapa),
        "paneles": sum(list(fila).count(tipo_panel) for fila in estado.get("mapa", [])),
        "baterias": len(estado.get("baterias", [])),
        "macetas": sum(1 for m in estado.get("macetas", []) if m),
        "contacto": bool(estado.get("contacto_hecho", False)),
    }


def leer_slots(base, tipo_panel):
    """Los 3 slots: [{numero, ruta, ocupado, danada, nombre, destino, dia, hora,
    guardado, stats}]. Un slot libre trae ocupado=False."""
    lista = []
    for n in range(1, SLOTS + 1):
        ruta = ruta_slot(base, n)
        slot = {"numero": n, "ruta": ruta, "ocupado": os.path.exists(ruta), "danada": False}
        if slot["ocupado"]:
            try:
                d = leer(ruta)
                meta = d.get("meta") or hacer_meta(d, f"{PREFIJO}{n:03d}",
                                                    datetime.fromtimestamp(os.path.getmtime(ruta)))
                slot.update(meta)
                slot["stats"] = estadisticas(d, tipo_panel)
            except (OSError, ValueError, KeyError, TypeError, AttributeError):
                slot["danada"] = True
        lista.append(slot)
    return lista
