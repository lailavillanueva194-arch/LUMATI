# Lumati_pulido: qué cambió respecto a ~/Lumati

Copia pulida hecha con IA (Claude Fable 5.2) el 14 nov 2026. La carpeta original
`~/Lumati` no se tocó. Se corre igual: `python main.py`.

Las reglas del juego son las mismas: con la misma partida simulada (6000 pasos),
el original y esta copia dan exactamente los mismos números (oxígeno, dosis,
inventario, producción, reloj). Lo único nuevo en reglas es Marte, que está aparte.

## Qué cambió, por archivo

**estilo.py (nuevo, ~400 líneas).** Todo lo visual de la interfaz en un solo lugar:
- Paleta única (sección "Paleta"): cambiar un color ahí cambia toda la interfaz.
- `panel()`, `casilla()`, `barra()`, `separador()`: paneles tipo madera con marco.
- Íconos dibujados por código (pixel art propio, con letras): 4 barras vitales,
  6 recursos, pico / regadera / taladro básico.
- `Particulas`: cuadritos de polvo y chispas (máximo 160, solo adorno).
- `vineta()`: borde de pantalla teñido.

**main.py.**
- Inventario (tecla E): dos paneles de madera. Arriba las 21 casillas con íconos
  de recurso; abajo el retrato del astronauta, "En la mano" (pico, regadera,
  taladro básico) y los datos de la misión, o el detalle de la casilla bajo el mouse.
- HUD: barras vitales con ícono y relleno que se mueve suave; reloj, avisos,
  mensajes, etiquetas de máquinas y barra de herramientas con el mismo estilo.
- "Crafteo": panel de receta abajo a la izquierda al elegir algo que cuesta
  (herramientas 4 a 8): qué pide, cuánto tienes, palomita o X.
- Barra crítica: antes parpadeaba cada 0.25 s; ahora pulsa despacio (accesibilidad).
- Viñetas en los bordes: morada mientras llega la radiación de una tormenta solar
  (menos si hay blindaje), azul oscuro con oxígeno bajo. Entran y salen despacio.
- Sombras suaves bajo máquinas, bloques y astronauta.
- Partículas: polvo al caminar, soplo al poner o quitar algo, chispas al recoger.
- Cámara con un pequeño retraso (`CAMARA_SUAVE = 12`; ponlo en 0 y queda pegada
  como antes). Respeta el mapa que da la vuelta.
- Pantalla de muerte y comparación final en panel de madera.
- Constantes nuevas arriba, en "Pulido visual". Se quitaron 7 constantes de color
  que ya no se usaban (`COLOR_PANEL`, `COLOR_CASILLA...`, `COLOR_FONDO_BARRA`).
- Métodos nuevos: `actualizar_pulido`, `seguir_con_camara`, `polvo_al_caminar`,
  `_usar_con_efecto`, `rect_receta`, `dibujar_receta`, `dibujar_vinetas`,
  `dibujar_polvo`, `dibujar_aviso_polvo`, `actualizar_polvo`, `colores_polvo`.
  Ningún método que ya existía cambió de nombre.

**clima.py.** `Reloj` acepta temperaturas distintas (la Luna usa las de siempre).
Clase nueva `TormentaPolvo` y constantes de Marte. `Clima` no cambió.

**textos.py.** 24 claves nuevas en español e inglés (inventario, receta, Marte).

**Sin cambios:** maquinas.py, supervivencia.py, energia.py, suelo.py, datos.py,
requirements.txt y todos los PNG de assets/.

## Lo que NO se tocó
- Mecánicas, costos, tiempos y demás valores de balance.
- Controles (1 a 8, E, M, X, T, N, R, L, Esc siguen igual).
- Los sprites de los diseñadores. Están limpios (pocos colores, sin píxeles
  semitransparentes), así que no se retocó ninguno y no hizo falta guardar copias.
- Los dibujos provisionales de máquinas, base y cables: siguen esperando sus PNG.

## Ojo: pico y regadera
El código original no tiene pico ni regadera como herramientas (su comentario
dice "Ya no hay pico") y la barra son las 8 construcciones. Para no cambiar
controles, pico, regadera y taladro básico se muestran en el inventario como
"En la mano", pero **el pico y la regadera no hacen nada todavía**. El taladro
básico sí es la herramienta 2, que ya era gratis.

## Marte
- Empezar en Marte: `python main.py marte`.
- O desde el juego: en la pantalla final ("Tu misión contra la real") pulsa **M**.
  Desde Marte, M regresa a la Luna.
- Qué tiene: suelo color óxido (los mismos cráteres de suelo.py, teñidos),
  temperaturas propias (20 a -90 °C, valores del juego) y tormentas de polvo:
  aviso de 8 s, luego 20 s con los paneles tapados y todas las máquinas sin
  energía. **P** dispara una (modo demo).
- Simplificación (está en el comentario de `TormentaPolvo`): el polvo apaga los
  paneles del todo; en la realidad baja su rendimiento poco a poco.
- No se hizo MOXIE ni nada más único de Marte. Las tormentas solares y todo lo
  demás son iguales a la Luna. La pantalla final sigue comparando con MOXIE.
- Por defecto se juega en la Luna; Marte no afecta a la Luna.

## Qué quedó sin probar
Todo se probó sin ventana (pantalla falsa), con capturas revisadas: inicio,
construcciones, receta, inventario, tormenta solar, noche, inglés, barras
críticas, muerte y rescate, final, vuelta completa al mapa, y Marte.
Falta probar en la Mac con ventana real:
- Teclado y mouse de verdad (pasar el mouse por casillas y barra, clics).
- Cómo se siente la cámara suave y si el polvo al caminar se ve bien a 60 FPS.
- Rendimiento real (sin ventana: unos 1.5 ms por cuadro).

## Para la presentación
Declarar que el pulido visual (estilo.py y los cambios de dibujo) y la versión
mínima de Marte se hicieron con Claude Fable 5.2.

---

## Ronda 2 (14 nov, noche)

Pedido de Oliver: sin barra de herramientas (es supervivencia, no creativo), una
máquina de crafteo, menús en blanco "de médico" y cables que no se vean tiesos.
Respaldo de la versión anterior completa: `Proyectos/Lumati_pulido_v1`.

### Qué cambió para el jugador
- **Ya no hay barra de abajo ni teclas 1 a 8.** Junto a la nave está el
  **Fabricador** (cuadro fijo en `CRAFTEO_POS = (14, 17)`). Clic en él abre su menú:
  una fila por objeto con su costo (ícono + `pide/tienes`, en rojo y con X lo que
  falta). Clic en una fila lo fabrica y va al inventario.
- **En la mano:** en el inventario (E), abajo, están los 8 objetos fabricados con
  cuántos tienes. Clic en uno lo pone en la mano; otro clic lo guarda. Abajo a la
  izquierda un recuadro chico dice qué llevas y cuántos quedan (clic: abre el
  inventario). Clic en el mapa coloca lo de la mano y gasta una unidad.
- **Quitar devuelve el objeto, no los recursos:** X sobre un taladro o una máquina,
  o clic con cable/panel/bloque en la mano sobre uno igual, lo regresa al
  inventario de objetos. (Un taladro mejorado vuelve como taladro básico, igual
  que antes se perdía la mejora.)
- **Con qué empiezas:** 1 taladro básico (en la mano), 1 panel solar y 5 cables:
  justo para el primer circuito. `OBJETOS_INICIALES` en main.py.
- **Costos:** los mismos de `maquinas.COSTO_CONSTRUIR`. Cable, taladro y panel
  solar ya eran gratis y siguen gratis (pero hay que ir al Fabricador); el cable
  sale en tramos de 5 (`FABRICA_CANTIDAD`). Para ponerles costo: `COSTO_FABRICAR`.
- **Menús blancos:** inventario, Fabricador, barras, reloj, avisos, datos, muerte y
  final usan la paleta nueva de `estilo.py`: blanco clínico, grises claros, texto
  gris casi negro y una franja fina cian (`ACENTO`) arriba de cada panel. Las barras
  vitales tienen fondo oscuro para que sus colores resalten.
- **Cables flexibles:** cada cable se dibuja como curva con holgura (una onda lenta
  fija según el cuadro). El centro de cada cable es un resorte amortiguado: se mueve
  cuando el astronauta camina encima o cuando pones/quitas un cable vecino, la onda
  pasa a los vecinos y en unos segundos se asienta. La red de energía NO cambió
  (un cable por cuadro, mismo relleno). `CABLE_FISICA = False` vuelve a los cables
  rectos de antes. Los cables se dibujan todos juntos después del piso.

### Archivos
- `main.py`: objetos y Fabricador (`OBJETOS`, `COSTO_FABRICAR`, `fabricar`,
  `elegir_en_mano`, `dibujar_crafteo`, `dibujar_mano`, `dibujar_fabricador`),
  sección de objetos en el inventario, cables con física (`actualizar_cables`,
  `dibujar_cables`, `_punto_nodo`, `pisar_cable`, `sacudir_vecinos`), docstring de
  controles. Se quitaron la barra, la receta abajo a la izquierda, las teclas 1-8 y
  los íconos decorativos de pico y regadera (no hacían nada).
- `estilo.py`: paleta blanca + `ACENTO`, `MARCO`, `BISEL`, `OK`; los nombres
  viejos (`MADERA`, `MADERA_OSCURA`) quedan como alias.
- `textos.py`: textos nuevos en español e inglés (Fabricador, en la mano, etc.).

### Probado (sin ventana)
- Partida completa por el camino nuevo, en la Luna y en Marte: primer circuito con
  lo inicial, fabricar, elegir en el inventario, colocar, mejorar taladro,
  purificador → electrolizador → tanque lleno → despegue → final.
- Quitar devuelve objetos; rescate conserva los objetos; inglés; cables rectos.
- Los cables se asientan solos (~6 s) y cruzan el borde del mapa sin cortes.
- Dibujo: ~2 ms por cuadro con cables moviéndose.

### Falta probar en la Mac
- Mouse y teclado reales; cómo se siente el balanceo de los cables a 60 FPS.
- `dibujar_cable` (la versión vieja con PNG de piezas) solo se usa si
  `CABLE_FISICA = False`: si las diseñadoras entregan PNG de cable, decidir cuál se queda.

## Ronda 3: acceso rápido (5 casillas)

- `main.py`: 5 casillas abajo al centro (`RAPIDA_*`, `dibujar_rapida`, `usar_rapida`, `asignar_rapida`).
  Teclas 1 a 5 o clic en la casilla: llevar ese objeto a la mano (otra vez: guardarlo).
  Asignar: en el inventario (E), mouse sobre un objeto y tecla 1 a 5; si ya estaba en otra casilla, se intercambian.
  Al empezar: taladro, cable y panel solar. Lo que fabricas por primera vez entra solo a la primera casilla libre.
  Los mensajes ahora salen encima del acceso rápido.
- `textos.py`: textos nuevos `rapida_vacia`, `rapida_asignada` y ayuda del inventario (es/en).

## Ronda 4: cables de colores, antena, base por dentro y guardado

Respaldo del estado anterior: `Proyectos/Lumati_pulido_v2`.

**Cables menos elásticos** (`main.py`, constantes `CABLE_*`, valores viejos anotados al lado):
holgura 5 → 2.5 px, resorte 60 → 150, freno 4 → 16, desplazamiento máximo 10 → 5 px.
Se mueven poco y se asientan en ~0.5 s. `CABLE_FISICA = False` sigue regresando a cables rectos.

**Colores de cable: verde, azul y amarillo** (`main.py`, `energia.py`).
- Cada color es su propio circuito: cables de distinto color NO se conectan entre sí.
  Máquinas, antenas y paneles se conectan a cables de cualquier color (un panel puede
  alimentar varios colores; una máquina que toca dos colores recibe energía si alguno la tiene).
- El color se guarda por cuadro en `colores_cable` (aparte del mapa). `energia.py` solo
  recibió un parámetro opcional `colores`; sin él funciona como antes.
- Elegir color: tecla **C** o **rueda del mouse** (con el cable en la mano). Se ve en
  "En la mano" y en la casilla rápida del cable.
- Con cable en la mano: clic en un cable de **otro** color lo pinta (gratis); del **mismo**
  color, lo quita y vuelve al inventario.
- Accesibilidad: además del color, patrón: verde liso, azul con rayas, amarillo con puntos.
- Sin rojo (luces de apagado) ni azul oscuro (poco oxígeno).
- Con `CABLE_FISICA = False` ya no se usan las piezas PNG de cable (no se pueden teñir).

**Antena de comunicación** (`main.py`, tipo de cuadro `ANTENA`).
- Se fabrica en el Fabricador. Costo provisional `COSTO_ANTENA = {"hierro": 4, "metal": 2}`
  (ajústalo ahí). Se coloca desde la mano como las máquinas y se quita con X.
- Necesita energía por cable. Encendida: cartel "Tierra: en contacto" bajo el reloj y cada
  `ANTENA_CADA` (40 s) un "Mensaje de la Tierra" con un dato real de `datos.py` y su fuente.
- No cambia cómo se gana (despegar). El final agrega "Contacto con la Tierra por antena: sí/no".
- El inventario muestra ahora los objetos en 2 filas de 5 (son 9).

**Base por dentro** (`main.py`, `ESCENA_BASE`, `SALA_RECT`).
- Clic en la base (al alcance) para entrar. La sala se ve desde arriba, en blanco de
  estación, y se camina con WASD. Dentro: oxígeno y radiación como en el piso de la base.
- Muebles (clic estando cerca):
  - **Cama**: dormir solo de 18:00 a 06:00. La pantalla se oscurece suave, el mundo avanza
    hasta las 06:00 en pasos de 0.5 s (taladros, máquinas, tormentas y barras siguen) y aclara.
  - **Almacén**: 12 casillas de 20 (`ALMACEN_CASILLAS`, `ALMACEN_PILA`). Clic en la mochila
    guarda esa casilla; clic en el almacén la saca.
  - **Panel de sistemas** (y el **rack de cables**): por color, cables, máquinas conectadas
    y si tiene energía; paneles, máquinas encendidas/apagadas, producción, dosis, antena.
  - **Terminal**: Guardar / Cargar partida.
  - **Puerta**: caminar hacia ella (o clic) para salir; el astronauta aparece abajo de la base.

**Guardar partida** (`main.py`, `estado_a_dict`, `aplicar_dict`).
- Archivo `partida_lumati.json` junto a `main.py`. **F5** guarda y **F9** carga (también la terminal).
- Guarda mapa, colores, taladros, máquinas, antenas, inventario, almacén, objetos, acceso rápido,
  barras, dosis, reloj, tormenta solar, tormenta de polvo, destino y si estabas dentro de la base.
- Se escribe en un archivo temporal y luego se renombra. Si no hay partida o está dañada, avisa
  y la partida actual no cambia.

**Textos nuevos** en `textos.py` (es/en). "Colocaste: {nombre}" reemplaza "{nombre} construido".

## Ronda 5: regadera

- `main.py`: objeto "regadera" (herramienta de mano, empieza con 1, casilla rápida 4; no se fabrica ni se coloca). El agua entra al invernadero solo con la regadera en la mano; cosechar sigue con cualquier cosa. Ícono propio. `FABRICABLES` = objetos del Fabricador.
- `textos.py`: textos de la regadera (es/en).

## Ronda 6: pico

- `main.py`: tipos PICADO y CAMINO (se caminan). Pico (herramienta de mano, casilla 1): suelo -> picado -> camino -> suelo. El taladro solo va en suelo picado; al quitarlo queda picado. Dibujo propio de ambos terrenos (Luna y Marte).
- `textos.py`: textos del pico (es/en).

## Ronda 7: arte nuevo de Piskel (Descargas, 14 nov)

- `assets/`: panel_solar_mapa.png (3 posiciones), icono_regadera.png, gotas.png, icono_o2.png (fondo quitado; originales en Descargas sin tocar).
- `main.py`: panel solar del mapa con el dibujo nuevo (cambia de posición según la hora), íconos de regadera y electrolizador, gotas al regar, menú de objetos en 2 filas de 6.
- Sin usar (no tocar terreno, piedras, base ni cables): roca-oscura, rocas-suelo-lunar, prueba-franjas. Pendientes de decidir: cubeta, panel-control, personaje-colores.

## Ronda 8: batería, taladros y cubeta (arte de Piskel)

- `assets/`: bateria.png (panel-control, 3 cuadros), taladro_niveles.png (personaje-colores, nivel 1-3), cubeta.png (vacía / con tierra). Fondos quitados.
- `main.py`: objeto Batería (BATERIA=16, costo COSTO_BATERIA): se carga con un panel activo en su red y da energía cuando los paneles no rinden. NUEVO: de noche los paneles no dan energía (`NOCHE_APAGA_PANELES`, False = como antes). Taladros con dibujo por nivel que tiemblan al trabajar. Invernadero en cubeta con la planta saliendo de la tierra. Guardado incluye baterías.
- `textos.py`: textos de la batería y aviso de noche (es/en).

## Ronda 9: invernadero en la base y nopal

- `main.py`: 6 huecos de maceta dentro de la base (fila al centro, sólidos). Con Invernadero en la mano: poner maceta; clic sin regar: cambiar cultivo; regadera: regar; con fruto: cosechar. Siempre con energía (la de la base). Se guardan en la partida. Cubeta como función `_dibujar_cubeta`.
- `maquinas.py`: cultivo nopal.
- `assets/plantas/sprite_12-16.png`: nopal PROVISIONAL hecho por código (el plantas.zip de Descargas no trae nopal).
- `textos.py`: textos del invernadero de la base (es/en).

## Ronda 10: cuarto de cultivos aparte

- `main.py`: la base tiene 2 cuartos (`self.cuarto`): módulo habitable y invernadero. Puerta lateral en la pared izquierda del habitable; en el invernadero, regreso por la pared derecha. Las macetas salieron del habitable: ahora son 12 (2 filas de 6) en el invernadero, piso verde. La salida al exterior sigue abajo en el habitable.
- `textos.py`: rótulos de los cuartos (es/en).

## Ronda 11: conectores y cable negro

- `energia.py`: parámetro opcional `une(a, b)` para decidir si dos cables vecinos se unen.
- `main.py`: con el cable en la mano, C/rueda recorre verde, azul, amarillo, negro y conectores +, T, L; R gira la pieza. Negro (troncal): une cualquier color, solo en su dirección (horizontal o vertical). Conectores: neutros, unen cualquier color por los lados de su forma. `piezas_cable` se guarda en la partida. Cuestan 1 cable.
- `textos.py`: nombres de piezas y giro (es/en).

## Ronda 12: electrolizador en caja y tanque de agua

- `main.py`: electrolizador dibujado como caja con ventana de agua, electrodos, burbujas al trabajar y salidas O2/H2 (ícono igual). Nuevo objeto Tanque de agua (TANQUE_AGUA=17, máx. AGUA_MAX=20, costo COSTO_TANQUE_AGUA): recibe agua de un purificador pegado y llena solo al electrolizador o invernadero pegados (pasivo, sin energía). Clic: guardar o sacar agua. Se guarda en la partida. Inventario de objetos en 2 filas de 7.
- `textos.py`: textos del tanque de agua (es/en).

## Ronda 13: inicio

- `main.py`: se empieza con 1 maceta (Invernadero) y 3 de agua (`AGUA_INICIAL`) para la regadera.

## Ronda 14: materiales de los taladros y piedra

- `assets/recursos_taladro.png` (de hierro.piskel): íconos de cristal, hierro y regolito en inventario, Fabricador y almacén (`ARTE_RECURSO`). `assets/bloque_regolito.png` (de minerales.piskel): el bloque de regolito en el mapa y su ícono. Las pinzas (tit.piskel) ya eran el ícono del cable.

## Ronda 15: relieve y vista del espacio

- `main.py`: 4 colinas de adorno (`COLINAS`, 3 alturas; se camina y construye encima). La cima tiene un montón de piedras con banderita. Parado en la cima, aparece suave el espacio negro con estrellas que brillan y unos cuantos cometas (`COMETAS_MAX`=2). Al bajar, se va.
- `textos.py`: aviso de la cima (es/en).

## Ronda 16: montañas y vista lateral desde la cima

- `main.py`: las colinas ahora son montañas (imagen por colina hecha por código: anillos más claros hacia la cima, sombra, crestas y piedras), con banderita en la cima. En la montaña no se construye. Parado en la cima, la vista cambia a una escena de lado: espacio negro con estrellas, unos cuantos cometas, la Tierra (Luna) o Fobos y Deimos (Marte), cordilleras y el astronauta en la punta. Caminar te baja.
- `textos.py`: textos de la montaña (es/en).

## Ronda 17

- `main.py`: montañas más raras: 2 en vez de 4 (`COLINAS`).

## Ronda 18: minimapa

- `main.py`: minimapa arriba a la derecha (todo el mapa, 3 px por cuadro, centrado en el astronauta, da la vuelta). Muestra base, nave, Fabricador, máquinas, cables de color, montañas y cimas. TAB lo muestra u oculta. Se redibuja cada 0.3 s.
- `textos.py`: rótulo del minimapa (es/en).
- Minimapa movido arriba a la izquierda, bajo la etiqueta del inventario.

## Ronda 19

- `main.py`: montañas hechas con capas semitransparentes (luz hacia la cima, sombra y curvas de nivel) encima de la textura del suelo, para que combinen con él.

## Ronda 20: eventos de Marte

Solo en Marte (la Luna no cambia: se comprobó que dibuja los mismos píxeles que antes).

- `eventos_marte.py` (nuevo, sin pygame): ficha `EventoMarte` (nombre, categoría polvo/radiación/suelo, frecuencia relativa, duración, aviso previo, efectos, dato) y el programador `EventosMarte`. Todos los números están en `ESCALA` y `CONFIG`, cada uno marcado "DATO NASA (fuente)" o "SUPUESTO DEL JUEGO". Las escalas de tiempo son supuestos: 1 año marciano = 180 s de juego; para las partículas solares, 1 sol = 3 s.
- Eventos, de más a menos frecuentes: sismos y remolinos de polvo (constantes; remolinos solo de día y menos con tormenta), tormenta de polvo regional (1 por año, en la temporada de polvo), tormenta global (cada 3 a 4 años, aviso más largo, 60 s, velo más espeso), partículas solares SEP (irregulares; actividad solar "baja" por defecto), impacto de meteorito (muy raro).
- `clima.py`: la tormenta de polvo que ya había es la regional; `TormentaPolvo` ahora tiene tipo (regional/global) y modo no automático. `Clima` acepta ejemplos, modo no automático y duración de partículas (Marte las usa; la Luna no pasa nada y queda igual). `Reloj.amortiguar`: con polvo, días más fríos y noches menos frías.
- `main.py`: efectos conectados. Polvo: paneles tapados (como antes), cultivo más lento (60 % regional, 35 % global; también las macetas de la base), temperatura amortiguada y polvo dibujado sobre los paneles. SEP: la cadena solar de siempre con ejemplos de DONKI que llegan a Marte (CME de 645 km/s del 2017), partículas el doble de largas, mensaje de refugio en la base y caída Forbush (radiación de fondo al 85 % un rato). Sismo: sacudida suave de cámara (`SACUDIDA_ACTIVA` = False la quita) y aviso con magnitud, sin daño. Impacto: cráter de 3x3 en suelo libre y a la vista (nunca encima de construcciones, montañas, base, nave ni Fabricador), sismo M4.0 y un taladro dentro del cráter saca más hielo. Remolino: embudo de polvo que cruza la pantalla, sin daño. Avisos cortos con ícono bajo el reloj. Cada evento muestra su dato real con fuente.
- Teclas del modo demo (solo Marte): P regional, G global, T partículas solares (SEP), V remolino, K sismo, I impacto.
- Partida guardada: tipo de tormenta, relojes de los eventos, cráteres y temperatura. Las partidas viejas cargan (campos nuevos con `d.get`).
- `maquinas.py`: `Taladro.extra` (pesos extra del botín; vacío = igual que antes).
- `datos.py`: 12 datos de Marte del encargo (NASA/JPL, Curiosity, InSight, MRO, DONKI), marcados `verificado=False` y `solo_marte` (la antena no los manda en la Luna).
- `textos.py`: textos nuevos (es/en).

## Ronda 21: taladros grandes, menú de opciones, guía y partidas

- `assets/taladro_niveles.png`: el borde blanco que quedó del recorte del fondo ahora es un contorno fino gris oscuro (donde era de 2 px se quitó la capa de afuera). El diseño de adentro no cambió. El original está en `assets/_originales/taladro_niveles.png`.
- `main.py`: taladros más grandes (`TALADRO_PIXEL` = 1.75: la figura mide ~60x56 en vez de ~34). Se dibujan después del piso de todos los cuadros para que lo que sobresale no lo tape el vecino. Almacén y progreso sobre una base oscura para que se lean; la etiqueta ("Sin energía", "Almacén lleno") sube.
- `main.py`: menú de opciones con Esc (ya no cierra el juego). El juego se pausa de verdad (reloj, barras, máquinas y eventos). Botones: Continuar, Guía del juego, Partidas, Guardar y salir, Salir sin guardar (con confirmación). Con otro menú abierto, Esc solo lo cierra; en la guía o las partidas, Esc vuelve. L cambia el idioma también dentro del menú.
- Guía del juego: 8 temas (Objetivo, Controles, Energía, Recursos, Agua y aire, Comida, Base, Peligros), con textos cortos sacados de lo que hace el código. Clic o flechas para cambiar de tema.
- `partidas.py` (nuevo, sin pygame): partidas en ranuras `partidas/ranura_NNN.json` (el estado de siempre + "meta" con nombre, destino, día, hora y fecha real). La primera vez que se abre el juego copia `partida_lumati.json`, `partida_marte_avanzada.json` y `partida_lumati_respaldo.json` a ranuras, sin borrarlos ni cambiarlos (`partidas/.migrado` evita repetirlo). Ya no se escribe `partida_lumati.json`.
- Lista de partidas: clic para cargar, "Guardar en ranura nueva", "Sobrescribir" con confirmación, páginas de 6 (flechas, rueda o < >). F5 guarda en la ranura actual (o una nueva); F9 carga la más reciente. La terminal de la base guarda igual y "Ver partidas" abre la lista.
- `textos.py`: textos del menú, partidas y guía (es/en). `.gitignore`: `partidas/`.

## Ronda 22: menú de opciones decorado

- `fondo_menu.py` (nuevo, solo dibujo): fondo del menú con espacio (degradado casi negro), estrellas que cambian de brillo despacio (periodos de 4 a 10 s, sin parpadeos), 3 planetas hechos por código (uno con anillo, uno rojizo tipo Marte y la Tierra) que se mecen un poco, 2 astronautas flotando y girando suave (el dibujo de las diseñadoras, `assets/astronauta.png`) y meteoros con cola de vez en cuando (máximo 2 a la vez). Nada pasa por encima de las tarjetas.
- `main.py`: cada opción es una tarjeta flotante aparte (ícono en un círculo a la izquierda, franja del acento, sombra), con un leve flotar escalonado. Al pasar el mouse crece, se corre un poco y su borde se pinta del acento (todo suave). "Salir sin guardar" va en rojo discreto; "Guardar y salir" se ve apagada cuando no se puede guardar. Título "Lumati" grande arriba.
- La guía y las partidas usan el mismo fondo, más oscuro, con sus paneles blancos de siempre.
- El menú tiene su propio reloj: la decoración se mueve, pero el juego sigue en pausa. Todo lo de antes funciona igual (Esc, guía, partidas, confirmaciones, F5/F9).

## Ronda 23: menú principal (inicio) y menú de pausa nuevo

- Al abrir el juego aparece el menú principal, con el fondo decorado de la ronda 22 y las tarjetas flotantes bajo el título "Lumati": Continuar (carga la partida guardada más reciente; apagada si no hay), Nueva partida (tarjetas Luna o Marte, y Volver), Partidas (solo para cargar), Guía del juego y Salir. Debajo del título dice cuál es la última partida. Esc no hace nada en esta pantalla; en sus subpáginas, vuelve.
- `python main.py marte` sigue empezando directo una partida nueva en Marte, sin pasar por el menú principal (lo más simple). `Juego()` sin `inicio=True` también empieza jugando (lo usan las pruebas).
- Menú de pausa nuevo (Esc jugando): un panel compacto blanco sobre el juego oscurecido, sin decoración. Botones: Continuar, Guía del juego, Partidas (guardar y cargar), Guardar, Menú principal y Salir del juego. Estos dos últimos preguntan: Guardar / No guardar / Cancelar (si no se puede guardar, por ejemplo muerto, "Guardar" se ve apagado). La pausa sigue siendo real.
- La guía y la lista de partidas son las mismas en los dos menús: desde el inicio con el fondo decorado (y la lista solo carga); desde la pausa con el juego oscurecido (y se puede guardar en una ranura nueva o sobrescribir).
- Final del juego: además de R (jugar otra vez) y M (siguiente misión), I vuelve al menú principal.
- `fondo_menu.py`: íconos nuevos (nueva partida, Luna, Marte, volver). `textos.py`: textos del inicio y la pausa (es/en).


## Refactor: main.py dividido en archivos

Copia nueva (`Lumati_refactor`); `Lumati_pulido` no se tocó. Sin cambios de lógica, nombres, controles,
textos, balance ni formato de guardado: cada método y función se copió tal cual (se comprobó que los 246
métodos y las 25 funciones/clases tienen exactamente el mismo código). La clase `Juego` ahora hereda de
"mixins" (clases por tema), así que `self.algo` se llama igual que antes. Las dependencias van en una sola
dirección (config -> arte -> mapa -> jugador -> mixins -> juego -> main): no hay importaciones circulares.

Antes: `main.py` tenía 5860 líneas. Ahora:

| Archivo | Líneas | Qué tiene |
|---|---|---|
| `main.py` | 117 | Arranque: docstring con todos los controles, `main()` (menú principal, o Marte directo con `python main.py marte`). Re-exporta los nombres de siempre (`main.TILE`, `main.Juego`...). |
| `config.py` | 507 | Todas las constantes: tamaños, colores, balance, sprites, rectángulos de la interfaz y de los menús. Solo valores. |
| `arte.py` | 311 | Carga del arte (texturas del suelo, astronauta, sprites, plantas) e íconos; cortar texto en líneas. |
| `mapa.py` | 150 | Generar el mapa, estructuras fijas, montañas (alturas y dibujo), cráteres y distancia en un mapa que da la vuelta. |
| `jugador.py` | 107 | El astronauta en el mapa (movimiento, choques, animación) y la cámara. |
| `juego.py` | 288 | La clase `Juego`: hereda de los mixins, `__init__`, `nueva_partida`, rescate y el bucle `run()`. |
| `juego_hud.py` | 547 | HudMixin: mensajes, avisos, barras, reloj, mano, acceso rápido, resaltado, viñetas, datos reales y el final. |
| `juego_herramientas.py` | 482 | HerramientasMixin: mouse, usar herramientas, objetos, acceso rápido, Fabricador, pico, taladros, construir, máquinas, nave. |
| `juego_energia.py` | 432 | EnergiaMixin: cables y piezas, paneles, tanque de agua, baterías, energía y física de los cables. |
| `juego_entrada.py` | 191 | EntradaMixin: clic, rueda, teclado (con teclas demo) y reiniciar. |
| `juego_mundo.py` | 204 | MundoMixin: actualizar cada cuadro y avanzar el mundo (reloj, tormentas, barras, máquinas, antena). |
| `juego_marte.py` | 279 | MarteMixin: eventos de Marte dentro del juego (polvo, SEP, sismos, remolinos, cráteres). |
| `juego_dibujo_mundo.py` | 431 | DibujoMundoMixin: dibujar el mapa, minimapa, montañas y cielo, astronauta, base, nave y cohete. |
| `juego_dibujo_objetos.py` | 480 | DibujoObjetosMixin: dibujo de cada objeto del mapa (cables, máquinas, taladros, paneles, plantas...). |
| `juego_inventario.py` | 308 | InventarioMixin: inventario (E) y menú del Fabricador. |
| `juego_base.py` | 671 | BaseMixin: la base por dentro (cuartos, muebles, macetas, dormir, almacén, menús de la base) y su dibujo. |
| `juego_guardado.py` | 245 | GuardadoMixin: estado a diccionario y de vuelta; guardar y cargar en ranuras. |
| `juego_menus.py` | 520 | MenusMixin: menú principal, pausa, guía, lista de partidas y confirmaciones. |
| **Total** | **6270** | (más líneas que antes por los docstrings y los imports de cada archivo) |

Sin cambios: `clima.py`, `datos.py`, `energia.py`, `estilo.py`, `eventos_marte.py`, `fondo_menu.py`, `maquinas.py`, `partidas.py`, `suelo.py`, `supervivencia.py`, `textos.py`.

Comprobado: mismo estado guardado y mismos píxeles que `Lumati_pulido` en 47 casos (inicio, nueva partida
con construcción, Marte con cada evento, base y cuarto de cultivos, pausa, guía, partidas, partida avanzada
de Marte, cima, final, muerte y rescate) y el mismo rendimiento.

Código que parece no usarse (se dejó, no se borró): en el `main.py` original, los imports `json`, `Reloj`,
`celdas_con_energia` y `BOTIN` (siguen en `main.py`), el método `guardar_y_salir` (sin uso desde la ronda 23)
y las constantes `COLOR_CABLE_BORDE`, `COLOR_CABLE_BRILLO`, `OPCIONES_RECT` y `PARTIDA` (esta última solo la
usan las pruebas). En otros archivos: `estilo.MADERA`, `estilo.MADERA_OSCURA`, `estilo.icono_equipo`,
`eventos_marte.SIN_FIN`, `eventos_marte.fichas` (solo pruebas), `maquinas.NIVEL_REQUERIDO`, `maquinas.A_MANO`,
`maquinas.NECESITA_NIVEL`, `maquinas.generar_recursos` y varias constantes y `generar_variante` de `suelo.py`.

## Slots de partidas (ronda 25)

- La pantalla de Partidas ahora son 3 slots fijos (Slot 1, 2 y 3), cada uno una tarjeta grande lado a lado: desde el menú principal sobre el fondo decorado, desde la pausa sobre el juego oscurecido. Cada tarjeta ocupada muestra nombre, destino con su planeta (Luna gris / Marte rojizo), día y hora del juego, fecha real del guardado y estadísticas sacadas del propio guardado: oxígeno, agua y comida producidos, dosis (mSv), hidrógeno del tanque más lleno (x/6 con barrita), taladros, máquinas, paneles, baterías, macetas sembradas y contacto con la Tierra. Un slot vacío muestra "Slot libre" con un + grande.
- Acciones: Cargar; Guardar aquí (solo desde la pausa; en un slot ocupado pide confirmar); Borrar (con confirmación: el archivo no se elimina, se mueve a `partidas/_borradas/` con la fecha en el nombre).
- El Slot N es el archivo `partidas/ranura_00N.json`: las 3 partidas que ya había quedaron como Slot 1, 2 y 3 sin moverlas. Al abrir el juego, una ranura de más (4, 5...) pasa a un slot libre o, si no hay, a `partidas/_extra/` (no se pierde).
- F5 guarda en el slot actual; si no hay, en el primero libre; si los 3 están llenos, avisa que se elija uno en Partidas (lo mismo con "Guardar" de la pausa, "Guardar y salir", "Volver al menú principal" y la terminal). F9 y "Continuar" cargan el más reciente.
- Archivos: `juego_slots.py` nuevo (206 líneas, SlotsMixin: tarjetas, estadísticas y acciones); `partidas.py` (slots, ordenar, borrar a _borradas, estadísticas); `juego_menus.py` (443 líneas: se quitó la lista vieja con páginas); `juego_guardado.py` (F5 con slots); `juego_entrada.py` (la rueda ya no cambia páginas); `config.py` (medidas de las tarjetas; se quitó `PARTIDAS_POR_PAGINA`); `textos.py` (es/en, y la guía menciona los 3 slots).
- Comprobado con el guion de equivalencia: todo lo demás es idéntico a antes (estado y píxeles); solo cambian la pantalla de Partidas y las páginas Controles y Base de la guía (su texto ahora habla de los slots).
