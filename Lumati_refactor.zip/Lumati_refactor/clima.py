"""Tormentas solares: aviso, cuenta regresiva y radiación. Lógica pura: no usa
pygame ni sabe de barras, colores o del jugador (eso lo decide main.py).

La cadena sale de los ejemplos reales de DONKI (NASA CCMC): una llamarada va
seguida de una eyección de masa coronal (CME) y, unas 3.5 a 5.5 horas después,
de partículas solares (SEP). Aquí esas horas se COMPRIMEN a segundos de juego
(simplificación). Los valores de balance están arriba, fáciles de cambiar.

Los eventos son ejemplos históricos reales guardados en el código: el juego
funciona sin internet. DONKI no incluye la Luna como destino, así que se usan
eventos de la Tierra como aproximación.

También aquí vive el reloj del día y la noche (clase Reloj): la luz sube y baja
despacio y la temperatura la sigue con un poco de retraso.
"""

import math
import random

# --------------------------------------------------------------------------
# Balance (dificultad fácil). Segundos de juego, no reales.
# --------------------------------------------------------------------------
SEMILLA_CLIMA = 7                       # misma semilla = mismas esperas
DURACION_CALMA = (60.0, 100.0)          # (mínimo, máximo) entre tormentas
DURACION_LLAMARADA = 6.0                # aviso: se ve la llamarada
DURACION_CME = 30.0                     # cuenta regresiva hasta las partículas
DURACION_PARTICULAS = {"S": 10.0, "C": 15.0, "O": 20.0}   # según intensidad
MULT_RADIACION = {"S": 2.0, "C": 3.0, "O": 5.0}   # veces la tasa normal (balance
                                                  # del juego, no es dato NASA)

# --------------------------------------------------------------------------
# Reloj del día y la noche (también segundos de juego)
# --------------------------------------------------------------------------
# SIMPLIFICACIÓN: el diseño dice que la noche lunar dura unas 2 semanas
# terrestres. Aquí un día lunar completo (día + noche) dura unos 15 minutos, para
# que se pueda ver pasar. Muy lento a propósito: ajusta DURACION_CICLO.
DURACION_CICLO = 900.0          # segundos que dura un día lunar completo
HORA_INICIO = 8.0               # el juego empieza de mañana, con todo el día por delante
UMBRAL_LUZ = 0.2                # altura del sol (-1 a 1) donde empieza a oscurecer; el
                                # amanecer y el atardecer duran ~1 min cada uno
# Temperaturas del JUEGO (valores simplificados, no son datos de la NASA).
TEMP_DIA = 90.0                 # °C en lo más caluroso, un poco después del mediodía
TEMP_NOCHE = -110.0             # °C en lo más frío, un poco después de medianoche
RETRASO_TEMP = 0.04             # fracción del ciclo que tarda el suelo en calentarse o enfriarse

AMANECER, DIA, ATARDECER, NOCHE = "amanecer", "dia", "atardecer", "noche"

# --------------------------------------------------------------------------
# Marte (solo se usa si se juega en Marte; la Luna no cambia)
# --------------------------------------------------------------------------
# Temperaturas del JUEGO para Marte (simplificadas, no son datos de la NASA):
# Marte es menos extremo que la Luna porque tiene algo de atmósfera.
TEMP_DIA_MARTE = 20.0
TEMP_NOCHE_MARTE = -90.0
# Tormenta de polvo: tapa los paneles solares un rato. Segundos de juego.
SEMILLA_POLVO = 13
POLVO_CALMA = (45.0, 75.0)      # (mínimo, máximo) entre tormentas de polvo
POLVO_AVISO = 8.0               # aviso antes de que llegue
POLVO_DURACION = 20.0           # cuánto dura
POLVO_EN_CALMA, POLVO_EN_AVISO, POLVO_ACTIVA = "calma", "aviso", "activa"
# Ronda 20: en Marte las tormentas (de polvo y solares) ya no se disparan solas:
# las programa eventos_marte.py. Mientras tanto la calma dura "para siempre".
CALMA_SIN_FIN = 1e9

# Fases
CALMA = "calma"
LLAMARADA = "llamarada"             # aviso previo
CME_EN_CAMINO = "cme_en_camino"     # cuenta regresiva
PARTICULAS = "particulas"           # radiación activa: hay que refugiarse

_SIGUIENTE = {CALMA: LLAMARADA, LLAMARADA: CME_EN_CAMINO,
              CME_EN_CAMINO: PARTICULAS, PARTICULAS: CALMA}

# Escala SCORE de la NASA para las CME (velocidad en km/s). En dificultad
# fácil solo se usan S, C y O: R y ER se tratan como O.
LIMITES_CME = ((500, "S"), (1000, "C"), (2000, "O"), (3000, "R"))
INTENSIDADES_FACIL = ("S", "C", "O")


def tipo_cme(velocidad):
    """Tipo NASA (S, C, O, R, ER) de una CME según su velocidad en km/s."""
    for limite, tipo in LIMITES_CME:
        if velocidad < limite:
            return tipo
    return "ER"


def intensidad_facil(tipo):
    """Intensidad que usa el juego: S, C u O (lo más fuerte se baja a O)."""
    return tipo if tipo in INTENSIDADES_FACIL else "O"


# --------------------------------------------------------------------------
# Eventos históricos reales (de los ejemplos de la especificación de DONKI)
# --------------------------------------------------------------------------
# velocidad_cme: dato real si lo hay; la intensidad sale de la escala NASA.
# intensidad_asignada: cuando el ejemplo no trae velocidad, la elige el juego
# (NO es dato de la NASA).
EVENTOS = [
    {"id": "flr_2016_01_01", "etiqueta": "FLR M2.3", "fecha": "2016-01-01",
     "velocidad_cme": None, "intensidad_asignada": "C"},
    {"id": "gst_2016_01_21", "etiqueta": "GST Kp 6", "fecha": "2016-01-21",
     "velocidad_cme": None, "intensidad_asignada": "C"},
    {"id": "flr_2016_01_28", "etiqueta": "FLR C9.6", "fecha": "2016-01-28",
     "velocidad_cme": None, "intensidad_asignada": "S"},
    {"id": "cme_2017_01_03", "etiqueta": "CME 645 km/s", "fecha": "2017-01-03",
     "velocidad_cme": 645, "intensidad_asignada": None},
]


def intensidad_de(evento):
    """Intensidad S/C/O de un evento: por velocidad real si hay, si no la asignada."""
    if evento["velocidad_cme"] is not None:
        return intensidad_facil(tipo_cme(evento["velocidad_cme"]))
    return evento["intensidad_asignada"]


# --------------------------------------------------------------------------
# Reloj
# --------------------------------------------------------------------------
class Reloj:
    """Reloj de 24 horas con medianoche en 0 y mediodía en 12. Determinista: no
    usa números al azar. Un ciclo completo dura DURACION_CICLO segundos.

    Expone: hora (0 a 24, nunca llega a 24), dia (1, 2, 3...), luz (0 de noche a
    1 de día, con transiciones suaves), oscuridad (1 - luz), momento y
    temperatura (sigue al sol con retraso)."""

    def __init__(self, hora=HORA_INICIO, temp_dia=TEMP_DIA, temp_noche=TEMP_NOCHE):
        self.temp_dia = temp_dia        # la Luna usa TEMP_DIA y TEMP_NOCHE; Marte, las suyas
        self.temp_noche = temp_noche
        self.amortiguar = 0.0           # 0 a 1: el polvo de Marte achica la diferencia día-noche
                                        # (días más fríos, noches menos frías). La Luna: siempre 0
        self.segundos = (hora % 24.0) / 24.0 * DURACION_CICLO     # dentro del ciclo actual
        self.ciclos = 0                                           # ciclos completos ya pasados

    def actualizar(self, dt):
        """Avanza dt segundos. Un dt grande da lo mismo que muchos pasos chicos;
        cero o negativo no hace nada."""
        if dt <= 0:
            return
        total = self.segundos + dt
        self.ciclos += int(total // DURACION_CICLO)
        self.segundos = total % DURACION_CICLO

    def adelantar_a_proximo(self, cada=6):
        """Salta hasta la próxima hora que sea múltiplo de `cada` (6, 12, 18 y 24;
        las 24 son las 00:00 del día siguiente). Es la tecla del modo demo: nadie
        puede esperar 7 minutos para ver la noche. Devuelve las horas saltadas."""
        horas = cada - (self.hora % cada)
        self.actualizar(horas / 24.0 * DURACION_CICLO + 1e-6)     # +1e-6: cae justo después de la hora
        return horas

    @property
    def fraccion(self):
        """Qué parte del ciclo va, de 0.0 a 1.0 (sin llegar a 1)."""
        return self.segundos / DURACION_CICLO

    @property
    def hora(self):
        return self.fraccion * 24.0

    @property
    def dia(self):
        return self.ciclos + 1

    @property
    def hora_texto(self):
        """'HH:MM', siempre de 00:00 a 23:59 (nunca '24:00')."""
        horas = int(self.hora) % 24
        minutos = min(59, int((self.hora - int(self.hora)) * 60))
        return f"{horas:02d}:{minutos:02d}"

    @property
    def altura_sol(self):
        """Altura del sol de -1 (medianoche) a 1 (mediodía): amanece a las 6 y
        anochece a las 18."""
        return math.sin(2 * math.pi * (self.fraccion - 0.25))

    @property
    def luz(self):
        """0.0 de noche, 1.0 de día, con suavizado entre una y otra."""
        t = min(1.0, max(0.0, (self.altura_sol + UMBRAL_LUZ) / (2 * UMBRAL_LUZ)))
        return t * t * (3 - 2 * t)

    @property
    def oscuridad(self):
        return 1.0 - self.luz

    @property
    def momento(self):
        """AMANECER, DIA, ATARDECER o NOCHE, según la luz y si va subiendo."""
        luz = self.luz
        if luz < 0.05:
            return NOCHE
        if luz > 0.95:
            return DIA
        return AMANECER if self.hora < 12 else ATARDECER

    @property
    def temperatura(self):
        """°C: la más alta un poco después del mediodía y la más baja un poco
        después de medianoche (el suelo tarda en calentarse y en enfriarse)."""
        calor = (math.sin(2 * math.pi * (self.fraccion - 0.25 - RETRASO_TEMP)) + 1) / 2
        temp = self.temp_noche + (self.temp_dia - self.temp_noche) * calor
        if self.amortiguar > 0:         # con polvo: se acerca a la temperatura media
            media = (self.temp_dia + self.temp_noche) / 2
            temp = media + (temp - media) * (1.0 - min(1.0, self.amortiguar))
        return temp


# --------------------------------------------------------------------------
# Tormenta de polvo (Marte)
# --------------------------------------------------------------------------
class TormentaPolvo:
    """Fases: calma -> aviso -> activa -> calma. Mientras está activa, el polvo
    tapa los paneles solares (tapa_paneles) y las máquinas se quedan sin energía.

    SIMPLIFICACIÓN: en Marte real el polvo baja el rendimiento de los paneles
    poco a poco; aquí los apaga del todo durante la tormenta, porque el juego
    fácil no mide cuánta energía da cada panel. Lógica pura, igual que Clima.

    Ronda 20: tipo "regional" (la de siempre) o "global" (más larga y fuerte;
    sus tiempos los pasa quien la inicia). Con automatico=False no se dispara
    sola: la calma dura hasta que alguien llame a iniciar()."""

    def __init__(self, semilla=SEMILLA_POLVO, automatico=True):
        self._azar = random.Random(semilla)
        self.automatico = automatico
        self.tipo = "regional"
        self.aviso = POLVO_AVISO        # duraciones de la tormenta en curso
        self.duracion = POLVO_DURACION
        self.fase = POLVO_EN_CALMA
        self.segundos_restantes = self._espera_calma()

    def _espera_calma(self):
        return self._azar.uniform(*POLVO_CALMA) if self.automatico else CALMA_SIN_FIN

    def _entrar(self, fase):
        self.fase = fase
        if fase == POLVO_EN_CALMA:
            self.segundos_restantes = self._espera_calma()
        elif fase == POLVO_EN_AVISO:
            self.segundos_restantes = self.aviso
        else:
            self.segundos_restantes = self.duracion

    def actualizar(self, dt):
        """Avanza dt segundos y devuelve la lista de fases en las que entró."""
        siguiente = {POLVO_EN_CALMA: POLVO_EN_AVISO, POLVO_EN_AVISO: POLVO_ACTIVA,
                     POLVO_ACTIVA: POLVO_EN_CALMA}
        cambios = []
        while dt > 0:
            usado = min(dt, self.segundos_restantes)
            self.segundos_restantes -= usado
            dt -= usado
            if self.segundos_restantes <= 0:
                self._entrar(siguiente[self.fase])
                cambios.append(self.fase)
        return cambios

    def iniciar(self, tipo="regional", aviso=None, duracion=None):
        """Dispara el aviso ahora (tecla del modo demo o eventos de Marte). Solo
        si hay calma. Sin aviso/duracion usa los de siempre (POLVO_AVISO y
        POLVO_DURACION)."""
        if self.fase != POLVO_EN_CALMA:
            return False
        self.tipo = tipo
        self.aviso = POLVO_AVISO if aviso is None else aviso
        self.duracion = POLVO_DURACION if duracion is None else duracion
        self._entrar(POLVO_EN_AVISO)
        return True

    @property
    def tapa_paneles(self):
        return self.fase == POLVO_ACTIVA


# --------------------------------------------------------------------------
# Clima
# --------------------------------------------------------------------------
class Clima:
    """Máquina de fases: CALMA -> LLAMARADA -> CME_EN_CAMINO -> PARTICULAS -> CALMA.

    Expone fase, segundos_restantes, evento (el ejemplo real en curso) e
    intensidad. Los eventos se recorren en orden y vuelven a empezar.
    """

    def __init__(self, semilla=SEMILLA_CLIMA, eventos=None, automatico=True,
                 duracion_particulas=None):
        """Sin argumentos es la de siempre (la Luna). Marte (ronda 20) pasa sus
        ejemplos de DONKI, automatico=False (las tormentas las programa
        eventos_marte.py) y partículas más largas."""
        self._azar = random.Random(semilla)
        self.eventos = eventos or EVENTOS
        self.automatico = automatico
        self.duracion_particulas = duracion_particulas or DURACION_PARTICULAS
        self._proximo = 0           # índice del siguiente evento a usar
        self.evento = None
        self.intensidad = None
        self.segundos_restantes = 0.0
        self.fase = CALMA
        self.reloj = Reloj()           # día y noche (no usa el azar de las tormentas)
        self._entrar(CALMA)

    def _entrar(self, fase):
        """Pone la fase y su duración."""
        self.fase = fase
        if fase == CALMA:
            self.evento = None
            self.intensidad = None
            self.segundos_restantes = (self._azar.uniform(*DURACION_CALMA) if self.automatico
                                       else CALMA_SIN_FIN)
        elif fase == LLAMARADA:
            self.evento = self.eventos[self._proximo % len(self.eventos)]
            self._proximo += 1
            self.intensidad = intensidad_de(self.evento)
            self.segundos_restantes = DURACION_LLAMARADA
        elif fase == CME_EN_CAMINO:
            self.segundos_restantes = DURACION_CME
        else:
            self.segundos_restantes = self.duracion_particulas[self.intensidad]

    def actualizar(self, dt):
        """Avanza dt segundos y devuelve la lista de fases en las que entró.

        Un dt grande pasa por cada fase, una por una, sin saltarse ninguna
        ni repetirla (igual que Taladro.actualizar con su while).
        """
        self.reloj.actualizar(dt)
        cambios = []
        while dt > 0:
            usado = min(dt, self.segundos_restantes)
            self.segundos_restantes -= usado
            dt -= usado
            if self.segundos_restantes <= 0:
                self._entrar(_SIGUIENTE[self.fase])
                cambios.append(self.fase)
        return cambios

    def iniciar_tormenta(self):
        """Dispara una tormenta ahora (tecla del modo demo). Solo si hay calma;
        devuelve True si arrancó."""
        if self.fase != CALMA:
            return False
        self._entrar(LLAMARADA)
        return True

    @property
    def en_peligro(self):
        """True mientras llegan las partículas (hay que estar en refugio)."""
        return self.fase == PARTICULAS

    @property
    def multiplicador_radiacion(self):
        """Cuántas veces sube la tasa de radiación ahora (1.0 si no hay tormenta)."""
        return MULT_RADIACION[self.intensidad] if self.en_peligro else 1.0
