"""Sonidos de Lumati, hechos por código (ronda 37).

No hay archivos de audio: cada efecto y cada pista de música se sintetiza al
arrancar con tonos, ruido filtrado y envolventes (solo `math`, `array` y `wave`).
Así el juego suena sin bajar nada y sin depender de nadie.

Si las diseñadoras (o quien sea) quieren cambiar un sonido por uno real, basta
con dejar `assets/sonidos/<nombre>.wav` (o .ogg) con el mismo nombre que aquí:
si el archivo existe se usa ese; si no, el sintetizado. No hay que tocar código.

Para oírlos sin abrir el juego:   python sonido.py carpeta_de_salida
(escribe un .wav por cada sonido y por cada pista de música).

Este módulo no importa pygame al cargarse: solo `a_sonido()` lo usa. La parte que
fabrica las muestras se puede probar sin ventana ni dispositivo de audio.
"""

import array
import io
import math
import os
import random
import sys
import wave

TASA = 22050             # muestras por segundo de los efectos
TASA_MUSICA = 11025      # la música es suave y grave: con la mitad alcanza (y se hace más rápido)
DOS_PI = 2 * math.pi

# ----------------------------------------------------------------------------
# Piezas para construir sonidos. Una "pista" es una lista de números de -1 a 1.
# ----------------------------------------------------------------------------


def mid(m):
    """Frecuencia en Hz de una nota MIDI (69 = La 440)."""
    return 440.0 * 2 ** ((m - 69) / 12)


def silencio(dur, tasa=TASA):
    return [0.0] * int(dur * tasa)


def onda(frec, dur, forma="seno", tasa=TASA, fase=0.0):
    """Tono. `frec` es un número o (inicial, final) para un barrido. `forma`:
    seno, triangulo, sierra o cuadrada (suavizada, para que no raspe)."""
    n = int(dur * tasa)
    if isinstance(frec, (int, float)):
        paso = [DOS_PI * frec / tasa] * n
    else:
        f0, f1 = frec
        razon = (f1 / f0) ** (1.0 / max(1, n))
        paso = [DOS_PI * f0 * razon ** i / tasa for i in range(n)]
    salida = []
    ph = fase
    if forma == "seno":
        for p in paso:
            salida.append(math.sin(ph))
            ph += p
    elif forma == "triangulo":
        for p in paso:
            salida.append(0.63662 * math.asin(math.sin(ph)))
            ph += p
    elif forma == "sierra":
        for p in paso:
            salida.append(2.0 * ((ph / DOS_PI) % 1.0) - 1.0)
            ph += p
    else:                                    # cuadrada suavizada
        for p in paso:
            salida.append(math.tanh(3.0 * math.sin(ph)))
            ph += p
    return salida


def ruido(dur, semilla=1, tasa=TASA):
    azar = random.Random(semilla)
    return [azar.uniform(-1.0, 1.0) for _ in range(int(dur * tasa))]


def pasa_bajo(x, corte, tasa=TASA):
    """Quita lo agudo (sonido más sordo). `corte` en Hz, o (inicial, final)."""
    salida = []
    y = 0.0
    n = len(x)
    for i, v in enumerate(x):
        c = corte if isinstance(corte, (int, float)) else corte[0] + (corte[1] - corte[0]) * i / max(1, n)
        a = 1.0 - math.exp(-DOS_PI * c / tasa)
        y += a * (v - y)
        salida.append(y)
    return salida


def pasa_alto(x, corte, tasa=TASA):
    """Quita lo grave (sonido más siseante)."""
    bajo = pasa_bajo(x, corte, tasa)
    return [v - b for v, b in zip(x, bajo)]


def pasa_banda(x, bajo, alto, tasa=TASA):
    return pasa_alto(pasa_bajo(x, alto, tasa), bajo, tasa)


def ganancia(x, g):
    return [v * g for v in x]


def envolvente(x, ataque=0.003, caida=None, soltar=0.01, tasa=TASA):
    """Da forma al volumen: sube en `ataque` s, baja como e^(-t/caida) (si hay
    `caida`) y se apaga en los últimos `soltar` s (así nunca suena un "clic")."""
    n = len(x)
    na = max(1, int(ataque * tasa))
    ns = max(1, min(n, int(soltar * tasa)))
    salida = []
    for i, v in enumerate(x):
        g = 1.0
        if i < na:
            g = i / na
        if caida:
            g *= math.exp(-i / (caida * tasa))
        if i >= n - ns:
            g *= (n - i) / ns
        salida.append(v * g)
    return salida


def hinchar(x, tasa=TASA, subida=0.5, bajada=0.5):
    """Volumen que sube y baja suave (viento, motores): campana de seno."""
    n = len(x)
    pico = max(1, int(n * subida / (subida + bajada)))
    salida = []
    for i, v in enumerate(x):
        g = math.sin(0.5 * math.pi * i / pico) if i < pico else math.cos(0.5 * math.pi * (i - pico) / max(1, n - pico))
        salida.append(v * g * g)
    return salida


def mezcla(*partes, largo=None):
    """Suma pistas. Cada parte es una pista o (pista, retraso en segundos)."""
    items = [(p, 0.0) if not isinstance(p, tuple) else p for p in partes]
    n = max(int(r * TASA) + len(p) for p, r in items)
    if largo is not None:
        n = int(largo * TASA)
    salida = [0.0] * n
    for p, r in items:
        o = int(r * TASA)
        for i, v in enumerate(p):
            if o + i < n:
                salida[o + i] += v
    return salida


def pegar(*pistas):
    salida = []
    for p in pistas:
        salida.extend(p)
    return salida


def normalizar(x, pico=0.95):
    m = max((abs(v) for v in x), default=0.0)
    if m <= 1e-9:
        return x
    g = pico / m
    return [v * g for v in x]


def tremolo(x, frec, prof, tasa=TASA):
    """Volumen que late `frec` veces por segundo (`prof` de 0 a 1)."""
    return [v * (1.0 - prof + prof * (0.5 + 0.5 * math.sin(DOS_PI * frec * i / tasa))) for i, v in enumerate(x)]


def bucle_sin_costura(x, cruce, tasa=TASA):
    """Hace que el final de la pista se funda con su principio: al repetirla en
    bucle no se oye el corte. Devuelve una pista `cruce` s más corta."""
    c = int(cruce * tasa)
    n = len(x) - c
    salida = x[:n]
    for i in range(c):
        k = i / c
        salida[i] = x[i] * k + x[n + i] * (1.0 - k)
    return salida


# ----------------------------------------------------------------------------
# Efectos. Cada uno devuelve una pista; el decorador anota el volumen relativo.
# ----------------------------------------------------------------------------
EFECTOS = {}          # nombre -> (función, volumen 0 a 1)


def _fx(nombre, vol=0.6):
    def poner(f):
        EFECTOS[nombre] = (f, vol)
        return f
    return poner


def _golpe(f0, f1, dur, tau, mezcla_ruido=0.35, corte=900, semilla=1):
    """Golpe seco: un tono grave que cae más un soplo de ruido sordo."""
    cuerpo = envolvente(onda((f0, f1), dur), 0.002, tau)
    soplo = envolvente(pasa_bajo(ruido(dur, semilla), corte), 0.001, tau * 0.6)
    return mezcla(cuerpo, ganancia(soplo, mezcla_ruido))


def _campana(frec, dur=1.2, brillo=1.0, tasa=TASA):
    """Campanita: parciales no armónicos que se apagan a distinta velocidad."""
    partes = []
    for k, (razon, amp, tau) in enumerate(((1.0, 1.0, 0.45), (2.0, 0.5, 0.28), (2.76, 0.35 * brillo, 0.2),
                                           (5.4, 0.15 * brillo, 0.1))):
        if frec * razon > 0.45 * tasa:       # más agudo que lo que cabe en esta tasa: sonaría raro
            continue
        partes.append(ganancia(envolvente(onda(frec * razon, dur, tasa=tasa), 0.002, tau * dur, tasa=tasa), amp))
    return mezcla(*partes)


def _notas(midis, paso, dur, forma="seno", tau=0.12, retardo=0.0):
    return mezcla(*[(envolvente(onda(mid(m), dur, forma), 0.004, tau), retardo + i * paso) for i, m in enumerate(midis)])


# --- interfaz ---------------------------------------------------------------
@_fx("clic", 0.45)
def _clic():
    return mezcla(envolvente(onda(1900, 0.03), 0.001, 0.008), ganancia(envolvente(onda(950, 0.04), 0.001, 0.012), 0.5))


@_fx("volver", 0.4)
def _volver():
    return envolvente(onda((900, 520), 0.09, "triangulo"), 0.003, 0.04)


@_fx("abrir", 0.5)
def _abrir():
    return envolvente(onda((420, 880), 0.12, "triangulo"), 0.005, 0.07)


@_fx("cerrar", 0.5)
def _cerrar():
    return envolvente(onda((880, 420), 0.11, "triangulo"), 0.004, 0.06)


@_fx("seleccion", 0.5)
def _seleccion():
    return mezcla(envolvente(onda(660, 0.07), 0.002, 0.03), (envolvente(onda(990, 0.07), 0.002, 0.03), 0.04))


@_fx("pestana", 0.4)
def _pestana():
    return envolvente(onda(1250, 0.05, "triangulo"), 0.001, 0.02)


@_fx("error", 0.5)
def _error():
    return mezcla(envolvente(onda((190, 130), 0.16, "cuadrada"), 0.004, 0.08), ganancia(envolvente(onda((95, 65), 0.16), 0.004, 0.08), 0.8))


@_fx("exito", 0.5)
def _exito():
    return _notas((72, 79), 0.07, 0.3, "triangulo", 0.13)


@_fx("guardar", 0.55)
def _guardar():
    return _notas((72, 76, 79), 0.08, 0.4, "triangulo", 0.16)


@_fx("pagina", 0.4)
def _pagina():
    return envolvente(pasa_banda(ruido(0.1, 4), 700, 3000), 0.01, 0.04)


# --- construir y herramientas ------------------------------------------------
@_fx("colocar", 0.7)
def _colocar():
    return _golpe(150, 70, 0.14, 0.05, 0.45, 700, 11)


@_fx("quitar", 0.6)
def _quitar():
    return mezcla(_golpe(210, 110, 0.12, 0.04, 0.4, 1100, 12), (envolvente(onda((300, 520), 0.08, "triangulo"), 0.004, 0.04), 0.05))


@_fx("cable", 0.5)
def _cable():
    click = envolvente(onda(2600, 0.02, "cuadrada"), 0.0005, 0.006)
    resto = envolvente(pasa_alto(ruido(0.07, 5), 2500), 0.001, 0.02)
    return mezcla(ganancia(click, 0.8), (ganancia(resto, 0.5), 0.005), (envolvente(onda(520, 0.06), 0.002, 0.02), 0.01))


@_fx("cable_quitar", 0.5)
def _cable_quitar():
    return mezcla(envolvente(onda(1400, 0.025, "cuadrada"), 0.0005, 0.007),
                  ganancia(envolvente(pasa_alto(ruido(0.07, 6), 1800), 0.001, 0.025), 0.4))


@_fx("pieza", 0.4)
def _pieza():
    return envolvente(onda((700, 1100), 0.06, "triangulo"), 0.002, 0.025)


@_fx("pico", 0.75)
def _pico():
    golpe = _golpe(260, 140, 0.12, 0.03, 0.9, 3500, 13)
    anillo = mezcla(*[ganancia(envolvente(onda(f, 0.3), 0.001, tau), a)
                      for f, a, tau in ((820, 0.5, 0.09), (2260, 0.3, 0.05), (4300, 0.12, 0.03))])
    return mezcla(golpe, (anillo, 0.004))


@_fx("taladro", 0.75)
def _taladro():
    dur = 0.55
    motor = tremolo(onda((70, 150), dur, "sierra"), 38, 0.5)
    chirrido = ganancia(pasa_banda(ruido(dur, 14), 800, 3500), 0.9)
    zumbido = mezcla(motor, chirrido)
    return mezcla(hinchar(zumbido, subida=0.35, bajada=0.65), (_golpe(120, 60, 0.18, 0.06, 0.4, 600, 15), dur - 0.12))


@_fx("maquina", 0.7)
def _maquina():
    clon = _golpe(110, 55, 0.2, 0.07, 0.5, 600, 16)
    zumbido = envolvente(tremolo(onda((60, 120), 0.45, "triangulo"), 24, 0.4), 0.02, 0.22)
    clic = envolvente(onda(1500, 0.03, "cuadrada"), 0.001, 0.01)
    return mezcla(clon, (ganancia(zumbido, 0.5), 0.08), (clic, 0.24))


@_fx("panel", 0.6)
def _panel():
    cristal = mezcla(*[ganancia(envolvente(onda(f, 0.5), 0.002, tau), a) for f, a, tau in ((1320, 0.5, 0.18), (1980, 0.35, 0.12), (2640, 0.2, 0.08))])
    return mezcla(_golpe(170, 90, 0.1, 0.035, 0.3, 700, 17), (cristal, 0.01))


@_fx("bateria", 0.65)
def _bateria():
    chispa = envolvente(onda((300, 1800), 0.18, "sierra"), 0.004, 0.08)
    return mezcla(_golpe(130, 65, 0.16, 0.05, 0.4, 500, 18), (ganancia(chispa, 0.4), 0.09), (ganancia(_campana(1100, 0.4), 0.3), 0.2))


@_fx("mejora", 0.6)
def _mejora():
    return mezcla(_notas((60, 64, 67, 72), 0.085, 0.35, "triangulo", 0.15), (_campana(mid(84), 0.7), 0.3))


@_fx("fabricar", 0.7)
def _fabricar():
    golpes = [(_golpe(180 - 20 * k, 90, 0.1, 0.03, 0.55, 2200, 20 + k), 0.11 * k) for k in range(3)]
    zumbido = envolvente(tremolo(onda((90, 180), 0.34, "sierra"), 30, 0.5), 0.02, 0.2)
    return mezcla(*golpes, (ganancia(zumbido, 0.25), 0.0), (ganancia(_campana(mid(88), 0.7), 0.55), 0.38))


@_fx("recoger", 0.55)
def _recoger():
    return envolvente(onda((660, 1500), 0.11, "triangulo"), 0.003, 0.06)


@_fx("recoger_varios", 0.55)
def _recoger_varios():
    return mezcla(envolvente(onda((600, 1300), 0.09, "triangulo"), 0.003, 0.05),
                  (envolvente(onda((900, 1800), 0.12, "triangulo"), 0.003, 0.07), 0.07))


@_fx("oxigeno", 0.6)
def _oxigeno():
    soplo = pasa_banda(ruido(0.65, 25), 500, 4500)
    return mezcla(hinchar(soplo, subida=0.4, bajada=0.6), (ganancia(envolvente(onda((300, 700), 0.25, "triangulo"), 0.01, 0.12), 0.15), 0.3))


@_fx("comer", 0.55)
def _comer():
    return mezcla(*[(envolvente(pasa_banda(ruido(0.07, 30 + k), 600, 3200), 0.002, 0.02), 0.11 * k) for k in range(3)])


@_fx("cosecha", 0.6)
def _cosecha():
    return mezcla(_comer(), (_notas((72, 76, 79), 0.06, 0.25, "triangulo", 0.1), 0.2))


@_fx("agua", 0.6)
def _agua():
    return mezcla(*[(envolvente(onda((900 + 250 * k, 450 + 120 * k), 0.12), 0.003, 0.05), 0.1 * k) for k in range(3)])


@_fx("riego", 0.6)
def _riego():
    chorro = hinchar(pasa_alto(ruido(0.9, 35), 2500), subida=0.2, bajada=0.8)
    gotas = [(envolvente(onda((1000 + 170 * k, 520 + 90 * k), 0.1), 0.003, 0.04), 0.18 + 0.13 * k) for k in range(5)]
    return mezcla(ganancia(chorro, 0.5), *[(ganancia(g, 0.35), r) for g, r in gotas])


@_fx("sembrar", 0.5)
def _sembrar():
    return mezcla(envolvente(pasa_banda(ruido(0.18, 40), 400, 2000), 0.01, 0.07), (envolvente(onda((500, 760), 0.1, "triangulo"), 0.003, 0.05), 0.08))


@_fx("almacen", 0.6)
def _almacen():
    return mezcla(_golpe(180, 100, 0.1, 0.035, 0.45, 1400, 41), (envolvente(onda(740, 0.1, "triangulo"), 0.002, 0.04), 0.06))


@_fx("listo", 0.35)
def _listo():
    return _notas((84, 91), 0.09, 0.25, "triangulo", 0.12)


# --- base ------------------------------------------------------------------
@_fx("puerta", 0.7)
def _puerta():
    siseo = hinchar(pasa_banda(ruido(0.5, 50), 600, 5000), subida=0.25, bajada=0.75)
    return mezcla(ganancia(siseo, 0.9), (_golpe(95, 50, 0.2, 0.08, 0.3, 500, 51), 0.32))


@_fx("dormir", 0.55)
def _dormir():
    return _notas((79, 76, 72, 67), 0.34, 1.0, "seno", 0.4)


@_fx("despertar", 0.55)
def _despertar():
    return mezcla(_notas((67, 72, 76, 79), 0.2, 0.8, "seno", 0.3), (ganancia(_campana(mid(91), 1.0), 0.3), 0.6))


# --- pasos ---------------------------------------------------------------------
@_fx("paso_luna", 0.28)
def _paso_luna():
    return _golpe(110, 60, 0.09, 0.03, 0.5, 450, 60)


@_fx("paso_marte", 0.3)
def _paso_marte():
    return mezcla(_golpe(120, 70, 0.08, 0.025, 0.2, 700, 61), (envolvente(pasa_banda(ruido(0.09, 62), 500, 2600), 0.002, 0.03), 0.01))


@_fx("paso_base", 0.3)
def _paso_base():
    return mezcla(_golpe(210, 120, 0.07, 0.022, 0.3, 1800, 63), (ganancia(envolvente(onda(360, 0.09), 0.001, 0.03), 0.4), 0.0))


# --- alertas y clima --------------------------------------------------------------
@_fx("alerta_baja", 0.5)
def _alerta_baja():
    bip = envolvente(onda(880, 0.1, "triangulo"), 0.004, 0.05)
    return mezcla(bip, (bip, 0.17))


@_fx("alerta_critica", 0.65)
def _alerta_critica():
    bip = envolvente(onda(1240, 0.09, "cuadrada"), 0.003, 0.05)
    return mezcla(bip, (bip, 0.14), (bip, 0.28))


@_fx("latido", 0.55)
def _latido():
    uno = envolvente(onda((75, 48), 0.14), 0.004, 0.06)
    return mezcla(uno, (ganancia(uno, 0.7), 0.17))


@_fx("geiger", 0.3)
def _geiger():
    return envolvente(pasa_alto(ruido(0.012, 70), 1500), 0.0002, 0.003)


@_fx("sirena", 0.45)
def _sirena():
    dur = 1.7
    tono = []
    ph = 0.0
    n = int(dur * TASA)
    for i in range(n):
        f = 820 + 140 * math.sin(DOS_PI * 1.5 * i / TASA)       # sube y baja dos veces y media
        tono.append(0.6 * math.sin(ph) + 0.25 * math.sin(2 * ph))
        ph += DOS_PI * f / TASA
    return envolvente(tono, 0.03, None, 0.12)


@_fx("cme", 0.6)
def _cme():
    return mezcla(hinchar(onda((55, 170), 1.8, "sierra"), subida=0.8, bajada=0.2),
                  ganancia(hinchar(pasa_bajo(ruido(1.8, 71), 500), subida=0.8, bajada=0.2), 0.5))


@_fx("alarma", 0.42)
def _alarma():
    pulso = envolvente(onda(560, 0.28, "cuadrada"), 0.006, None, 0.05)
    hueco = silencio(0.12)
    return pegar(pulso, hueco, pulso, hueco, pulso)


@_fx("calma", 0.5)
def _calma():
    return mezcla(_notas((79, 76, 72), 0.18, 0.7, "seno", 0.3), (_campana(mid(84), 0.9), 0.5))


@_fx("noche_paneles", 0.5)
def _noche_paneles():
    return envolvente(onda((620, 140), 0.55, "triangulo"), 0.01, 0.3)


@_fx("polvo_aviso", 0.6)
def _polvo_aviso():
    viento = pasa_banda(ruido(2.0, 80), (250, 900), 2500)
    return hinchar(viento, subida=0.85, bajada=0.15)


@_fx("polvo_llega", 0.65)
def _polvo_llega():
    viento = pasa_bajo(ruido(2.2, 81), (900, 400))
    return mezcla(hinchar(viento, subida=0.25, bajada=0.75), ganancia(hinchar(pasa_alto(ruido(2.2, 82), 1800), subida=0.2, bajada=0.8), 0.3))


@_fx("sismo", 0.7)
def _sismo():
    dur = 2.8
    retumbo = tremolo(mezcla(onda((38, 30), dur), ganancia(onda(55, dur), 0.6), ganancia(pasa_bajo(ruido(dur, 83), 120), 1.4)), 7, 0.5)
    return hinchar(retumbo, subida=0.2, bajada=0.8)


@_fx("impacto", 0.85)
def _impacto():
    dur = 2.0
    estallido = envolvente(pasa_bajo(ruido(dur, 84), (2800, 120)), 0.002, 0.45)
    grave = envolvente(onda((95, 28), dur), 0.002, 0.5)
    escombros = [(envolvente(pasa_banda(ruido(0.08, 85 + k), 600, 3000), 0.002, 0.03), 0.45 + 0.17 * k) for k in range(5)]
    return mezcla(estallido, ganancia(grave, 1.2), *[(ganancia(e, 0.35), r) for e, r in escombros])


@_fx("remolino", 0.55)
def _remolino():
    dur = 2.4
    soplo = pasa_banda(ruido(dur, 90), (300, 1600), 2200)
    return hinchar(tremolo(soplo, 5, 0.3), subida=0.5, bajada=0.5)


@_fx("antena_contacto", 0.55)
def _antena_contacto():
    pitidos = [(envolvente(onda(mid(m), 0.06, "cuadrada"), 0.002, 0.03), 0.07 * k) for k, m in enumerate((84, 88, 84, 91, 88, 96))]
    return mezcla(*pitidos, (ganancia(_campana(mid(79), 0.9), 0.4), 0.42))


@_fx("antena_perdida", 0.5)
def _antena_perdida():
    return mezcla(_notas((84, 79, 72), 0.12, 0.2, "cuadrada", 0.07), (ganancia(pasa_alto(ruido(0.3, 91), 2000), 0.12), 0.1))


@_fx("dato", 0.45)
def _dato():
    return mezcla(_campana(mid(79), 0.8), (_campana(mid(86), 0.9), 0.12))


# --- vida, nave, compañero --------------------------------------------------------
@_fx("muerte", 0.7)
def _muerte():
    dur = 3.0
    caida = envolvente(onda((220, 38), dur, "triangulo"), 0.02, 1.2)
    aire = envolvente(pasa_bajo(ruido(dur, 95), (1200, 150)), 0.02, 1.0)
    return mezcla(caida, ganancia(aire, 0.6))


@_fx("rescate", 0.6)
def _rescate():
    return mezcla(_oxigeno(), (_notas((60, 67, 72, 76, 79), 0.12, 0.6, "triangulo", 0.25), 0.2))


@_fx("despegue", 0.9)
def _despegue():
    dur = 4.2
    rugido = hinchar(pasa_bajo(ruido(dur, 96), (400, 1800)), subida=0.55, bajada=0.45)
    motor = hinchar(tremolo(onda((48, 110), dur, "sierra"), 21, 0.45), subida=0.65, bajada=0.35)
    chorro = ganancia(hinchar(pasa_alto(ruido(dur, 97), 2500), subida=0.7, bajada=0.3), 0.4)
    return mezcla(ganancia(rugido, 1.0), ganancia(motor, 0.55), chorro)


@_fx("llegada", 0.6)
def _llegada():
    return mezcla(*[(envolvente(onda(mid(m), 1.6), 0.02, 0.9), 0.0) for m in (60, 64, 67)], (ganancia(_campana(mid(84), 1.2), 0.5), 0.3))


@_fx("final", 0.65)
def _final():
    return mezcla(_notas((60, 64, 67, 72), 0.2, 1.3, "triangulo", 0.5), (_notas((72, 76, 79, 84), 0.0, 1.8, "seno", 0.9, 0.8), 0.0),
                  (ganancia(_campana(mid(96), 1.5), 0.4), 0.85))


@_fx("companero", 0.55)
def _companero():
    return mezcla(*[(envolvente(onda((mid(m), mid(m) * 1.08), 0.08, "cuadrada"), 0.003, 0.04), 0.085 * k) for k, m in enumerate((76, 83, 79, 88))])


@_fx("companero_pila", 0.55)
def _companero_pila():
    return mezcla(envolvente(onda((300, 2000), 0.35, "cuadrada"), 0.01, 0.2), (_campana(mid(91), 0.5), 0.36))


@_fx("companero_guardar", 0.5)
def _companero_guardar():
    return mezcla(*[(envolvente(onda((mid(m), mid(m) * 0.92), 0.08, "cuadrada"), 0.003, 0.04), 0.085 * k) for k, m in enumerate((88, 79, 83, 76))])


@_fx("cofre", 0.5)
def _cofre():
    return mezcla(_golpe(130, 80, 0.12, 0.04, 0.4, 900, 98), (envolvente(onda((400, 650), 0.12, "triangulo"), 0.004, 0.06), 0.07))


# ----------------------------------------------------------------------------
# Música y ambiente (bucles). Todo es periódico: al repetirse no se oye el corte.
# ----------------------------------------------------------------------------
MUSICAS = {}          # nombre -> (función, volumen)


def _mus(nombre, vol=0.5):
    def poner(f):
        MUSICAS[nombre] = (f, vol)
        return f
    return poner


def _pad(acordes, dur_acorde, tasa=TASA_MUSICA, parciales=((1, 1.0), (2, 0.35), (3, 0.12)), brillo_lfo=0.0):
    """Colchón de acordes: cada acorde (lista de notas MIDI) suena `dur_acorde` s y
    se mezcla con el siguiente con una campana de coseno. Da la vuelta (el último
    se funde con el primero), así que sirve para un bucle."""
    n = int(len(acordes) * dur_acorde * tasa)
    salida = [0.0] * n
    largo = int(2 * dur_acorde * tasa)
    ventana = [0.5 - 0.5 * math.cos(DOS_PI * i / largo) for i in range(largo)]
    for k, acorde in enumerate(acordes):
        inicio = int((k - 0.5) * dur_acorde * tasa)
        bloque = [0.0] * largo
        for m in acorde:
            f = mid(m)
            for razon, amp in parciales:
                for desafina in (0.997, 1.003):               # dos voces apenas desafinadas: "coro"
                    w = DOS_PI * f * razon * desafina / tasa
                    fase = (k * 1.7 + m) % DOS_PI
                    a = amp * 0.5
                    for i in range(largo):
                        bloque[i] += a * math.sin(fase + w * i)
        for i in range(largo):
            salida[(inicio + i) % n] += bloque[i] * ventana[i]
    return salida


def _campanadas(notas, dur_total, dur_nota=2.6, tasa=TASA_MUSICA, vol=0.5):
    """Campanitas sueltas colocadas en el bucle: [(segundo, nota MIDI), ...]. Dan
    la vuelta al final (su cola cae sobre el principio)."""
    n = int(dur_total * tasa)
    salida = [0.0] * n
    for seg, m in notas:
        c = _campana(mid(m), dur_nota, 0.8, tasa)
        o = int(seg * tasa)
        for i, v in enumerate(c):
            salida[(o + i) % n] += v * vol
    return salida


def _suavizar_final(x, tasa=TASA_MUSICA):
    return x


@_mus("musica_menu", 0.5)
def _musica_menu():
    acordes = [(45, 57, 60, 64), (41, 57, 60, 65), (48, 55, 60, 64), (43, 55, 59, 62)]     # Am7 Fmaj7 C G
    pad = _pad(acordes, 3.5)
    arp = []
    for k, grupo in enumerate(((69, 72, 76, 72), (65, 69, 72, 69), (67, 72, 76, 72), (62, 67, 71, 67))):
        for j, m in enumerate(grupo):
            arp.append((k * 3.5 + j * 0.875, m))
    return normalizar(mezcla(pad, ganancia(_campanadas(arp, 14.0, 2.0, vol=0.6), 0.9)), 0.9)


@_mus("musica_luna", 0.42)
def _musica_luna():
    acordes = [(38, 50, 57), (34, 46, 53), (36, 48, 55), (31, 43, 50)]                     # grave y quieto
    pad = _pad(acordes, 4.0, parciales=((1, 1.0), (2, 0.25)))
    notas = [(1.0, 74), (4.6, 77), (7.9, 72), (11.5, 69), (14.2, 74)]
    return normalizar(mezcla(pad, _campanadas(notas, 16.0, 3.2, vol=0.5)), 0.85)


@_mus("musica_marte", 0.42)
def _musica_marte():
    acordes = [(38, 50, 57, 62), (36, 48, 55, 60), (34, 46, 53, 62), (36, 48, 55, 64)]       # Re menor, más cálido
    pad = _pad(acordes, 4.0, parciales=((1, 1.0), (2, 0.4), (3, 0.2)))
    pulso = envolvente(tremolo(onda(mid(26), 16.0, "triangulo", TASA_MUSICA), 0.5, 0.8, TASA_MUSICA), 0.01, None, 0.01, TASA_MUSICA)
    notas = [(0.5, 69), (3.1, 72), (6.8, 74), (9.4, 69), (12.7, 65)]
    return normalizar(mezcla(pad, ganancia(pulso, 0.5), _campanadas(notas, 16.0, 3.0, vol=0.5)), 0.85)


@_mus("musica_base", 0.38)
def _musica_base():
    acordes = [(41, 53, 60, 64), (43, 55, 62, 65), (40, 52, 59, 62), (45, 57, 60, 64)]       # cálido, de interior
    pad = _pad(acordes, 3.5, parciales=((1, 1.0), (2, 0.5), (3, 0.25)))
    notas = [(0.0, 72), (3.5, 76), (7.0, 71), (10.5, 69)]
    return normalizar(mezcla(pad, _campanadas(notas, 14.0, 2.2, vol=0.35)), 0.85)


@_mus("musica_viaje", 0.5)
def _musica_viaje():
    acordes = [(33, 45, 52, 57), (36, 48, 55, 60), (29, 41, 48, 53), (31, 43, 50, 55)]        # amplio, de viaje
    pad = _pad(acordes, 4.0, parciales=((1, 1.0), (2, 0.5), (3, 0.3), (4, 0.15)))
    notas = [(0.0, 76), (2.0, 81), (4.0, 84), (6.0, 88), (8.0, 84), (10.0, 83), (12.0, 79), (14.0, 76)]
    return normalizar(mezcla(pad, _campanadas(notas, 16.0, 3.0, vol=0.55)), 0.85)


@_mus("musica_final", 0.5)
def _musica_final():
    acordes = [(48, 60, 64, 67), (53, 60, 65, 69), (43, 59, 62, 67), (48, 60, 64, 67)]         # C F G C: llegada
    pad = _pad(acordes, 3.5, parciales=((1, 1.0), (2, 0.45), (3, 0.25)))
    notas = [(0.0, 79), (1.75, 84), (3.5, 81), (5.25, 84), (7.0, 83), (8.75, 79), (10.5, 84), (12.25, 88)]
    return normalizar(mezcla(pad, _campanadas(notas, 14.0, 2.4, vol=0.55)), 0.9)


# Ambientes: bucles cortos de fondo (se suben o bajan según dónde estás).
@_mus("ambiente_viento", 0.5)
def _ambiente_viento():
    dur = 6.0
    t = TASA_MUSICA
    a = pasa_banda(ruido(dur + 0.6, 100, t), 120, 700, t)
    b = pasa_bajo(ruido(dur + 0.6, 101, t), 260, t)
    n = len(a)
    onda_lenta = [0.65 + 0.35 * math.sin(DOS_PI * 0.33 * i / t) for i in range(n)]
    x = [(a[i] * 1.4 + b[i] * 1.2) * onda_lenta[i] for i in range(n)]
    return normalizar(bucle_sin_costura(x, 0.6, t), 0.8)


@_mus("ambiente_traje", 0.5)
def _ambiente_traje():
    """Dentro del traje: zumbido grave de los sistemas y una respiración lenta."""
    dur = 5.0
    t = TASA_MUSICA
    n = int(dur * t)
    zumbido = [0.5 * math.sin(DOS_PI * 100 * i / t) + 0.25 * math.sin(DOS_PI * 200 * i / t + 1) + 0.1 * math.sin(DOS_PI * 50 * i / t) for i in range(n)]
    soplo = pasa_banda(ruido(dur + 0.4, 102, t), 300, 2200, t)
    soplo = bucle_sin_costura(soplo, 0.4, t)
    resp = [max(0.0, math.sin(DOS_PI * i / (t * 5.0))) ** 2 for i in range(n)]
    x = [zumbido[i] * 0.5 + soplo[i] * resp[i] * 1.6 for i in range(n)]
    return normalizar(x, 0.8)


@_mus("ambiente_base", 0.5)
def _ambiente_base():
    """Ventilación de la base: zumbido parejo con un siseo de aire."""
    dur = 4.0
    t = TASA_MUSICA
    n = int(dur * t)
    hum = [0.5 * math.sin(DOS_PI * 120 * i / t) + 0.3 * math.sin(DOS_PI * 240 * i / t + 0.5) + 0.12 * math.sin(DOS_PI * 60 * i / t) for i in range(n)]
    aire = bucle_sin_costura(pasa_banda(ruido(dur + 0.4, 103, t), 500, 3000, t), 0.4, t)
    x = [hum[i] * 0.7 + aire[i] * 0.55 for i in range(n)]
    return normalizar(x, 0.8)


@_mus("ambiente_maquina", 0.5)
def _ambiente_maquina():
    """Zumbido de una máquina trabajando (se oye si estás cerca)."""
    dur = 2.0
    t = TASA_MUSICA
    n = int(dur * t)
    x = [0.5 * math.sin(DOS_PI * 90 * i / t) * (0.75 + 0.25 * math.sin(DOS_PI * 12 * i / t))
         + 0.25 * math.sin(DOS_PI * 180 * i / t + 1.0) + 0.1 * math.sin(DOS_PI * 270 * i / t) for i in range(n)]
    return normalizar(x, 0.8)


TASA_DE = {nombre: TASA_MUSICA for nombre in MUSICAS}


# ----------------------------------------------------------------------------
# De muestras a pygame
# ----------------------------------------------------------------------------
def a_wav(x, tasa=TASA):
    """La pista como un archivo WAV mono de 16 bits, en memoria."""
    datos = array.array("h", [max(-32767, min(32767, int(v * 32767))) for v in x])
    if sys.byteorder == "big":
        datos.byteswap()
    memoria = io.BytesIO()
    with wave.open(memoria, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(tasa)
        w.writeframes(datos.tobytes())
    memoria.seek(0)
    return memoria


def muestras(nombre):
    """(pista, tasa, volumen) de un efecto o de una pista de música, ya normalizada."""
    if nombre in EFECTOS:
        f, vol = EFECTOS[nombre]
        return normalizar(f(), 0.95), TASA, vol
    f, vol = MUSICAS[nombre]
    return normalizar(f(), 0.95), TASA_MUSICA, vol


def nombres():
    return list(EFECTOS) + list(MUSICAS)


def _archivo_de(carpeta, nombre):
    for ext in (".ogg", ".wav"):
        ruta = os.path.join(carpeta, nombre + ext)
        if os.path.isfile(ruta):
            return ruta
    return None


def preparar(nombre, carpeta=None):
    """Lo que hay que hacer para tener `nombre`, sin tocar pygame (se puede llamar
    desde otro hilo mientras el juego sigue): ("archivo", ruta, volumen) si hay un
    archivo en `carpeta`, o ("wav", memoria, volumen) con el sonido sintetizado."""
    _, vol = EFECTOS.get(nombre) or MUSICAS[nombre]
    ruta = _archivo_de(carpeta, nombre) if carpeta else None
    if ruta:
        return "archivo", ruta, vol
    x, tasa, vol = muestras(nombre)
    return "wav", a_wav(x, tasa), vol


def a_sonido(preparado):
    """pygame.mixer.Sound de lo que devolvió preparar() (solo desde el hilo
    principal), o None si algo falla."""
    import pygame
    tipo, origen, vol = preparado
    try:
        sonido = pygame.mixer.Sound(origen) if tipo == "archivo" else pygame.mixer.Sound(file=origen)
        sonido.set_volume(vol)
        return sonido
    except (pygame.error, OSError, ValueError, wave.Error):
        return None


def exportar(carpeta):
    """Escribe un .wav por cada sonido (para oírlos con cualquier reproductor)."""
    os.makedirs(carpeta, exist_ok=True)
    for nombre in nombres():
        x, tasa, _ = muestras(nombre)
        with open(os.path.join(carpeta, nombre + ".wav"), "wb") as f:
            f.write(a_wav(x, tasa).getvalue())
        print(f"{nombre}.wav  {len(x) / tasa:.2f} s")


if __name__ == "__main__":
    exportar(sys.argv[1] if len(sys.argv) > 1 else "sonidos_exportados")
